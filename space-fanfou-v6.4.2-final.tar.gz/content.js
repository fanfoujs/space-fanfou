(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ("undefined" !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && "object" === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value
    });
    if (2 & mode && "string" != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function() {
      return module["default"];
    } : function() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 66);
})([ function(module, exports, __webpack_require__) {
  (function(__filename) {
    function loadConstants() {
      const context = __webpack_require__(50);
      return context.keys().reduce((constants, key) => key.endsWith(__filename) ? constants : Object.assign(constants, context(key)), {});
    }
    module.exports = Object.assign(exports, loadConstants());
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  function isQueryable(object) {
    return "function" === typeof object.querySelectorAll;
  }
  function select(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    return (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelector(String(selectors));
  }
  function selectLast(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    const all = (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelectorAll(String(selectors));
    return all[all.length - 1];
  }
  function selectExists(selectors, baseElement) {
    if (2 === arguments.length) return Boolean(select(selectors, baseElement));
    return Boolean(select(selectors));
  }
  function selectAll(selectors, baseElements) {
    if (2 === arguments.length && !baseElements) return [];
    if (!baseElements || isQueryable(baseElements)) {
      const elements = (null !== baseElements && void 0 !== baseElements ? baseElements : document).querySelectorAll(String(selectors));
      return Array.apply(null, elements);
    }
    const all = [];
    for (let i = 0; i < baseElements.length; i++) {
      const current = baseElements[i].querySelectorAll(String(selectors));
      for (let ii = 0; ii < current.length; ii++) all.push(current[ii]);
    }
    const array = [];
    all.forEach((function(v) {
      array.push(v);
    }));
    return array;
  }
  select.last = selectLast;
  select.exists = selectExists;
  select.all = selectAll;
  __webpack_exports__["a"] = select;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const ManyKeysMap = __webpack_require__(36);
  const pDefer = __webpack_require__(37);
  const cache = new ManyKeysMap;
  const isDomReady = () => "interactive" === document.readyState || "complete" === document.readyState;
  const elementReady = (selector, {target = document, stopOnDomReady = true, timeout = 1 / 0} = {}) => {
    const cacheKeys = [ target, selector, stopOnDomReady, timeout ];
    const cachedPromise = cache.get(cacheKeys);
    if (cachedPromise) return cachedPromise;
    let rafId;
    const deferred = pDefer();
    const {promise} = deferred;
    cache.set(cacheKeys, promise);
    const stop = () => {
      cancelAnimationFrame(rafId);
      cache.delete(cacheKeys, promise);
      deferred.resolve();
    };
    if (timeout !== 1 / 0) setTimeout(stop, timeout);
    (function check() {
      const element = target.querySelector(selector);
      if (element) {
        deferred.resolve(element);
        stop();
      } else if (stopOnDomReady && isDomReady()) stop(); else rafId = requestAnimationFrame(check);
    })();
    return Object.assign(promise, {
      stop
    });
  };
  module.exports = elementReady;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return functionOnce;
  }));
  var functionOnce = once;
  function once(fn) {
    var called, value;
    if ("function" !== typeof fn) throw new Error("expected a function but got " + fn);
    return function() {
      if (called) return value;
      called = true;
      value = fn.apply(this, arguments);
      fn = void 0;
      return value;
    };
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var wrapper = __webpack_require__(5);
  class Deferred {
    constructor() {
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
      Object.freeze(this);
    }
  }
  var safelyInvokeFns = __webpack_require__(13);
  var extensionUnloaded = __webpack_require__(12);
  var arrayUniquePush = __webpack_require__(8);
  var arrayRemove = __webpack_require__(9);
  var constants = __webpack_require__(0);
  let port;
  let id = 0;
  const deferreds = {};
  const broadcastListeners = [];
  function onMessage({type, senderId, message}) {
    if (type === constants["BROADCASTING_MESSAGE"]) messaging.broadcast(message); else if (null != senderId) {
      const d = deferreds[senderId];
      d.resolve(message);
      delete deferreds[senderId];
    }
  }
  function onDisconnect() {
    extensionUnloaded["a"].trigger();
  }
  const messaging = Object(wrapper["a"])({
    install() {
      port = chrome.runtime.connect();
      port.onMessage.addListener(onMessage);
      port.onDisconnect.addListener(onDisconnect);
    },
    uninstall() {
      port = null;
      broadcastListeners.length = 0;
    },
    registerBroadcastListener(fn) {
      Object(arrayUniquePush["a"])(broadcastListeners, fn);
    },
    unregisterBroadcastListener(fn) {
      Object(arrayRemove["a"])(broadcastListeners, fn);
    },
    broadcast(message) {
      Object(safelyInvokeFns["a"])({
        fns: broadcastListeners,
        args: [ message ]
      });
    },
    postMessage(message) {
      const senderId = id++;
      const d = deferreds[senderId] = new Deferred;
      port.postMessage({
        senderId,
        message
      });
      return d.promise;
    }
  });
  __webpack_exports__["a"] = messaging;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var is_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11);
  var is_promise__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(is_promise__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
  var _libs_noop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17);
  function toBooleanPromise(x) {
    return "boolean" === typeof x ? x : is_promise__WEBPACK_IMPORTED_MODULE_0___default()(x) ? x.then(toBooleanPromise) : Promise.resolve(true);
  }
  __webpack_exports__["a"] = module => {
    let promise;
    const {install = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], uninstall = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], ...rest} = module;
    _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__["a"].addListener(uninstall);
    return {
      ...rest,
      ready() {
        return promise || (promise = toBooleanPromise(install()));
      }
    };
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  let outputLevel = 1;
  if (true) outputLevel = 2;
  function log(level, logger, ...message) {
    if (level >= outputLevel) logger("[SpaceFanfou]", ...message);
  }
  __webpack_exports__["a"] = {
    debug(...message) {
      log(0, console.log, ...message);
    },
    info(...message) {
      log(1, console.log, ...message);
    },
    error(...message) {
      log(2, console.error, ...message);
    }
  };
}, function(module, exports) {
  module.exports = pick;
  function pick(obj, select) {
    var result = {};
    if ("string" === typeof select) select = [].slice.call(arguments, 1);
    var len = select.length;
    for (var i = 0; i < len; i++) {
      var key = select[i];
      if (key in obj) result[key] = obj[key];
    }
    return result;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    if (!array.includes(element)) array.push(element);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    const index = array.indexOf(element);
    if (-1 !== index) array.splice(index, 1);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var defined__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23);
  var defined__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(defined__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6);
  function defaultExceptionHandler(error) {
    _libs_log__WEBPACK_IMPORTED_MODULE_1__["a"].error(error);
  }
  __webpack_exports__["a"] = opts => {
    let fn;
    if ("function" === typeof opts) {
      fn = opts;
      opts = {};
    } else fn = opts.fn;
    const exceptionHandler = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.exceptionHandler, defaultExceptionHandler);
    const args = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.args, []);
    try {
      fn(...args);
    } catch (error) {
      exceptionHandler(error);
    }
  };
}, function(module, exports) {
  module.exports = isPromise;
  module.exports.default = isPromise;
  function isPromise(obj) {
    return !!obj && ("object" === typeof obj || "function" === typeof obj) && "function" === typeof obj.then;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  __webpack_exports__["a"] = {
    trigger() {
      const event = new CustomEvent(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"]);
      window.dispatchEvent(event);
    },
    addListener(fn) {
      window.addEventListener(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"], fn, {
        once: true
      });
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
  __webpack_exports__["a"] = opts => {
    if (Array.isArray(opts)) opts = {
      fns: opts
    };
    const {fns, ...restOpts} = opts;
    for (const fn of fns) Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__["a"])({
      fn,
      ...restOpts
    });
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(useSourceMap) {
    var list = [];
    list.toString = function() {
      return this.map((function(item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) return "@media ".concat(item[2], " {").concat(content, "}");
        return content;
      })).join("");
    };
    list.i = function(modules, mediaQuery, dedupe) {
      if ("string" === typeof modules) modules = [ [ null, modules, "" ] ];
      var alreadyImportedModules = {};
      if (dedupe) for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (null != id) alreadyImportedModules[id] = true;
      }
      for (var _i = 0; _i < modules.length; _i++) {
        var item = [].concat(modules[_i]);
        if (dedupe && alreadyImportedModules[item[0]]) continue;
        if (mediaQuery) if (!item[2]) item[2] = mediaQuery; else item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        list.push(item);
      }
    };
    return list;
  };
  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || "";
    var cssMapping = item[3];
    if (!cssMapping) return content;
    if (useSourceMap && "function" === typeof btoa) {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map((function(source) {
        return "/*# sourceURL=".concat(cssMapping.sourceRoot || "").concat(source, " */");
      }));
      return [ content ].concat(sourceURLs).concat([ sourceMapping ]).join("\n");
    }
    return [ content ].join("\n");
  }
  function toComment(sourceMap) {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    return "/*# ".concat(data, " */");
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
  var _libs_noop__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17);
  function forever() {
    return false;
  }
  async function keepRetry(opts) {
    const {checker, executor = _libs_noop__WEBPACK_IMPORTED_MODULE_1__["a"], delay = 100, until = forever, resolve, reject} = opts;
    if (await checker()) {
      Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__["a"])(executor);
      resolve(true);
    } else if (until()) reject(); else setTimeout(keepRetry, delay, opts);
  }
  __webpack_exports__["a"] = opts => new Promise((resolve, reject) => {
    keepRetry({
      ...opts,
      resolve,
      reject
    });
  });
}, function(module, exports, __webpack_require__) {
  (function(global, factory) {
    true ? factory(exports) : void 0;
  })(0, (function(exports) {
    "use strict";
    const LOWER_CASE$1 = "LOWER_CASE";
    const UPPER_CASE$1 = "UPPER_CASE";
    const CAMEL_CASE$1 = "CAMEL_CASE";
    const PASCAL_CASE$1 = "PASCAL_CASE";
    const KEBAB_CASE$1 = "KEBAB_CASE";
    const SNAKE_CASE$1 = "SNAKE_CASE";
    const TRAIN_CASE$1 = "TRAIN_CASE";
    const LOWER_CASE = /^[^A-Z]+$/;
    const UPPER_CASE = /^[^a-z]+$/;
    const CAMEL_CASE = /^[a-z]+(?:[A-Z][a-z\d]+)*$/;
    const PASCAL_CASE = /^[A-Z][a-z\d]+(?:[A-Z][a-z\d]+)*$/;
    const KEBAB_CASE = /^[a-z][a-z\d]+(-[a-z\d]+)+$/;
    const SNAKE_CASE = /^[a-z][a-z\d]+(_[a-z\d]+)+$/;
    const TRAIN_CASE = /^[A-Z][a-z\d]+(-[A-Z][a-z\d]+)+$/;
    const FRAGMENT = /([A-Za-z\d]+)+/g;
    const isString = _isString;
    const isLowerCase = _is(LOWER_CASE);
    const isUpperCase = _is(UPPER_CASE);
    const isCamelCase = _is(CAMEL_CASE);
    const isPascalCase = _is(PASCAL_CASE);
    const isKebabCase = _is(KEBAB_CASE);
    const isSnakeCase = _is(SNAKE_CASE);
    const isTrainCase = _is(TRAIN_CASE);
    const caseOf = _caseOf;
    const toLowerCase = _toLowerCase;
    const toUpperCase = _toUpperCase;
    const toCamelCase = _toCamelCase;
    const toPascalCase = _toPascalCase;
    const toKebabCase = _toKebabCase;
    const toSnakeCase = _toSnakeCase;
    const toTrainCase = _toTrainCase;
    function _isString(any) {
      return "string" === typeof any || null !== any && "object" === typeof any && any.constructor === String;
    }
    function _is(pattern) {
      return function(str) {
        return isString(str) ? pattern.test(str) : false;
      };
    }
    function _caseOf(str) {
      if (isCamelCase(str)) return CAMEL_CASE$1; else if (isPascalCase(str)) return PASCAL_CASE$1; else if (isKebabCase(str)) return KEBAB_CASE$1; else if (isSnakeCase(str)) return SNAKE_CASE$1; else if (isTrainCase(str)) return TRAIN_CASE$1; else if (isLowerCase(str)) return LOWER_CASE$1; else if (isUpperCase(str)) return UPPER_CASE$1; else return null;
    }
    function _toLowerCase(str) {
      return String.prototype.toLowerCase.call(String(str));
    }
    function _toUpperCase(str) {
      return String.prototype.toUpperCase.call(String(str));
    }
    function _toCamelCase(str) {
      return _fragment(_toLowerCase(String(str))).map((frag, idx) => 0 === idx ? frag : _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toPascalCase(str) {
      return _fragment(_toLowerCase(String(str))).map(frag => _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toKebabCase(str) {
      return _fragment(_toLowerCase(String(str))).join("-");
    }
    function _toSnakeCase(str) {
      return _fragment(_toLowerCase(String(str))).join("_");
    }
    function _toTrainCase(str) {
      return _fragment(toLowerCase(String(str))).map(frag => toUpperCase(frag[0]) + _tail(frag)).join("-");
    }
    function _tail(str) {
      return String.prototype.slice.call(str, 1);
    }
    function _fragment(str) {
      return String.prototype.match.call(str, FRAGMENT);
    }
    exports.caseOf = caseOf;
    exports.isCamelCase = isCamelCase;
    exports.isKebabCase = isKebabCase;
    exports.isLowerCase = isLowerCase;
    exports.isPascalCase = isPascalCase;
    exports.isSnakeCase = isSnakeCase;
    exports.isString = isString;
    exports.isTrainCase = isTrainCase;
    exports.isUpperCase = isUpperCase;
    exports.toCamelCase = toCamelCase;
    exports.toKebabCase = toKebabCase;
    exports.toLowerCase = toLowerCase;
    exports.toPascalCase = toPascalCase;
    exports.toSnakeCase = toSnakeCase;
    exports.toTrainCase = toTrainCase;
    exports.toUpperCase = toUpperCase;
  }));
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = () => {};
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var is_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11);
  var is_promise__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(is_promise__WEBPACK_IMPORTED_MODULE_0__);
  __webpack_exports__["a"] = iterable => new Promise(resolve => {
    const total = iterable.length;
    let count = 0;
    let done = false;
    if (0 === total) return resolve(true);
    function check(value) {
      if (!value) return fail();
      if (++count === total) {
        done = true;
        resolve(true);
      }
    }
    function fail() {
      done = true;
      resolve(false);
    }
    for (const item of iterable) {
      if (done) return;
      if (is_promise__WEBPACK_IMPORTED_MODULE_0___default()(item)) item.then(check, fail); else check(item);
    }
  });
}, function(module, exports) {
  module.exports = function(ms) {
    return new Promise((function(resolve) {
      setTimeout(resolve, ms);
    }));
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const svgTagNames = __webpack_require__(38);
  const flatten = __webpack_require__(39);
  const IS_NON_DIMENSIONAL = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
  const excludeSvgTags = [ "a", "audio", "canvas", "iframe", "script", "video" ];
  const svgTags = svgTagNames.filter(name => !excludeSvgTags.includes(name));
  const isSVG = tagName => svgTags.includes(tagName);
  const setCSSProps = (el, style) => {
    Object.keys(style).forEach(name => {
      let value = style[name];
      if ("number" === typeof value && !IS_NON_DIMENSIONAL.test(name)) value += "px";
      el.style[name] = value;
    });
  };
  const createElement = tagName => {
    if (isSVG(tagName)) return document.createElementNS("http://www.w3.org/2000/svg", tagName);
    if (tagName === DocumentFragment) return document.createDocumentFragment();
    return document.createElement(tagName);
  };
  const setAttribute = (el, name, value) => {
    if (void 0 === value || null === value) return;
    if (/^xlink[AHRST]/.test(name)) el.setAttributeNS("http://www.w3.org/1999/xlink", name.replace("xlink", "xlink:").toLowerCase(), value); else el.setAttribute(name, value);
  };
  const build = (tagName, attrs, children) => {
    const el = createElement(tagName);
    Object.keys(attrs).forEach(name => {
      const value = attrs[name];
      if ("class" === name || "className" === name) setAttribute(el, "class", value); else if ("style" === name) setCSSProps(el, value); else if (0 === name.indexOf("on")) {
        const eventName = name.slice(2).toLowerCase();
        el.addEventListener(eventName, value);
      } else if ("dangerouslySetInnerHTML" === name) el.innerHTML = value.__html; else if ("key" !== name && false !== value) setAttribute(el, name, true === value ? "" : value);
    });
    if (!attrs.dangerouslySetInnerHTML) el.appendChild(children);
    return el;
  };
  function h(tagName, attrs) {
    const childrenArgs = [].slice.apply(arguments, [ 2 ]);
    const children = document.createDocumentFragment();
    flatten(childrenArgs).forEach(child => {
      if (child instanceof Node) children.appendChild(child); else if ("boolean" !== typeof child && "undefined" !== typeof child && null !== child) children.appendChild(document.createTextNode(child));
    });
    return build(tagName, attrs || {}, children);
  }
  const React = {
    createElement: h,
    Fragment: "function" === typeof DocumentFragment ? DocumentFragment : () => {}
  };
  module.exports = React;
  module.exports.h = h;
  module.exports.default = React;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__(1);
  var index_esm = __webpack_require__(3);
  var just_pick = __webpack_require__(7);
  var just_pick_default = __webpack_require__.n(just_pick);
  var parseQueryString = queryString => Object.fromEntries(new URLSearchParams(queryString).entries());
  var memoize = fn => {
    const cache = {};
    if (1 !== fn.length) throw new Error("fn 必须有且只有一个参数");
    const memoized = arg => {
      if (!cache.hasOwnProperty(arg)) cache[arg] = fn(arg);
      return cache[arg];
    };
    memoized.delete = arg => {
      delete cache[arg];
    };
    return memoized;
  };
  const helper = document.createElement("a");
  memoize(url => {
    helper.href = url;
    return {
      ...just_pick_default()(helper, [ "protocol", "origin", "pathname" ]),
      domain: helper.hostname,
      query: parseQueryString(helper.search),
      hash: helper.hash.slice(1)
    };
  });
  __webpack_require__(0);
  __webpack_exports__["a"] = Object(index_esm["a"])(() => {
    let extensionId;
    extensionId = chrome.runtime.id;
    return "chrome-extension://" + extensionId;
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  (function(__filename) {
    function loadModules() {
      const modules = {};
      const context = __webpack_require__(61);
      for (const key of context.keys()) {
        if (key.endsWith(__filename)) continue;
        const moduleName = key.replace(/^\.\/|\.js$/g, "");
        const module = context(key).default;
        modules[moduleName] = module;
      }
      return modules;
    }
    __webpack_exports__["default"] = loadModules();
  }).call(this, "/index.js");
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    for (var i = 0; i < arguments.length; i++) if ("undefined" !== typeof arguments[i]) return arguments[i];
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isObj = __webpack_require__(57);
  const disallowedKeys = [ "__proto__", "prototype", "constructor" ];
  const isValidPath = pathSegments => !pathSegments.some(segment => disallowedKeys.includes(segment));
  function getPathSegments(path) {
    const pathArray = path.split(".");
    const parts = [];
    for (let i = 0; i < pathArray.length; i++) {
      let p = pathArray[i];
      while ("\\" === p[p.length - 1] && void 0 !== pathArray[i + 1]) {
        p = p.slice(0, -1) + ".";
        p += pathArray[++i];
      }
      parts.push(p);
    }
    if (!isValidPath(parts)) return [];
    return parts;
  }
  module.exports = {
    get(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return void 0 === value ? object : value;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return;
      for (let i = 0; i < pathArray.length; i++) {
        if (!Object.prototype.propertyIsEnumerable.call(object, pathArray[i])) return value;
        object = object[pathArray[i]];
        if (void 0 === object || null === object) {
          if (i !== pathArray.length - 1) return value;
          break;
        }
      }
      return object;
    },
    set(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return object;
      const root = object;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (!isObj(object[p])) object[p] = {};
        if (i === pathArray.length - 1) object[p] = value;
        object = object[p];
      }
      return root;
    },
    delete(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (i === pathArray.length - 1) {
          delete object[p];
          return true;
        }
        object = object[p];
        if (!isObj(object)) return false;
      }
    },
    has(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return false;
      for (let i = 0; i < pathArray.length; i++) if (isObj(object)) {
        if (!(pathArray[i] in object)) return false;
        object = object[pathArray[i]];
      } else return false;
      return true;
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(url, options) {
    if (!options) options = {};
    url = url && url.__esModule ? url.default : url;
    if ("string" !== typeof url) return url;
    if (/^['"].*['"]$/.test(url)) url = url.slice(1, -1);
    if (options.hash) url += options.hash;
    if (/["'() \t\n]/.test(url) || options.needQuotes) return '"'.concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), '"');
    return url;
  };
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(40);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
  /*!
 * JavaScript Cookie v2.2.1
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */  (function(factory) {
    var registeredInModuleLoader;
    if (true) {
      !(__WEBPACK_AMD_DEFINE_FACTORY__ = factory, __WEBPACK_AMD_DEFINE_RESULT__ = "function" === typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__, 
      void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
      registeredInModuleLoader = true;
    }
    if (true) {
      module.exports = factory();
      registeredInModuleLoader = true;
    }
    if (!registeredInModuleLoader) {
      var OldCookies = window.Cookies;
      var api = window.Cookies = factory();
      api.noConflict = function() {
        window.Cookies = OldCookies;
        return api;
      };
    }
  })((function() {
    function extend() {
      var i = 0;
      var result = {};
      for (;i < arguments.length; i++) {
        var attributes = arguments[i];
        for (var key in attributes) result[key] = attributes[key];
      }
      return result;
    }
    function decode(s) {
      return s.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
    }
    function init(converter) {
      function api() {}
      function set(key, value, attributes) {
        if ("undefined" === typeof document) return;
        attributes = extend({
          path: "/"
        }, api.defaults, attributes);
        if ("number" === typeof attributes.expires) attributes.expires = new Date(1 * new Date + 864e5 * attributes.expires);
        attributes.expires = attributes.expires ? attributes.expires.toUTCString() : "";
        try {
          var result = JSON.stringify(value);
          if (/^[\{\[]/.test(result)) value = result;
        } catch (e) {}
        value = converter.write ? converter.write(value, key) : encodeURIComponent(String(value)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
        key = encodeURIComponent(String(key)).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/[\(\)]/g, escape);
        var stringifiedAttributes = "";
        for (var attributeName in attributes) {
          if (!attributes[attributeName]) continue;
          stringifiedAttributes += "; " + attributeName;
          if (true === attributes[attributeName]) continue;
          stringifiedAttributes += "=" + attributes[attributeName].split(";")[0];
        }
        return document.cookie = key + "=" + value + stringifiedAttributes;
      }
      function get(key, json) {
        if ("undefined" === typeof document) return;
        var jar = {};
        var cookies = document.cookie ? document.cookie.split("; ") : [];
        var i = 0;
        for (;i < cookies.length; i++) {
          var parts = cookies[i].split("=");
          var cookie = parts.slice(1).join("=");
          if (!json && '"' === cookie.charAt(0)) cookie = cookie.slice(1, -1);
          try {
            var name = decode(parts[0]);
            cookie = (converter.read || converter)(cookie, name) || decode(cookie);
            if (json) try {
              cookie = JSON.parse(cookie);
            } catch (e) {}
            jar[name] = cookie;
            if (key === name) break;
          } catch (e) {}
        }
        return key ? jar[key] : jar;
      }
      api.set = set;
      api.get = function(key) {
        return get(key, false);
      };
      api.getJSON = function(key) {
        return get(key, true);
      };
      api.remove = function(key, attributes) {
        set(key, "", extend(attributes, {
          expires: -1
        }));
      };
      api.defaults = {};
      api.withConverter = init;
      return api;
    }
    return init((function() {}));
  }));
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(41);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(42);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(43);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(45);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(48);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(49);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && "object" == typeof a && "object" == typeof b) {
      if (a.constructor !== b.constructor) return false;
      var length, i, keys;
      if (Array.isArray(a)) {
        length = a.length;
        if (length != b.length) return false;
        for (i = length; 0 !== i--; ) if (!equal(a[i], b[i])) return false;
        return true;
      }
      if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
      if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
      if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length) return false;
      for (i = length; 0 !== i--; ) if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
      for (i = length; 0 !== i--; ) {
        var key = keys[i];
        if (!equal(a[key], b[key])) return false;
      }
      return true;
    }
    return a !== a && b !== b;
  };
}, function(module, exports, __webpack_require__) {
  (function(process) {
    module.exports = process.env.PROMISE_QUEUE_COVERAGE ? __webpack_require__(59) : __webpack_require__(60);
  }).call(this, __webpack_require__(58));
}, function(module, exports, __webpack_require__) {
  "use strict";
  const nullKey = Symbol("null");
  let keyCounter = 0;
  module.exports = class extends Map {
    constructor() {
      super();
      this._objectHashes = new WeakMap;
      this._symbolHashes = new Map;
      this._publicKeys = new Map;
      const [pairs] = arguments;
      if (null === pairs || void 0 === pairs) return;
      if ("function" !== typeof pairs[Symbol.iterator]) throw new TypeError(typeof pairs + " is not iterable (cannot read property Symbol(Symbol.iterator))");
      for (const [keys, value] of pairs) this.set(keys, value);
    }
    _getPublicKeys(keys, create = false) {
      if (!Array.isArray(keys)) throw new TypeError("The keys parameter must be an array");
      const privateKey = this._getPrivateKey(keys, create);
      let publicKey;
      if (privateKey && this._publicKeys.has(privateKey)) publicKey = this._publicKeys.get(privateKey); else if (create) {
        publicKey = [ ...keys ];
        this._publicKeys.set(privateKey, publicKey);
      }
      return {
        privateKey,
        publicKey
      };
    }
    _getPrivateKey(keys, create = false) {
      const privateKeys = [];
      for (let key of keys) {
        if (null === key) key = nullKey;
        const hashes = "object" === typeof key || "function" === typeof key ? "_objectHashes" : "symbol" === typeof key ? "_symbolHashes" : false;
        if (!hashes) privateKeys.push(key); else if (this[hashes].has(key)) privateKeys.push(this[hashes].get(key)); else if (create) {
          const privateKey = `@@mkm-ref-${keyCounter++}@@`;
          this[hashes].set(key, privateKey);
          privateKeys.push(privateKey);
        } else return false;
      }
      return JSON.stringify(privateKeys);
    }
    set(keys, value) {
      const {publicKey} = this._getPublicKeys(keys, true);
      return super.set(publicKey, value);
    }
    get(keys) {
      const {publicKey} = this._getPublicKeys(keys);
      return super.get(publicKey);
    }
    has(keys) {
      const {publicKey} = this._getPublicKeys(keys);
      return super.has(publicKey);
    }
    delete(keys) {
      const {publicKey, privateKey} = this._getPublicKeys(keys);
      return Boolean(publicKey && super.delete(publicKey) && this._publicKeys.delete(privateKey));
    }
    clear() {
      super.clear();
      this._symbolHashes.clear();
      this._publicKeys.clear();
    }
    get [Symbol.toStringTag]() {
      return "ManyKeysMap";
    }
    get size() {
      return super.size;
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const pDefer = () => {
    const deferred = {};
    deferred.promise = new Promise((resolve, reject) => {
      deferred.resolve = resolve;
      deferred.reject = reject;
    });
    return deferred;
  };
  module.exports = pDefer;
}, function(module) {
  module.exports = JSON.parse('["a","altGlyph","altGlyphDef","altGlyphItem","animate","animateColor","animateMotion","animateTransform","animation","audio","canvas","circle","clipPath","color-profile","cursor","defs","desc","discard","ellipse","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","filter","font","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignObject","g","glyph","glyphRef","handler","hatch","hatchpath","hkern","iframe","image","line","linearGradient","listener","marker","mask","mesh","meshgradient","meshpatch","meshrow","metadata","missing-glyph","mpath","path","pattern","polygon","polyline","prefetch","radialGradient","rect","script","set","solidColor","solidcolor","stop","style","svg","switch","symbol","tbreak","text","textArea","textPath","title","tref","tspan","unknown","use","video","view","vkern"]');
}, function(module, exports, __webpack_require__) {
  "use strict";
  /*!
 * arr-flatten <https://github.com/jonschlinkert/arr-flatten>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */  module.exports = function(arr) {
    return flat(arr, []);
  };
  function flat(arr, res) {
    var cur, i = 0;
    var len = arr.length;
    for (;i < len; i++) {
      cur = arr[i];
      Array.isArray(cur) ? flat(cur, res) : res.push(cur);
    }
    return res;
  }
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '/* 复制自饭否官方账号 @饭否 的样式，略有改动 */\nbody {\n  background-color: #acdae5;\n  background-image: url("https://static.fanfou.com/img/bg/0.png");\n  background-repeat: no-repeat;\n  background-attachment: fixed;\n  background-position: top left;\n  color: #222;\n}\na,\n#sidebar a:hover,\n.pagination .more:hover,\n.stamp a:hover,\n.light .stamp a {\n  color: #06c;\n}\n.unlight .content a:link,\n.unlight .content a:visited {\n  color: #06c;\n}\na:hover,\n.light .stamp .reply a {\n  background-color: #06c;\n}\na:hover .label,\na.photo:hover img,\n.stamp a:hover,\n.light .stamp a {\n  border-color: #06c;\n}\n.actions .open-notice:hover {\n  color: #06c;\n}\n#sidebar {\n  background-color: #e2f2da;\n  border-left: 1px solid #b2d1a3;\n}\n#sidebar .sect {\n  border-top-color: #b2d1a3;\n}\n#sidebar .stabs {\n  border-bottom-color: #b2d1a3;\n}\n#sidebar .stabs li.current a {\n  color: #222;\n}\n#user_stats li {\n  border-left-color: #b2d1a3;\n}\n#user_stats .count {\n  color: #222;\n}\n#user_stats a:hover .count {\n  color: #06c;\n}\n#goodapp span {\n  color: #222;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#navigation,\n#columns,\n#footer,\n#sign-up,\n#sign-in,\n#body {\n  border-radius: 10px;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#goodapp,\n#badge-sect,\n#fanfou-ad-microwave-oven,\n.howto .paipai {\n  display: none;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(25);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(44);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  exports.push([ module.i, ".sf-remove-logo-beta .global-header-content {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n  background-size: 188px 42px;\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/fanfou-logo.svg";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(25);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(46);
  var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(47);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
  exports.push([ module.i, "#sf-remove-personalized-theme-switch {\n  position: fixed;\n  bottom: 15px;\n  right: 15px;\n  display: block;\n  width: 35px;\n  height: 35px;\n  padding: 5px;\n  color: transparent;\n  cursor: pointer;\n  background-color: rgba(0, 0, 0, 0.25);\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: 23px;\n  border-radius: 50px;\n  transition: opacity 750ms;\n}\n#sf-remove-personalized-theme-switch:hover {\n  background-color: rgba(0, 0, 0, 0.5);\n}\n#sf-remove-personalized-theme-switch.sf-enabled {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");\n}\n@media (min-width: 990px) {\n  #sf-remove-personalized-theme-switch {\n    animation: sf-fade-in 750ms;\n  }\n}\n@media (max-width: 989px) {\n  #sf-remove-personalized-theme-switch {\n    opacity: 0;\n    z-index: -9999;\n  }\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/default-theme.png";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/personalized-theme.png";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "@media (max-width: 800px) and (max-height: 600px) {\n  html,\n  body {\n    overflow: hidden;\n  }\n  #popup {\n    position: fixed;\n    left: 50%;\n    top: 50%;\n    transform: translate(-50%, -50%);\n    margin: 0;\n  }\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(14);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#sidebar {\n  background-color: rgba(255, 255, 255, 0.9);\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var map = {
    "./action-types.js": 51,
    "./assets.js": 52,
    "./custom-event-types.js": 53,
    "./extension-origin.js": 54,
    "./index.js": 0,
    "./message-types.js": 55,
    "./others.js": 56
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 50;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "STORAGE_READ", (function() {
    return STORAGE_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_WRITE", (function() {
    return STORAGE_WRITE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_DELETE", (function() {
    return STORAGE_DELETE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_CHANGED", (function() {
    return STORAGE_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ", (function() {
    return SETTINGS_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ_ALL", (function() {
    return SETTINGS_READ_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_WRITE_ALL", (function() {
    return SETTINGS_WRITE_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_CHANGED", (function() {
    return SETTINGS_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "GET_OPTION_DEFS", (function() {
    return GET_OPTION_DEFS;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_FETCH_GET", (function() {
    return PROXIED_FETCH_GET;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_AUDIO", (function() {
    return PROXIED_AUDIO;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_CREATE_TAB", (function() {
    return PROXIED_CREATE_TAB;
  }));
  const STORAGE_READ = "STORAGE_READ";
  const STORAGE_WRITE = "STORAGE_WRITE";
  const STORAGE_DELETE = "STORAGE_DELETE";
  const STORAGE_CHANGED = "STORAGE_CHANGED";
  const SETTINGS_READ = "SETTINGS_READ";
  const SETTINGS_READ_ALL = "SETTINGS_READ_ALL";
  const SETTINGS_WRITE_ALL = "SETTINGS_WRITE_ALL";
  const SETTINGS_CHANGED = "SETTINGS_CHANGED";
  const GET_OPTION_DEFS = "GET_OPTION_DEFS";
  const PROXIED_FETCH_GET = "PROXIED_FETCH_GET";
  const PROXIED_AUDIO = "PROXIED_AUDIO";
  const PROXIED_CREATE_TAB = "PROXIED_CREATE_TAB";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "ASSET_CLASSNAME", (function() {
    return ASSET_CLASSNAME;
  }));
  const ASSET_CLASSNAME = "sf-asset";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BRIDGE_EVENT_TYPE", (function() {
    return BRIDGE_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "POST_STATUS_SUCCESS_EVENT_TYPE", (function() {
    return POST_STATUS_SUCCESS_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_UNLOADED_EVENT_TYPE", (function() {
    return EXTENSION_UNLOADED_EVENT_TYPE;
  }));
  const BRIDGE_EVENT_TYPE = "SpaceFanfouBridgeMessage";
  const POST_STATUS_SUCCESS_EVENT_TYPE = "SpaceFanfouPostStatusSuccess";
  const EXTENSION_UNLOADED_EVENT_TYPE = "SpaceFanfouUnloaded";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER_RE", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER_RE;
  }));
  const EXTENSION_ORIGIN_PLACEHOLDER = "<EXTENSION_ORIGIN_PLACEHOLDER>";
  const EXTENSION_ORIGIN_PLACEHOLDER_RE = new RegExp(EXTENSION_ORIGIN_PLACEHOLDER, "g");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BROADCASTING_MESSAGE", (function() {
    return BROADCASTING_MESSAGE;
  }));
  __webpack_require__.d(__webpack_exports__, "CONVERSATIONAL_MESSAGE", (function() {
    return CONVERSATIONAL_MESSAGE;
  }));
  const BROADCASTING_MESSAGE = "BROADCASTING_MESSAGE";
  const CONVERSATIONAL_MESSAGE = "CONVERSATIONAL_MESSAGE";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "CONTROL_PLACEHOLDER", (function() {
    return CONTROL_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_KEY_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_KEY_IS_EXTENSION_UPGRADED;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED;
  }));
  const CONTROL_PLACEHOLDER = "<CONTROL_PLACEHOLDER>";
  const STORAGE_KEY_IS_EXTENSION_UPGRADED = "is-extension-upgraded";
  const STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED = "session";
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = value => {
    const type = typeof value;
    return null !== value && ("object" === type || "function" === type);
  };
}, function(module, exports) {
  var process = module.exports = {};
  var cachedSetTimeout;
  var cachedClearTimeout;
  function defaultSetTimout() {
    throw new Error("setTimeout has not been defined");
  }
  function defaultClearTimeout() {
    throw new Error("clearTimeout has not been defined");
  }
  (function() {
    try {
      if ("function" === typeof setTimeout) cachedSetTimeout = setTimeout; else cachedSetTimeout = defaultSetTimout;
    } catch (e) {
      cachedSetTimeout = defaultSetTimout;
    }
    try {
      if ("function" === typeof clearTimeout) cachedClearTimeout = clearTimeout; else cachedClearTimeout = defaultClearTimeout;
    } catch (e) {
      cachedClearTimeout = defaultClearTimeout;
    }
  })();
  function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) return setTimeout(fun, 0);
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
      cachedSetTimeout = setTimeout;
      return setTimeout(fun, 0);
    }
    try {
      return cachedSetTimeout(fun, 0);
    } catch (e) {
      try {
        return cachedSetTimeout.call(null, fun, 0);
      } catch (e) {
        return cachedSetTimeout.call(this, fun, 0);
      }
    }
  }
  function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) return clearTimeout(marker);
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
      cachedClearTimeout = clearTimeout;
      return clearTimeout(marker);
    }
    try {
      return cachedClearTimeout(marker);
    } catch (e) {
      try {
        return cachedClearTimeout.call(null, marker);
      } catch (e) {
        return cachedClearTimeout.call(this, marker);
      }
    }
  }
  var queue = [];
  var draining = false;
  var currentQueue;
  var queueIndex = -1;
  function cleanUpNextTick() {
    if (!draining || !currentQueue) return;
    draining = false;
    if (currentQueue.length) queue = currentQueue.concat(queue); else queueIndex = -1;
    if (queue.length) drainQueue();
  }
  function drainQueue() {
    if (draining) return;
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;
    var len = queue.length;
    while (len) {
      currentQueue = queue;
      queue = [];
      while (++queueIndex < len) if (currentQueue) currentQueue[queueIndex].run();
      queueIndex = -1;
      len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
  }
  process.nextTick = function(fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) for (var i = 1; i < arguments.length; i++) args[i - 1] = arguments[i];
    queue.push(new Item(fun, args));
    if (1 === queue.length && !draining) runTimeout(drainQueue);
  };
  function Item(fun, array) {
    this.fun = fun;
    this.array = array;
  }
  Item.prototype.run = function() {
    this.fun.apply(null, this.array);
  };
  process.title = "browser";
  process.browser = true;
  process.env = {};
  process.argv = [];
  process.version = "";
  process.versions = {};
  function noop() {}
  process.on = noop;
  process.addListener = noop;
  process.once = noop;
  process.off = noop;
  process.removeListener = noop;
  process.removeAllListeners = noop;
  process.emit = noop;
  process.prependListener = noop;
  process.prependOnceListener = noop;
  process.listeners = function(name) {
    return [];
  };
  process.binding = function(name) {
    throw new Error("process.binding is not supported");
  };
  process.cwd = function() {
    return "/";
  };
  process.chdir = function(dir) {
    throw new Error("process.chdir is not supported");
  };
  process.umask = function() {
    return 0;
  };
}, function(module, exports) {}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
  (function(root, factory) {
    "use strict";
    if ((true, module.exports) && true) module.exports = factory(); else if (true) !(__WEBPACK_AMD_DEFINE_FACTORY__ = factory, 
    __WEBPACK_AMD_DEFINE_RESULT__ = "function" === typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__, 
    void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  })(0, (function() {
    "use strict";
    var LocalPromise = "undefined" !== typeof Promise ? Promise : function() {
      return {
        then: function() {
          throw new Error("Queue.configure() before use Queue");
        }
      };
    };
    var noop = function() {};
    var resolveWith = function(value) {
      if (value && "function" === typeof value.then) return value;
      return new LocalPromise((function(resolve) {
        resolve(value);
      }));
    };
    function Queue(maxPendingPromises, maxQueuedPromises, options) {
      this.options = options = options || {};
      this.pendingPromises = 0;
      this.maxPendingPromises = "undefined" !== typeof maxPendingPromises ? maxPendingPromises : 1 / 0;
      this.maxQueuedPromises = "undefined" !== typeof maxQueuedPromises ? maxQueuedPromises : 1 / 0;
      this.queue = [];
    }
    Queue.configure = function(GlobalPromise) {
      LocalPromise = GlobalPromise;
    };
    Queue.prototype.add = function(promiseGenerator) {
      var self = this;
      return new LocalPromise((function(resolve, reject, notify) {
        if (self.queue.length >= self.maxQueuedPromises) {
          reject(new Error("Queue limit reached"));
          return;
        }
        self.queue.push({
          promiseGenerator,
          resolve,
          reject,
          notify: notify || noop
        });
        self._dequeue();
      }));
    };
    Queue.prototype.getPendingLength = function() {
      return this.pendingPromises;
    };
    Queue.prototype.getQueueLength = function() {
      return this.queue.length;
    };
    Queue.prototype._dequeue = function() {
      var self = this;
      if (this.pendingPromises >= this.maxPendingPromises) return false;
      var item = this.queue.shift();
      if (!item) {
        if (this.options.onEmpty) this.options.onEmpty();
        return false;
      }
      try {
        this.pendingPromises++;
        resolveWith(item.promiseGenerator()).then((function(value) {
          self.pendingPromises--;
          item.resolve(value);
          self._dequeue();
        }), (function(err) {
          self.pendingPromises--;
          item.reject(err);
          self._dequeue();
        }), (function(message) {
          item.notify(message);
        }));
      } catch (err) {
        self.pendingPromises--;
        item.reject(err);
        self._dequeue();
      }
      return true;
    };
    return Queue;
  }));
}, function(module, exports, __webpack_require__) {
  var map = {
    "./index.js": 22,
    "./notification.js": 68,
    "./scrollManager.js": 62,
    "./statusFormIntersectionObserver.js": 63,
    "./storage.js": 64,
    "./timelineElementObserver.js": 65
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 61;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(13);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
  const CHECKING_INTERVAL = 32;
  let timerId = null;
  let prevY = -1;
  const listeners = [];
  function handler() {
    const currY = scrollManager.getScrollTop();
    if (-1 !== prevY && currY !== prevY) Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_1__["a"])(listeners);
    prevY = currY;
  }
  const scrollManager = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_0__["a"])({
    install() {
      if (timerId) return;
      timerId = setInterval(handler, CHECKING_INTERVAL);
      handler();
    },
    uninstall() {
      if (!timerId) return;
      clearInterval(timerId);
      timerId = null;
    },
    addListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_2__["a"])(listeners, fn);
    },
    removeListener(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_3__["a"])(listeners, fn);
    },
    getScrollTop() {
      return Math.max(document.documentElement ? document.documentElement.scrollTop : 0, document.body ? document.body.scrollTop : 0);
    }
  });
  __webpack_exports__["default"] = scrollManager;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var element_ready__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
  var element_ready__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(element_ready__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9);
  let observer;
  let spy;
  const listeners = [];
  function createSpy(update) {
    const documentRect = document.documentElement.getBoundingClientRect();
    const updateRect = update.getBoundingClientRect();
    const updateOffset = updateRect.top - documentRect.top;
    spy = document.createElement("div");
    spy.classList.add("sf-spy");
    spy.style.position = "absolute";
    spy.style.top = updateOffset - 11 + "px";
    spy.style.pointerEvents = "none";
    document.body.append(spy);
    return spy;
  }
  function intersectionObserverCallback([{intersectionRatio}]) {
    const isIntersected = intersectionRatio > 0;
    Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_2__["a"])({
      fns: listeners,
      args: [ isIntersected ]
    });
  }
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    async install() {
      const update = await element_ready__WEBPACK_IMPORTED_MODULE_0___default()("#phupdate");
      if (update) {
        createSpy(update);
        observer = new IntersectionObserver(intersectionObserverCallback);
        observer.observe(spy);
      }
      return !!update;
    },
    uninstall() {
      if (observer) {
        observer.disconnect();
        spy.remove();
        observer = spy = null;
        listeners.length = 0;
      }
    },
    addListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__["a"])(listeners, fn);
    },
    removeListener(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__["a"])(listeners, fn);
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _environment_messaging__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(0);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      return _environment_messaging__WEBPACK_IMPORTED_MODULE_0__["a"].ready();
    },
    async read(key, storageAreaName) {
      const {value} = await _environment_messaging__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_READ"],
        payload: {
          storageAreaName,
          key
        }
      });
      return value;
    },
    async write(key, value, storageAreaName) {
      await _environment_messaging__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_WRITE"],
        payload: {
          storageAreaName,
          key,
          value
        }
      });
    },
    async delete(key, storageAreaName) {
      await _environment_messaging__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_DELETE"],
        payload: {
          storageAreaName,
          key
        }
      });
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var select_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
  var element_ready__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
  var element_ready__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(element_ready__WEBPACK_IMPORTED_MODULE_1__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9);
  let stream;
  let observer;
  const map = new WeakMap;
  const callbacks = [];
  function callCallbacks(...args) {
    Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_3__["a"])({
      fns: callbacks,
      args
    });
  }
  function streamMutationObserver(mutationRecords) {
    for (const {addedNodes, removedNodes} of mutationRecords) {
      for (const addedOl of addedNodes) {
        const subObserver = new MutationObserver(olMutationObserver);
        subObserver.observe(addedOl, {
          childList: true
        });
        map.set(addedOl, subObserver);
        callCallbacks([ {
          addedNodes: Array.from(addedOl.children),
          removedNodes: []
        } ]);
      }
      for (const removedOl of removedNodes) {
        const subObserver = map.get(removedOl);
        subObserver.disconnect();
        callCallbacks([ {
          addedNodes: [],
          removedNodes: Array.from(removedOl.children)
        } ]);
      }
    }
  }
  function olMutationObserver(mutationRecords) {
    callCallbacks(mutationRecords.map(mutationRecord => ({
      ...mutationRecord,
      addedNodes: Array.from(mutationRecord.addedNodes),
      removedNodes: Array.from(mutationRecord.removedNodes)
    })));
  }
  function getStatusLists() {
    return select_dom__WEBPACK_IMPORTED_MODULE_0__["a"].all(":scope>ol", stream);
  }
  function getStatuses() {
    return select_dom__WEBPACK_IMPORTED_MODULE_0__["a"].all(":scope>ol>li", stream);
  }
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_2__["a"])({
    async install() {
      stream = await element_ready__WEBPACK_IMPORTED_MODULE_1___default()("#stream");
      if (stream) {
        observer = new MutationObserver(streamMutationObserver);
        observer.observe(stream, {
          childList: true
        });
        streamMutationObserver([ {
          addedNodes: getStatusLists(),
          removedNodes: []
        } ]);
      }
      return !!stream;
    },
    uninstall() {
      if (observer) {
        observer.disconnect();
        observer = null;
        callbacks.length = 0;
      }
    },
    addCallback(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_4__["a"])(callbacks, fn);
      fn([ {
        addedNodes: getStatuses(),
        removedNodes: []
      } ]);
    },
    removeCallback(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_5__["a"])(callbacks, fn);
      fn([ {
        addedNodes: [],
        removedNodes: getStatuses()
      } ]);
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _content_namespaceObject = {};
  __webpack_require__.r(_content_namespaceObject);
  __webpack_require__.d(_content_namespaceObject, "default", (function() {
    return _content;
  }));
  var remove_brackets_content_namespaceObject = {};
  __webpack_require__.r(remove_brackets_content_namespaceObject);
  __webpack_require__.d(remove_brackets_content_namespaceObject, "default", (function() {
    return remove_brackets_content;
  }));
  var remove_logo_beta_content_namespaceObject = {};
  __webpack_require__.r(remove_logo_beta_content_namespaceObject);
  __webpack_require__.d(remove_logo_beta_content_namespaceObject, "default", (function() {
    return remove_logo_beta_content;
  }));
  var remove_personalized_theme_content_namespaceObject = {};
  __webpack_require__.r(remove_personalized_theme_content_namespaceObject);
  __webpack_require__.d(remove_personalized_theme_content_namespaceObject, "default", (function() {
    return remove_personalized_theme_content;
  }));
  var fix_style_content_namespaceObject = {};
  __webpack_require__.r(fix_style_content_namespaceObject);
  __webpack_require__.d(fix_style_content_namespaceObject, "default", (function() {
    return fix_style_content;
  }));
  var metadata_namespaceObject = {};
  __webpack_require__.r(metadata_namespaceObject);
  __webpack_require__.d(metadata_namespaceObject, "options", (function() {
    return options;
  }));
  var batch_manage_relationships_metadata_namespaceObject = {};
  __webpack_require__.r(batch_manage_relationships_metadata_namespaceObject);
  __webpack_require__.d(batch_manage_relationships_metadata_namespaceObject, "options", (function() {
    return metadata_options;
  }));
  var batch_remove_private_messages_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_private_messages_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_private_messages_metadata_namespaceObject, "options", (function() {
    return batch_remove_private_messages_metadata_options;
  }));
  var batch_remove_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_statuses_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_statuses_metadata_namespaceObject, "options", (function() {
    return batch_remove_statuses_metadata_options;
  }));
  var better_at_autocomplete_metadata_namespaceObject = {};
  __webpack_require__.r(better_at_autocomplete_metadata_namespaceObject);
  __webpack_require__.d(better_at_autocomplete_metadata_namespaceObject, "isSoldered", (function() {
    return metadata_isSoldered;
  }));
  var box_shadows_metadata_namespaceObject = {};
  __webpack_require__.r(box_shadows_metadata_namespaceObject);
  __webpack_require__.d(box_shadows_metadata_namespaceObject, "options", (function() {
    return box_shadows_metadata_options;
  }));
  var check_friendship_metadata_namespaceObject = {};
  __webpack_require__.r(check_friendship_metadata_namespaceObject);
  __webpack_require__.d(check_friendship_metadata_namespaceObject, "options", (function() {
    return check_friendship_metadata_options;
  }));
  var check_saved_searches_metadata_namespaceObject = {};
  __webpack_require__.r(check_saved_searches_metadata_namespaceObject);
  __webpack_require__.d(check_saved_searches_metadata_namespaceObject, "options", (function() {
    return check_saved_searches_metadata_options;
  }));
  var enrich_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(enrich_statuses_metadata_namespaceObject);
  __webpack_require__.d(enrich_statuses_metadata_namespaceObject, "options", (function() {
    return enrich_statuses_metadata_options;
  }));
  var favorite_fanfouers_metadata_namespaceObject = {};
  __webpack_require__.r(favorite_fanfouers_metadata_namespaceObject);
  __webpack_require__.d(favorite_fanfouers_metadata_namespaceObject, "options", (function() {
    return favorite_fanfouers_metadata_options;
  }));
  var fix_photo_zoom_metadata_namespaceObject = {};
  __webpack_require__.r(fix_photo_zoom_metadata_namespaceObject);
  __webpack_require__.d(fix_photo_zoom_metadata_namespaceObject, "isSoldered", (function() {
    return fix_photo_zoom_metadata_isSoldered;
  }));
  var floating_status_form_metadata_namespaceObject = {};
  __webpack_require__.r(floating_status_form_metadata_namespaceObject);
  __webpack_require__.d(floating_status_form_metadata_namespaceObject, "options", (function() {
    return floating_status_form_metadata_options;
  }));
  var go_top_button_metadata_namespaceObject = {};
  __webpack_require__.r(go_top_button_metadata_namespaceObject);
  __webpack_require__.d(go_top_button_metadata_namespaceObject, "isSoldered", (function() {
    return go_top_button_metadata_isSoldered;
  }));
  var google_analytics_metadata_namespaceObject = {};
  __webpack_require__.r(google_analytics_metadata_namespaceObject);
  __webpack_require__.d(google_analytics_metadata_namespaceObject, "isSoldered", (function() {
    return google_analytics_metadata_isSoldered;
  }));
  var keyboard_shortcuts_metadata_namespaceObject = {};
  __webpack_require__.r(keyboard_shortcuts_metadata_namespaceObject);
  __webpack_require__.d(keyboard_shortcuts_metadata_namespaceObject, "isSoldered", (function() {
    return keyboard_shortcuts_metadata_isSoldered;
  }));
  var notifications_metadata_namespaceObject = {};
  __webpack_require__.r(notifications_metadata_namespaceObject);
  __webpack_require__.d(notifications_metadata_namespaceObject, "options", (function() {
    return notifications_metadata_options;
  }));
  var process_unread_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(process_unread_statuses_metadata_namespaceObject);
  __webpack_require__.d(process_unread_statuses_metadata_namespaceObject, "options", (function() {
    return process_unread_statuses_metadata_options;
  }));
  var remove_app_recommendations_metadata_namespaceObject = {};
  __webpack_require__.r(remove_app_recommendations_metadata_namespaceObject);
  __webpack_require__.d(remove_app_recommendations_metadata_namespaceObject, "options", (function() {
    return remove_app_recommendations_metadata_options;
  }));
  var remove_brackets_metadata_namespaceObject = {};
  __webpack_require__.r(remove_brackets_metadata_namespaceObject);
  __webpack_require__.d(remove_brackets_metadata_namespaceObject, "isSoldered", (function() {
    return remove_brackets_metadata_isSoldered;
  }));
  var remove_logo_beta_metadata_namespaceObject = {};
  __webpack_require__.r(remove_logo_beta_metadata_namespaceObject);
  __webpack_require__.d(remove_logo_beta_metadata_namespaceObject, "options", (function() {
    return remove_logo_beta_metadata_options;
  }));
  var remove_personalized_theme_metadata_namespaceObject = {};
  __webpack_require__.r(remove_personalized_theme_metadata_namespaceObject);
  __webpack_require__.d(remove_personalized_theme_metadata_namespaceObject, "options", (function() {
    return remove_personalized_theme_metadata_options;
  }));
  var retinafy_photos_metadata_namespaceObject = {};
  __webpack_require__.r(retinafy_photos_metadata_namespaceObject);
  __webpack_require__.d(retinafy_photos_metadata_namespaceObject, "isSoldered", (function() {
    return retinafy_photos_metadata_isSoldered;
  }));
  var share_new_avatar_metadata_namespaceObject = {};
  __webpack_require__.r(share_new_avatar_metadata_namespaceObject);
  __webpack_require__.d(share_new_avatar_metadata_namespaceObject, "isSoldered", (function() {
    return share_new_avatar_metadata_isSoldered;
  }));
  var share_to_fanfou_metadata_namespaceObject = {};
  __webpack_require__.r(share_to_fanfou_metadata_namespaceObject);
  __webpack_require__.d(share_to_fanfou_metadata_namespaceObject, "options", (function() {
    return share_to_fanfou_metadata_options;
  }));
  var show_contextual_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(show_contextual_statuses_metadata_namespaceObject);
  __webpack_require__.d(show_contextual_statuses_metadata_namespaceObject, "options", (function() {
    return show_contextual_statuses_metadata_options;
  }));
  var sidebar_statistics_metadata_namespaceObject = {};
  __webpack_require__.r(sidebar_statistics_metadata_namespaceObject);
  __webpack_require__.d(sidebar_statistics_metadata_namespaceObject, "isSoldered", (function() {
    return sidebar_statistics_metadata_isSoldered;
  }));
  var status_form_enhancements_metadata_namespaceObject = {};
  __webpack_require__.r(status_form_enhancements_metadata_namespaceObject);
  __webpack_require__.d(status_form_enhancements_metadata_namespaceObject, "isSoldered", (function() {
    return status_form_enhancements_metadata_isSoldered;
  }));
  var translucent_sidebar_metadata_namespaceObject = {};
  __webpack_require__.r(translucent_sidebar_metadata_namespaceObject);
  __webpack_require__.d(translucent_sidebar_metadata_namespaceObject, "options", (function() {
    return translucent_sidebar_metadata_options;
  }));
  var update_timestamps_metadata_namespaceObject = {};
  __webpack_require__.r(update_timestamps_metadata_namespaceObject);
  __webpack_require__.d(update_timestamps_metadata_namespaceObject, "isSoldered", (function() {
    return update_timestamps_metadata_isSoldered;
  }));
  var user_switcher_metadata_namespaceObject = {};
  __webpack_require__.r(user_switcher_metadata_namespaceObject);
  __webpack_require__.d(user_switcher_metadata_namespaceObject, "isSoldered", (function() {
    return user_switcher_metadata_isSoldered;
  }));
  var _content = () => ({
    onLoad() {}
  });
  var select_dom = __webpack_require__(1);
  var element_ready = __webpack_require__(2);
  var element_ready_default = __webpack_require__.n(element_ready);
  async function removeBrackets(selector) {
    const found = await element_ready_default()(selector);
    if (!found) return;
    for (const element of select_dom["a"].all(selector)) {
      const html = element.innerHTML;
      if (html.startsWith("(")) element.innerHTML = html.replace(/^\(|\)$/g, "");
    }
  }
  var remove_brackets_content = () => ({
    onLoad() {
      const selectors = [ "#navigation .count", "#navtabs .count" ];
      selectors.forEach(removeBrackets);
    }
  });
  var keepRetry = __webpack_require__(15);
  const CLASSNAME_FEATURE = "sf-remove-logo-beta";
  const RE_BETA_LOGO = /url\("?https?:\/\/static\d?\.fanfou\.com\/img\/fanfou_beta\.(png|svg)"?\)/;
  var remove_logo_beta_content = context => {
    const {elementCollection} = context;
    elementCollection.add({
      header: ".global-header-content"
    });
    function getLogoCssBackgroundImage() {
      const {header} = elementCollection.getAll();
      const {backgroundImage} = getComputedStyle(header);
      return backgroundImage;
    }
    return {
      applyWhen: () => elementCollection.ready("header"),
      waitReady: () => Object(keepRetry["a"])({
        checker: () => "none" !== getLogoCssBackgroundImage(),
        delay: 0
      }),
      onLoad() {
        const isBetaLogo = RE_BETA_LOGO.test(getLogoCssBackgroundImage());
        if (isBetaLogo) document.body.classList.add(CLASSNAME_FEATURE);
      },
      onUnload() {
        document.body.classList.remove(CLASSNAME_FEATURE);
      }
    };
  };
  var dom_chef = __webpack_require__(20);
  var fanfou_default_theme = __webpack_require__(26);
  var fanfou_default_theme_default = __webpack_require__.n(fanfou_default_theme);
  function isUserThemeStyleElement(styleElement) {
    const css = styleElement.textContent;
    return css.startsWith("body {") && css.includes(".reply a {") && css.includes("#sidebar {") && css.includes("#goodapp span {");
  }
  var findUserThemeStyleElement = () => select_dom["a"].all("head style").find(isUserThemeStyleElement);
  var js_cookie = __webpack_require__(27);
  var js_cookie_default = __webpack_require__.n(js_cookie);
  var index_esm = __webpack_require__(3);
  var getLoggedInUserId = Object(index_esm["a"])(() => js_cookie_default.a.get("u"));
  var arrayUniquePush = __webpack_require__(8);
  var arrayRemove = __webpack_require__(9);
  const STORAGE_KEY = "remove-personalized-theme/userIdList";
  const STORAGE_AREA_NAME = "sync";
  var remove_personalized_theme_content = context => {
    const {requireModules} = context;
    const {storage} = requireModules([ "storage" ]);
    let isEnabled = false;
    let userThemeStyleElement;
    let userThemeCss = "";
    let button;
    let userId;
    function extractUserIdFromUrl() {
      const splitPathname = window.location.pathname.split("/");
      return [ "favorites", "friends", "followers" ].includes(splitPathname[1]) ? splitPathname[2] : null;
    }
    async function extractUserIdFromMeta() {
      const meta = await element_ready_default()('meta[name="author"]');
      if (meta) {
        const rawValue = meta.getAttribute("content");
        return rawValue.match(/\((.+)\)$/)[1];
      }
    }
    function createButton() {
      return Object(dom_chef["h"])("a", {
        id: "sf-remove-personalized-theme-switch",
        onClick: () => toggle(!isEnabled)
      });
    }
    async function readList() {
      return await storage.read(STORAGE_KEY, STORAGE_AREA_NAME) || [];
    }
    async function writeList(list) {
      await storage.write(STORAGE_KEY, list, STORAGE_AREA_NAME);
    }
    async function shouldEnableOnLoad() {
      const list = await readList();
      return list.includes(userId);
    }
    async function saveState() {
      const list = await readList();
      if (isEnabled) Object(arrayUniquePush["a"])(list, userId); else Object(arrayRemove["a"])(list, userId);
      await writeList(list);
    }
    function toggle(nextState, force = false) {
      if (nextState === isEnabled && !force) return;
      setStyle(nextState ? fanfou_default_theme_default.a : userThemeCss);
      button.title = nextState ? "使用用户自定义模板" : "使用饭否默认模板";
      button.classList.toggle("sf-enabled", isEnabled = nextState);
      saveState();
    }
    function setStyle(css) {
      userThemeStyleElement.textContent = css;
    }
    return {
      async applyWhen() {
        userId = extractUserIdFromUrl() || await extractUserIdFromMeta();
        return userId && userId !== getLoggedInUserId();
      },
      waitReady: () => Object(keepRetry["a"])({
        checker: () => findUserThemeStyleElement(),
        until: () => "complete" === document.readyState,
        delay: 0
      }),
      async onLoad() {
        userThemeStyleElement = findUserThemeStyleElement();
        userThemeCss = userThemeStyleElement.textContent;
        button = createButton();
        document.body.append(button);
        toggle(await shouldEnableOnLoad(), true);
      },
      onUnload() {
        setStyle(userThemeCss);
        userThemeStyleElement = null;
        userThemeCss = "";
        button.remove();
        button = null;
        isEnabled = false;
      }
    };
  };
  var findElementWithSpecifiedContentInArray = (array, search) => array.find(element => {
    if ("string" === typeof search) return element.textContent.trim() === search; else if (search instanceof RegExp) return search.test(element.textContent);
    throw new Error("search 必须为字符串或正则表达式");
  });
  var getLoggedInUserProfilePageUrl = Object(index_esm["a"])(() => {
    const navLinks = select_dom["a"].all("#navigation li a");
    const profilePageLink = findElementWithSpecifiedContentInArray(navLinks, "我的空间");
    return profilePageLink.href;
  });
  var is_promise = __webpack_require__(11);
  var is_promise_default = __webpack_require__.n(is_promise);
  var promiseAny = iterable => new Promise(resolve => {
    const total = iterable.length;
    let count = 0;
    let done = false;
    if (0 === total) return resolve(false);
    function check(value) {
      if (done) return;
      if (value) {
        done = true;
        resolve(true);
      } else fail();
    }
    function fail() {
      if (done) return;
      if (++count === total) {
        done = true;
        resolve(false);
      }
    }
    for (const item of iterable) {
      if (done) return;
      if (is_promise_default()(item)) item.then(check, fail); else check(item);
    }
  });
  var promiseEvery = __webpack_require__(18);
  function neg(x) {
    return is_promise_default()(x) ? x.then(neg) : !x;
  }
  function isLoggedInUserProfilePage() {
    const userId = getLoggedInUserId();
    return userId && window.location.pathname.split("/")[1] === userId;
  }
  Object(index_esm["a"])(async () => {
    if (!isFriendsListPage()) return false;
    await element_ready_default()("#stream");
    const urlA = Object(select_dom["a"])(".tabs .crumb").href;
    const urlB = getLoggedInUserProfilePageUrl();
    return urlA === urlB;
  });
  Object(index_esm["a"])(async () => {
    if (!isFollowersListPage()) return false;
    await element_ready_default()("#stream");
    const urlA = Object(select_dom["a"])(".tabs .crumb").href;
    const urlB = getLoggedInUserProfilePageUrl();
    return urlA === urlB;
  });
  const isUserProfilePage = Object(index_esm["a"])(() => promiseAny([ element_ready_default()("#overlay-report"), isLoggedInUserProfilePage() ]));
  function isPhotoAlbumPage() {
    return window.location.pathname.startsWith("/album/");
  }
  function isPhotoEntryPage() {
    return window.location.pathname.startsWith("/photo/");
  }
  function isFavoritesPage() {
    return window.location.pathname.startsWith("/favorites/");
  }
  function isFriendsListPage() {
    return "friends" === window.location.pathname.split("/")[1];
  }
  function isFollowersListPage() {
    return "followers" === window.location.pathname.split("/")[1];
  }
  const isUserPage = Object(index_esm["a"])(() => promiseAny([ isUserProfilePage(), isPhotoAlbumPage(), isPhotoEntryPage(), isFavoritesPage(), isFriendsListPage(), isFollowersListPage() ]));
  Object(index_esm["a"])(() => {
    const userId = getLoggedInUserId();
    return promiseAny([ isLoggedInUserProfilePage(), Object(promiseEvery["a"])([ isUserPage(), window.location.pathname.split("/")[2] === userId ]) ]);
  });
  function isFriendRequestPage() {
    return "/friend.request" === window.location.pathname;
  }
  Object(index_esm["a"])(() => Object(promiseEvery["a"])([ element_ready_default()("#stream"), neg(isFriendRequestPage()) ]));
  function isSharePage() {
    return [ "/sharer", "/sharer/image" ].includes(window.location.pathname);
  }
  var fix_style_content = () => ({
    applyWhen: () => isSharePage()
  });
  var box_shadows_content = __webpack_require__(28);
  var remove_app_recommendations_content = __webpack_require__(29);
  var features_remove_logo_beta_content = __webpack_require__(30);
  var features_remove_personalized_theme_content = __webpack_require__(31);
  var share_to_fanfou_fix_style_content = __webpack_require__(32);
  var translucent_sidebar_content = __webpack_require__(33);
  const options = {
    _: {
      defaultValue: true,
      label: "随页面向下滚动自动加载更多消息"
    }
  };
  const metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理关注的人"
    }
  };
  const batch_remove_private_messages_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理私信"
    }
  };
  const batch_remove_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理消息",
      comment: "按住 Shift 键可以批量选择"
    }
  };
  const metadata_isSoldered = true;
  const box_shadows_metadata_options = {
    _: {
      defaultValue: false,
      label: "在导航栏、主窗体等框架下显示阴影"
    }
  };
  const check_friendship_metadata_options = {
    _: {
      defaultValue: false,
      label: "在用户页面显示好友关系检查工具"
    }
  };
  const check_saved_searches_metadata_options = {
    _: {
      defaultValue: true,
      label: "自动检查关注的话题是否有新消息"
    },
    enableNotifications: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有新消息时显示桌面通知"
    }
  };
  const enrich_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "消息内容增强",
      comment: "自动展开短链接，为图片链接添加预览图等"
    }
  };
  const favorite_fanfouers_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许添加有爱饭友，并显示在首页侧栏上"
    }
  };
  const fix_photo_zoom_metadata_isSoldered = true;
  const floating_status_form_metadata_options = {
    _: {
      defaultValue: false,
      label: "使用跟随页面滚动的浮动输入框"
    },
    keepFocusAfterPosting: {
      defaultValue: false,
      label: "消息发出后将焦点保留在输入框"
    },
    keepAtNamesAfterPosting: {
      defaultValue: false,
      label: "消息发出后在输入框中保留所 @ 的人"
    }
  };
  const go_top_button_metadata_isSoldered = true;
  const google_analytics_metadata_isSoldered = true;
  const keyboard_shortcuts_metadata_isSoldered = true;
  const notifications_metadata_options = {
    _: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "启用 Chrome 桌面通知"
    },
    notifyUnreadMentions: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新 @ 提到我的通知"
    },
    notifyUnreadPrivateMessages: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新私信通知"
    },
    notifyNewFollowers: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新关注者通知"
    },
    doNotDisturbWhenVisitingFanfou: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "当我浏览饭否页面时不要显示通知"
    },
    notifyUpdateDetails: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "太空饭否更新后通知显示更新内容"
    },
    playSound: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示通知时播放提示音"
    }
  };
  const process_unread_statuses_metadata_options = {
    _: {
      isSoldered: true,
      label: "时间线上出现新消息时进行处理"
    },
    playSound: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有未读消息时播放提示音",
      comment: "饭否页面打开状态下"
    }
  };
  const remove_app_recommendations_metadata_options = {
    _: {
      defaultValue: false,
      label: "屏蔽「饭否应用」广告区和「随机应用推荐」"
    }
  };
  const remove_brackets_metadata_isSoldered = true;
  const remove_logo_beta_metadata_options = {
    _: {
      defaultValue: true,
      label: "去除 logo 的「测试版」字样"
    }
  };
  const remove_personalized_theme_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许关闭用户的自定义模板",
      comment: "恢复到饭否初始样式"
    }
  };
  const retinafy_photos_metadata_isSoldered = true;
  const share_new_avatar_metadata_isSoldered = true;
  const share_to_fanfou_metadata_options = {
    _: {
      defaultValue: false,
      label: "添加「分享到饭否」到网页右键菜单"
    }
  };
  var constants = __webpack_require__(0);
  const show_contextual_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "允许展开回复和转发的消息"
    },
    fetchStatusNumberPerClick: {
      defaultValue: 3,
      label: `每次展开 ${constants["CONTROL_PLACEHOLDER"]} 条消息`,
      controlOptions: {
        step: 1,
        min: 1,
        max: 7
      }
    },
    autoFetch: {
      defaultValue: false,
      label: "消息载入后自动展开 1 条消息"
    }
  };
  const sidebar_statistics_metadata_isSoldered = true;
  const status_form_enhancements_metadata_isSoldered = true;
  const translucent_sidebar_metadata_options = {
    _: {
      defaultValue: true,
      label: "半透明的侧栏"
    }
  };
  const update_timestamps_metadata_isSoldered = true;
  const user_switcher_metadata_isSoldered = true;
  var dot_prop = __webpack_require__(24);
  var dot_prop_default = __webpack_require__.n(dot_prop);
  var just_pick = __webpack_require__(7);
  var just_pick_default = __webpack_require__.n(just_pick);
  var parseFilename = filename => {
    const index = filename.lastIndexOf(".");
    let basename, extname;
    if (-1 === index) {
      basename = filename;
      extname = "";
    } else {
      basename = filename.slice(0, index);
      extname = filename.slice(index);
    }
    return {
      basename,
      extname
    };
  };
  var getExtensionOrigin = __webpack_require__(21);
  var replaceExtensionOrigin = code => {
    const extensionOrigin = Object(getExtensionOrigin["a"])();
    const replacedCode = code.replace(constants["EXTENSION_ORIGIN_PLACEHOLDER_RE"], extensionOrigin);
    return replacedCode;
  };
  function loadComponent(path, module) {
    const [, featureName, filename] = path.split("/");
    if ("metadata.js" === filename) return {
      featureName,
      type: "metadata",
      module
    };
    const {basename, extname} = parseFilename(filename);
    const atPos = basename.lastIndexOf("@");
    const subfeatureName = 0 === atPos ? "default" : basename.slice(0, atPos);
    if ([ ".less", ".css" ].includes(extname)) return {
      featureName,
      subfeatureName,
      type: "style",
      module: replaceExtensionOrigin(module)
    };
    if (".js" === extname) return {
      featureName,
      subfeatureName,
      type: "script",
      module: module.default
    };
  }
  function loadComponents() {
    const modules = {
      "./auto-pager/metadata.js": metadata_namespaceObject,
      "./batch-manage-relationships/metadata.js": batch_manage_relationships_metadata_namespaceObject,
      "./batch-remove-private-messages/metadata.js": batch_remove_private_messages_metadata_namespaceObject,
      "./batch-remove-statuses/metadata.js": batch_remove_statuses_metadata_namespaceObject,
      "./better-at-autocomplete/metadata.js": better_at_autocomplete_metadata_namespaceObject,
      "./box-shadows/metadata.js": box_shadows_metadata_namespaceObject,
      "./check-friendship/metadata.js": check_friendship_metadata_namespaceObject,
      "./check-saved-searches/metadata.js": check_saved_searches_metadata_namespaceObject,
      "./enrich-statuses/metadata.js": enrich_statuses_metadata_namespaceObject,
      "./favorite-fanfouers/metadata.js": favorite_fanfouers_metadata_namespaceObject,
      "./fix-photo-zoom/metadata.js": fix_photo_zoom_metadata_namespaceObject,
      "./floating-status-form/metadata.js": floating_status_form_metadata_namespaceObject,
      "./go-top-button/metadata.js": go_top_button_metadata_namespaceObject,
      "./google-analytics/metadata.js": google_analytics_metadata_namespaceObject,
      "./keyboard-shortcuts/metadata.js": keyboard_shortcuts_metadata_namespaceObject,
      "./notifications/metadata.js": notifications_metadata_namespaceObject,
      "./process-unread-statuses/metadata.js": process_unread_statuses_metadata_namespaceObject,
      "./remove-app-recommendations/metadata.js": remove_app_recommendations_metadata_namespaceObject,
      "./remove-brackets/metadata.js": remove_brackets_metadata_namespaceObject,
      "./remove-logo-beta/metadata.js": remove_logo_beta_metadata_namespaceObject,
      "./remove-personalized-theme/metadata.js": remove_personalized_theme_metadata_namespaceObject,
      "./retinafy-photos/metadata.js": retinafy_photos_metadata_namespaceObject,
      "./share-new-avatar/metadata.js": share_new_avatar_metadata_namespaceObject,
      "./share-to-fanfou/metadata.js": share_to_fanfou_metadata_namespaceObject,
      "./show-contextual-statuses/metadata.js": show_contextual_statuses_metadata_namespaceObject,
      "./sidebar-statistics/metadata.js": sidebar_statistics_metadata_namespaceObject,
      "./status-form-enhancements/metadata.js": status_form_enhancements_metadata_namespaceObject,
      "./translucent-sidebar/metadata.js": translucent_sidebar_metadata_namespaceObject,
      "./update-timestamps/metadata.js": update_timestamps_metadata_namespaceObject,
      "./user-switcher/metadata.js": user_switcher_metadata_namespaceObject,
      "./box-shadows/@content.less": box_shadows_content,
      "./remove-app-recommendations/@content.less": remove_app_recommendations_content,
      "./remove-logo-beta/@content.less": features_remove_logo_beta_content,
      "./remove-personalized-theme/@content.less": features_remove_personalized_theme_content,
      "./share-to-fanfou/fix-style@content.less": share_to_fanfou_fix_style_content,
      "./translucent-sidebar/@content.less": translucent_sidebar_content,
      "./google-analytics/@content.js": _content_namespaceObject,
      "./remove-brackets/@content.js": remove_brackets_content_namespaceObject,
      "./remove-logo-beta/@content.js": remove_logo_beta_content_namespaceObject,
      "./remove-personalized-theme/@content.js": remove_personalized_theme_content_namespaceObject,
      "./share-to-fanfou/fix-style@content.js": fix_style_content_namespaceObject
    };
    const components = Object.entries(modules).map(([path, module]) => loadComponent(path, module));
    return components;
  }
  function processOptionDef(featureName, optionName, rawOptionDef, isSubOption) {
    const {isSoldered = false, defaultValue, disableCloudSyncing = false} = rawOptionDef;
    const optionDef = {
      key: optionName,
      isSoldered,
      isSubOption,
      disableCloudSyncing,
      type: function() {
        if (isSoldered || "boolean" === typeof defaultValue) return "checkbox"; else if ("number" === typeof defaultValue) return "number"; else throw new Error("无法判断选项的类型，因为没有指定 `isSoldered` 或 `defaultValue`");
      }(),
      ...just_pick_default()(rawOptionDef, [ "label", "comment", "controlOptions" ])
    };
    if (isSubOption) optionDef.parentKey = featureName;
    return optionDef;
  }
  function processMetadata(featureName, metadata) {
    const isSoldered = !!metadata.isSoldered;
    const optionNames = [];
    const optionDefs = [];
    const defaultValues = {};
    const optionStorageAreaMap = {};
    if (!isSoldered) for (const [k, v] of Object.entries(metadata.options)) {
      const isSubOption = "_" !== k;
      const optionName = isSubOption ? `${featureName}/${k}` : featureName;
      const optionDef = processOptionDef(featureName, optionName, v, isSubOption);
      optionNames.push(optionName);
      optionDefs.push(optionDef);
      defaultValues[optionName] = v.isSoldered || v.defaultValue;
      optionStorageAreaMap[optionName] = v.disableCloudSyncing ? "local" : "sync";
    }
    return {
      isSoldered,
      optionNames,
      optionDefs,
      defaultValues,
      optionStorageAreaMap
    };
  }
  function loadFeatures() {
    const features = {};
    for (const {featureName, subfeatureName, type, module} of loadComponents()) if ("metadata" === type) dot_prop_default.a.set(features, featureName + ".metadata", processMetadata(featureName, module)); else dot_prop_default.a.set(features, `${featureName}.subfeatures.${subfeatureName}.${type}`, module);
    return features;
  }
  var src_features = loadFeatures();
  var safelyInvokeFn = __webpack_require__(10);
  async function init({createEnvironment, modules, createFeatureClass, createSubfeatureClass}) {
    const environment = await createEnvironment();
    const Feature = createFeatureClass({
      ...environment,
      modules
    });
    const Subfeature = createSubfeatureClass({
      ...environment,
      modules
    });
    for (const [featureName, {metadata, subfeatures}] of Object.entries(src_features)) {
      if (!subfeatures) continue;
      const feature = new Feature({
        featureName,
        metadata
      });
      for (const [subfeatureName, {style, script}] of Object.entries(subfeatures)) {
        const subfeature = new Subfeature({
          featureName,
          subfeatureName,
          style,
          script,
          parent: feature
        });
        feature.addSubfeature(subfeature);
      }
      Object(safelyInvokeFn["a"])(feature.init.bind(feature));
    }
  }
  init(__webpack_require__(67));
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "createEnvironment", (function() {
    return createContentEnvironment;
  }));
  __webpack_require__.d(__webpack_exports__, "createFeatureClass", (function() {
    return createFeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "createSubfeatureClass", (function() {
    return createSubfeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "modules", (function() {
    return content_modules["default"];
  }));
  var environment_messaging = __webpack_require__(4);
  var wrapper = __webpack_require__(5);
  var constants = __webpack_require__(0);
  async function eventHandler(event) {
    const {from, senderId, message} = event.detail;
    if ("page" === from) {
      const respondedMessage = await bridge_bridge.postMessageToBackground(message);
      bridge_bridge.postMessageToInjected({
        senderId,
        message: respondedMessage
      });
    }
  }
  function handleBroadcastMessage(message) {
    const event = new CustomEvent(constants["BRIDGE_EVENT_TYPE"], {
      detail: {
        type: constants["BROADCASTING_MESSAGE"],
        message
      }
    });
    window.dispatchEvent(event);
  }
  const bridge_bridge = Object(wrapper["a"])({
    async install() {
      await environment_messaging["a"].ready();
      environment_messaging["a"].registerBroadcastListener(handleBroadcastMessage);
      window.addEventListener(constants["BRIDGE_EVENT_TYPE"], eventHandler);
    },
    uninstall() {
      window.removeEventListener(constants["BRIDGE_EVENT_TYPE"], eventHandler);
    },
    async postMessageToBackground(message) {
      const respondedMessage = await environment_messaging["a"].postMessage(message);
      return respondedMessage;
    },
    postMessageToInjected({senderId, message}) {
      const event = new CustomEvent(constants["BRIDGE_EVENT_TYPE"], {
        detail: {
          from: "background",
          senderId,
          message
        }
      });
      window.dispatchEvent(event);
    }
  });
  var environment_bridge = bridge_bridge;
  const settings_settings = Object(wrapper["a"])({
    async install() {
      await environment_messaging["a"].ready();
    },
    readAll() {
      return environment_messaging["a"].postMessage({
        action: constants["SETTINGS_READ_ALL"]
      });
    }
  });
  var environment_settings = settings_settings;
  var extensionUnloaded = __webpack_require__(12);
  var log = __webpack_require__(6);
  function appendToRoot(element) {
    document.documentElement.append(element);
  }
  function appendToHead(element) {
    document.head.append(element);
  }
  function insertImmediatelyAfterHead(element) {
    document.head.after(element);
  }
  function insertBeforeBody(element) {
    if (document.body) document.body.before(element); else document.documentElement.append(element);
  }
  var loadAsset = opts => {
    var _context;
    const {type, url, code, async, mount = appendToHead, dataset} = opts;
    let element;
    if ("style" === type && code) {
      element = document.createElement("style");
      element.setAttribute("type", "text/css");
      element.append(document.createTextNode(code));
    } else if ("style" === type && url) {
      element = document.createElement("link");
      element.setAttribute("rel", "stylesheet");
      element.setAttribute("type", "text/css");
      element.setAttribute("href", url);
    } else if ("script" === type && code) {
      element = document.createElement("script");
      element.setAttribute("type", "text/javascript");
      element.append(document.createTextNode(code));
    } else if ("script" === type && url) {
      element = document.createElement("script");
      element.setAttribute("type", "text/javascript");
      element.setAttribute("src", url);
      async && element.setAttribute("async", "");
    }
    if (!element) return log["a"].error("非法参数：", opts);
    if (dataset) Object.assign(element.dataset, dataset);
    element.classList.add(constants["ASSET_CLASSNAME"]);
    mount(element);
    extensionUnloaded["a"].addListener((_context = element).remove.bind(_context));
    return element;
  };
  var injectScript = () => {
    const URL_INJECTED_JS = chrome.runtime.getURL("page.js");
    loadAsset({
      type: "script",
      url: URL_INJECTED_JS,
      mount: appendToRoot
    });
  };
  var index_esm = __webpack_require__(3);
  var keepRetry = __webpack_require__(15);
  var waitForHead = Object(index_esm["a"])(() => Object(keepRetry["a"])({
    checker: () => document.head,
    delay: 0
  }));
  var getExtensionOrigin = __webpack_require__(21);
  async function injectMainStyle() {
    await waitForHead();
    loadAsset({
      type: "style",
      url: Object(getExtensionOrigin["a"])() + "/page.css",
      mount: insertImmediatelyAfterHead
    });
  }
  async function createContentEnvironment() {
    environment_messaging["a"].ready();
    environment_bridge.ready();
    injectScript();
    injectMainStyle();
    await environment_settings.ready();
    return {
      messaging: environment_messaging["a"],
      settings: environment_settings
    };
  }
  var just_pick = __webpack_require__(7);
  var just_pick_default = __webpack_require__.n(just_pick);
  var fast_deep_equal = __webpack_require__(34);
  var fast_deep_equal_default = __webpack_require__.n(fast_deep_equal);
  var safelyInvokeFn = __webpack_require__(10);
  var promise_queue = __webpack_require__(35);
  var promise_queue_default = __webpack_require__.n(promise_queue);
  __webpack_require__(16);
  const STORAGE_KEY = "migrated";
  const MAX_CONCURRENT = 1;
  const MAX_QUEUE = 1 / 0;
  const queue = new promise_queue_default.a(MAX_CONCURRENT, MAX_QUEUE);
  var migrate = opts => queue.add(async () => {
    const {storage, storageAreaName, migrationId, executor} = opts;
    const migrated = await storage.read(STORAGE_KEY, storageAreaName) || [];
    if ("string" !== typeof storageAreaName) throw new TypeError("必须指定 storageAreaName");
    if ("string" !== typeof migrationId) throw new TypeError("必须指定 migrationId");
    if ("function" !== typeof executor) throw new TypeError("必须指定 executor");
    if (false) ;
    if (!migrated.includes(migrationId)) {
      try {
        await executor();
      } catch (error) {
        log["a"].error(error);
      }
      await storage.write(STORAGE_KEY, [ ...migrated, migrationId ], storageAreaName);
    }
  });
  var createFeatureClass = ({messaging, bridge, settings, modules}) => class {
    constructor({featureName, metadata}) {
      this.featureName = featureName;
      this.metadata = metadata;
      this.subfeatures = [];
      this.optionValuesCache = {};
      this.isLoaded = false;
    }
    get transport() {
      return messaging || bridge;
    }
    addSubfeature(subfeature) {
      this.subfeatures.push(subfeature);
    }
    async init() {
      await this.loadOptionValues();
      await this.migrate();
      if (this.metadata.isSoldered || await this.checkIfEnabled()) await this.load();
      this.listenOnSettingsChange();
      this.listenOnExtensionUnload();
    }
    async loadOptionValues() {
      const optionValues = await settings.readAll();
      this.optionValuesCache = just_pick_default()(optionValues, this.metadata.optionNames);
    }
    async migrate() {
      const {storage} = modules;
      for (const subfeature of this.subfeatures) {
        const {migrations = []} = subfeature;
        for (const migration of migrations) await migrate({
          storage,
          ...migration
        });
      }
    }
    checkIfEnabled() {
      return this.optionValuesCache[this.featureName];
    }
    load() {
      if (this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.load.bind(subfeature));
      this.isLoaded = true;
    }
    unload() {
      if (!this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.unload.bind(subfeature));
      this.isLoaded = false;
    }
    listenOnSettingsChange() {
      this.transport.registerBroadcastListener(message => {
        if (message.action === constants["SETTINGS_CHANGED"]) this.handleSettingsChange();
      });
    }
    async handleSettingsChange() {
      const previousOptionValues = this.optionValuesCache;
      await this.loadOptionValues();
      const currentOptionValues = this.optionValuesCache;
      const previousEnabled = previousOptionValues[this.featureName];
      const currentEnabled = currentOptionValues[this.featureName];
      if (currentEnabled === previousEnabled) {
        if (!currentEnabled) return;
        if (fast_deep_equal_default()(previousOptionValues, currentOptionValues)) return;
        for (const subfeature of this.subfeatures) subfeature.handleSettingsChange();
      } else if (this.isLoaded) this.unload(); else this.load();
    }
    listenOnExtensionUnload() {
      extensionUnloaded["a"].addListener(this.handleExtensionUnload.bind(this));
    }
    handleExtensionUnload() {
      this.unload();
    }
  };
  var select_dom = __webpack_require__(1);
  var element_ready = __webpack_require__(2);
  var element_ready_default = __webpack_require__.n(element_ready);
  class ElementCollection_ElementCollection {
    constructor() {
      this._collection = {};
    }
    add(elements) {
      for (const [alias, elementOpts] of Object.entries(elements)) {
        let selector, parent, getAll;
        if ("string" === typeof elementOpts) {
          selector = elementOpts;
          getAll = false;
        } else {
          selector = elementOpts.selector;
          parent = elementOpts.parent;
          getAll = elementOpts.getAll;
        }
        if ("string" !== typeof selector) throw new TypeError("selector 未指定");
        this._collection[alias] = {
          selector,
          parent,
          getAll,
          element: null,
          promise: null
        };
      }
    }
    has(alias) {
      return {}.hasOwnProperty.call(this._collection, alias);
    }
    get(alias) {
      if (Array.isArray(alias)) {
        const ret = {};
        for (const item of alias) ret[item] = this.get(item);
        return ret;
      }
      const entry = this._collection[alias];
      if (!entry.element || entry.getAll && !entry.element.length) {
        const fn = entry.getAll ? select_dom["a"].all : select_dom["a"];
        const parent = entry.parent ? this.get(entry.parent) : document;
        entry.element = fn(entry.selector, parent);
      }
      return entry.element;
    }
    getAll() {
      const allAliases = Object.keys(this._collection);
      return this.get(allAliases);
    }
    getToken(alias) {
      return {
        isElementCollectionToken: true,
        collection: this,
        alias
      };
    }
    ready(alias) {
      const entry = this._collection[alias];
      if (entry.parent) throw new Error("不能设定 parent");
      if (!entry.promise) entry.promise = element_ready_default()(entry.selector);
      return entry.promise;
    }
    free() {
      for (const entry of Object.values(this._collection)) entry.element = entry.promise = null;
    }
  }
  var promiseEvery = __webpack_require__(18);
  var createSubfeatureClass = ({messaging, bridge, modules}) => class {
    constructor({featureName, subfeatureName, style, script, parent}) {
      var _this$script;
      this.requireModules = moduleNames => {
        const requiredModules = {};
        for (const moduleName of moduleNames) {
          const module = modules[moduleName];
          if (!module) throw new Error("未知 module：" + moduleName);
          this.waitReadyFns.push(module.ready);
          requiredModules[moduleName] = module;
        }
        return requiredModules;
      };
      this.registerDOMEventListener = (element, eventType, listener, opts = false) => {
        if (!element) log["a"].error("element 不存在"); else if ("string" === typeof element && !this.elementCollection.has(element)) log["a"].error("如果使用选择器，请通过 ElementCollection 注册：", element); else if ("string" !== typeof element && !element.addEventListener) log["a"].error("element 不存在或类型非法", element);
        this.domEventListeners = [ ...this.domEventListeners, {
          element,
          eventType,
          listener,
          opts
        } ];
      };
      this.readOptionValue = key => {
        const optionName = `${this.featureName}/${key}`;
        const optionValue = this.parent.optionValuesCache[optionName];
        return optionValue;
      };
      this.featureName = featureName;
      this.subfeatureName = subfeatureName;
      this.parent = parent;
      this.initContext();
      if (style) this.style = {
        element: null,
        code: style
      };
      if (script) {
        const featureScriptObj = script(this.context) || {};
        if (featureScriptObj.waitReady) this.waitReadyFns.push(featureScriptObj.waitReady);
        this.migrations = featureScriptObj.migrations;
        this.script = just_pick_default()(featureScriptObj, [ "applyWhen", "onLoad", "onSettingsChange", "onUnload" ]);
      }
      this.isApplicable = Object(index_esm["a"])((null === (_this$script = this.script) || void 0 === _this$script ? void 0 : _this$script.applyWhen) || (() => Promise.resolve(true)));
    }
    get transport() {
      return messaging || bridge;
    }
    initContext() {
      this.waitReadyFns = [];
      this.domEventListeners = [];
      this.elementCollection = new ElementCollection_ElementCollection;
      this.context = {
        ...just_pick_default()(this, [ "requireModules", "registerDOMEventListener", "elementCollection", "readOptionValue" ]),
        ...just_pick_default()(this.transport, [ "registerBroadcastListener", "unregisterBroadcastListener" ])
      };
    }
    async load() {
      if (!await this.isApplicable()) return;
      await this.loadStyle();
      await this.loadScript();
    }
    async unload() {
      if (!await this.isApplicable()) return;
      this.unloadStyle();
      this.unloadScript();
    }
    async loadStyle() {
      if (!this.style) return;
      await waitForHead();
      this.style.element = loadAsset({
        type: "style",
        code: this.style.code,
        dataset: just_pick_default()(this, [ "featureName", "subfeatureName" ]),
        mount: insertBeforeBody
      });
    }
    unloadStyle() {
      if (!this.style) return;
      this.style.element.remove();
      this.style.element = null;
    }
    async loadScript() {
      if (!this.script) return;
      if (await Object(promiseEvery["a"])(this.waitReadyFns.map(fn => fn()))) {
        var _this$script$onLoad, _this$script2;
        this.bindDOMEventListeners();
        await (null === (_this$script$onLoad = (_this$script2 = this.script).onLoad) || void 0 === _this$script$onLoad ? void 0 : _this$script$onLoad.call(_this$script2));
      } else log["a"].debug(`${this.featureName}[${this.subfeatureName}] 没有加载，因为 waitReady 检查未通过`);
    }
    async unloadScript() {
      var _this$script$onUnload, _this$script3;
      if (!this.script) return;
      this.unbindDOMEventListeners();
      await (null === (_this$script$onUnload = (_this$script3 = this.script).onUnload) || void 0 === _this$script$onUnload ? void 0 : _this$script$onUnload.call(_this$script3));
      this.elementCollection.free();
    }
    bindDOMEventListeners() {
      this.processDOMEventListeners("addEventListener");
    }
    unbindDOMEventListeners() {
      this.processDOMEventListeners("removeEventListener");
    }
    processDOMEventListeners(methodName) {
      for (const entry of this.domEventListeners) {
        const {element, eventType, listener, opts} = entry;
        if (!element) {
          log["a"].error("DOM 元素不存在", entry);
          continue;
        }
        const actualElement = "string" === typeof element ? this.elementCollection.get(element) : element;
        const actualElementArray = Array.isArray(actualElement) ? actualElement : [ actualElement ];
        for (const actualElement_ of actualElementArray) actualElement_[methodName](eventType, listener, opts);
      }
    }
    handleSettingsChange() {
      var _this$script$onSettin, _this$script4;
      null === (_this$script$onSettin = (_this$script4 = this.script).onSettingsChange) || void 0 === _this$script$onSettin ? void 0 : _this$script$onSettin.call(_this$script4);
    }
  };
  var content_modules = __webpack_require__(22);
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var dom_chef = __webpack_require__(20);
  var select_dom = __webpack_require__(1);
  var element_ready = __webpack_require__(2);
  var element_ready_default = __webpack_require__.n(element_ready);
  var p_sleep = __webpack_require__(19);
  var p_sleep_default = __webpack_require__.n(p_sleep);
  async function fade(element, duration, start, end) {
    const {opacity, transition} = element.style;
    element.style.transition = "unset !important";
    element.style.opacity = start;
    element.style.transition = `opacity ${duration}ms`;
    await p_sleep_default()(0);
    element.style.opacity = end;
    await p_sleep_default()(duration);
    element.style.transition = transition;
    element.style.transition = opacity;
  }
  function fadeIn(element, duration) {
    return fade(element, duration, 0, 1);
  }
  function fadeOut(element, duration) {
    return fade(element, duration, 1, 0);
  }
  const FADE_DURATION = 500;
  const STAY_DURATION = 3500;
  const CLASSNAME_INFO = "sysmsg";
  const CLASSNAME_ERROR = "errmsg";
  let container;
  let header;
  function removeExisitingNotifications() {
    const elements = select_dom["a"].all(`.${CLASSNAME_INFO}, .${CLASSNAME_ERROR}`, container);
    for (const element of elements) element.remove();
  }
  function createNotification(className, text) {
    const element = Object(dom_chef["h"])("div", {
      className
    }, text);
    header.after(element);
    return element;
  }
  async function animate(element) {
    await fadeIn(element, FADE_DURATION);
    await p_sleep_default()(STAY_DURATION);
    await fadeOut(element, FADE_DURATION);
    element.remove();
  }
  __webpack_exports__["default"] = {
    async ready() {
      container = await element_ready_default()("#container");
      header = await element_ready_default()("#header");
      return container && header;
    },
    create(type, text) {
      removeExisitingNotifications();
      return animate(createNotification(type, text));
    },
    INFO: CLASSNAME_INFO,
    ERROR: CLASSNAME_ERROR
  };
} ]);