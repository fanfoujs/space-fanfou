(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ("undefined" !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && "object" === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value
    });
    if (2 & mode && "string" != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function() {
      return module["default"];
    } : function() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 8);
})([ function(module, exports, __webpack_require__) {
  (function(__filename) {
    function loadConstants() {
      const context = __webpack_require__(1);
      return context.keys().reduce((constants, key) => key.endsWith(__filename) ? constants : Object.assign(constants, context(key)), {});
    }
    module.exports = Object.assign(exports, loadConstants());
  }).call(this, "/index.js");
}, function(module, exports, __webpack_require__) {
  var map = {
    "./action-types.js": 2,
    "./assets.js": 3,
    "./custom-event-types.js": 4,
    "./extension-origin.js": 5,
    "./index.js": 0,
    "./message-types.js": 6,
    "./others.js": 7
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 1;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "STORAGE_READ", (function() {
    return STORAGE_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_WRITE", (function() {
    return STORAGE_WRITE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_DELETE", (function() {
    return STORAGE_DELETE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_CHANGED", (function() {
    return STORAGE_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ", (function() {
    return SETTINGS_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ_ALL", (function() {
    return SETTINGS_READ_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_WRITE_ALL", (function() {
    return SETTINGS_WRITE_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_CHANGED", (function() {
    return SETTINGS_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "GET_OPTION_DEFS", (function() {
    return GET_OPTION_DEFS;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_FETCH_GET", (function() {
    return PROXIED_FETCH_GET;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_AUDIO", (function() {
    return PROXIED_AUDIO;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_CREATE_TAB", (function() {
    return PROXIED_CREATE_TAB;
  }));
  const STORAGE_READ = "STORAGE_READ";
  const STORAGE_WRITE = "STORAGE_WRITE";
  const STORAGE_DELETE = "STORAGE_DELETE";
  const STORAGE_CHANGED = "STORAGE_CHANGED";
  const SETTINGS_READ = "SETTINGS_READ";
  const SETTINGS_READ_ALL = "SETTINGS_READ_ALL";
  const SETTINGS_WRITE_ALL = "SETTINGS_WRITE_ALL";
  const SETTINGS_CHANGED = "SETTINGS_CHANGED";
  const GET_OPTION_DEFS = "GET_OPTION_DEFS";
  const PROXIED_FETCH_GET = "PROXIED_FETCH_GET";
  const PROXIED_AUDIO = "PROXIED_AUDIO";
  const PROXIED_CREATE_TAB = "PROXIED_CREATE_TAB";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "ASSET_CLASSNAME", (function() {
    return ASSET_CLASSNAME;
  }));
  const ASSET_CLASSNAME = "sf-asset";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BRIDGE_EVENT_TYPE", (function() {
    return BRIDGE_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "POST_STATUS_SUCCESS_EVENT_TYPE", (function() {
    return POST_STATUS_SUCCESS_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_UNLOADED_EVENT_TYPE", (function() {
    return EXTENSION_UNLOADED_EVENT_TYPE;
  }));
  const BRIDGE_EVENT_TYPE = "SpaceFanfouBridgeMessage";
  const POST_STATUS_SUCCESS_EVENT_TYPE = "SpaceFanfouPostStatusSuccess";
  const EXTENSION_UNLOADED_EVENT_TYPE = "SpaceFanfouUnloaded";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER_RE", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER_RE;
  }));
  const EXTENSION_ORIGIN_PLACEHOLDER = "<EXTENSION_ORIGIN_PLACEHOLDER>";
  const EXTENSION_ORIGIN_PLACEHOLDER_RE = new RegExp(EXTENSION_ORIGIN_PLACEHOLDER, "g");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BROADCASTING_MESSAGE", (function() {
    return BROADCASTING_MESSAGE;
  }));
  __webpack_require__.d(__webpack_exports__, "CONVERSATIONAL_MESSAGE", (function() {
    return CONVERSATIONAL_MESSAGE;
  }));
  const BROADCASTING_MESSAGE = "BROADCASTING_MESSAGE";
  const CONVERSATIONAL_MESSAGE = "CONVERSATIONAL_MESSAGE";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "CONTROL_PLACEHOLDER", (function() {
    return CONTROL_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_KEY_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_KEY_IS_EXTENSION_UPGRADED;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED;
  }));
  const CONTROL_PLACEHOLDER = "<CONTROL_PLACEHOLDER>";
  const STORAGE_KEY_IS_EXTENSION_UPGRADED = "is-extension-upgraded";
  const STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED = "session";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var constants = __webpack_require__(0);
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === constants["PROXIED_AUDIO"]) {
      const {audioUrl} = request.payload;
      const audio = new Audio;
      audio.src = audioUrl;
      audio.play().then(() => {
        sendResponse({
          success: true
        });
      }).catch(error => {
        console.error("Failed to play audio:", error);
        sendResponse({
          success: false,
          error: error.message
        });
      });
      return true;
    }
  });
} ]);