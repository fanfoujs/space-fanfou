(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ("undefined" !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && "object" === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value
    });
    if (2 & mode && "string" != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function() {
      return module["default"];
    } : function() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 41);
})([ function(module, exports, __webpack_require__) {
  (function(__filename) {
    function loadConstants() {
      const context = __webpack_require__(45);
      return context.keys().reduce((constants, key) => key.endsWith(__filename) ? constants : Object.assign(constants, context(key)), {});
    }
    module.exports = Object.assign(exports, loadConstants());
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(21);
  var _libs_log__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
  var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(0);
  const messageHandlers = {};
  const connectedPorts = [];
  const broadcastListeners = [];
  function createMessageHandler(port) {
    return async ({senderId, message}) => {
      const handler = messageHandlers[message.action];
      let respondedMessage;
      if (handler) {
        try {
          respondedMessage = await handler(message.payload);
        } catch (error) {
          _libs_log__WEBPACK_IMPORTED_MODULE_3__["a"].error(error);
        }
        if (!isPortDisconnected(port)) port.postMessage({
          senderId,
          message: respondedMessage
        });
      } else throw new Error(`未知消息类型 「${message.action}」`);
    };
  }
  function isPortDisconnected(port) {
    return !connectedPorts.includes(port);
  }
  const messaging = {
    install() {
      chrome.runtime.onConnect.addListener(port => {
        connectedPorts.push(port);
        port.onMessage.addListener(createMessageHandler(port));
        port.onDisconnect.addListener(() => Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_2__["a"])(connectedPorts, port));
      });
    },
    registerHandler(actionType, handler) {
      if (messageHandlers[actionType]) throw new Error(`重复注册 「${actionType}」 类型的消息处理器`); else messageHandlers[actionType] = handler;
    },
    unregisterHandler(actionType) {
      if (!delete messageHandlers[actionType]) throw new Error(`不存在 「${actionType}」 类型的消息处理器，因此取消注册失败`);
    },
    registerBroadcastListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_1__["a"])(broadcastListeners, fn);
    },
    broadcastMessage(message) {
      for (const port of connectedPorts) port.postMessage({
        type: _constants__WEBPACK_IMPORTED_MODULE_4__["BROADCASTING_MESSAGE"],
        message
      });
      this.handleBroadcastMessage(message);
    },
    handleBroadcastMessage(message) {
      Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_0__["a"])({
        fns: broadcastListeners,
        args: [ message ]
      });
    }
  };
  __webpack_exports__["a"] = messaging;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var messaging = __webpack_require__(1);
  var pify = __webpack_require__(36);
  var pify_default = __webpack_require__.n(pify);
  var promisifyChromeApi = fn => pify_default()(fn, {
    errorFirst: false
  });
  var safelyInvokeFns = __webpack_require__(8);
  function initLocalStorage() {
    var _context;
    const get = promisifyChromeApi((_context = chrome.storage.local).get.bind(_context));
    const set = promisifyChromeApi((_context = chrome.storage.local).set.bind(_context));
    const remove = promisifyChromeApi((_context = chrome.storage.local).remove.bind(_context));
    const listeners = [];
    chrome.storage.local.onChanged.addListener(changes => {
      Object(safelyInvokeFns["a"])({
        fns: listeners,
        args: [ changes ]
      });
    });
    return {
      async read(key) {
        return (await get(key))[key];
      },
      readAll() {
        return get(null);
      },
      async write(key, value) {
        await set({
          [key]: value
        });
      },
      async writeAll(object) {
        await set(object);
      },
      async delete(key) {
        await remove(key);
      },
      listen(fn) {
        listeners.push(fn);
      }
    };
  }
  var storage_areas_local = initLocalStorage();
  var fast_deep_equal = __webpack_require__(9);
  var fast_deep_equal_default = __webpack_require__.n(fast_deep_equal);
  function initSyncStorage() {
    var _context;
    const get = promisifyChromeApi((_context = chrome.storage.sync).get.bind(_context));
    const set = promisifyChromeApi((_context = chrome.storage.sync).set.bind(_context));
    const remove = promisifyChromeApi((_context = chrome.storage.sync).remove.bind(_context));
    const listeners = [];
    chrome.storage.sync.onChanged.addListener(changes => {
      Object(safelyInvokeFns["a"])({
        fns: listeners,
        args: [ changes ]
      });
    });
    return {
      async read(key) {
        return (await get(key))[key];
      },
      readAll() {
        return get(null);
      },
      async write(key, value) {
        const oldValue = await get(key);
        if (!fast_deep_equal_default()(oldValue, value)) await set({
          [key]: value
        });
      },
      async writeAll(object) {
        const oldValue = {};
        for (const key of Object.keys(object)) oldValue[key] = await get(key);
        if (!fast_deep_equal_default()(oldValue, object)) await set(object);
      },
      async delete(key) {
        await remove(key);
      },
      listen(fn) {
        listeners.push(fn);
      }
    };
  }
  var storage_areas_sync = initSyncStorage();
  function initSessionStorage() {
    const memoryStorage = {};
    return {
      read(key) {
        const isExists = memoryStorage.hasOwnProperty(key);
        const value = isExists ? memoryStorage[key] : null;
        return value;
      },
      readAll() {
        return {
          ...memoryStorage
        };
      },
      write(key, value) {
        memoryStorage[key] = value;
      },
      delete(key) {
        delete memoryStorage[key];
      }
    };
  }
  var session = initSessionStorage();
  var arrayUniquePush = __webpack_require__(20);
  var arrayRemove = __webpack_require__(21);
  function initStorageAreas() {
    const storageAreas = {
      local: storage_areas_local,
      sync: storage_areas_sync,
      session
    };
    const listeners = [];
    const createListener = storageAreaName => changes => {
      for (const [key, {oldValue, newValue}] of Object.entries(changes)) Object(safelyInvokeFns["a"])({
        fns: listeners,
        args: [ {
          key,
          storageAreaName,
          oldValue,
          newValue
        } ]
      });
    };
    for (const storageAreaName of [ "local", "sync" ]) storageAreas[storageAreaName].listen(createListener(storageAreaName));
    return {
      ...storageAreas,
      listen: fn => Object(arrayUniquePush["a"])(listeners, fn),
      unlisten: fn => Object(arrayRemove["a"])(listeners, fn)
    };
  }
  var storage_areas = initStorageAreas();
  var expose = object => {
    if ("undefined" === typeof SF) window.SF = {};
    Object.assign(window.SF, object);
  };
  __webpack_require__(13);
  var constants = __webpack_require__(0);
  function registerHandlers() {
    messaging["a"].registerHandler(constants["STORAGE_READ"], async payload => {
      const {storageAreaName, key} = payload;
      const value = await storage.read(key, storageAreaName);
      return {
        value
      };
    });
    messaging["a"].registerHandler(constants["STORAGE_WRITE"], async payload => {
      const {storageAreaName, key, value} = payload;
      await storage.write(key, value, storageAreaName);
    });
    messaging["a"].registerHandler(constants["STORAGE_DELETE"], async payload => {
      const {storageAreaName, key} = payload;
      await storage.delete(key, storageAreaName);
    });
    storage_areas.listen(changeDetails => {
      messaging["a"].broadcastMessage({
        action: constants["STORAGE_CHANGED"],
        payload: changeDetails
      });
    });
  }
  const storage = {
    install() {
      registerHandlers();
    },
    read(key, storageAreaName) {
      return storage_areas[storageAreaName].read(key);
    },
    write(key, value, storageAreaName) {
      if (false) ;
      return storage_areas[storageAreaName].write(key, value);
    },
    delete(key, storageAreaName) {
      return storage_areas[storageAreaName].delete(key);
    }
  };
  expose({
    storage: {
      ...false ? void 0 : {},
      readAll(storageAreaName) {
        return storage_areas[storageAreaName].readAll();
      },
      async import({sync, local}) {
        await Promise.all([ storage_areas.sync.writeAll(sync), storage_areas.local.writeAll(local) ]);
      },
      async export() {
        return {
          sync: await storage_areas.sync.readAll(),
          local: await storage_areas.local.readAll()
        };
      }
    }
  });
  __webpack_exports__["a"] = storage;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  (function(global) {
    var __spreadArray = (void 0, function(to, from, pack) {
      if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
      return to.concat(ar || Array.prototype.slice.call(from));
    });
    var config = {
      defaults: {},
      errorType: null,
      polyfills: {
        fetch: null,
        FormData: null,
        URLSearchParams: null,
        performance: null,
        PerformanceObserver: null,
        AbortController: null
      },
      polyfill: function(p, _a) {
        var _b = void 0 === _a ? {} : _a, _c = _b.doThrow, doThrow = void 0 === _c ? true : _c, _d = _b.instance, instance = void 0 === _d ? false : _d;
        var args = [];
        for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
        var res = this.polyfills[p] || ("undefined" !== typeof self ? self[p] : null) || ("undefined" !== typeof global ? global[p] : null);
        if (doThrow && !res) throw new Error(p + " is not defined");
        return instance && res ? new (res.bind.apply(res, __spreadArray([ void 0 ], args, false))) : res;
      }
    };
    __webpack_exports__["a"] = config;
  }).call(this, __webpack_require__(42));
}, function(module, exports) {
  module.exports = pick;
  function pick(obj, select) {
    var result = {};
    if ("string" === typeof select) select = [].slice.call(arguments, 1);
    var len = select.length;
    for (var i = 0; i < len; i++) {
      var key = select[i];
      if (key in obj) result[key] = obj[key];
    }
    return result;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  let outputLevel = 1;
  if (true) outputLevel = 2;
  function log(level, logger, ...message) {
    if (level >= outputLevel) logger("[SpaceFanfou]", ...message);
  }
  __webpack_exports__["a"] = {
    debug(...message) {
      log(0, console.log, ...message);
    },
    info(...message) {
      log(1, console.log, ...message);
    },
    error(...message) {
      log(2, console.error, ...message);
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var defined__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17);
  var defined__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(defined__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5);
  function defaultExceptionHandler(error) {
    _libs_log__WEBPACK_IMPORTED_MODULE_1__["a"].error(error);
  }
  __webpack_exports__["a"] = opts => {
    let fn;
    if ("function" === typeof opts) {
      fn = opts;
      opts = {};
    } else fn = opts.fn;
    const exceptionHandler = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.exceptionHandler, defaultExceptionHandler);
    const args = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.args, []);
    try {
      fn(...args);
    } catch (error) {
      exceptionHandler(error);
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isObj = __webpack_require__(43);
  const disallowedKeys = [ "__proto__", "prototype", "constructor" ];
  const isValidPath = pathSegments => !pathSegments.some(segment => disallowedKeys.includes(segment));
  function getPathSegments(path) {
    const pathArray = path.split(".");
    const parts = [];
    for (let i = 0; i < pathArray.length; i++) {
      let p = pathArray[i];
      while ("\\" === p[p.length - 1] && void 0 !== pathArray[i + 1]) {
        p = p.slice(0, -1) + ".";
        p += pathArray[++i];
      }
      parts.push(p);
    }
    if (!isValidPath(parts)) return [];
    return parts;
  }
  module.exports = {
    get(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return void 0 === value ? object : value;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return;
      for (let i = 0; i < pathArray.length; i++) {
        if (!Object.prototype.propertyIsEnumerable.call(object, pathArray[i])) return value;
        object = object[pathArray[i]];
        if (void 0 === object || null === object) {
          if (i !== pathArray.length - 1) return value;
          break;
        }
      }
      return object;
    },
    set(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return object;
      const root = object;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (!isObj(object[p])) object[p] = {};
        if (i === pathArray.length - 1) object[p] = value;
        object = object[p];
      }
      return root;
    },
    delete(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (i === pathArray.length - 1) {
          delete object[p];
          return true;
        }
        object = object[p];
        if (!isObj(object)) return false;
      }
    },
    has(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return false;
      for (let i = 0; i < pathArray.length; i++) if (isObj(object)) {
        if (!(pathArray[i] in object)) return false;
        object = object[pathArray[i]];
      } else return false;
      return true;
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
  __webpack_exports__["a"] = opts => {
    if (Array.isArray(opts)) opts = {
      fns: opts
    };
    const {fns, ...restOpts} = opts;
    for (const fn of fns) Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__["a"])({
      fn,
      ...restOpts
    });
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && "object" == typeof a && "object" == typeof b) {
      if (a.constructor !== b.constructor) return false;
      var length, i, keys;
      if (Array.isArray(a)) {
        length = a.length;
        if (length != b.length) return false;
        for (i = length; 0 !== i--; ) if (!equal(a[i], b[i])) return false;
        return true;
      }
      if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
      if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
      if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length) return false;
      for (i = length; 0 !== i--; ) if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
      for (i = length; 0 !== i--; ) {
        var key = keys[i];
        if (!equal(a[key], b[key])) return false;
      }
      return true;
    }
    return a !== a && b !== b;
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var __assign = (void 0, function() {
    __assign = Object.assign || function(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  });
  var __spreadArray = (void 0, function(to, from, pack) {
    if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  });
  var mix = function(one, two, mergeArrays) {
    if (void 0 === mergeArrays) mergeArrays = false;
    if (!one || !two || "object" !== typeof one || "object" !== typeof two) return one;
    var clone = __assign({}, one);
    for (var prop in two) if (two.hasOwnProperty(prop)) if (two[prop] instanceof Array && one[prop] instanceof Array) clone[prop] = mergeArrays ? __spreadArray(__spreadArray([], one[prop], true), two[prop], true) : two[prop]; else if ("object" === typeof two[prop] && "object" === typeof one[prop]) clone[prop] = mix(one[prop], two[prop], mergeArrays); else clone[prop] = two[prop];
    return clone;
  };
  var config = __webpack_require__(3);
  var onMatch = function(entries, name, callback, _performance) {
    if (!entries.getEntriesByName) return false;
    var matches = entries.getEntriesByName(name);
    if (matches && matches.length > 0) {
      callback(matches.reverse()[0]);
      if (_performance.clearMeasures) _performance.clearMeasures(name);
      perfs.callbacks.delete(name);
      if (perfs.callbacks.size < 1) {
        perfs.observer.disconnect();
        if (_performance.clearResourceTimings) _performance.clearResourceTimings();
      }
      return true;
    }
    return false;
  };
  var lazyObserver = function(_performance, _observer) {
    if (!perfs.observer && _performance && _observer) {
      perfs.observer = new _observer((function(entries) {
        perfs.callbacks.forEach((function(callback, name) {
          onMatch(entries, name, callback, _performance);
        }));
      }));
      if (_performance.clearResourceTimings) _performance.clearResourceTimings();
    }
    return perfs.observer;
  };
  var perfs = {
    callbacks: new Map,
    observer: null,
    observe: function(name, callback) {
      if (!name || !callback) return;
      var _performance = config["a"].polyfill("performance", {
        doThrow: false
      });
      var _observer = config["a"].polyfill("PerformanceObserver", {
        doThrow: false
      });
      if (!lazyObserver(_performance, _observer)) return;
      if (!onMatch(_performance, name, callback, _performance)) {
        if (perfs.callbacks.size < 1) perfs.observer.observe({
          entryTypes: [ "resource", "measure" ]
        });
        perfs.callbacks.set(name, callback);
      }
    }
  };
  var dist_perfs = perfs;
  var middlewareHelper = function(middlewares) {
    return function(fetchFunction) {
      return 0 === middlewares.length ? fetchFunction : 1 === middlewares.length ? middlewares[0](fetchFunction) : middlewares.reduceRight((function(acc, curr, idx) {
        return idx === middlewares.length - 2 ? curr(acc(fetchFunction)) : curr(acc);
      }));
    };
  };
  var WretchErrorWrapper = function() {
    function WretchErrorWrapper(error) {
      this.error = error;
    }
    return WretchErrorWrapper;
  }();
  var resolver = function(wretcher) {
    var url = wretcher._url, _catchers = wretcher._catchers, resolvers = wretcher._resolvers, middlewares = wretcher._middlewares, opts = wretcher._options;
    var catchers = new Map(_catchers);
    var finalOptions = mix(config["a"].defaults, opts);
    var fetchController = config["a"].polyfill("AbortController", {
      doThrow: false,
      instance: true
    });
    if (!finalOptions["signal"] && fetchController) finalOptions["signal"] = fetchController.signal;
    var timeout = {
      ref: null,
      clear: function() {
        if (timeout.ref) {
          clearTimeout(timeout.ref);
          timeout.ref = null;
        }
      }
    };
    var fetchRequest = middlewareHelper(middlewares)(config["a"].polyfill("fetch"))(url, finalOptions);
    var throwingPromise = fetchRequest.catch((function(error) {
      throw new WretchErrorWrapper(error);
    })).then((function(response) {
      timeout.clear();
      if (!response.ok) {
        if ("opaque" === response.type) {
          var err = new Error("Opaque response");
          err["status"] = response.status;
          err["response"] = response;
          throw err;
        }
        return response[config["a"].errorType || "text"]().then((function(msg) {
          var err = new Error(msg);
          err[config["a"].errorType || "text"] = msg;
          err["status"] = response.status;
          err["response"] = response;
          throw err;
        }));
      }
      return response;
    }));
    var catchersWrapper = function(promise) {
      return promise.catch((function(err) {
        timeout.clear();
        var error = err instanceof WretchErrorWrapper ? err.error : err;
        if (err instanceof WretchErrorWrapper && catchers.has("__fromFetch")) return catchers.get("__fromFetch")(error, wretcher); else if (catchers.has(error.status)) return catchers.get(error.status)(error, wretcher); else if (catchers.has(error.name)) return catchers.get(error.name)(error, wretcher); else throw error;
      }));
    };
    var bodyParser = function(funName) {
      return function(cb) {
        return funName ? catchersWrapper(throwingPromise.then((function(_) {
          return _ && _[funName]();
        })).then((function(_) {
          return cb ? cb(_) : _;
        }))) : catchersWrapper(throwingPromise.then((function(_) {
          return cb ? cb(_) : _;
        })));
      };
    };
    var responseChain = {
      res: bodyParser(null),
      json: bodyParser("json"),
      blob: bodyParser("blob"),
      formData: bodyParser("formData"),
      arrayBuffer: bodyParser("arrayBuffer"),
      text: bodyParser("text"),
      perfs: function(cb) {
        fetchRequest.then((function(res) {
          return dist_perfs.observe(res.url, cb);
        })).catch((function() {}));
        return responseChain;
      },
      setTimeout: function(time, controller) {
        if (void 0 === controller) controller = fetchController;
        timeout.clear();
        timeout.ref = setTimeout((function() {
          return controller.abort();
        }), time);
        return responseChain;
      },
      controller: function() {
        return [ fetchController, responseChain ];
      },
      error: function(errorId, cb) {
        catchers.set(errorId, cb);
        return responseChain;
      },
      badRequest: function(cb) {
        return responseChain.error(400, cb);
      },
      unauthorized: function(cb) {
        return responseChain.error(401, cb);
      },
      forbidden: function(cb) {
        return responseChain.error(403, cb);
      },
      notFound: function(cb) {
        return responseChain.error(404, cb);
      },
      timeout: function(cb) {
        return responseChain.error(408, cb);
      },
      internalError: function(cb) {
        return responseChain.error(500, cb);
      },
      fetchError: function(cb) {
        return responseChain.error("__fromFetch", cb);
      },
      onAbort: function(cb) {
        return responseChain.error("AbortError", cb);
      }
    };
    return resolvers.reduce((function(chain, r) {
      return r(chain, wretcher);
    }), responseChain);
  };
  var wretcher_assign = (void 0, function() {
    wretcher_assign = Object.assign || function(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return wretcher_assign.apply(this, arguments);
  });
  var wretcher_spreadArray = (void 0, function(to, from, pack) {
    if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  });
  var JSON_MIME = "application/json";
  var CONTENT_TYPE_HEADER = "Content-Type";
  function extractContentType(headers) {
    var _a;
    if (void 0 === headers) headers = {};
    return null === (_a = Object.entries(headers).find((function(_a) {
      var k = _a[0];
      return k.toLowerCase() === CONTENT_TYPE_HEADER.toLowerCase();
    }))) || void 0 === _a ? void 0 : _a[1];
  }
  function isLikelyJsonMime(value) {
    return /^application\/.*json.*/.test(value);
  }
  var wretcher_Wretcher = function() {
    function Wretcher(_url, _options, _catchers, _resolvers, _middlewares, _deferredChain) {
      if (void 0 === _catchers) _catchers = new Map;
      if (void 0 === _resolvers) _resolvers = [];
      if (void 0 === _middlewares) _middlewares = [];
      if (void 0 === _deferredChain) _deferredChain = [];
      this._url = _url;
      this._options = _options;
      this._catchers = _catchers;
      this._resolvers = _resolvers;
      this._middlewares = _middlewares;
      this._deferredChain = _deferredChain;
    }
    Wretcher.factory = function(url, options) {
      if (void 0 === url) url = "";
      if (void 0 === options) options = {};
      return new Wretcher(url, options);
    };
    Wretcher.prototype.selfFactory = function(_a) {
      var _b = void 0 === _a ? {} : _a, _c = _b.url, url = void 0 === _c ? this._url : _c, _d = _b.options, options = void 0 === _d ? this._options : _d, _e = _b.catchers, catchers = void 0 === _e ? this._catchers : _e, _f = _b.resolvers, resolvers = void 0 === _f ? this._resolvers : _f, _g = _b.middlewares, middlewares = void 0 === _g ? this._middlewares : _g, _h = _b.deferredChain, deferredChain = void 0 === _h ? this._deferredChain : _h;
      return new Wretcher(url, wretcher_assign({}, options), new Map(catchers), wretcher_spreadArray([], resolvers, true), wretcher_spreadArray([], middlewares, true), wretcher_spreadArray([], deferredChain, true));
    };
    Wretcher.prototype.defaults = function(options, mixin) {
      if (void 0 === mixin) mixin = false;
      config["a"].defaults = mixin ? mix(config["a"].defaults, options) : options;
      return this;
    };
    Wretcher.prototype.errorType = function(method) {
      config["a"].errorType = method;
      return this;
    };
    Wretcher.prototype.polyfills = function(polyfills) {
      config["a"].polyfills = wretcher_assign(wretcher_assign({}, config["a"].polyfills), polyfills);
      return this;
    };
    Wretcher.prototype.url = function(url, replace) {
      if (void 0 === replace) replace = false;
      if (replace) return this.selfFactory({
        url
      });
      var split = this._url.split("?");
      return this.selfFactory({
        url: split.length > 1 ? split[0] + url + "?" + split[1] : this._url + url
      });
    };
    Wretcher.prototype.options = function(options, mixin) {
      if (void 0 === mixin) mixin = true;
      return this.selfFactory({
        options: mixin ? mix(this._options, options) : options
      });
    };
    Wretcher.prototype.query = function(qp, replace) {
      if (void 0 === replace) replace = false;
      return this.selfFactory({
        url: appendQueryParams(this._url, qp, replace)
      });
    };
    Wretcher.prototype.headers = function(headerValues) {
      return this.selfFactory({
        options: mix(this._options, {
          headers: headerValues || {}
        })
      });
    };
    Wretcher.prototype.accept = function(headerValue) {
      return this.headers({
        Accept: headerValue
      });
    };
    Wretcher.prototype.content = function(headerValue) {
      var _a;
      return this.headers((_a = {}, _a[CONTENT_TYPE_HEADER] = headerValue, _a));
    };
    Wretcher.prototype.auth = function(headerValue) {
      return this.headers({
        Authorization: headerValue
      });
    };
    Wretcher.prototype.catcher = function(errorId, catcher) {
      var newMap = new Map(this._catchers);
      newMap.set(errorId, catcher);
      return this.selfFactory({
        catchers: newMap
      });
    };
    Wretcher.prototype.signal = function(controller) {
      return this.selfFactory({
        options: wretcher_assign(wretcher_assign({}, this._options), {
          signal: controller.signal
        })
      });
    };
    Wretcher.prototype.resolve = function(doResolve, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        resolvers: clear ? [ doResolve ] : wretcher_spreadArray(wretcher_spreadArray([], this._resolvers, true), [ doResolve ], false)
      });
    };
    Wretcher.prototype.defer = function(callback, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        deferredChain: clear ? [ callback ] : wretcher_spreadArray(wretcher_spreadArray([], this._deferredChain, true), [ callback ], false)
      });
    };
    Wretcher.prototype.middlewares = function(middlewares, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        middlewares: clear ? middlewares : wretcher_spreadArray(wretcher_spreadArray([], this._middlewares, true), middlewares, true)
      });
    };
    Wretcher.prototype.method = function(method, options, body) {
      if (void 0 === options) options = {};
      if (void 0 === body) body = null;
      var base = this.options(wretcher_assign(wretcher_assign({}, options), {
        method
      }));
      var contentType = extractContentType(base._options.headers);
      var jsonify = "object" === typeof body && (!base._options.headers || !contentType || isLikelyJsonMime(contentType));
      base = !body ? base : jsonify ? base.json(body, contentType) : base.body(body);
      return resolver(base._deferredChain.reduce((function(acc, curr) {
        return curr(acc, acc._url, acc._options);
      }), base));
    };
    Wretcher.prototype.get = function(options) {
      return this.method("GET", options);
    };
    Wretcher.prototype.delete = function(options) {
      return this.method("DELETE", options);
    };
    Wretcher.prototype.put = function(body, options) {
      return this.method("PUT", options, body);
    };
    Wretcher.prototype.post = function(body, options) {
      return this.method("POST", options, body);
    };
    Wretcher.prototype.patch = function(body, options) {
      return this.method("PATCH", options, body);
    };
    Wretcher.prototype.head = function(options) {
      return this.method("HEAD", options);
    };
    Wretcher.prototype.opts = function(options) {
      return this.method("OPTIONS", options);
    };
    Wretcher.prototype.replay = function(options) {
      return this.method(this._options.method, options);
    };
    Wretcher.prototype.body = function(contents) {
      return this.selfFactory({
        options: wretcher_assign(wretcher_assign({}, this._options), {
          body: contents
        })
      });
    };
    Wretcher.prototype.json = function(jsObject, contentType) {
      var currentContentType = extractContentType(this._options.headers);
      return this.content(contentType || isLikelyJsonMime(currentContentType) && currentContentType || JSON_MIME).body(JSON.stringify(jsObject));
    };
    Wretcher.prototype.formData = function(formObject, recursive) {
      if (void 0 === recursive) recursive = false;
      return this.body(convertFormData(formObject, recursive));
    };
    Wretcher.prototype.formUrl = function(input) {
      return this.body("string" === typeof input ? input : convertFormUrl(input)).content("application/x-www-form-urlencoded");
    };
    return Wretcher;
  }();
  var appendQueryParams = function(url, qp, replace) {
    var queryString;
    if ("string" === typeof qp) queryString = qp; else {
      var usp = config["a"].polyfill("URLSearchParams", {
        instance: true
      });
      for (var key in qp) if (qp[key] instanceof Array) for (var _i = 0, _a = qp[key]; _i < _a.length; _i++) {
        var val = _a[_i];
        usp.append(key, val);
      } else usp.append(key, qp[key]);
      queryString = usp.toString();
    }
    var split = url.split("?");
    if (!queryString) return replace ? split[0] : url;
    if (replace || split.length < 2) return split[0] + "?" + queryString;
    return url + "&" + queryString;
  };
  function convertFormData(formObject, recursive, formData, ancestors) {
    if (void 0 === recursive) recursive = false;
    if (void 0 === formData) formData = config["a"].polyfill("FormData", {
      instance: true
    });
    if (void 0 === ancestors) ancestors = [];
    Object.entries(formObject).forEach((function(_a) {
      var key = _a[0], value = _a[1];
      var formKey = ancestors.reduce((function(acc, ancestor) {
        return acc ? "".concat(acc, "[").concat(ancestor, "]") : ancestor;
      }), null);
      formKey = formKey ? "".concat(formKey, "[").concat(key, "]") : key;
      if (value instanceof Array) for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
        var item = value_1[_i];
        formData.append(formKey + "[]", item);
      } else if (recursive && "object" === typeof value && (!(recursive instanceof Array) || !recursive.includes(key))) {
        if (null !== value) convertFormData(value, recursive, formData, wretcher_spreadArray(wretcher_spreadArray([], ancestors, true), [ key ], false));
      } else formData.append(formKey, value);
    }));
    return formData;
  }
  function encodeQueryValue(key, value) {
    return encodeURIComponent(key) + "=" + encodeURIComponent("object" === typeof value ? JSON.stringify(value) : "" + value);
  }
  function convertFormUrl(formObject) {
    return Object.keys(formObject).map((function(key) {
      var value = formObject[key];
      if (value instanceof Array) return value.map((function(v) {
        return encodeQueryValue(key, v);
      })).join("&");
      return encodeQueryValue(key, value);
    })).join("&");
  }
  var factory = wretcher_Wretcher.factory;
  factory["default"] = wretcher_Wretcher.factory;
  __webpack_exports__["a"] = factory;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = () => {
    const {version, version_name: name} = chrome.runtime.getManifest();
    return name || version;
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return functionOnce;
  }));
  var functionOnce = once;
  function once(fn) {
    var called, value;
    if ("function" !== typeof fn) throw new Error("expected a function but got " + fn);
    return function() {
      if (called) return value;
      called = true;
      value = fn.apply(this, arguments);
      fn = void 0;
      return value;
    };
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return isLooseKebabCase;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return isLooseCamelCase;
  }));
  var casey_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16);
  var casey_js__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(casey_js__WEBPACK_IMPORTED_MODULE_0__);
  function isLooseKebabCase(string) {
    return casey_js__WEBPACK_IMPORTED_MODULE_0___default.a.isKebabCase(string) || casey_js__WEBPACK_IMPORTED_MODULE_0___default.a.isLowerCase(string);
  }
  function isLooseCamelCase(string) {
    return casey_js__WEBPACK_IMPORTED_MODULE_0___default.a.isCamelCase(string) || casey_js__WEBPACK_IMPORTED_MODULE_0___default.a.isLowerCase(string) && !casey_js__WEBPACK_IMPORTED_MODULE_0___default.a.isKebabCase(string);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = () => {};
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var service_background_namespaceObject = {};
  __webpack_require__.r(service_background_namespaceObject);
  __webpack_require__.d(service_background_namespaceObject, "default", (function() {
    return service_background;
  }));
  var notifications_service_background_namespaceObject = {};
  __webpack_require__.r(notifications_service_background_namespaceObject);
  __webpack_require__.d(notifications_service_background_namespaceObject, "default", (function() {
    return notifications_service_background;
  }));
  var update_details_background_namespaceObject = {};
  __webpack_require__.r(update_details_background_namespaceObject);
  __webpack_require__.d(update_details_background_namespaceObject, "default", (function() {
    return update_details_background;
  }));
  var _background_namespaceObject = {};
  __webpack_require__.r(_background_namespaceObject);
  __webpack_require__.d(_background_namespaceObject, "default", (function() {
    return _background;
  }));
  var metadata_namespaceObject = {};
  __webpack_require__.r(metadata_namespaceObject);
  __webpack_require__.d(metadata_namespaceObject, "options", (function() {
    return options;
  }));
  var batch_manage_relationships_metadata_namespaceObject = {};
  __webpack_require__.r(batch_manage_relationships_metadata_namespaceObject);
  __webpack_require__.d(batch_manage_relationships_metadata_namespaceObject, "options", (function() {
    return metadata_options;
  }));
  var batch_remove_private_messages_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_private_messages_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_private_messages_metadata_namespaceObject, "options", (function() {
    return batch_remove_private_messages_metadata_options;
  }));
  var batch_remove_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_statuses_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_statuses_metadata_namespaceObject, "options", (function() {
    return batch_remove_statuses_metadata_options;
  }));
  var better_at_autocomplete_metadata_namespaceObject = {};
  __webpack_require__.r(better_at_autocomplete_metadata_namespaceObject);
  __webpack_require__.d(better_at_autocomplete_metadata_namespaceObject, "isSoldered", (function() {
    return metadata_isSoldered;
  }));
  var box_shadows_metadata_namespaceObject = {};
  __webpack_require__.r(box_shadows_metadata_namespaceObject);
  __webpack_require__.d(box_shadows_metadata_namespaceObject, "options", (function() {
    return box_shadows_metadata_options;
  }));
  var check_friendship_metadata_namespaceObject = {};
  __webpack_require__.r(check_friendship_metadata_namespaceObject);
  __webpack_require__.d(check_friendship_metadata_namespaceObject, "options", (function() {
    return check_friendship_metadata_options;
  }));
  var check_saved_searches_metadata_namespaceObject = {};
  __webpack_require__.r(check_saved_searches_metadata_namespaceObject);
  __webpack_require__.d(check_saved_searches_metadata_namespaceObject, "options", (function() {
    return check_saved_searches_metadata_options;
  }));
  var enrich_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(enrich_statuses_metadata_namespaceObject);
  __webpack_require__.d(enrich_statuses_metadata_namespaceObject, "options", (function() {
    return enrich_statuses_metadata_options;
  }));
  var favorite_fanfouers_metadata_namespaceObject = {};
  __webpack_require__.r(favorite_fanfouers_metadata_namespaceObject);
  __webpack_require__.d(favorite_fanfouers_metadata_namespaceObject, "options", (function() {
    return favorite_fanfouers_metadata_options;
  }));
  var fix_photo_zoom_metadata_namespaceObject = {};
  __webpack_require__.r(fix_photo_zoom_metadata_namespaceObject);
  __webpack_require__.d(fix_photo_zoom_metadata_namespaceObject, "isSoldered", (function() {
    return fix_photo_zoom_metadata_isSoldered;
  }));
  var floating_status_form_metadata_namespaceObject = {};
  __webpack_require__.r(floating_status_form_metadata_namespaceObject);
  __webpack_require__.d(floating_status_form_metadata_namespaceObject, "options", (function() {
    return floating_status_form_metadata_options;
  }));
  var go_top_button_metadata_namespaceObject = {};
  __webpack_require__.r(go_top_button_metadata_namespaceObject);
  __webpack_require__.d(go_top_button_metadata_namespaceObject, "isSoldered", (function() {
    return go_top_button_metadata_isSoldered;
  }));
  var google_analytics_metadata_namespaceObject = {};
  __webpack_require__.r(google_analytics_metadata_namespaceObject);
  __webpack_require__.d(google_analytics_metadata_namespaceObject, "isSoldered", (function() {
    return google_analytics_metadata_isSoldered;
  }));
  var keyboard_shortcuts_metadata_namespaceObject = {};
  __webpack_require__.r(keyboard_shortcuts_metadata_namespaceObject);
  __webpack_require__.d(keyboard_shortcuts_metadata_namespaceObject, "isSoldered", (function() {
    return keyboard_shortcuts_metadata_isSoldered;
  }));
  var notifications_metadata_namespaceObject = {};
  __webpack_require__.r(notifications_metadata_namespaceObject);
  __webpack_require__.d(notifications_metadata_namespaceObject, "options", (function() {
    return notifications_metadata_options;
  }));
  var process_unread_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(process_unread_statuses_metadata_namespaceObject);
  __webpack_require__.d(process_unread_statuses_metadata_namespaceObject, "options", (function() {
    return process_unread_statuses_metadata_options;
  }));
  var remove_app_recommendations_metadata_namespaceObject = {};
  __webpack_require__.r(remove_app_recommendations_metadata_namespaceObject);
  __webpack_require__.d(remove_app_recommendations_metadata_namespaceObject, "options", (function() {
    return remove_app_recommendations_metadata_options;
  }));
  var remove_brackets_metadata_namespaceObject = {};
  __webpack_require__.r(remove_brackets_metadata_namespaceObject);
  __webpack_require__.d(remove_brackets_metadata_namespaceObject, "isSoldered", (function() {
    return remove_brackets_metadata_isSoldered;
  }));
  var remove_logo_beta_metadata_namespaceObject = {};
  __webpack_require__.r(remove_logo_beta_metadata_namespaceObject);
  __webpack_require__.d(remove_logo_beta_metadata_namespaceObject, "options", (function() {
    return remove_logo_beta_metadata_options;
  }));
  var remove_personalized_theme_metadata_namespaceObject = {};
  __webpack_require__.r(remove_personalized_theme_metadata_namespaceObject);
  __webpack_require__.d(remove_personalized_theme_metadata_namespaceObject, "options", (function() {
    return remove_personalized_theme_metadata_options;
  }));
  var retinafy_photos_metadata_namespaceObject = {};
  __webpack_require__.r(retinafy_photos_metadata_namespaceObject);
  __webpack_require__.d(retinafy_photos_metadata_namespaceObject, "isSoldered", (function() {
    return retinafy_photos_metadata_isSoldered;
  }));
  var share_new_avatar_metadata_namespaceObject = {};
  __webpack_require__.r(share_new_avatar_metadata_namespaceObject);
  __webpack_require__.d(share_new_avatar_metadata_namespaceObject, "isSoldered", (function() {
    return share_new_avatar_metadata_isSoldered;
  }));
  var share_to_fanfou_metadata_namespaceObject = {};
  __webpack_require__.r(share_to_fanfou_metadata_namespaceObject);
  __webpack_require__.d(share_to_fanfou_metadata_namespaceObject, "options", (function() {
    return share_to_fanfou_metadata_options;
  }));
  var show_contextual_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(show_contextual_statuses_metadata_namespaceObject);
  __webpack_require__.d(show_contextual_statuses_metadata_namespaceObject, "options", (function() {
    return show_contextual_statuses_metadata_options;
  }));
  var sidebar_statistics_metadata_namespaceObject = {};
  __webpack_require__.r(sidebar_statistics_metadata_namespaceObject);
  __webpack_require__.d(sidebar_statistics_metadata_namespaceObject, "isSoldered", (function() {
    return sidebar_statistics_metadata_isSoldered;
  }));
  var status_form_enhancements_metadata_namespaceObject = {};
  __webpack_require__.r(status_form_enhancements_metadata_namespaceObject);
  __webpack_require__.d(status_form_enhancements_metadata_namespaceObject, "isSoldered", (function() {
    return status_form_enhancements_metadata_isSoldered;
  }));
  var translucent_sidebar_metadata_namespaceObject = {};
  __webpack_require__.r(translucent_sidebar_metadata_namespaceObject);
  __webpack_require__.d(translucent_sidebar_metadata_namespaceObject, "options", (function() {
    return translucent_sidebar_metadata_options;
  }));
  var update_timestamps_metadata_namespaceObject = {};
  __webpack_require__.r(update_timestamps_metadata_namespaceObject);
  __webpack_require__.d(update_timestamps_metadata_namespaceObject, "isSoldered", (function() {
    return update_timestamps_metadata_isSoldered;
  }));
  var user_switcher_metadata_namespaceObject = {};
  __webpack_require__.r(user_switcher_metadata_namespaceObject);
  __webpack_require__.d(user_switcher_metadata_namespaceObject, "isSoldered", (function() {
    return user_switcher_metadata_isSoldered;
  }));
  var dist = __webpack_require__(10);
  function isQueryable(object) {
    return "function" === typeof object.querySelectorAll;
  }
  function select_dom_select(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    return (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelector(String(selectors));
  }
  function selectLast(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    const all = (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelectorAll(String(selectors));
    return all[all.length - 1];
  }
  function selectExists(selectors, baseElement) {
    if (2 === arguments.length) return Boolean(select_dom_select(selectors, baseElement));
    return Boolean(select_dom_select(selectors));
  }
  function selectAll(selectors, baseElements) {
    if (2 === arguments.length && !baseElements) return [];
    if (!baseElements || isQueryable(baseElements)) {
      const elements = (null !== baseElements && void 0 !== baseElements ? baseElements : document).querySelectorAll(String(selectors));
      return Array.apply(null, elements);
    }
    const all = [];
    for (let i = 0; i < baseElements.length; i++) {
      const current = baseElements[i].querySelectorAll(String(selectors));
      for (let ii = 0; ii < current.length; ii++) all.push(current[ii]);
    }
    const array = [];
    all.forEach((function(v) {
      array.push(v);
    }));
    return array;
  }
  select_dom_select.last = selectLast;
  select_dom_select.exists = selectExists;
  select_dom_select.all = selectAll;
  var select_dom = select_dom_select;
  var dot_prop = __webpack_require__(7);
  var dot_prop_default = __webpack_require__.n(dot_prop);
  var array_last = __webpack_require__(33);
  var array_last_default = __webpack_require__.n(array_last);
  const NEW_TIMESTAMP_STORAGE_KEY = "saved-searches/newTimestampUserMap";
  const NEW_TIMESTAMP_STORAGE_AREA_NAME = "local";
  const READ_TIMESTAMP_STORAGE_KEY = "saved-searches/readTimestampUserMap";
  const READ_TIMESTAMP_STORAGE_AREA_NAME = "sync";
  const SAVED_SEARCHES_READ = "SAVED_SEARCHES_READ";
  const SAVED_SEARCHES_WRITE = "SAVED_SEARCHES_WRITE";
  var messaging = __webpack_require__(1);
  var parseHTML = html => {
    const parser = new DOMParser;
    const document = parser.parseFromString(html, "text/html");
    return document;
  };
  var asyncSingleton = fn => {
    let promise;
    return (...args) => {
      if (!promise) promise = fn(...args).finally(() => {
        promise = null;
      });
      return promise;
    };
  };
  var findElementWithSpecifiedContentInArray = (array, search) => array.find(element => {
    if ("string" === typeof search) return element.textContent.trim() === search; else if (search instanceof RegExp) return search.test(element.textContent);
    throw new Error("search 必须为字符串或正则表达式");
  });
  var libs_isNaN = x => x !== x;
  var log = __webpack_require__(5);
  const CHECKING_INTERVAL = 3e5;
  const MAX_PAGES_TO_SEARCH = 10;
  var service_background = context => {
    const {requireModules, readOptionValue} = context;
    const {storage, notification} = requireModules([ "storage", "notification" ]);
    let intervalId;
    let previousLoggedInUserId;
    async function readNewTimestampUserMap() {
      return await storage.read(NEW_TIMESTAMP_STORAGE_KEY, NEW_TIMESTAMP_STORAGE_AREA_NAME) || {};
    }
    async function writeNewTimestampUserMap(newTimestampUserMap) {
      await storage.write(NEW_TIMESTAMP_STORAGE_KEY, newTimestampUserMap, NEW_TIMESTAMP_STORAGE_AREA_NAME);
    }
    async function readReadTimestampUserMap() {
      return await storage.read(READ_TIMESTAMP_STORAGE_KEY, READ_TIMESTAMP_STORAGE_AREA_NAME) || {};
    }
    async function writeReadTimestampUserMap(readTimestampUserMap) {
      await storage.write(READ_TIMESTAMP_STORAGE_KEY, readTimestampUserMap, READ_TIMESTAMP_STORAGE_AREA_NAME);
    }
    function extractLoggedInUserId(document) {
      const navLinks = select_dom.all("#navigation li a", document);
      const profilePageLink = findElementWithSpecifiedContentInArray(navLinks, "我的空间");
      return profilePageLink ? profilePageLink.pathname.split("/").pop() : null;
    }
    function extractSavedKeywords(document) {
      return select_dom.all("#savedsearchs > ul > li > a > .label", document).map(element => element.textContent.trim());
    }
    function extractStatusId(li) {
      const statusId = select_dom(".stamp .time", li).pathname.split("/").pop();
      return statusId;
    }
    function extractStatusTime(li) {
      const stime = select_dom(".stamp .time", li).getAttribute("stime");
      const statusTimestamp = Date.parse(stime);
      return statusTimestamp;
    }
    function isValidTimestamp(x) {
      return "number" === typeof x && !libs_isNaN(x);
    }
    function hasUnread(newTimestamp, readTimestamp) {
      return isValidTimestamp(newTimestamp) && isValidTimestamp(readTimestamp) && newTimestamp > readTimestamp;
    }
    async function searchKeyword(loggedInUserId, keyword, pageNumber = 1, maxId = "") {
      const url = "https://fanfou.com/search";
      const data = {
        q: keyword,
        m: maxId
      };
      const headers = {
        "X-Requested-With": "XMLHttpRequest"
      };
      const response = await Object(dist["a"])(url).query(data).headers(headers).get().json();
      const document = parseHTML(response.data.timeline);
      const statuses = Array.from(document.body.children);
      const latestStatusMatchingKeyword = statuses[0];
      const latestFilteredStatus = statuses.find(li => !isPotentiallyReadStatus(li, loggedInUserId));
      if (!latestStatusMatchingKeyword) return null;
      if (latestFilteredStatus) return latestFilteredStatus;
      if (pageNumber >= MAX_PAGES_TO_SEARCH) return null;
      const nextPageStatus = await searchKeyword(loggedInUserId, keyword, pageNumber + 1, extractStatusId(array_last_default()(statuses)));
      if (nextPageStatus) return nextPageStatus;
      if (pageNumber > 1) return null;
      return latestStatusMatchingKeyword;
    }
    async function getNewTimestampMatchingKeyword(loggedInUserId, keyword) {
      try {
        const latestStatusMatchingKeyword = await searchKeyword(loggedInUserId, keyword);
        return latestStatusMatchingKeyword ? extractStatusTime(latestStatusMatchingKeyword) : 0;
      } catch (error) {
        log["a"].info(`获取关键字「${keyword}」的搜索结果出错`, error);
      }
    }
    function isPotentiallyReadStatus(li, loggedInUserId) {
      return isMyStatus(li, loggedInUserId) || isMentionedInStatus(li, loggedInUserId);
    }
    function isMyStatus(li, loggedInUserId) {
      const authorId = select_dom(".author", li).pathname.split("/").pop();
      return authorId === loggedInUserId;
    }
    function isMentionedInStatus(li, loggedInUserId) {
      return select_dom.all(".content .former", li).some(atUser => {
        const atUserId = atUser.pathname.split("/").pop();
        return atUserId === loggedInUserId;
      });
    }
    function cleanupTimestampMap(timestampMap, savedKeywords) {
      for (const keyword of Object.keys(timestampMap)) if (!savedKeywords.includes(keyword)) delete timestampMap[keyword];
    }
    const check = asyncSingleton(async () => {
      const response = await Object(dist["a"])("https://fanfou.com/home").get().text();
      const document = parseHTML(response);
      const loggedInUserId = extractLoggedInUserId(document);
      previousLoggedInUserId = loggedInUserId;
      if (!loggedInUserId) return;
      const savedKeywords = extractSavedKeywords(document);
      const newTimestampUserMap = await readNewTimestampUserMap();
      const newTimestampMap = dot_prop_default.a.get(newTimestampUserMap, loggedInUserId + ".newTimestampMap") || {};
      for (const keyword of savedKeywords) {
        const previousNewTimestamp = newTimestampMap[keyword] || 0;
        const newTimestamp = await getNewTimestampMatchingKeyword(loggedInUserId, keyword);
        if (isValidTimestamp(newTimestamp)) {
          newTimestampMap[keyword] = newTimestamp;
          if (newTimestamp > previousNewTimestamp) showNotificationForKeyword(loggedInUserId, keyword);
        }
      }
      cleanupTimestampMap(newTimestampMap, savedKeywords);
      newTimestampUserMap[loggedInUserId] = {
        newTimestampMap,
        lastChecked: Date.now()
      };
      await writeNewTimestampUserMap(newTimestampUserMap);
      const readTimestampUserMap = await readReadTimestampUserMap();
      const readTimestampMap = readTimestampUserMap[loggedInUserId] || {};
      for (const keyword of savedKeywords) {
        const readTimestamp = readTimestampMap[keyword];
        if (null == readTimestamp || 0 === readTimestamp) readTimestampMap[keyword] = newTimestampMap[keyword];
      }
      cleanupTimestampMap(readTimestampMap, savedKeywords);
      readTimestampUserMap[loggedInUserId] = readTimestampMap;
      await writeReadTimestampUserMap(readTimestampUserMap);
    });
    function showNotificationForKeyword(userId, keyword) {
      if (readOptionValue("enableNotifications")) {
        const url = "https://fanfou.com/q/" + encodeURIComponent(keyword);
        const onClick = () => {
          chrome.tabs.create({
            url,
            active: true
          });
          markKeywordAsRead(userId, keyword);
        };
        notification.create({
          id: `saved-searches/${userId}/${keyword}`,
          message: `您关注的话题「${keyword}」有了新消息`,
          onClick,
          buttonDefs: [ {
            title: "查看",
            onClick
          }, {
            title: "忽略"
          } ]
        });
      }
    }
    async function markKeywordAsRead(userId, keyword) {
      const readTimestampUserMap = await readReadTimestampUserMap();
      const newTimestamp = await getNewTimestampMatchingKeyword(userId, keyword);
      if (isValidTimestamp(newTimestamp)) {
        dot_prop_default.a.set(readTimestampUserMap, `${userId}.${keyword}`, newTimestamp);
        await writeReadTimestampUserMap(readTimestampUserMap);
      }
    }
    async function onRead(payload) {
      const {userId, keyword} = payload;
      const newTimestampUserMap = await readNewTimestampUserMap();
      const readTimestampUserMap = await readReadTimestampUserMap();
      const lastChecked = dot_prop_default.a.get(newTimestampUserMap, userId + ".lastChecked") || 0;
      const now = Date.now();
      if (previousLoggedInUserId !== userId && now - lastChecked > CHECKING_INTERVAL) {
        setTimeout(check);
        return false;
      }
      const newTimestamp = dot_prop_default.a.get(newTimestampUserMap, `${userId}.newTimestampMap.${keyword}`);
      const readTimestamp = dot_prop_default.a.get(readTimestampUserMap, `${userId}.${keyword}`);
      return hasUnread(newTimestamp, readTimestamp);
    }
    async function onWrite(payload) {
      const {userId, keyword} = payload;
      await markKeywordAsRead(userId, keyword);
    }
    return {
      onLoad() {
        check();
        setInterval(check, CHECKING_INTERVAL);
        messaging["a"].registerHandler(SAVED_SEARCHES_READ, onRead);
        messaging["a"].registerHandler(SAVED_SEARCHES_WRITE, onWrite);
      },
      onUnload() {
        previousLoggedInUserId = null;
        clearInterval(intervalId);
        intervalId = null;
        messaging["a"].unregisterHandler(SAVED_SEARCHES_READ, onRead);
        messaging["a"].unregisterHandler(SAVED_SEARCHES_WRITE, onWrite);
      }
    };
  };
  var just_map_values = __webpack_require__(22);
  var just_map_values_default = __webpack_require__.n(just_map_values);
  var RGX = /([^{]*?)\w(?=\})/g;
  var MAP = {
    YYYY: "getFullYear",
    YY: "getYear",
    MM: function(d) {
      return d.getMonth() + 1;
    },
    DD: "getDate",
    HH: "getHours",
    mm: "getMinutes",
    ss: "getSeconds",
    fff: "getMilliseconds"
  };
  var tinydate = function(str, custom) {
    var parts = [], offset = 0;
    str.replace(RGX, (function(key, _, idx) {
      parts.push(str.substring(offset, idx - 1));
      offset = idx += key.length + 1;
      parts.push(custom && custom[key] || function(d) {
        return ("00" + ("string" === typeof MAP[key] ? d[MAP[key]]() : MAP[key](d))).slice(-key.length);
      });
    }));
    if (offset !== str.length) parts.push(str.substring(offset));
    return function(arg) {
      var out = "", i = 0, d = arg || new Date;
      for (;i < parts.length; i++) out += "string" === typeof parts[i] ? parts[i] : parts[i](d);
      return out;
    };
  };
  var timestamp = tinydate("{YYYY}-{MM}-{DD} {HH}:{mm}:{ss}");
  var notifications_service_background = context => {
    const {readOptionValue, requireModules} = context;
    const {notification} = requireModules([ "notification" ]);
    const URL_FANFOU_WEB_ORIGIN = "https://fanfou.com";
    const URL_FANFOU_M_HOME = "https://m.fanfou.com/home";
    const CHECK_INTERVAL = 3e4;
    const AJAX_TIMEOUT = 1e4;
    const NOTIFICATION_TIMEOUT = 15e3;
    let timerId;
    let isVisitingFanfou = false;
    const userMap = {};
    const itemsToCheck = {
      unreadMentions: {
        relatedOptionName: "notifyUnreadMentions",
        findElement(document) {
          return select_dom('h2 a[href="/mentions"]', document);
        },
        extract(element) {
          const re = /@我的\((\d+)\)/;
          const matched = element.textContent.match(re);
          return null === matched || void 0 === matched ? void 0 : matched[1];
        },
        template: count => `你被 @ 了 ${count} 次`,
        targetUrl: URL_FANFOU_WEB_ORIGIN + "/mentions",
        reuseExistingTabs: true
      },
      unreadPrivateMessages: {
        relatedOptionName: "notifyUnreadPrivateMessages",
        findElement(document) {
          return select_dom('#nav [accesskey="7"]', document);
        },
        extract(element) {
          const re = /私信\((\d+)\)/;
          const matched = element.textContent.match(re);
          return null === matched || void 0 === matched ? void 0 : matched[1];
        },
        template: count => `你有 ${count} 封未读私信`,
        targetUrl: URL_FANFOU_WEB_ORIGIN + "/privatemsg",
        reuseExistingTabs: true
      },
      newFollowers: {
        relatedOptionName: "notifyNewFollowers",
        findElement(document) {
          var _select, _select$parentElement, _select$parentElement2;
          return null === (_select = select_dom('p > span.a > a[href^="/friend.add/"]', document)) || void 0 === _select ? void 0 : null === (_select$parentElement = _select.parentElement) || void 0 === _select$parentElement ? void 0 : null === (_select$parentElement2 = _select$parentElement.parentElement) || void 0 === _select$parentElement2 ? void 0 : _select$parentElement2.previousElementSibling;
        },
        extract(element) {
          const re = /(\d+) 个人关注了你/;
          const matched = element.textContent.match(re);
          return null === matched || void 0 === matched ? void 0 : matched[1];
        },
        template: count => `有 ${count} 个新饭友关注了你`,
        targetUrl: URL_FANFOU_WEB_ORIGIN + "/home",
        reuseExistingTabs: false
      },
      newFollowerRequests: {
        relatedOptionName: "notifyNewFollowers",
        findElement(document) {
          var _select2;
          return null === (_select2 = select_dom('a[href="/friend.request"]', document)) || void 0 === _select2 ? void 0 : _select2.parentElement;
        },
        extract(element) {
          const re = /(\d+) 个人申请关注你，去看看是谁/;
          const matched = element.textContent.match(re);
          return null === matched || void 0 === matched ? void 0 : matched[1];
        },
        template: count => `有 ${count} 个新饭友请求关注你`,
        targetUrl: URL_FANFOU_WEB_ORIGIN + "/friend.request",
        reuseExistingTabs: true
      }
    };
    class CountCollector {
      constructor(userId) {
        this.userId = userId;
        this.currentCounts = this.createEmptyCounts();
        this.previousCounts = this.createEmptyCounts();
      }
      createEmptyCounts() {
        return just_map_values_default()(itemsToCheck, () => 0);
      }
    }
    function isFanfouUrl(url) {
      const re = /^https?:\/\/([a-z0-9-]+\.)?fanfou\.com\//;
      return re.test(url);
    }
    async function fetchFanfouMobileDOM() {
      try {
        const html = await Object(dist["a"])(URL_FANFOU_M_HOME).get().setTimeout(AJAX_TIMEOUT).text();
        const document = parseHTML(html);
        return document;
      } catch (error) {
        log["a"].info("获取 m.fanfou.com 页面源码失败 @ " + timestamp(), error);
        return null;
      }
    }
    function checkIfLoggedIn(document) {
      return select_dom.exists("#nav", document);
    }
    function extractUserId(document) {
      const userProfilePageLink = select_dom('#nav [accesskey="1"]', document);
      const userId = unescape(userProfilePageLink.getAttribute("href")).replace("/", "");
      return userId;
    }
    function getCountCollectorForUser(userId) {
      return userMap[userId] || (userMap[userId] = new CountCollector(userId));
    }
    function extract(document, countCollector) {
      countCollector.previousCounts = countCollector.currentCounts;
      countCollector.currentCounts = countCollector.createEmptyCounts();
      for (const [name, opts] of Object.entries(itemsToCheck)) {
        const element = opts.findElement(document);
        const extracted = element && opts.extract(element);
        countCollector.currentCounts[name] = parseInt(extracted, 10) || 0;
      }
    }
    function notify(countCollector) {
      if (readOptionValue("doNotDisturbWhenVisitingFanfou") && isVisitingFanfou) return;
      for (const [name, opts] of Object.entries(itemsToCheck)) {
        const currentCount = countCollector.currentCounts[name];
        const previousCount = countCollector.previousCounts[name];
        const isOptionEnabled = readOptionValue(opts.relatedOptionName);
        if (currentCount > previousCount && isOptionEnabled) {
          const message = opts.template(currentCount);
          createNotification(name, opts, message);
        }
      }
    }
    function createNotification(name, opts, message) {
      const onClick = () => {
        const {targetUrl: url, reuseExistingTabs} = opts;
        chrome.tabs.query({
          url
        }, matchedTabs => {
          if (reuseExistingTabs && matchedTabs.length) {
            const {id, windowId} = matchedTabs[0];
            chrome.tabs.update(id, {
              active: true
            });
            chrome.windows.update(windowId, {
              focused: true
            });
            chrome.tabs.reload(id);
          } else chrome.tabs.create({
            url,
            active: true
          });
        });
      };
      notification.create({
        id: name,
        message,
        onClick,
        buttonDefs: [ {
          title: "查看",
          onClick
        }, {
          title: "忽略"
        } ],
        timeout: NOTIFICATION_TIMEOUT
      });
    }
    async function check() {
      cancelTimer();
      const document = await fetchFanfouMobileDOM();
      if (document && checkIfLoggedIn(document)) {
        const currentlyLoggedInUserId = extractUserId(document);
        const countCollector = getCountCollectorForUser(currentlyLoggedInUserId);
        extract(document, countCollector);
        notify(countCollector);
      }
      setTimer();
    }
    function setTimer() {
      timerId = setTimeout(check, CHECK_INTERVAL);
    }
    function cancelTimer() {
      if (timerId) {
        clearTimeout(timerId);
        timerId = null;
      }
    }
    function onActivated(activeInfo) {
      chrome.tabs.get(activeInfo.tabId, tab => {
        if (isVisitingFanfou = isFanfouUrl(tab.url)) hideRelativeNotificationIfMatched(tab.url);
      });
    }
    function onUpdated(tabId, changeInfo, tab) {
      if (tab.selected && (isVisitingFanfou = isFanfouUrl(tab.url))) hideRelativeNotificationIfMatched(tab.url);
    }
    function hideRelativeNotificationIfMatched(tabUrl) {
      for (const [name, opts] of Object.entries(itemsToCheck)) if (opts.targetUrl === tabUrl) {
        notification.hide(name);
        break;
      }
    }
    return {
      onLoad() {
        check();
        chrome.tabs.onActivated.addListener(onActivated);
        chrome.tabs.onUpdated.addListener(onUpdated);
      },
      onUnload() {
        cancelTimer();
        chrome.tabs.onActivated.removeListener(onActivated);
        chrome.tabs.onUpdated.removeListener(onUpdated);
      }
    };
  };
  var split_lines = __webpack_require__(34);
  var split_lines_default = __webpack_require__.n(split_lines);
  var string_width = __webpack_require__(35);
  var string_width_default = __webpack_require__.n(string_width);
  const MAX_CONTINOUS_BLANK_LINE_NUMBER = 1;
  const MAX_SUMMARY_LENGTH = 120;
  var parseVersionHistory = rawVersionHistory => {
    const lines = split_lines_default()(rawVersionHistory);
    const parsed = [];
    let currentLine;
    let continousBlankLineNumber = 0;
    let currentVersionItem;
    while (lines.length) {
      currentLine = lines.shift().trim();
      if (!currentLine) if (++continousBlankLineNumber > MAX_CONTINOUS_BLANK_LINE_NUMBER) throw new Error(`连续空行不该超过 ${MAX_CONTINOUS_BLANK_LINE_NUMBER} 行`); else continue;
      continousBlankLineNumber = 0;
      if (currentLine.startsWith("#")) continue;
      if (currentLine.startsWith("v")) {
        const versionTag = currentLine.slice(1);
        currentVersionItem = {
          version: versionTag,
          releaseDate: "0000-00-00",
          summary: "",
          updateDetails: []
        };
        parsed.push(currentVersionItem);
        continue;
      }
      if (currentLine.startsWith("@")) {
        const releaseDate = currentLine.slice(1);
        currentVersionItem.releaseDate = releaseDate;
        continue;
      }
      if (currentLine.startsWith("~ ")) {
        const summary = currentLine.slice(2);
        if (string_width_default()(summary) > MAX_SUMMARY_LENGTH) throw new Error(`摘要不该长于 ${MAX_SUMMARY_LENGTH} 字`);
        currentVersionItem.summary = summary;
        continue;
      }
      if (currentLine.startsWith("- ")) {
        const updateDetail = currentLine.slice(2);
        currentVersionItem.updateDetails.push(updateDetail);
        continue;
      }
      throw new Error("无法识别：" + currentLine);
    }
    return parsed;
  };
  var versionHistory = "# 参见 /docs/publish.md\n\nv1.0.0\n@2019-09-12\n~ 这次版本更新完全重写了代码，带来了云同步功能，并且在功能、样式和用户体验方面作了大量改进。\n- 用户设置和其他扩展数据支持云同步\n- 发送消息彻底 AJAX 化，大幅优化了发送消息和上传图片的用户体验\n- 优化饭友关注关系检查速度\n- 右键菜单分享功能支持分享图片\n- 改进及增加更多快捷键支持（T 键全局支持返回页首；←/→ 键控制翻页；Enter 键使输入框聚焦；Esc 键使输入框失焦）\n- 多用户切换列表按照使用历史排序\n- 有爱饭友支持拖拽排序\n- 定时刷新时间戳显示\n- 更换了 Timeline 新未读消息提示音\n- 改进了对 HiDPI 显示器的支持\n- 发送或删除消息后，更新侧栏的统计数字\n- 改进了关闭用户自定义模板功能，现在可以应用到更多页面\n- 加快功能加载的速度\n- 大量功能、样式和用户体验方面的问题修正与改进\n\nv0.9.7.2\n@2017-08-19\n- 针对 HiDPI 显示器进行优化\n\nv0.9.6.2\n@2017-06-28\n- 修正对虾米音乐的支持，添加对网易云音乐的支持（暂时只支持 HTTP）\n\nv0.9.6.0\n@2017-06-26\n- 启用全新样式\n- 支持饭否 HTTPS 页面\n- 细节改进\n\nv0.9.3.5\n@2014-08-14\n- 修正对美团云图片的支持\n\nv0.9.2.6\n@2014-03-31\n- 新增批量管理好友关注请求功能\n\nv0.9.2.2\n@2014-03-11\n- 消息内容支持换行\n- 新增「背景图片自适应窗口大小」插件\n\nv0.9.1.8\n@2014-03-03\n- 改善页面滚动性能\n- 诸多细节改进和 bugs 修正\n\nv0.9.0.2\n@2014-01-30\n- 修正当未加锁删除互相关注的粉丝时出错的 bug\n\nv0.9.0.1\n@2014-01-25\n- 修正 is.gd 短链接展开的 bug\n\nv0.9.0.0\n@2014-01-23\n- 修正虾米播放器\n- 加入 Flickr 图片预览支持\n\nv0.8.9.6\n@2014-01-15\n- 允许自定义页面右上角的用户名\n\nv0.8.9.1\n@2014-01-14\n- 自动展开短链接、为图片链接添加预览图、为虾米链接添加封面和播放器\n- 从剪贴板读取和上传图片\n- 自动隐藏页面右上角自己的名字（默认关闭）\n- 将界面中自己的名字替换为「我」（默认关闭）\n- 样式更新和细节修正\n\nv0.8.7.0\n@2013-11-20\n- 修正「Emoji 表情选择器」插件\n- 修正「自动检查关注的话题」插件\n- 修正设置页\n\nv0.8.6.7\n@2013-11-17\n- 修正「Emoji 表情选择器」插件\n\nv0.8.6.4\n@2013-11-09\n- 修正「多用户切换」插件\n\nv0.8.6.3\n@2013-11-07\n- 启用全新设计的设置页和 logo\n\nv0.8.6.1\n@2013-11-04\n- 修正「经典饭否 logo」插件\n\nv0.8.5.7\n@2013-11-01\n- 允许彻底屏蔽随机应用推荐（不再需要手工屏蔽）\n\nv0.8.5.5\n@2013-11-01\n- 新增「自动检查关注的话题」插件\n\nv0.8.4.8\n@2013-09-28\n- 增加上传头像后自动备份的功能\n- 修正点击后退按钮后 Timeline 中 AJAX 加载的消息丢失的 bug\n- 细节更新\n\nv0.8.4.4\n@2013-09-09\n- 更新「展开转发和回复消息」插件\n- 修正图片放大功能\n- 细节更新\n\nv0.8.4.0\n@2013-08-29\n- 修正样式\n\nv0.8.3.8\n@2013-08-17\n- 修正「浮动输入框」插件样式 bug\n- 修正「转发自己消息」插件 bug\n\nv0.8.3.6\n@2013-08-06\n- 消息通知插件允许不同时检查新@消息数量和新私信数量（请参见设置页）\n\nv0.8.3.5\n@2013-08-01\n- 样式更新\n- 细节更新\n\nv0.8.3.0\n@2013-07-11\n- 修正「好友关系检查」插件\n\nv0.8.2.9\n@2013-07-10\n- 新增「好友关系检查」插件\n\nv0.8.2.8\n@2013-07-09\n- 修正「转发自己消息」插件\n- 更新「Emoji 表情选择器」插件\n\nv0.8.2.5\n@2013-07-09\n- 新增「Emoji 表情选择器」\n- 样式更新\n- 细节更新\n\nv0.8.1.6\n@2013-06-29\n- 新增太空饭否版@自动补全功能\n- 修正「Emoji 表情选择器」插件\n\nv0.8.1.4\n@2013-06-24\n- 修正「Emoji 表情选择器」插件\n\nv0.8.1.3\n@2013-06-23\n- 新增 Emoji 表情支持\n\nv0.8.1.0\n@2013-05-09\n- 新增「统计数字字体样式切换」插件\n- 修正页码撑大页面的 bug\n- 更新「侧栏详细统计信息」插件\n- 细节更新\n\nv0.7.5.2\n@2013-02-27\n- 更新「侧栏详细统计信息」插件: 解决偶尔加载失败的问题\n\nv0.7.5.0\n@2013-02-21\n- 更新和添加设置页截图\n\nv0.7.4.8\n@2013-02-17\n- 首次启动显示欢迎提示\n\nv0.7.4.7\n@2013-02-13\n- 新增「未读消息处理」插件（详见设置页）\n- 更新「浮动输入框」插件\n- 更新「批量消息处理」插件\n- 更新「自动翻页」插件\n- 新增「提醒用户评分」插件\n- 细节更新\n\nv0.7.4.0\n@2012-12-27\n- bug 修正\n\nv0.7.3.6\n@2012-12-23\n- 修正圣诞帽错位问题\n- 设置页添加关闭圣诞帽效果功能\n\nv0.7.3.4\n@2012-12-20\n- 2012 圣诞节彩蛋\n\nv0.7.3.1\n@2012-12-16\n- 修正侧栏模块无法折叠的问题\n\nv0.7.2.9\n@2012-11-15\n- bug 修正\n- 更新「自动翻页」插件\n\nv0.7.2.7\n@2012-11-15\n- 细节更新\n- 更新「浮动输入框」插件\n\nv0.7.1.6\n@2012-08-24\n- 更新「屏蔽随机应用推荐和饭否应用广告」插件\n- 更新设置页\n\nv0.7.1.4\n@2012-08-23\n- 细节更新\n- 更新「屏蔽随机应用推荐和饭否应用广告」插件\n\nv0.7.0.4\n@2012-07-29\n- 修正「展开转发和回复消息」插件\n\nv0.7.0.0\n@2012-07-21\n- 细节更新\n- 多处 bugs 修正\n- 性能优化\n\nv0.6.9.0\n@2012-07-01\n- 新增「有爱饭友列表」插件\n- 多处样式更新和 bugs 修正\n\nv0.6.8.2\n@2012-06-23\n- 修正「浮动输入框」插件拖拽图片上传功能\n- 细节更新\n\nv0.6.8.0\n@2012-06-21\n- 修正部分未读消息不显示的问题\n- 修正「浮动输入框」插件开启后不能传图的问题\n- 改进加载方式\n- 新增「消息批量管理」插件\n- 「侧栏详细统计信息」插件添加查看背景图片功能\n- 多处样式更新和 bugs 修正\n\nv0.6.7.0\n@2012-06-04\n- 更换插件加载原理，提升性能\n- 增加向上滚动滚轮后自动点击「显示新增 X 条新消息」功能\n- 修正「侧栏详细统计信息」插件\n- 修正更改设置项后不能及时生效的问题\n- 细节更新\n\nv0.6.6.3\n@2012-05-31\n- 优化「返回顶部」功能和页面滚动性能\n- 样式更新\n- 更新「侧栏统计信息」插件\n\nv0.6.6.0\n@2012-05-30\n- 新增通知插件（具体功能见设置页）\n- 更新设置页\n";
  var version_history = parseVersionHistory(versionHistory);
  var getExtensionVersion = __webpack_require__(11);
  var constants = __webpack_require__(0);
  const update_details_background_NOTIFICATION_TIMEOUT = 15e3;
  var update_details_background = context => {
    const {readOptionValue, requireModules} = context;
    const {storage, notification} = requireModules([ "storage", "notification" ]);
    const patchedVersionHistory = function() {
      const patched = [ ...version_history ];
      const updateDetailsFor100 = version_history.find(({version}) => "1.0.0" === version);
      const updateDetailsFor101 = {
        ...updateDetailsFor100
      };
      const indexOf100 = patched.indexOf(updateDetailsFor100);
      updateDetailsFor101.version = "1.0.1";
      patched.splice(indexOf100, 0, updateDetailsFor101);
      return patched;
    }();
    function isExtensionUpgraded() {
      return storage.read(constants["STORAGE_KEY_IS_EXTENSION_UPGRADED"], constants["STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED"]);
    }
    function getCurrentVersionUpdateDetails() {
      const currentVersion = Object(getExtensionVersion["a"])();
      const versionItem = patchedVersionHistory.find(({version}) => version === currentVersion);
      if (!versionItem) return "";
      if (versionItem.summary) return versionItem.summary;
      return versionItem.updateDetails.map((updateDetail, i) => `${i + 1}. ${updateDetail}`).join(" ");
    }
    async function shouldNotifyUpdateDetails() {
      return await isExtensionUpgraded() && readOptionValue("notifyUpdateDetails") && getCurrentVersionUpdateDetails();
    }
    function notifyUpdateDetails() {
      const onClick = () => {
        const url = chrome.runtime.getURL("settings.html") + "#version-history";
        chrome.tabs.create({
          url,
          active: true
        });
      };
      notification.create({
        id: "extension-upgraded",
        title: "太空饭否更新至 v" + Object(getExtensionVersion["a"])(),
        message: getCurrentVersionUpdateDetails(),
        onClick,
        buttonDefs: [ {
          title: "查看详情",
          onClick
        }, {
          title: "忽略"
        } ],
        timeout: update_details_background_NOTIFICATION_TIMEOUT
      });
    }
    return {
      async onLoad() {
        if (await shouldNotifyUpdateDetails()) notifyUpdateDetails();
      }
    };
  };
  var lib = __webpack_require__(28);
  var lib_default = __webpack_require__.n(lib);
  var _background = () => {
    const menuIds = [];
    const menuItems = [ {
      title: "分享到饭否",
      contexts: [ "page", "selection" ],
      onclick(info, tab) {
        const url = lib_default()("https://fanfou.com/sharer", {
          u: tab.url,
          t: tab.title,
          d: info.selectionText || ""
        });
        createSharerPopup(url, 440);
      }
    }, {
      title: "分享图片到饭否",
      contexts: [ "image" ],
      onclick(info, tab) {
        const url = lib_default()("https://fanfou.com/sharer/image", {
          u: tab.url,
          t: tab.title,
          img_src: info.srcUrl
        });
        createSharerPopup(url, 540);
      }
    } ];
    function createSharerPopup(url, height) {
      window.open(url, "sharer", "toolbar=0,status=0,resizable=0,width=640,height=" + height);
    }
    function registerMenuItems() {
      for (const menuItem of menuItems) menuIds.push(chrome.contextMenus.create(menuItem));
    }
    function unregisterMenuItems() {
      menuIds.forEach(menuId => chrome.contextMenus.remove(menuId));
      menuIds.length = 0;
    }
    return {
      onLoad() {
        registerMenuItems();
      },
      onUnload() {
        unregisterMenuItems();
      }
    };
  };
  const options = {
    _: {
      defaultValue: true,
      label: "随页面向下滚动自动加载更多消息"
    }
  };
  const metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理关注的人"
    }
  };
  const batch_remove_private_messages_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理私信"
    }
  };
  const batch_remove_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理消息",
      comment: "按住 Shift 键可以批量选择"
    }
  };
  const metadata_isSoldered = true;
  const box_shadows_metadata_options = {
    _: {
      defaultValue: false,
      label: "在导航栏、主窗体等框架下显示阴影"
    }
  };
  const check_friendship_metadata_options = {
    _: {
      defaultValue: false,
      label: "在用户页面显示好友关系检查工具"
    }
  };
  const check_saved_searches_metadata_options = {
    _: {
      defaultValue: true,
      label: "自动检查关注的话题是否有新消息"
    },
    enableNotifications: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有新消息时显示桌面通知"
    }
  };
  const enrich_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "消息内容增强",
      comment: "自动展开短链接，为图片链接添加预览图等"
    }
  };
  const favorite_fanfouers_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许添加有爱饭友，并显示在首页侧栏上"
    }
  };
  const fix_photo_zoom_metadata_isSoldered = true;
  const floating_status_form_metadata_options = {
    _: {
      defaultValue: false,
      label: "使用跟随页面滚动的浮动输入框"
    },
    keepFocusAfterPosting: {
      defaultValue: false,
      label: "消息发出后将焦点保留在输入框"
    },
    keepAtNamesAfterPosting: {
      defaultValue: false,
      label: "消息发出后在输入框中保留所 @ 的人"
    }
  };
  const go_top_button_metadata_isSoldered = true;
  const google_analytics_metadata_isSoldered = true;
  const keyboard_shortcuts_metadata_isSoldered = true;
  const notifications_metadata_options = {
    _: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "启用 Chrome 桌面通知"
    },
    notifyUnreadMentions: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新 @ 提到我的通知"
    },
    notifyUnreadPrivateMessages: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新私信通知"
    },
    notifyNewFollowers: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新关注者通知"
    },
    doNotDisturbWhenVisitingFanfou: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "当我浏览饭否页面时不要显示通知"
    },
    notifyUpdateDetails: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "太空饭否更新后通知显示更新内容"
    },
    playSound: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示通知时播放提示音"
    }
  };
  const process_unread_statuses_metadata_options = {
    _: {
      isSoldered: true,
      label: "时间线上出现新消息时进行处理"
    },
    playSound: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有未读消息时播放提示音",
      comment: "饭否页面打开状态下"
    }
  };
  const remove_app_recommendations_metadata_options = {
    _: {
      defaultValue: false,
      label: "屏蔽「饭否应用」广告区和「随机应用推荐」"
    }
  };
  const remove_brackets_metadata_isSoldered = true;
  const remove_logo_beta_metadata_options = {
    _: {
      defaultValue: true,
      label: "去除 logo 的「测试版」字样"
    }
  };
  const remove_personalized_theme_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许关闭用户的自定义模板",
      comment: "恢复到饭否初始样式"
    }
  };
  const retinafy_photos_metadata_isSoldered = true;
  const share_new_avatar_metadata_isSoldered = true;
  const share_to_fanfou_metadata_options = {
    _: {
      defaultValue: false,
      label: "添加「分享到饭否」到网页右键菜单"
    }
  };
  const show_contextual_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "允许展开回复和转发的消息"
    },
    fetchStatusNumberPerClick: {
      defaultValue: 3,
      label: `每次展开 ${constants["CONTROL_PLACEHOLDER"]} 条消息`,
      controlOptions: {
        step: 1,
        min: 1,
        max: 7
      }
    },
    autoFetch: {
      defaultValue: false,
      label: "消息载入后自动展开 1 条消息"
    }
  };
  const sidebar_statistics_metadata_isSoldered = true;
  const status_form_enhancements_metadata_isSoldered = true;
  const translucent_sidebar_metadata_options = {
    _: {
      defaultValue: true,
      label: "半透明的侧栏"
    }
  };
  const update_timestamps_metadata_isSoldered = true;
  const user_switcher_metadata_isSoldered = true;
  var just_pick = __webpack_require__(4);
  var just_pick_default = __webpack_require__.n(just_pick);
  var parseFilename = filename => {
    const index = filename.lastIndexOf(".");
    let basename, extname;
    if (-1 === index) {
      basename = filename;
      extname = "";
    } else {
      basename = filename.slice(0, index);
      extname = filename.slice(index);
    }
    return {
      basename,
      extname
    };
  };
  var index_esm = __webpack_require__(12);
  __webpack_require__(27);
  var getExtensionOrigin = Object(index_esm["a"])(() => {
    let extensionId;
    extensionId = chrome.runtime.id;
    return "chrome-extension://" + extensionId;
  });
  var replaceExtensionOrigin = code => {
    const extensionOrigin = getExtensionOrigin();
    const replacedCode = code.replace(constants["EXTENSION_ORIGIN_PLACEHOLDER_RE"], extensionOrigin);
    return replacedCode;
  };
  function loadComponent(path, module) {
    const [, featureName, filename] = path.split("/");
    if ("metadata.js" === filename) return {
      featureName,
      type: "metadata",
      module
    };
    const {basename, extname} = parseFilename(filename);
    const atPos = basename.lastIndexOf("@");
    const subfeatureName = 0 === atPos ? "default" : basename.slice(0, atPos);
    if ([ ".less", ".css" ].includes(extname)) return {
      featureName,
      subfeatureName,
      type: "style",
      module: replaceExtensionOrigin(module)
    };
    if (".js" === extname) return {
      featureName,
      subfeatureName,
      type: "script",
      module: module.default
    };
  }
  function loadComponents() {
    const modules = {
      "./auto-pager/metadata.js": metadata_namespaceObject,
      "./batch-manage-relationships/metadata.js": batch_manage_relationships_metadata_namespaceObject,
      "./batch-remove-private-messages/metadata.js": batch_remove_private_messages_metadata_namespaceObject,
      "./batch-remove-statuses/metadata.js": batch_remove_statuses_metadata_namespaceObject,
      "./better-at-autocomplete/metadata.js": better_at_autocomplete_metadata_namespaceObject,
      "./box-shadows/metadata.js": box_shadows_metadata_namespaceObject,
      "./check-friendship/metadata.js": check_friendship_metadata_namespaceObject,
      "./check-saved-searches/metadata.js": check_saved_searches_metadata_namespaceObject,
      "./enrich-statuses/metadata.js": enrich_statuses_metadata_namespaceObject,
      "./favorite-fanfouers/metadata.js": favorite_fanfouers_metadata_namespaceObject,
      "./fix-photo-zoom/metadata.js": fix_photo_zoom_metadata_namespaceObject,
      "./floating-status-form/metadata.js": floating_status_form_metadata_namespaceObject,
      "./go-top-button/metadata.js": go_top_button_metadata_namespaceObject,
      "./google-analytics/metadata.js": google_analytics_metadata_namespaceObject,
      "./keyboard-shortcuts/metadata.js": keyboard_shortcuts_metadata_namespaceObject,
      "./notifications/metadata.js": notifications_metadata_namespaceObject,
      "./process-unread-statuses/metadata.js": process_unread_statuses_metadata_namespaceObject,
      "./remove-app-recommendations/metadata.js": remove_app_recommendations_metadata_namespaceObject,
      "./remove-brackets/metadata.js": remove_brackets_metadata_namespaceObject,
      "./remove-logo-beta/metadata.js": remove_logo_beta_metadata_namespaceObject,
      "./remove-personalized-theme/metadata.js": remove_personalized_theme_metadata_namespaceObject,
      "./retinafy-photos/metadata.js": retinafy_photos_metadata_namespaceObject,
      "./share-new-avatar/metadata.js": share_new_avatar_metadata_namespaceObject,
      "./share-to-fanfou/metadata.js": share_to_fanfou_metadata_namespaceObject,
      "./show-contextual-statuses/metadata.js": show_contextual_statuses_metadata_namespaceObject,
      "./sidebar-statistics/metadata.js": sidebar_statistics_metadata_namespaceObject,
      "./status-form-enhancements/metadata.js": status_form_enhancements_metadata_namespaceObject,
      "./translucent-sidebar/metadata.js": translucent_sidebar_metadata_namespaceObject,
      "./update-timestamps/metadata.js": update_timestamps_metadata_namespaceObject,
      "./user-switcher/metadata.js": user_switcher_metadata_namespaceObject,
      "./check-saved-searches/service@background.js": service_background_namespaceObject,
      "./notifications/service@background.js": notifications_service_background_namespaceObject,
      "./notifications/update-details@background.js": update_details_background_namespaceObject,
      "./share-to-fanfou/@background.js": _background_namespaceObject
    };
    const components = Object.entries(modules).map(([path, module]) => loadComponent(path, module));
    return components;
  }
  function processOptionDef(featureName, optionName, rawOptionDef, isSubOption) {
    const {isSoldered = false, defaultValue, disableCloudSyncing = false} = rawOptionDef;
    const optionDef = {
      key: optionName,
      isSoldered,
      isSubOption,
      disableCloudSyncing,
      type: function() {
        if (isSoldered || "boolean" === typeof defaultValue) return "checkbox"; else if ("number" === typeof defaultValue) return "number"; else throw new Error("无法判断选项的类型，因为没有指定 `isSoldered` 或 `defaultValue`");
      }(),
      ...just_pick_default()(rawOptionDef, [ "label", "comment", "controlOptions" ])
    };
    if (isSubOption) optionDef.parentKey = featureName;
    return optionDef;
  }
  function processMetadata(featureName, metadata) {
    const isSoldered = !!metadata.isSoldered;
    const optionNames = [];
    const optionDefs = [];
    const defaultValues = {};
    const optionStorageAreaMap = {};
    if (!isSoldered) for (const [k, v] of Object.entries(metadata.options)) {
      const isSubOption = "_" !== k;
      const optionName = isSubOption ? `${featureName}/${k}` : featureName;
      const optionDef = processOptionDef(featureName, optionName, v, isSubOption);
      optionNames.push(optionName);
      optionDefs.push(optionDef);
      defaultValues[optionName] = v.isSoldered || v.defaultValue;
      optionStorageAreaMap[optionName] = v.disableCloudSyncing ? "local" : "sync";
    }
    return {
      isSoldered,
      optionNames,
      optionDefs,
      defaultValues,
      optionStorageAreaMap
    };
  }
  function loadFeatures() {
    const features = {};
    for (const {featureName, subfeatureName, type, module} of loadComponents()) if ("metadata" === type) dot_prop_default.a.set(features, featureName + ".metadata", processMetadata(featureName, module)); else dot_prop_default.a.set(features, `${featureName}.subfeatures.${subfeatureName}.${type}`, module);
    return features;
  }
  __webpack_exports__["a"] = loadFeatures();
}, function(module, exports, __webpack_require__) {
  (function(global, factory) {
    true ? factory(exports) : void 0;
  })(0, (function(exports) {
    "use strict";
    const LOWER_CASE$1 = "LOWER_CASE";
    const UPPER_CASE$1 = "UPPER_CASE";
    const CAMEL_CASE$1 = "CAMEL_CASE";
    const PASCAL_CASE$1 = "PASCAL_CASE";
    const KEBAB_CASE$1 = "KEBAB_CASE";
    const SNAKE_CASE$1 = "SNAKE_CASE";
    const TRAIN_CASE$1 = "TRAIN_CASE";
    const LOWER_CASE = /^[^A-Z]+$/;
    const UPPER_CASE = /^[^a-z]+$/;
    const CAMEL_CASE = /^[a-z]+(?:[A-Z][a-z\d]+)*$/;
    const PASCAL_CASE = /^[A-Z][a-z\d]+(?:[A-Z][a-z\d]+)*$/;
    const KEBAB_CASE = /^[a-z][a-z\d]+(-[a-z\d]+)+$/;
    const SNAKE_CASE = /^[a-z][a-z\d]+(_[a-z\d]+)+$/;
    const TRAIN_CASE = /^[A-Z][a-z\d]+(-[A-Z][a-z\d]+)+$/;
    const FRAGMENT = /([A-Za-z\d]+)+/g;
    const isString = _isString;
    const isLowerCase = _is(LOWER_CASE);
    const isUpperCase = _is(UPPER_CASE);
    const isCamelCase = _is(CAMEL_CASE);
    const isPascalCase = _is(PASCAL_CASE);
    const isKebabCase = _is(KEBAB_CASE);
    const isSnakeCase = _is(SNAKE_CASE);
    const isTrainCase = _is(TRAIN_CASE);
    const caseOf = _caseOf;
    const toLowerCase = _toLowerCase;
    const toUpperCase = _toUpperCase;
    const toCamelCase = _toCamelCase;
    const toPascalCase = _toPascalCase;
    const toKebabCase = _toKebabCase;
    const toSnakeCase = _toSnakeCase;
    const toTrainCase = _toTrainCase;
    function _isString(any) {
      return "string" === typeof any || null !== any && "object" === typeof any && any.constructor === String;
    }
    function _is(pattern) {
      return function(str) {
        return isString(str) ? pattern.test(str) : false;
      };
    }
    function _caseOf(str) {
      if (isCamelCase(str)) return CAMEL_CASE$1; else if (isPascalCase(str)) return PASCAL_CASE$1; else if (isKebabCase(str)) return KEBAB_CASE$1; else if (isSnakeCase(str)) return SNAKE_CASE$1; else if (isTrainCase(str)) return TRAIN_CASE$1; else if (isLowerCase(str)) return LOWER_CASE$1; else if (isUpperCase(str)) return UPPER_CASE$1; else return null;
    }
    function _toLowerCase(str) {
      return String.prototype.toLowerCase.call(String(str));
    }
    function _toUpperCase(str) {
      return String.prototype.toUpperCase.call(String(str));
    }
    function _toCamelCase(str) {
      return _fragment(_toLowerCase(String(str))).map((frag, idx) => 0 === idx ? frag : _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toPascalCase(str) {
      return _fragment(_toLowerCase(String(str))).map(frag => _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toKebabCase(str) {
      return _fragment(_toLowerCase(String(str))).join("-");
    }
    function _toSnakeCase(str) {
      return _fragment(_toLowerCase(String(str))).join("_");
    }
    function _toTrainCase(str) {
      return _fragment(toLowerCase(String(str))).map(frag => toUpperCase(frag[0]) + _tail(frag)).join("-");
    }
    function _tail(str) {
      return String.prototype.slice.call(str, 1);
    }
    function _fragment(str) {
      return String.prototype.match.call(str, FRAGMENT);
    }
    exports.caseOf = caseOf;
    exports.isCamelCase = isCamelCase;
    exports.isKebabCase = isKebabCase;
    exports.isLowerCase = isLowerCase;
    exports.isPascalCase = isPascalCase;
    exports.isSnakeCase = isSnakeCase;
    exports.isString = isString;
    exports.isTrainCase = isTrainCase;
    exports.isUpperCase = isUpperCase;
    exports.toCamelCase = toCamelCase;
    exports.toKebabCase = toKebabCase;
    exports.toLowerCase = toLowerCase;
    exports.toPascalCase = toPascalCase;
    exports.toSnakeCase = toSnakeCase;
    exports.toTrainCase = toTrainCase;
    exports.toUpperCase = toUpperCase;
  }));
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    for (var i = 0; i < arguments.length; i++) if ("undefined" !== typeof arguments[i]) return arguments[i];
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var promise_queue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(38);
  var promise_queue__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(promise_queue__WEBPACK_IMPORTED_MODULE_0__);
  __webpack_require__(13);
  var _libs_log__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
  const STORAGE_KEY = "migrated";
  const MAX_CONCURRENT = 1;
  const MAX_QUEUE = 1 / 0;
  const queue = new promise_queue__WEBPACK_IMPORTED_MODULE_0___default.a(MAX_CONCURRENT, MAX_QUEUE);
  __webpack_exports__["a"] = opts => queue.add(async () => {
    const {storage, storageAreaName, migrationId, executor} = opts;
    const migrated = await storage.read(STORAGE_KEY, storageAreaName) || [];
    if ("string" !== typeof storageAreaName) throw new TypeError("必须指定 storageAreaName");
    if ("string" !== typeof migrationId) throw new TypeError("必须指定 migrationId");
    if ("function" !== typeof executor) throw new TypeError("必须指定 executor");
    if (false) ;
    if (!migrated.includes(migrationId)) {
      try {
        await executor();
      } catch (error) {
        _libs_log__WEBPACK_IMPORTED_MODULE_2__["a"].error(error);
      }
      await storage.write(STORAGE_KEY, [ ...migrated, migrationId ], storageAreaName);
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var gte = __webpack_require__(37);
  var gte_default = __webpack_require__.n(gte);
  var fast_deep_equal = __webpack_require__(9);
  var fast_deep_equal_default = __webpack_require__.n(fast_deep_equal);
  var defined = __webpack_require__(17);
  var defined_default = __webpack_require__.n(defined);
  var index_esm = __webpack_require__(12);
  var just_map_values = __webpack_require__(22);
  var just_map_values_default = __webpack_require__.n(just_map_values);
  var messaging = __webpack_require__(1);
  var storage = __webpack_require__(2);
  var features = __webpack_require__(15);
  var parseUrl = __webpack_require__(27);
  var isFanfouWebUrl = url => "fanfou.com" === Object(parseUrl["a"])(url).domain;
  var migrate = __webpack_require__(18);
  var gt = __webpack_require__(39);
  var gt_default = __webpack_require__.n(gt);
  var isLegacyVersion = version => "string" === typeof version && /^0\.\d\.\d\.\d$/.test(version);
  var isExtensionUpgraded = (previousVersion, currentVersion) => {
    if (!previousVersion) return false;
    if (isLegacyVersion(previousVersion)) return true;
    return gt_default()(currentVersion, previousVersion);
  };
  var safelyInvokeFn = __webpack_require__(6);
  function readJSONFromLocalStorage(key) {
    let value = null;
    Object(safelyInvokeFn["a"])(() => {
      value = JSON.parse(localStorage.getItem(key));
    });
    return value;
  }
  var getExtensionVersion = __webpack_require__(11);
  var omitBy = (object, predicate) => {
    const ret = {};
    for (const [k, v] of Object.entries(object)) if (!predicate(v, k)) ret[k] = v;
    return ret;
  };
  var constants = __webpack_require__(0);
  const SETTINGS_STORAGE_KEY = "settings";
  const SETTINGS_VERSION_STORAGE_KEY = "settings/version";
  const PREVIOUS_EXTENSION_VERSION_STORAGE_KEY = "extension-version/previous";
  const PREVIOUS_EXTENSION_VERSION_STORAGE_AREA_NAME = "local";
  let optionValuesCache;
  const getDefaults = Object(index_esm["a"])(() => Object.values(features["a"]).reduce((defaultValues, feature) => Object.assign(defaultValues, feature.metadata.defaultValues), {}));
  const getAllOptionNames = Object(index_esm["a"])(() => Object.keys(getDefaults()));
  const getOptionDefs = Object(index_esm["a"])(() => {
    const unsolderedFeatures = omitBy(features["a"], feature => feature.metadata.isSoldered);
    const optionDefs = just_map_values_default()(unsolderedFeatures, feature => feature.metadata.optionDefs);
    return optionDefs;
  });
  const getOptionStorageAreaName = function() {
    const fullOptionStorageAreaMap = Object.values(features["a"]).reduce((map, feature) => Object.assign(map, feature.metadata.optionStorageAreaMap), {});
    return optionName => fullOptionStorageAreaMap[optionName];
  }();
  function mergeSettings(map) {
    const merged = {};
    for (const optionName of getAllOptionNames()) {
      const storageAreaName = getOptionStorageAreaName(optionName);
      const optionValue = map[storageAreaName][optionName];
      merged[optionName] = optionValue;
    }
    return merged;
  }
  async function migrateSettings() {
    var _do;
    const optionNameMap = {
      auto_pager: "auto-pager",
      box_shadows: "box-shadows",
      check_saved_searches: "check-saved-searches",
      "check_saved_searches.show_notification": "check-saved-searches/enableNotifications",
      clean_personal_theme: "remove-personalized-theme",
      enrich_statuses: "enrich-statuses",
      expanding_replies: "show-contextual-statuses",
      "expanding_replies.auto_expand": "show-contextual-statuses/autoFetch",
      "expanding_replies.number": "show-contextual-statuses/fetchStatusNumberPerClick",
      fav_friends: "favorite-fanfouers",
      float_message: "floating-status-form",
      "float_message.keepmentions": "floating-status-form/keepAtNamesAfterPosting",
      "float_message.notlostfocus": "floating-status-form/keepFocusAfterPosting",
      friend_manage: "batch-manage-relationships",
      friendship_check: "check-friendship",
      logo_remove_beta: "remove-logo-beta",
      notification: "notifications",
      "notification.followers": "notifications/notifyNewFollowers",
      "notification.mentions": "notifications/notifyUnreadMentions",
      "notification.notdisturb": "notifications/doNotDisturbWhenVisitingFanfou",
      "notification.playsound": "notifications/playSound",
      "notification.privatemsgs": "notifications/notifyUnreadPrivateMessages",
      "notification.updates": "notifications/notifyUpdateDetails",
      privatemsg_manage: "batch-remove-private-messages",
      remove_app_recom: "remove-app-recommendations",
      share_to_fanfou: "share-to-fanfou",
      status_manage: "batch-remove-statuses",
      translucent_sidebar: "translucent-sidebar",
      unread_statuses: "process-unread-statuses",
      "unread_statuses.playsound": "process-unread-statuses/playSound"
    };
    const legacyOptionValues = readJSONFromLocalStorage("settings");
    _do = legacyOptionValues;
    if (_do) {
      var _do2;
      const object = {};
      for (const [legacyOptionName, newOptionName] of Object.entries(optionNameMap)) {
        const legacyOptionValue = legacyOptionValues[legacyOptionName];
        object[newOptionName] = legacyOptionValue;
      }
      _do2 = object;
    }
    const migratedOptionValues = _do && _do2;
    for (const storageAreaName of [ "local", "sync" ]) await Object(migrate["a"])({
      storage: storage["a"],
      storageAreaName,
      migrationId: "settings/legacy-to-1.0.0",
      async executor() {
        if (migratedOptionValues) await storage["a"].write(SETTINGS_STORAGE_KEY, migratedOptionValues, storageAreaName);
      }
    });
  }
  async function initOptions() {
    const defaults = getDefaults();
    const oldOptionValues = await settings.readFromStorage();
    const newOptionValues = {};
    for (const optionName of getAllOptionNames()) {
      const optionValue = defined_default()(oldOptionValues[optionName], defaults[optionName]);
      newOptionValues[optionName] = optionValue;
    }
    await settings.writeAll(newOptionValues, true);
  }
  async function checkIfExtensionUpgraded() {
    await Object(migrate["a"])({
      storage: storage["a"],
      storageAreaName: "local",
      migrationId: "extension-version/legacy-to-1.0.0",
      async executor() {
        const legacyVersion = localStorage.getItem("sf_version");
        if (legacyVersion) await storage["a"].write(PREVIOUS_EXTENSION_VERSION_STORAGE_KEY, legacyVersion, PREVIOUS_EXTENSION_VERSION_STORAGE_AREA_NAME);
      }
    });
    const previousVersion = await storage["a"].read(PREVIOUS_EXTENSION_VERSION_STORAGE_KEY, PREVIOUS_EXTENSION_VERSION_STORAGE_AREA_NAME);
    const currentVersion = Object(getExtensionVersion["a"])();
    await storage["a"].write(PREVIOUS_EXTENSION_VERSION_STORAGE_KEY, currentVersion, PREVIOUS_EXTENSION_VERSION_STORAGE_AREA_NAME);
    await storage["a"].write(constants["STORAGE_KEY_IS_EXTENSION_UPGRADED"], isExtensionUpgraded(previousVersion, currentVersion), constants["STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED"]);
  }
  function registerHandlers() {
    messaging["a"].registerHandler(constants["SETTINGS_READ"], async payload => {
      const {key} = payload;
      const value = await settings.read(key);
      return {
        value
      };
    });
    messaging["a"].registerHandler(constants["SETTINGS_READ_ALL"], async () => {
      const allOptions = await settings.readAll();
      return allOptions;
    });
    messaging["a"].registerHandler(constants["SETTINGS_WRITE_ALL"], async payload => {
      const {optionValues} = payload;
      await settings.writeAll(optionValues);
    });
    messaging["a"].registerHandler(constants["GET_OPTION_DEFS"], () => {
      const optionDefs = getOptionDefs();
      return optionDefs;
    });
  }
  function listenOnStorageChange() {
    messaging["a"].registerBroadcastListener(async message => {
      if (message.action === constants["STORAGE_CHANGED"]) {
        const {key, storageAreaName, newValue} = message.payload;
        if (key === SETTINGS_STORAGE_KEY && "sync" === storageAreaName) {
          const newOptionValues = mergeSettings({
            local: optionValuesCache,
            sync: newValue
          });
          await settings.writeAll(newOptionValues);
        }
      }
    });
  }
  function listenOnPageCoonect() {
    chrome.runtime.onConnect.addListener(port => {
      const {tab} = port.sender;
      if (tab && isFanfouWebUrl(tab.url)) chrome.pageAction.show(tab.id);
    });
  }
  const settings = {
    async install() {
      await migrateSettings();
      await initOptions();
      await checkIfExtensionUpgraded();
      registerHandlers();
      listenOnStorageChange();
      listenOnPageCoonect();
    },
    readFromStorage: async () => mergeSettings({
      local: await storage["a"].read(SETTINGS_STORAGE_KEY, "local") || {},
      sync: await storage["a"].read(SETTINGS_STORAGE_KEY, "sync") || {}
    }),
    read(optionName) {
      return optionValuesCache[optionName];
    },
    readAll() {
      return {
        ...optionValuesCache
      };
    },
    async writeAll(newOptionValues, isInit = false) {
      if (fast_deep_equal_default()(optionValuesCache, newOptionValues)) return;
      optionValuesCache = {
        ...newOptionValues
      };
      await storage["a"].write(SETTINGS_STORAGE_KEY, newOptionValues, "local");
      const localVersion = Object(getExtensionVersion["a"])();
      const syncVersion = await storage["a"].read(SETTINGS_VERSION_STORAGE_KEY, "sync") || localVersion;
      if (gte_default()(localVersion, syncVersion)) {
        await storage["a"].write(SETTINGS_STORAGE_KEY, newOptionValues, "sync");
        await storage["a"].write(SETTINGS_VERSION_STORAGE_KEY, localVersion, "sync");
      }
      if (!isInit) settings.handleSettingsChange();
    },
    handleSettingsChange() {
      messaging["a"].broadcastMessage({
        action: constants["SETTINGS_CHANGED"]
      });
    }
  };
  __webpack_exports__["a"] = settings;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    if (!array.includes(element)) array.push(element);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    const index = array.indexOf(element);
    if (-1 !== index) array.splice(index, 1);
  };
}, function(module, exports) {
  module.exports = map;
  function map(obj, predicate) {
    var result = {};
    var keys = Object.keys(obj);
    var len = keys.length;
    for (var i = 0; i < len; i++) {
      var key = keys[i];
      result[key] = predicate(obj[key], key, obj);
    }
    return result;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  __webpack_exports__["a"] = {
    trigger() {
      const event = new CustomEvent(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"]);
      window.dispatchEvent(event);
    },
    addListener(fn) {
      window.addEventListener(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"], fn, {
        once: true
      });
    }
  };
}, function(module, exports) {
  module.exports = isPromise;
  module.exports.default = isPromise;
  function isPromise(obj) {
    return !!obj && ("object" === typeof obj || "function" === typeof obj) && "function" === typeof obj.then;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var is_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(24);
  var is_promise__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(is_promise__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23);
  var _libs_noop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14);
  function toBooleanPromise(x) {
    return "boolean" === typeof x ? x : is_promise__WEBPACK_IMPORTED_MODULE_0___default()(x) ? x.then(toBooleanPromise) : Promise.resolve(true);
  }
  __webpack_exports__["a"] = module => {
    let promise;
    const {install = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], uninstall = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], ...rest} = module;
    _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__["a"].addListener(uninstall);
    return {
      ...rest,
      ready() {
        return promise || (promise = toBooleanPromise(install()));
      }
    };
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  (function(__filename) {
    function loadModules() {
      const modules = {};
      const context = __webpack_require__(66);
      for (const key of context.keys()) {
        if (key.endsWith(__filename)) continue;
        const moduleName = key.replace(/^\.\/|\.js$/g, "");
        const module = context(key).default;
        modules[moduleName] = module;
      }
      return modules;
    }
    __webpack_exports__["default"] = loadModules();
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var just_pick = __webpack_require__(4);
  var just_pick_default = __webpack_require__.n(just_pick);
  var parseQueryString = queryString => Object.fromEntries(new URLSearchParams(queryString).entries());
  var memoize = fn => {
    const cache = {};
    if (1 !== fn.length) throw new Error("fn 必须有且只有一个参数");
    const memoized = arg => {
      if (!cache.hasOwnProperty(arg)) cache[arg] = fn(arg);
      return cache[arg];
    };
    memoized.delete = arg => {
      delete cache[arg];
    };
    return memoized;
  };
  const helper = document.createElement("a");
  __webpack_exports__["a"] = memoize(url => {
    helper.href = url;
    return {
      ...just_pick_default()(helper, [ "protocol", "origin", "pathname" ]),
      domain: helper.hostname,
      query: parseQueryString(helper.search),
      hash: helper.hash.slice(1)
    };
  });
}, function(module, exports, __webpack_require__) {
  "use strict";
  var parse = __webpack_require__(56);
  var URLSearchParams = __webpack_require__(57);
  var defaultRegex = [ /{([\w]+)}/g, /:([a-zA-Z][\w]+)/g ];
  var fixedEncodeURIComponent = function(str) {
    return encodeURIComponent(str).replace(/[!'()*]/g, (function(c) {
      return "%" + c.charCodeAt(0).toString(16);
    }));
  };
  function transformUrl(urlTemplate) {
    var params = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    var options = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    var matcher = options.matcher;
    var matchers = matcher ? [ matcher ].concat(defaultRegex) : defaultRegex;
    var matches = [];
    var usedParams = [];
    var getParamValue = function(key) {
      if (key in params) {
        usedParams.push(key);
        return params[key];
      }
      throw new Error("Param (".concat(key, ") not provided for url template: ").concat(urlTemplate));
    };
    matchers.forEach((function(m) {
      var re = new RegExp(m);
      var match;
      while (null != (match = re.exec(urlTemplate))) matches.push(match);
    }));
    var replacedUrl = matches.reduce((function(acc, cur) {
      var full = cur[0];
      var key = cur[1];
      var value = getParamValue(key);
      return acc.replace(full, fixedEncodeURIComponent(value));
    }), urlTemplate);
    var _parse = parse(replacedUrl), urlPart = _parse.url, query = _parse.query, _parse$hash = _parse.hash, hashPart = void 0 === _parse$hash ? "" : _parse$hash;
    var searchParams = new URLSearchParams(query);
    Object.keys(params).forEach((function(key) {
      if (usedParams.indexOf(key) < 0) {
        var values = params[key];
        (Array.isArray(values) ? values : [ values ]).forEach((function(value) {
          searchParams.append(key, value);
        }));
      }
    }));
    searchParams.sort();
    var queryPart = searchParams.toString();
    queryPart = queryPart ? "?" + queryPart : "";
    return "".concat(urlPart).concat(queryPart).concat(hashPart);
  }
  module.exports = transformUrl;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const SemVer = __webpack_require__(59);
  const compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
  module.exports = compare;
}, function(module, exports, __webpack_require__) {
  "use strict";
  (function(process) {
    const debug = "object" === typeof process && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {};
    module.exports = debug;
  }).call(this, __webpack_require__(31));
}, function(module, exports) {
  var process = module.exports = {};
  var cachedSetTimeout;
  var cachedClearTimeout;
  function defaultSetTimout() {
    throw new Error("setTimeout has not been defined");
  }
  function defaultClearTimeout() {
    throw new Error("clearTimeout has not been defined");
  }
  (function() {
    try {
      if ("function" === typeof setTimeout) cachedSetTimeout = setTimeout; else cachedSetTimeout = defaultSetTimout;
    } catch (e) {
      cachedSetTimeout = defaultSetTimout;
    }
    try {
      if ("function" === typeof clearTimeout) cachedClearTimeout = clearTimeout; else cachedClearTimeout = defaultClearTimeout;
    } catch (e) {
      cachedClearTimeout = defaultClearTimeout;
    }
  })();
  function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) return setTimeout(fun, 0);
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
      cachedSetTimeout = setTimeout;
      return setTimeout(fun, 0);
    }
    try {
      return cachedSetTimeout(fun, 0);
    } catch (e) {
      try {
        return cachedSetTimeout.call(null, fun, 0);
      } catch (e) {
        return cachedSetTimeout.call(this, fun, 0);
      }
    }
  }
  function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) return clearTimeout(marker);
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
      cachedClearTimeout = clearTimeout;
      return clearTimeout(marker);
    }
    try {
      return cachedClearTimeout(marker);
    } catch (e) {
      try {
        return cachedClearTimeout.call(null, marker);
      } catch (e) {
        return cachedClearTimeout.call(this, marker);
      }
    }
  }
  var queue = [];
  var draining = false;
  var currentQueue;
  var queueIndex = -1;
  function cleanUpNextTick() {
    if (!draining || !currentQueue) return;
    draining = false;
    if (currentQueue.length) queue = currentQueue.concat(queue); else queueIndex = -1;
    if (queue.length) drainQueue();
  }
  function drainQueue() {
    if (draining) return;
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;
    var len = queue.length;
    while (len) {
      currentQueue = queue;
      queue = [];
      while (++queueIndex < len) if (currentQueue) currentQueue[queueIndex].run();
      queueIndex = -1;
      len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
  }
  process.nextTick = function(fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) for (var i = 1; i < arguments.length; i++) args[i - 1] = arguments[i];
    queue.push(new Item(fun, args));
    if (1 === queue.length && !draining) runTimeout(drainQueue);
  };
  function Item(fun, array) {
    this.fun = fun;
    this.array = array;
  }
  Item.prototype.run = function() {
    this.fun.apply(null, this.array);
  };
  process.title = "browser";
  process.browser = true;
  process.env = {};
  process.argv = [];
  process.version = "";
  process.versions = {};
  function noop() {}
  process.on = noop;
  process.addListener = noop;
  process.once = noop;
  process.off = noop;
  process.removeListener = noop;
  process.removeAllListeners = noop;
  process.emit = noop;
  process.prependListener = noop;
  process.prependOnceListener = noop;
  process.listeners = function(name) {
    return [];
  };
  process.binding = function(name) {
    throw new Error("process.binding is not supported");
  };
  process.cwd = function() {
    return "/";
  };
  process.chdir = function(dir) {
    throw new Error("process.chdir is not supported");
  };
  process.umask = function() {
    return 0;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const SEMVER_SPEC_VERSION = "2.0.0";
  const MAX_LENGTH = 256;
  const MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
  const MAX_SAFE_COMPONENT_LENGTH = 16;
  const MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
  const RELEASE_TYPES = [ "major", "premajor", "minor", "preminor", "patch", "prepatch", "prerelease" ];
  module.exports = {
    MAX_LENGTH,
    MAX_SAFE_COMPONENT_LENGTH,
    MAX_SAFE_BUILD_LENGTH,
    MAX_SAFE_INTEGER,
    RELEASE_TYPES,
    SEMVER_SPEC_VERSION,
    FLAG_INCLUDE_PRERELEASE: 1,
    FLAG_LOOSE: 2
  };
}, function(module, exports, __webpack_require__) {
  /*!
 * array-last <https://github.com/jonschlinkert/array-last>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
  var isNumber = __webpack_require__(44);
  module.exports = function(arr, n) {
    if (!Array.isArray(arr)) throw new Error("expected the first argument to be an array");
    var len = arr.length;
    if (0 === len) return null;
    n = isNumber(n) ? +n : 1;
    if (1 === n) return arr[len - 1];
    var res = new Array(n);
    while (n--) res[n] = arr[--len];
    return res;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = (string, options) => {
    options = Object.assign({
      preserveNewLines: false
    }, options);
    if ("string" !== typeof string) throw new TypeError(`Expected input to be of type \`string\`, got \`${typeof string}\``);
    if (!options.preserveNewlines) return string.split(/\r?\n/);
    const parts = string.split(/(\r?\n)/);
    const lines = [];
    for (let i = 0; i < parts.length; i += 2) lines.push(parts[i] + (parts[i + 1] || ""));
    return lines;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const stripAnsi = __webpack_require__(52);
  const isFullwidthCodePoint = __webpack_require__(54);
  const emojiRegex = __webpack_require__(55);
  const stringWidth = string => {
    if ("string" !== typeof string || 0 === string.length) return 0;
    string = stripAnsi(string);
    if (0 === string.length) return 0;
    string = string.replace(emojiRegex(), "  ");
    let width = 0;
    for (let i = 0; i < string.length; i++) {
      const code = string.codePointAt(i);
      if (code <= 31 || code >= 127 && code <= 159) continue;
      if (code >= 768 && code <= 879) continue;
      if (code > 65535) i++;
      width += isFullwidthCodePoint(code) ? 2 : 1;
    }
    return width;
  };
  module.exports = stringWidth;
  module.exports.default = stringWidth;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const processFn = (fn, options) => function(...args) {
    const P = options.promiseModule;
    return new P((resolve, reject) => {
      if (options.multiArgs) args.push((...result) => {
        if (options.errorFirst) if (result[0]) reject(result); else {
          result.shift();
          resolve(result);
        } else resolve(result);
      }); else if (options.errorFirst) args.push((error, result) => {
        if (error) reject(error); else resolve(result);
      }); else args.push(resolve);
      fn.apply(this, args);
    });
  };
  module.exports = (input, options) => {
    options = Object.assign({
      exclude: [ /.+(Sync|Stream)$/ ],
      errorFirst: true,
      promiseModule: Promise
    }, options);
    const objType = typeof input;
    if (!(null !== input && ("object" === objType || "function" === objType))) throw new TypeError(`Expected \`input\` to be a \`Function\` or \`Object\`, got \`${null === input ? "null" : objType}\``);
    const filter = key => {
      const match = pattern => "string" === typeof pattern ? key === pattern : pattern.test(key);
      return options.include ? options.include.some(match) : !options.exclude.some(match);
    };
    let ret;
    if ("function" === objType) ret = function(...args) {
      return options.excludeMain ? input(...args) : processFn(input, options).apply(this, args);
    }; else ret = Object.create(Object.getPrototypeOf(input));
    for (const key in input) {
      const property = input[key];
      ret[key] = "function" === typeof property && filter(key) ? processFn(property, options) : property;
    }
    return ret;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const compare = __webpack_require__(29);
  const gte = (a, b, loose) => compare(a, b, loose) >= 0;
  module.exports = gte;
}, function(module, exports, __webpack_require__) {
  (function(process) {
    module.exports = process.env.PROMISE_QUEUE_COVERAGE ? __webpack_require__(63) : __webpack_require__(64);
  }).call(this, __webpack_require__(31));
}, function(module, exports, __webpack_require__) {
  "use strict";
  const compare = __webpack_require__(29);
  const gt = (a, b, loose) => compare(a, b, loose) > 0;
  module.exports = gt;
}, function(module, exports) {
  module.exports = debounce;
  function debounce(fn, wait, callFirst) {
    var timeout = null;
    var debouncedFn = null;
    var clear = function() {
      if (timeout) {
        clearTimeout(timeout);
        debouncedFn = null;
        timeout = null;
      }
    };
    var flush = function() {
      var call = debouncedFn;
      clear();
      if (call) call();
    };
    var debounceWrapper = function() {
      if (!wait) return fn.apply(this, arguments);
      var context = this;
      var args = arguments;
      var callNow = callFirst && !timeout;
      clear();
      debouncedFn = function() {
        fn.apply(context, args);
      };
      timeout = setTimeout((function() {
        timeout = null;
        if (!callNow) {
          var call = debouncedFn;
          debouncedFn = null;
          return call();
        }
      }), wait);
      if (callNow) return debouncedFn();
    };
    debounceWrapper.cancel = clear;
    debounceWrapper.flush = flush;
    return debounceWrapper;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _features__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15);
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6);
  async function init({createEnvironment, modules, createFeatureClass, createSubfeatureClass}) {
    const environment = await createEnvironment();
    const Feature = createFeatureClass({
      ...environment,
      modules
    });
    const Subfeature = createSubfeatureClass({
      ...environment,
      modules
    });
    for (const [featureName, {metadata, subfeatures}] of Object.entries(_features__WEBPACK_IMPORTED_MODULE_0__["a"])) {
      if (!subfeatures) continue;
      const feature = new Feature({
        featureName,
        metadata
      });
      for (const [subfeatureName, {style, script}] of Object.entries(subfeatures)) {
        const subfeature = new Subfeature({
          featureName,
          subfeatureName,
          script,
          parent: feature
        });
        feature.addSubfeature(subfeature);
      }
      Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_1__["a"])(feature.init.bind(feature));
    }
  }
  init(__webpack_require__(69));
}, function(module, exports) {
  var g;
  g = function() {
    return this;
  }();
  try {
    g = g || new Function("return this")();
  } catch (e) {
    if ("object" === typeof window) g = window;
  }
  module.exports = g;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = value => {
    const type = typeof value;
    return null !== value && ("object" === type || "function" === type);
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  /*!
 * is-number <https://github.com/jonschlinkert/is-number>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */  module.exports = function(num) {
    var type = typeof num;
    if ("string" === type || num instanceof String) {
      if (!num.trim()) return false;
    } else if ("number" !== type && !(num instanceof Number)) return false;
    return num - num + 1 >= 0;
  };
}, function(module, exports, __webpack_require__) {
  var map = {
    "./action-types.js": 46,
    "./assets.js": 47,
    "./custom-event-types.js": 48,
    "./extension-origin.js": 49,
    "./index.js": 0,
    "./message-types.js": 50,
    "./others.js": 51
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 45;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "STORAGE_READ", (function() {
    return STORAGE_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_WRITE", (function() {
    return STORAGE_WRITE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_DELETE", (function() {
    return STORAGE_DELETE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_CHANGED", (function() {
    return STORAGE_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ", (function() {
    return SETTINGS_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ_ALL", (function() {
    return SETTINGS_READ_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_WRITE_ALL", (function() {
    return SETTINGS_WRITE_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_CHANGED", (function() {
    return SETTINGS_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "GET_OPTION_DEFS", (function() {
    return GET_OPTION_DEFS;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_FETCH_GET", (function() {
    return PROXIED_FETCH_GET;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_AUDIO", (function() {
    return PROXIED_AUDIO;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_CREATE_TAB", (function() {
    return PROXIED_CREATE_TAB;
  }));
  const STORAGE_READ = "STORAGE_READ";
  const STORAGE_WRITE = "STORAGE_WRITE";
  const STORAGE_DELETE = "STORAGE_DELETE";
  const STORAGE_CHANGED = "STORAGE_CHANGED";
  const SETTINGS_READ = "SETTINGS_READ";
  const SETTINGS_READ_ALL = "SETTINGS_READ_ALL";
  const SETTINGS_WRITE_ALL = "SETTINGS_WRITE_ALL";
  const SETTINGS_CHANGED = "SETTINGS_CHANGED";
  const GET_OPTION_DEFS = "GET_OPTION_DEFS";
  const PROXIED_FETCH_GET = "PROXIED_FETCH_GET";
  const PROXIED_AUDIO = "PROXIED_AUDIO";
  const PROXIED_CREATE_TAB = "PROXIED_CREATE_TAB";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "ASSET_CLASSNAME", (function() {
    return ASSET_CLASSNAME;
  }));
  const ASSET_CLASSNAME = "sf-asset";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BRIDGE_EVENT_TYPE", (function() {
    return BRIDGE_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "POST_STATUS_SUCCESS_EVENT_TYPE", (function() {
    return POST_STATUS_SUCCESS_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_UNLOADED_EVENT_TYPE", (function() {
    return EXTENSION_UNLOADED_EVENT_TYPE;
  }));
  const BRIDGE_EVENT_TYPE = "SpaceFanfouBridgeMessage";
  const POST_STATUS_SUCCESS_EVENT_TYPE = "SpaceFanfouPostStatusSuccess";
  const EXTENSION_UNLOADED_EVENT_TYPE = "SpaceFanfouUnloaded";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER_RE", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER_RE;
  }));
  const EXTENSION_ORIGIN_PLACEHOLDER = "<EXTENSION_ORIGIN_PLACEHOLDER>";
  const EXTENSION_ORIGIN_PLACEHOLDER_RE = new RegExp(EXTENSION_ORIGIN_PLACEHOLDER, "g");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BROADCASTING_MESSAGE", (function() {
    return BROADCASTING_MESSAGE;
  }));
  __webpack_require__.d(__webpack_exports__, "CONVERSATIONAL_MESSAGE", (function() {
    return CONVERSATIONAL_MESSAGE;
  }));
  const BROADCASTING_MESSAGE = "BROADCASTING_MESSAGE";
  const CONVERSATIONAL_MESSAGE = "CONVERSATIONAL_MESSAGE";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "CONTROL_PLACEHOLDER", (function() {
    return CONTROL_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_KEY_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_KEY_IS_EXTENSION_UPGRADED;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED;
  }));
  const CONTROL_PLACEHOLDER = "<CONTROL_PLACEHOLDER>";
  const STORAGE_KEY_IS_EXTENSION_UPGRADED = "is-extension-upgraded";
  const STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED = "session";
}, function(module, exports, __webpack_require__) {
  "use strict";
  const ansiRegex = __webpack_require__(53);
  module.exports = string => "string" === typeof string ? string.replace(ansiRegex(), "") : string;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = ({onlyFirst = false} = {}) => {
    const pattern = [ "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)", "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))" ].join("|");
    return new RegExp(pattern, onlyFirst ? void 0 : "g");
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isFullwidthCodePoint = codePoint => {
    if (Number.isNaN(codePoint)) return false;
    if (codePoint >= 4352 && (codePoint <= 4447 || 9001 === codePoint || 9002 === codePoint || 11904 <= codePoint && codePoint <= 12871 && 12351 !== codePoint || 12880 <= codePoint && codePoint <= 19903 || 19968 <= codePoint && codePoint <= 42182 || 43360 <= codePoint && codePoint <= 43388 || 44032 <= codePoint && codePoint <= 55203 || 63744 <= codePoint && codePoint <= 64255 || 65040 <= codePoint && codePoint <= 65049 || 65072 <= codePoint && codePoint <= 65131 || 65281 <= codePoint && codePoint <= 65376 || 65504 <= codePoint && codePoint <= 65510 || 110592 <= codePoint && codePoint <= 110593 || 127488 <= codePoint && codePoint <= 127569 || 131072 <= codePoint && codePoint <= 262141)) return true;
    return false;
  };
  module.exports = isFullwidthCodePoint;
  module.exports.default = isFullwidthCodePoint;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    return /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F|\uD83D\uDC68(?:\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68\uD83C\uDFFB|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|[\u2695\u2696\u2708]\uFE0F|\uD83D[\uDC66\uDC67]|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708])\uFE0F|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C[\uDFFB-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)\uD83C\uDFFB|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB\uDFFC])|\uD83D\uDC69(?:\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB-\uDFFD])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83C\uDFF4\u200D\u2620)\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDF6\uD83C\uDDE6|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDBB\uDDD2-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5\uDEEB\uDEEC\uDEF4-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(url) {
    var parsed = {};
    var q = url.indexOf("?");
    var h = url.indexOf("#");
    var hasQuery = !!~q;
    var hasHash = !!~h;
    parsed.url = url.slice(0, hasQuery && q || hasHash && h || url.length);
    if (hasQuery) parsed.query = url.slice(q, hasHash && h || url.length);
    if (hasHash) parsed.hash = url.slice(h);
    return parsed;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var URLSearchParams = "undefined" !== typeof window && window.URLSearchParams;
  if (!URLSearchParams) URLSearchParams = __webpack_require__(58);
  module.exports = URLSearchParams;
}, function(module, exports) {
  /*! (c) Andrea Giammarchi - ISC */
  var self = this || {};
  try {
    (function(URLSearchParams, plus) {
      if (new URLSearchParams("q=%2B").get("q") !== plus || new URLSearchParams({
        q: plus
      }).get("q") !== plus || new URLSearchParams([ [ "q", plus ] ]).get("q") !== plus || "q=%0A" !== new URLSearchParams("q=\n").toString() || "q=+%26" !== new URLSearchParams({
        q: " &"
      }).toString() || "q=%25zx" !== new URLSearchParams({
        q: "%zx"
      }).toString()) throw URLSearchParams;
      self.URLSearchParams = URLSearchParams;
    })(URLSearchParams, "+");
  } catch (URLSearchParams) {
    (function(Object, String, isArray) {
      "use strict";
      var create = Object.create;
      var defineProperty = Object.defineProperty;
      var find = /[!'\(\)~]|%20|%00/g;
      var findPercentSign = /%(?![0-9a-fA-F]{2})/g;
      var plus = /\+/g;
      var replace = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
      };
      var proto = {
        append: function(key, value) {
          appendTo(this._ungap, key, value);
        },
        delete: function(key) {
          delete this._ungap[key];
        },
        get: function(key) {
          return this.has(key) ? this._ungap[key][0] : null;
        },
        getAll: function(key) {
          return this.has(key) ? this._ungap[key].slice(0) : [];
        },
        has: function(key) {
          return key in this._ungap;
        },
        set: function(key, value) {
          this._ungap[key] = [ String(value) ];
        },
        forEach: function(callback, thisArg) {
          var self = this;
          for (var key in self._ungap) self._ungap[key].forEach(invoke, key);
          function invoke(value) {
            callback.call(thisArg, value, String(key), self);
          }
        },
        toJSON: function() {
          return {};
        },
        toString: function() {
          var query = [];
          for (var key in this._ungap) {
            var encoded = encode(key);
            for (var i = 0, value = this._ungap[key]; i < value.length; i++) query.push(encoded + "=" + encode(value[i]));
          }
          return query.join("&");
        }
      };
      for (var key in proto) defineProperty(URLSearchParams.prototype, key, {
        configurable: true,
        writable: true,
        value: proto[key]
      });
      self.URLSearchParams = URLSearchParams;
      function URLSearchParams(query) {
        var dict = create(null);
        defineProperty(this, "_ungap", {
          value: dict
        });
        switch (true) {
         case !query:
          break;

         case "string" === typeof query:
          if ("?" === query.charAt(0)) query = query.slice(1);
          for (var pairs = query.split("&"), i = 0, length = pairs.length; i < length; i++) {
            var value = pairs[i];
            var index = value.indexOf("=");
            if (-1 < index) appendTo(dict, decode(value.slice(0, index)), decode(value.slice(index + 1))); else if (value.length) appendTo(dict, decode(value), "");
          }
          break;

         case isArray(query):
          for (i = 0, length = query.length; i < length; i++) {
            value = query[i];
            appendTo(dict, value[0], value[1]);
          }
          break;

         case "forEach" in query:
          query.forEach(addEach, dict);
          break;

         default:
          for (var key in query) appendTo(dict, key, query[key]);
        }
      }
      function addEach(value, key) {
        appendTo(this, key, value);
      }
      function appendTo(dict, key, value) {
        var res = isArray(value) ? value.join(",") : value;
        if (key in dict) dict[key].push(res); else dict[key] = [ res ];
      }
      function decode(str) {
        return decodeURIComponent(str.replace(findPercentSign, "%25").replace(plus, " "));
      }
      function encode(str) {
        return encodeURIComponent(str).replace(find, replacer);
      }
      function replacer(match) {
        return replace[match];
      }
    })(Object, String, Array.isArray);
  }
  (function(URLSearchParamsProto) {
    var iterable = false;
    try {
      iterable = !!Symbol.iterator;
    } catch (o_O) {}
    if (!("forEach" in URLSearchParamsProto)) URLSearchParamsProto.forEach = function(callback, thisArg) {
      var self = this;
      var names = Object.create(null);
      this.toString().replace(/=[\s\S]*?(?:&|$)/g, "=").split("=").forEach((function(name) {
        if (!name.length || name in names) return;
        (names[name] = self.getAll(name)).forEach((function(value) {
          callback.call(thisArg, value, name, self);
        }));
      }));
    };
    if (!("keys" in URLSearchParamsProto)) URLSearchParamsProto.keys = function() {
      return iterator(this, (function(value, key) {
        this.push(key);
      }));
    };
    if (!("values" in URLSearchParamsProto)) URLSearchParamsProto.values = function() {
      return iterator(this, (function(value, key) {
        this.push(value);
      }));
    };
    if (!("entries" in URLSearchParamsProto)) URLSearchParamsProto.entries = function() {
      return iterator(this, (function(value, key) {
        this.push([ key, value ]);
      }));
    };
    if (iterable && !(Symbol.iterator in URLSearchParamsProto)) URLSearchParamsProto[Symbol.iterator] = URLSearchParamsProto.entries;
    if (!("sort" in URLSearchParamsProto)) URLSearchParamsProto.sort = function() {
      var i, key, value, entries = this.entries(), entry = entries.next(), done = entry.done, keys = [], values = Object.create(null);
      while (!done) {
        value = entry.value;
        key = value[0];
        keys.push(key);
        if (!(key in values)) values[key] = [];
        values[key].push(value[1]);
        entry = entries.next();
        done = entry.done;
      }
      keys.sort();
      for (i = 0; i < keys.length; i++) this.delete(keys[i]);
      for (i = 0; i < keys.length; i++) {
        key = keys[i];
        this.append(key, values[key].shift());
      }
    };
    function iterator(self, callback) {
      var items = [];
      self.forEach(callback, items);
      return iterable ? items[Symbol.iterator]() : {
        next: function() {
          var value = items.shift();
          return {
            done: void 0 === value,
            value
          };
        }
      };
    }
    (function(Object) {
      var dP = Object.defineProperty, gOPD = Object.getOwnPropertyDescriptor, createSearchParamsPollute = function(search) {
        function append(name, value) {
          URLSearchParamsProto.append.call(this, name, value);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        function del(name) {
          URLSearchParamsProto.delete.call(this, name);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        function set(name, value) {
          URLSearchParamsProto.set.call(this, name, value);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        return function(sp, value) {
          sp.append = append;
          sp.delete = del;
          sp.set = set;
          return dP(sp, "_usp", {
            configurable: true,
            writable: true,
            value
          });
        };
      }, createSearchParamsCreate = function(polluteSearchParams) {
        return function(obj, sp) {
          dP(obj, "_searchParams", {
            configurable: true,
            writable: true,
            value: polluteSearchParams(sp, obj)
          });
          return sp;
        };
      }, updateSearchParams = function(sp) {
        var append = sp.append;
        sp.append = URLSearchParamsProto.append;
        URLSearchParams.call(sp, sp._usp.search.slice(1));
        sp.append = append;
      }, verifySearchParams = function(obj, Class) {
        if (!(obj instanceof Class)) throw new TypeError("'searchParams' accessed on an object that does not implement interface " + Class.name);
      }, upgradeClass = function(Class) {
        var createSearchParams, ClassProto = Class.prototype, searchParams = gOPD(ClassProto, "searchParams"), href = gOPD(ClassProto, "href"), search = gOPD(ClassProto, "search");
        if (!searchParams && search && search.set) {
          createSearchParams = createSearchParamsCreate(createSearchParamsPollute(search));
          Object.defineProperties(ClassProto, {
            href: {
              get: function() {
                return href.get.call(this);
              },
              set: function(value) {
                var sp = this._searchParams;
                href.set.call(this, value);
                if (sp) updateSearchParams(sp);
              }
            },
            search: {
              get: function() {
                return search.get.call(this);
              },
              set: function(value) {
                var sp = this._searchParams;
                search.set.call(this, value);
                if (sp) updateSearchParams(sp);
              }
            },
            searchParams: {
              get: function() {
                verifySearchParams(this, Class);
                return this._searchParams || createSearchParams(this, new URLSearchParams(this.search.slice(1)));
              },
              set: function(sp) {
                verifySearchParams(this, Class);
                createSearchParams(this, sp);
              }
            }
          });
        }
      };
      try {
        upgradeClass(HTMLAnchorElement);
        if (/^function|object$/.test(typeof URL) && URL.prototype) upgradeClass(URL);
      } catch (meh) {}
    })(Object);
  })(self.URLSearchParams.prototype);
  module.exports = self.URLSearchParams;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const debug = __webpack_require__(30);
  const {MAX_LENGTH, MAX_SAFE_INTEGER} = __webpack_require__(32);
  const {safeRe: re, t} = __webpack_require__(60);
  const parseOptions = __webpack_require__(61);
  const {compareIdentifiers} = __webpack_require__(62);
  class SemVer {
    constructor(version, options) {
      options = parseOptions(options);
      if (version instanceof SemVer) if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) return version; else version = version.version; else if ("string" !== typeof version) throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
      if (version.length > MAX_LENGTH) throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
      debug("SemVer", version, options);
      this.options = options;
      this.loose = !!options.loose;
      this.includePrerelease = !!options.includePrerelease;
      const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
      if (!m) throw new TypeError("Invalid Version: " + version);
      this.raw = version;
      this.major = +m[1];
      this.minor = +m[2];
      this.patch = +m[3];
      if (this.major > MAX_SAFE_INTEGER || this.major < 0) throw new TypeError("Invalid major version");
      if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) throw new TypeError("Invalid minor version");
      if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) throw new TypeError("Invalid patch version");
      if (!m[4]) this.prerelease = []; else this.prerelease = m[4].split(".").map(id => {
        if (/^[0-9]+$/.test(id)) {
          const num = +id;
          if (num >= 0 && num < MAX_SAFE_INTEGER) return num;
        }
        return id;
      });
      this.build = m[5] ? m[5].split(".") : [];
      this.format();
    }
    format() {
      this.version = `${this.major}.${this.minor}.${this.patch}`;
      if (this.prerelease.length) this.version += "-" + this.prerelease.join(".");
      return this.version;
    }
    toString() {
      return this.version;
    }
    compare(other) {
      debug("SemVer.compare", this.version, this.options, other);
      if (!(other instanceof SemVer)) {
        if ("string" === typeof other && other === this.version) return 0;
        other = new SemVer(other, this.options);
      }
      if (other.version === this.version) return 0;
      return this.compareMain(other) || this.comparePre(other);
    }
    compareMain(other) {
      if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
      if (this.major < other.major) return -1;
      if (this.major > other.major) return 1;
      if (this.minor < other.minor) return -1;
      if (this.minor > other.minor) return 1;
      if (this.patch < other.patch) return -1;
      if (this.patch > other.patch) return 1;
      return 0;
    }
    comparePre(other) {
      if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
      if (this.prerelease.length && !other.prerelease.length) return -1; else if (!this.prerelease.length && other.prerelease.length) return 1; else if (!this.prerelease.length && !other.prerelease.length) return 0;
      let i = 0;
      do {
        const a = this.prerelease[i];
        const b = other.prerelease[i];
        debug("prerelease compare", i, a, b);
        if (void 0 === a && void 0 === b) return 0; else if (void 0 === b) return 1; else if (void 0 === a) return -1; else if (a === b) continue; else return compareIdentifiers(a, b);
      } while (++i);
    }
    compareBuild(other) {
      if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
      let i = 0;
      do {
        const a = this.build[i];
        const b = other.build[i];
        debug("build compare", i, a, b);
        if (void 0 === a && void 0 === b) return 0; else if (void 0 === b) return 1; else if (void 0 === a) return -1; else if (a === b) continue; else return compareIdentifiers(a, b);
      } while (++i);
    }
    inc(release, identifier, identifierBase) {
      if (release.startsWith("pre")) {
        if (!identifier && false === identifierBase) throw new Error("invalid increment argument: identifier is empty");
        if (identifier) {
          const match = ("-" + identifier).match(this.options.loose ? re[t.PRERELEASELOOSE] : re[t.PRERELEASE]);
          if (!match || match[1] !== identifier) throw new Error("invalid identifier: " + identifier);
        }
      }
      switch (release) {
       case "premajor":
        this.prerelease.length = 0;
        this.patch = 0;
        this.minor = 0;
        this.major++;
        this.inc("pre", identifier, identifierBase);
        break;

       case "preminor":
        this.prerelease.length = 0;
        this.patch = 0;
        this.minor++;
        this.inc("pre", identifier, identifierBase);
        break;

       case "prepatch":
        this.prerelease.length = 0;
        this.inc("patch", identifier, identifierBase);
        this.inc("pre", identifier, identifierBase);
        break;

       case "prerelease":
        if (0 === this.prerelease.length) this.inc("patch", identifier, identifierBase);
        this.inc("pre", identifier, identifierBase);
        break;

       case "release":
        if (0 === this.prerelease.length) throw new Error(`version ${this.raw} is not a prerelease`);
        this.prerelease.length = 0;
        break;

       case "major":
        if (0 !== this.minor || 0 !== this.patch || 0 === this.prerelease.length) this.major++;
        this.minor = 0;
        this.patch = 0;
        this.prerelease = [];
        break;

       case "minor":
        if (0 !== this.patch || 0 === this.prerelease.length) this.minor++;
        this.patch = 0;
        this.prerelease = [];
        break;

       case "patch":
        if (0 === this.prerelease.length) this.patch++;
        this.prerelease = [];
        break;

       case "pre":
        {
          const base = Number(identifierBase) ? 1 : 0;
          if (0 === this.prerelease.length) this.prerelease = [ base ]; else {
            let i = this.prerelease.length;
            while (--i >= 0) if ("number" === typeof this.prerelease[i]) {
              this.prerelease[i]++;
              i = -2;
            }
            if (-1 === i) {
              if (identifier === this.prerelease.join(".") && false === identifierBase) throw new Error("invalid increment argument: identifier already exists");
              this.prerelease.push(base);
            }
          }
          if (identifier) {
            let prerelease = [ identifier, base ];
            if (false === identifierBase) prerelease = [ identifier ];
            if (0 === compareIdentifiers(this.prerelease[0], identifier)) {
              if (isNaN(this.prerelease[1])) this.prerelease = prerelease;
            } else this.prerelease = prerelease;
          }
          break;
        }

       default:
        throw new Error("invalid increment argument: " + release);
      }
      this.raw = this.format();
      if (this.build.length) this.raw += "+" + this.build.join(".");
      return this;
    }
  }
  module.exports = SemVer;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const {MAX_SAFE_COMPONENT_LENGTH, MAX_SAFE_BUILD_LENGTH, MAX_LENGTH} = __webpack_require__(32);
  const debug = __webpack_require__(30);
  exports = module.exports = {};
  const re = exports.re = [];
  const safeRe = exports.safeRe = [];
  const src = exports.src = [];
  const safeSrc = exports.safeSrc = [];
  const t = exports.t = {};
  let R = 0;
  const LETTERDASHNUMBER = "[a-zA-Z0-9-]";
  const safeRegexReplacements = [ [ "\\s", 1 ], [ "\\d", MAX_LENGTH ], [ LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH ] ];
  const makeSafeRegex = value => {
    for (const [token, max] of safeRegexReplacements) value = value.split(token + "*").join(`${token}{0,${max}}`).split(token + "+").join(`${token}{1,${max}}`);
    return value;
  };
  const createToken = (name, value, isGlobal) => {
    const safe = makeSafeRegex(value);
    const index = R++;
    debug(name, index, value);
    t[name] = index;
    src[index] = value;
    safeSrc[index] = safe;
    re[index] = new RegExp(value, isGlobal ? "g" : void 0);
    safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
  };
  createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
  createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
  createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
  createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
  createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
  createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
  createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
  createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
  createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
  createToken("BUILDIDENTIFIER", LETTERDASHNUMBER + "+");
  createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
  createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
  createToken("FULL", `^${src[t.FULLPLAIN]}$`);
  createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
  createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
  createToken("GTLT", "((?:<|>)?=?)");
  createToken("XRANGEIDENTIFIERLOOSE", src[t.NUMERICIDENTIFIERLOOSE] + "|x|X|\\*");
  createToken("XRANGEIDENTIFIER", src[t.NUMERICIDENTIFIER] + "|x|X|\\*");
  createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
  createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
  createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
  createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("COERCEPLAIN", `(^|[^\\d])(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
  createToken("COERCE", src[t.COERCEPLAIN] + "(?:$|[^\\d])");
  createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?` + `(?:${src[t.BUILD]})?(?:$|[^\\d])`);
  createToken("COERCERTL", src[t.COERCE], true);
  createToken("COERCERTLFULL", src[t.COERCEFULL], true);
  createToken("LONETILDE", "(?:~>?)");
  createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
  exports.tildeTrimReplace = "$1~";
  createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
  createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("LONECARET", "(?:\\^)");
  createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
  exports.caretTrimReplace = "$1^";
  createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
  createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
  createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
  createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
  createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
  exports.comparatorTrimReplace = "$1$2$3";
  createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
  createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
  createToken("STAR", "(<|>)?=?\\s*\\*");
  createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
  createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
}, function(module, exports, __webpack_require__) {
  "use strict";
  const looseOption = Object.freeze({
    loose: true
  });
  const emptyOpts = Object.freeze({});
  const parseOptions = options => {
    if (!options) return emptyOpts;
    if ("object" !== typeof options) return looseOption;
    return options;
  };
  module.exports = parseOptions;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const numeric = /^[0-9]+$/;
  const compareIdentifiers = (a, b) => {
    if ("number" === typeof a && "number" === typeof b) return a === b ? 0 : a < b ? -1 : 1;
    const anum = numeric.test(a);
    const bnum = numeric.test(b);
    if (anum && bnum) {
      a = +a;
      b = +b;
    }
    return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
  };
  const rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
  module.exports = {
    compareIdentifiers,
    rcompareIdentifiers
  };
}, function(module, exports) {}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
  (function(root, factory) {
    "use strict";
    if ((true, module.exports) && true) module.exports = factory(); else if (true) !(__WEBPACK_AMD_DEFINE_FACTORY__ = factory, 
    __WEBPACK_AMD_DEFINE_RESULT__ = "function" === typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__, 
    void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  })(0, (function() {
    "use strict";
    var LocalPromise = "undefined" !== typeof Promise ? Promise : function() {
      return {
        then: function() {
          throw new Error("Queue.configure() before use Queue");
        }
      };
    };
    var noop = function() {};
    var resolveWith = function(value) {
      if (value && "function" === typeof value.then) return value;
      return new LocalPromise((function(resolve) {
        resolve(value);
      }));
    };
    function Queue(maxPendingPromises, maxQueuedPromises, options) {
      this.options = options = options || {};
      this.pendingPromises = 0;
      this.maxPendingPromises = "undefined" !== typeof maxPendingPromises ? maxPendingPromises : 1 / 0;
      this.maxQueuedPromises = "undefined" !== typeof maxQueuedPromises ? maxQueuedPromises : 1 / 0;
      this.queue = [];
    }
    Queue.configure = function(GlobalPromise) {
      LocalPromise = GlobalPromise;
    };
    Queue.prototype.add = function(promiseGenerator) {
      var self = this;
      return new LocalPromise((function(resolve, reject, notify) {
        if (self.queue.length >= self.maxQueuedPromises) {
          reject(new Error("Queue limit reached"));
          return;
        }
        self.queue.push({
          promiseGenerator,
          resolve,
          reject,
          notify: notify || noop
        });
        self._dequeue();
      }));
    };
    Queue.prototype.getPendingLength = function() {
      return this.pendingPromises;
    };
    Queue.prototype.getQueueLength = function() {
      return this.queue.length;
    };
    Queue.prototype._dequeue = function() {
      var self = this;
      if (this.pendingPromises >= this.maxPendingPromises) return false;
      var item = this.queue.shift();
      if (!item) {
        if (this.options.onEmpty) this.options.onEmpty();
        return false;
      }
      try {
        this.pendingPromises++;
        resolveWith(item.promiseGenerator()).then((function(value) {
          self.pendingPromises--;
          item.resolve(value);
          self._dequeue();
        }), (function(err) {
          self.pendingPromises--;
          item.reject(err);
          self._dequeue();
        }), (function(message) {
          item.notify(message);
        }));
      } catch (err) {
        self.pendingPromises--;
        item.reject(err);
        self._dequeue();
      }
      return true;
    };
    return Queue;
  }));
}, function(module, exports) {
  (function() {
    const showErrors = () => {
      if (chrome.runtime.lastError) console.error(chrome.runtime.lastError);
    };
    chrome.runtime.getManifest().content_scripts.forEach(script => {
      const allFrames = script.all_frames;
      const url = script.matches;
      const loadContentScripts = tab => {
        (script.js || []).forEach(file => {
          chrome.tabs.executeScript(tab.id, {
            allFrames,
            file
          }, showErrors);
        });
        (script.css || []).forEach(file => {
          chrome.tabs.insertCSS(tab.id, {
            allFrames,
            file
          }, showErrors);
        });
      };
      chrome.tabs.query({
        url
      }, tabs => tabs.forEach(loadContentScripts));
    });
  })();
}, function(module, exports, __webpack_require__) {
  var map = {
    "./index.js": 26,
    "./notification.js": 70,
    "./storage.js": 68
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 66;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "/assets/sounds/ding.mp3";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var just_pick__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4);
  var just_pick__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(just_pick__WEBPACK_IMPORTED_MODULE_0__);
  var _background_environment_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_2__["a"])(just_pick__WEBPACK_IMPORTED_MODULE_0___default()(_background_environment_storage__WEBPACK_IMPORTED_MODULE_1__["a"], [ "read", "write", "delete" ]));
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "createEnvironment", (function() {
    return createBackgroundEnvironment;
  }));
  __webpack_require__.d(__webpack_exports__, "createFeatureClass", (function() {
    return createFeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "createSubfeatureClass", (function() {
    return createSubfeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "modules", (function() {
    return background_modules["default"];
  }));
  var environment_messaging = __webpack_require__(1);
  var environment_storage = __webpack_require__(2);
  var environment_settings = __webpack_require__(19);
  var dist = __webpack_require__(10);
  var constants = __webpack_require__(0);
  function registerHandler() {
    environment_messaging["a"].registerHandler(constants["PROXIED_FETCH_GET"], async payload => {
      const {url, query, responseType = "text"} = payload;
      let error, responseText, responseJSON;
      let w = Object(dist["a"])(url);
      if (query) w = w.query(query);
      try {
        w = await w.get();
        if ("text" === responseType) responseText = await w.text(); else if ("json" === responseType) responseJSON = await w.json();
      } catch (exception) {
        error = exception;
      }
      return {
        error,
        responseText,
        responseJSON
      };
    });
  }
  var proxiedFetch = {
    install() {
      registerHandler();
    }
  };
  let offscreenDocumentCreated = false;
  async function ensureOffscreenDocument() {
    if (offscreenDocumentCreated) return;
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: [ "OFFSCREEN_DOCUMENT" ]
    });
    if (existingContexts.length > 0) {
      offscreenDocumentCreated = true;
      return;
    }
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: [ "AUDIO_PLAYBACK" ],
      justification: "Play notification sounds"
    });
    offscreenDocumentCreated = true;
  }
  async function playSound(audioUrl) {
    try {
      await ensureOffscreenDocument();
      await chrome.runtime.sendMessage({
        type: constants["PROXIED_AUDIO"],
        payload: {
          audioUrl
        }
      });
    } catch (error) {
      console.error("Failed to play sound via offscreen document:", error);
    }
  }
  function proxiedAudio_registerHandler() {
    environment_messaging["a"].registerHandler(constants["PROXIED_AUDIO"], payload => {
      const {audioUrl} = payload;
      playSound(audioUrl);
    });
  }
  var proxiedAudio = {
    install() {
      proxiedAudio_registerHandler();
    }
  };
  function proxiedCreateTab_registerHandler() {
    environment_messaging["a"].registerHandler(constants["PROXIED_CREATE_TAB"], payload => {
      const {url, openInBackgroundTab = false} = payload;
      chrome.tabs.create({
        url,
        active: !openInBackgroundTab
      });
    });
  }
  var proxiedCreateTab = {
    install() {
      proxiedCreateTab_registerHandler();
    }
  };
  async function createBackgroundEnvironment() {
    __webpack_require__(65);
    await Promise.all([ environment_messaging["a"].install(), environment_storage["a"].install(), environment_settings["a"].install(), proxiedFetch.install(), proxiedAudio.install(), proxiedCreateTab.install() ]);
    return {
      messaging: environment_messaging["a"],
      settings: environment_settings["a"]
    };
  }
  var just_pick = __webpack_require__(4);
  var just_pick_default = __webpack_require__.n(just_pick);
  var fast_deep_equal = __webpack_require__(9);
  var fast_deep_equal_default = __webpack_require__.n(fast_deep_equal);
  var safelyInvokeFn = __webpack_require__(6);
  var migrate = __webpack_require__(18);
  var extensionUnloaded = __webpack_require__(23);
  var createFeatureClass = ({messaging, bridge, settings, modules}) => class {
    constructor({featureName, metadata}) {
      this.featureName = featureName;
      this.metadata = metadata;
      this.subfeatures = [];
      this.optionValuesCache = {};
      this.isLoaded = false;
    }
    get transport() {
      return messaging || bridge;
    }
    addSubfeature(subfeature) {
      this.subfeatures.push(subfeature);
    }
    async init() {
      await this.loadOptionValues();
      await this.migrate();
      if (this.metadata.isSoldered || await this.checkIfEnabled()) await this.load();
      this.listenOnSettingsChange();
      this.listenOnExtensionUnload();
    }
    async loadOptionValues() {
      const optionValues = await settings.readAll();
      this.optionValuesCache = just_pick_default()(optionValues, this.metadata.optionNames);
    }
    async migrate() {
      const {storage} = modules;
      for (const subfeature of this.subfeatures) {
        const {migrations = []} = subfeature;
        for (const migration of migrations) await Object(migrate["a"])({
          storage,
          ...migration
        });
      }
    }
    checkIfEnabled() {
      return this.optionValuesCache[this.featureName];
    }
    load() {
      if (this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.load.bind(subfeature));
      this.isLoaded = true;
    }
    unload() {
      if (!this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.unload.bind(subfeature));
      this.isLoaded = false;
    }
    listenOnSettingsChange() {
      this.transport.registerBroadcastListener(message => {
        if (message.action === constants["SETTINGS_CHANGED"]) this.handleSettingsChange();
      });
    }
    async handleSettingsChange() {
      const previousOptionValues = this.optionValuesCache;
      await this.loadOptionValues();
      const currentOptionValues = this.optionValuesCache;
      const previousEnabled = previousOptionValues[this.featureName];
      const currentEnabled = currentOptionValues[this.featureName];
      if (currentEnabled === previousEnabled) {
        if (!currentEnabled) return;
        if (fast_deep_equal_default()(previousOptionValues, currentOptionValues)) return;
        for (const subfeature of this.subfeatures) subfeature.handleSettingsChange();
      } else if (this.isLoaded) this.unload(); else this.load();
    }
    listenOnExtensionUnload() {
      extensionUnloaded["a"].addListener(this.handleExtensionUnload.bind(this));
    }
    handleExtensionUnload() {
      this.unload();
    }
  };
  var is_promise = __webpack_require__(24);
  var is_promise_default = __webpack_require__.n(is_promise);
  var promiseEvery = iterable => new Promise(resolve => {
    const total = iterable.length;
    let count = 0;
    let done = false;
    if (0 === total) return resolve(true);
    function check(value) {
      if (!value) return fail();
      if (++count === total) {
        done = true;
        resolve(true);
      }
    }
    function fail() {
      done = true;
      resolve(false);
    }
    for (const item of iterable) {
      if (done) return;
      if (is_promise_default()(item)) item.then(check, fail); else check(item);
    }
  });
  var createSubfeatureClass = ({modules}) => class {
    constructor({featureName, subfeatureName, script, parent}) {
      this.requireModules = moduleNames => {
        const requiredModules = {};
        for (const moduleName of moduleNames) {
          const module = modules[moduleName];
          if (!module) throw new Error("未知 module：" + moduleName);
          this.waitReadyFns.push(module.ready);
          requiredModules[moduleName] = module;
        }
        return requiredModules;
      };
      this.readOptionValue = key => {
        const optionName = `${this.featureName}/${key}`;
        const optionValue = this.parent.optionValuesCache[optionName];
        return optionValue;
      };
      this.featureName = featureName;
      this.subfeatureName = subfeatureName;
      this.parent = parent;
      this.initContext();
      const featureScriptObj = script(this.context);
      this.migrations = featureScriptObj.migrations;
      this.script = just_pick_default()(featureScriptObj, [ "onLoad", "onSettingsChange", "onUnload" ]);
    }
    initContext() {
      this.waitReadyFns = [];
      this.context = just_pick_default()(this, [ "requireModules", "readOptionValue" ]);
    }
    async load() {
      var _this$script$onLoad, _this$script;
      await promiseEvery(this.waitReadyFns.map(fn => fn()));
      await (null === (_this$script$onLoad = (_this$script = this.script).onLoad) || void 0 === _this$script$onLoad ? void 0 : _this$script$onLoad.call(_this$script));
    }
    async unload() {
      var _this$script$onUnload, _this$script2;
      await (null === (_this$script$onUnload = (_this$script2 = this.script).onUnload) || void 0 === _this$script$onUnload ? void 0 : _this$script$onUnload.call(_this$script2));
    }
    handleSettingsChange() {
      var _this$script$onSettin, _this$script3;
      null === (_this$script$onSettin = (_this$script3 = this.script).onSettingsChange) || void 0 === _this$script$onSettin ? void 0 : _this$script$onSettin.call(_this$script3);
    }
  };
  var background_modules = __webpack_require__(26);
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var just_pick = __webpack_require__(4);
  var just_pick_default = __webpack_require__.n(just_pick);
  var just_debounce_it = __webpack_require__(40);
  var just_debounce_it_default = __webpack_require__.n(just_debounce_it);
  var settings = __webpack_require__(19);
  var wrapper = __webpack_require__(25);
  var playSound = audioUrl => {
    const audio = new Audio;
    audio.src = audioUrl;
    audio.play();
  };
  var noop = __webpack_require__(14);
  const DEFAULT_NOTIFICATION_TIMEOUT = 15e3;
  const SOUND_URL = __webpack_require__(67);
  const notificationMap = {};
  const playSoundForNotification = just_debounce_it_default()(() => {
    if (settings["a"].read("notifications/playSound")) playSound(SOUND_URL);
  }, 1);
  function createNotification(opts) {
    const {id, title = "太空饭否", message, timeout = DEFAULT_NOTIFICATION_TIMEOUT, buttonDefs = []} = opts;
    const buttons = buttonDefs.map(buttonDef => just_pick_default()(buttonDef, [ "title" ]));
    if (!id) throw new Error("必须指定通知的 id");
    destroyNotification(id);
    chrome.notifications.create(id, {
      type: "basic",
      iconUrl: "/icons/icon-256.png",
      title,
      message,
      buttons,
      requireInteraction: true,
      silent: true
    });
    playSoundForNotification();
    opts.timeoutId = setTimeout(() => {
      destroyNotification(id);
    }, timeout);
    notificationMap[id] = opts;
  }
  function destroyNotification(id) {
    const opts = notificationMap[id];
    if (opts) {
      clearTimeout(opts.timeoutId);
      chrome.notifications.clear(id);
      delete notificationMap[id];
    }
  }
  function onNotificationClicked(id) {
    const opts = notificationMap[id];
    if (opts) {
      const handler = opts.onClick || noop["a"];
      handler();
      destroyNotification(id);
    }
  }
  function onButtonClicked(id, buttonIndex) {
    const opts = notificationMap[id];
    if (opts) {
      var _opts$buttonDefs, _opts$buttonDefs$butt;
      const handler = (null === (_opts$buttonDefs = opts.buttonDefs) || void 0 === _opts$buttonDefs ? void 0 : null === (_opts$buttonDefs$butt = _opts$buttonDefs[buttonIndex]) || void 0 === _opts$buttonDefs$butt ? void 0 : _opts$buttonDefs$butt.onClick) || noop["a"];
      handler();
      destroyNotification(id);
    }
  }
  __webpack_exports__["default"] = Object(wrapper["a"])({
    install() {
      chrome.notifications.onClicked.addListener(onNotificationClicked);
      chrome.notifications.onButtonClicked.addListener(onButtonClicked);
    },
    create: createNotification,
    hide: destroyNotification
  });
} ]);