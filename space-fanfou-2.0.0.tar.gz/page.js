(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ("undefined" !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && "object" === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value
    });
    if (2 & mode && "string" != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function() {
      return module["default"];
    } : function() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 157);
})([ function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  function isQueryable(object) {
    return "function" === typeof object.querySelectorAll;
  }
  function select(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    return (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelector(String(selectors));
  }
  function selectLast(selectors, baseElement) {
    if (2 === arguments.length && !baseElement) return null;
    const all = (null !== baseElement && void 0 !== baseElement ? baseElement : document).querySelectorAll(String(selectors));
    return all[all.length - 1];
  }
  function selectExists(selectors, baseElement) {
    if (2 === arguments.length) return Boolean(select(selectors, baseElement));
    return Boolean(select(selectors));
  }
  function selectAll(selectors, baseElements) {
    if (2 === arguments.length && !baseElements) return [];
    if (!baseElements || isQueryable(baseElements)) {
      const elements = (null !== baseElements && void 0 !== baseElements ? baseElements : document).querySelectorAll(String(selectors));
      return Array.apply(null, elements);
    }
    const all = [];
    for (let i = 0; i < baseElements.length; i++) {
      const current = baseElements[i].querySelectorAll(String(selectors));
      for (let ii = 0; ii < current.length; ii++) all.push(current[ii]);
    }
    const array = [];
    all.forEach((function(v) {
      array.push(v);
    }));
    return array;
  }
  select.last = selectLast;
  select.exists = selectExists;
  select.all = selectAll;
  __webpack_exports__["a"] = select;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return x;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return k;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return K;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return Q;
  }));
  __webpack_require__.d(__webpack_exports__, "e", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "f", (function() {
    return b;
  }));
  __webpack_require__.d(__webpack_exports__, "g", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "h", (function() {
    return J;
  }));
  __webpack_require__.d(__webpack_exports__, "i", (function() {
    return l;
  }));
  __webpack_require__.d(__webpack_exports__, "j", (function() {
    return G;
  }));
  __webpack_require__.d(__webpack_exports__, "k", (function() {
    return H;
  }));
  var n, l, u, i, r, o, e, f, c, s, a, h, p = {}, v = [], y = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, w = Array.isArray;
  function d(n, l) {
    for (var u in l) n[u] = l[u];
    return n;
  }
  function g(n) {
    n && n.parentNode && n.parentNode.removeChild(n);
  }
  function _(l, u, t) {
    var i, r, o, e = {};
    for (o in u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : e[o] = u[o];
    if (arguments.length > 2 && (e.children = arguments.length > 3 ? n.call(arguments, 2) : t), 
    "function" == typeof l && null != l.defaultProps) for (o in l.defaultProps) void 0 === e[o] && (e[o] = l.defaultProps[o]);
    return m(l, e, i, r, null);
  }
  function m(n, t, i, r, o) {
    var e = {
      type: n,
      props: t,
      key: i,
      ref: r,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __c: null,
      constructor: void 0,
      __v: null == o ? ++u : o,
      __i: -1,
      __u: 0
    };
    return null == o && null != l.vnode && l.vnode(e), e;
  }
  function b() {
    return {
      current: null
    };
  }
  function k(n) {
    return n.children;
  }
  function x(n, l) {
    this.props = n, this.context = l;
  }
  function S(n, l) {
    if (null == l) return n.__ ? S(n.__, n.__i + 1) : null;
    for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? S(n) : null;
  }
  function C(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
      for (n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) {
        n.__e = n.__c.base = u.__e;
        break;
      }
      return C(n);
    }
  }
  function M(n) {
    (!n.__d && (n.__d = !0) && i.push(n) && !$.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)($);
  }
  function $() {
    for (var n, u, t, r, o, f, c, s = 1; i.length; ) i.length > s && i.sort(e), n = i.shift(), 
    s = i.length, n.__d && (t = void 0, r = void 0, o = (r = (u = n).__v).__e, f = [], 
    c = [], u.__P && ((t = d({}, r)).__v = r.__v + 1, l.vnode && l.vnode(t), O(u.__P, t, r, u.__n, u.__P.namespaceURI, 32 & r.__u ? [ o ] : null, f, null == o ? S(r) : o, !!(32 & r.__u), c), 
    t.__v = r.__v, t.__.__k[t.__i] = t, N(f, t, c), r.__e = r.__ = null, t.__e != o && C(t)));
    $.__r = 0;
  }
  function I(n, l, u, t, i, r, o, e, f, c, s) {
    var a, h, y, w, d, g, _, m = t && t.__k || v, b = l.length;
    for (f = P(u, l, m, f, b), a = 0; a < b; a++) null != (y = u.__k[a]) && (h = -1 == y.__i ? p : m[y.__i] || p, 
    y.__i = a, g = O(n, y, h, i, r, o, e, f, c, s), w = y.__e, y.ref && h.ref != y.ref && (h.ref && B(h.ref, null, y), 
    s.push(y.ref, y.__c || w, y)), null == d && null != w && (d = w), (_ = !!(4 & y.__u)) || h.__k === y.__k ? f = A(y, f, n, _) : "function" == typeof y.type && void 0 !== g ? f = g : w && (f = w.nextSibling), 
    y.__u &= -7);
    return u.__e = d, f;
  }
  function P(n, l, u, t, i) {
    var r, o, e, f, c, s = u.length, a = s, h = 0;
    for (n.__k = new Array(i), r = 0; r < i; r++) null != (o = l[r]) && "boolean" != typeof o && "function" != typeof o ? (f = r + h, 
    (o = n.__k[r] = "string" == typeof o || "number" == typeof o || "bigint" == typeof o || o.constructor == String ? m(null, o, null, null, null) : w(o) ? m(k, {
      children: o
    }, null, null, null) : null == o.constructor && o.__b > 0 ? m(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v) : o).__ = n, 
    o.__b = n.__b + 1, e = null, -1 != (c = o.__i = L(o, u, f, a)) && (a--, (e = u[c]) && (e.__u |= 2)), 
    null == e || null == e.__v ? (-1 == c && (i > s ? h-- : i < s && h++), "function" != typeof o.type && (o.__u |= 4)) : c != f && (c == f - 1 ? h-- : c == f + 1 ? h++ : (c > f ? h-- : h++, 
    o.__u |= 4))) : n.__k[r] = null;
    if (a) for (r = 0; r < s; r++) null != (e = u[r]) && 0 == (2 & e.__u) && (e.__e == t && (t = S(e)), 
    D(e, e));
    return t;
  }
  function A(n, l, u, t) {
    var i, r;
    if ("function" == typeof n.type) {
      for (i = n.__k, r = 0; i && r < i.length; r++) i[r] && (i[r].__ = n, l = A(i[r], l, u, t));
      return l;
    }
    n.__e != l && (t && (l && n.type && !l.parentNode && (l = S(n)), u.insertBefore(n.__e, l || null)), 
    l = n.__e);
    do {
      l = l && l.nextSibling;
    } while (null != l && 8 == l.nodeType);
    return l;
  }
  function H(n, l) {
    return l = l || [], null == n || "boolean" == typeof n || (w(n) ? n.some((function(n) {
      H(n, l);
    })) : l.push(n)), l;
  }
  function L(n, l, u, t) {
    var i, r, o, e = n.key, f = n.type, c = l[u], s = null != c && 0 == (2 & c.__u);
    if (null === c && null == n.key || s && e == c.key && f == c.type) return u;
    if (t > (s ? 1 : 0)) for (i = u - 1, r = u + 1; i >= 0 || r < l.length; ) if (null != (c = l[o = i >= 0 ? i-- : r++]) && 0 == (2 & c.__u) && e == c.key && f == c.type) return o;
    return -1;
  }
  function T(n, l, u) {
    "-" == l[0] ? n.setProperty(l, null == u ? "" : u) : n[l] = null == u ? "" : "number" != typeof u || y.test(l) ? u : u + "px";
  }
  function j(n, l, u, t, i) {
    var r, o;
    n: if ("style" == l) if ("string" == typeof u) n.style.cssText = u; else {
      if ("string" == typeof t && (n.style.cssText = t = ""), t) for (l in t) u && l in u || T(n.style, l, "");
      if (u) for (l in u) t && u[l] == t[l] || T(n.style, l, u[l]);
    } else if ("o" == l[0] && "n" == l[1]) r = l != (l = l.replace(f, "$1")), o = l.toLowerCase(), 
    l = o in n || "onFocusOut" == l || "onFocusIn" == l ? o.slice(2) : l.slice(2), n.l || (n.l = {}), 
    n.l[l + r] = u, u ? t ? u.u = t.u : (u.u = c, n.addEventListener(l, r ? a : s, r)) : n.removeEventListener(l, r ? a : s, r); else {
      if ("http://www.w3.org/2000/svg" == i) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s"); else if ("width" != l && "height" != l && "href" != l && "list" != l && "form" != l && "tabIndex" != l && "download" != l && "rowSpan" != l && "colSpan" != l && "role" != l && "popover" != l && l in n) try {
        n[l] = null == u ? "" : u;
        break n;
      } catch (n) {}
      "function" == typeof u || (null == u || !1 === u && "-" != l[4] ? n.removeAttribute(l) : n.setAttribute(l, "popover" == l && 1 == u ? "" : u));
    }
  }
  function F(n) {
    return function(u) {
      if (this.l) {
        var t = this.l[u.type + n];
        if (null == u.t) u.t = c++; else if (u.t < t.u) return;
        return t(l.event ? l.event(u) : u);
      }
    };
  }
  function O(n, u, t, i, r, o, e, f, c, s) {
    var a, h, p, v, y, _, m, b, S, C, M, $, P, A, H, L, T, j = u.type;
    if (null != u.constructor) return null;
    128 & t.__u && (c = !!(32 & t.__u), o = [ f = u.__e = t.__e ]), (a = l.__b) && a(u);
    n: if ("function" == typeof j) try {
      if (b = u.props, S = "prototype" in j && j.prototype.render, C = (a = j.contextType) && i[a.__c], 
      M = a ? C ? C.props.value : a.__ : i, t.__c ? m = (h = u.__c = t.__c).__ = h.__E : (S ? u.__c = h = new j(b, M) : (u.__c = h = new x(b, M), 
      h.constructor = j, h.render = E), C && C.sub(h), h.props = b, h.state || (h.state = {}), 
      h.context = M, h.__n = i, p = h.__d = !0, h.__h = [], h._sb = []), S && null == h.__s && (h.__s = h.state), 
      S && null != j.getDerivedStateFromProps && (h.__s == h.state && (h.__s = d({}, h.__s)), 
      d(h.__s, j.getDerivedStateFromProps(b, h.__s))), v = h.props, y = h.state, h.__v = u, 
      p) S && null == j.getDerivedStateFromProps && null != h.componentWillMount && h.componentWillMount(), 
      S && null != h.componentDidMount && h.__h.push(h.componentDidMount); else {
        if (S && null == j.getDerivedStateFromProps && b !== v && null != h.componentWillReceiveProps && h.componentWillReceiveProps(b, M), 
        !h.__e && null != h.shouldComponentUpdate && !1 === h.shouldComponentUpdate(b, h.__s, M) || u.__v == t.__v) {
          for (u.__v != t.__v && (h.props = b, h.state = h.__s, h.__d = !1), u.__e = t.__e, 
          u.__k = t.__k, u.__k.some((function(n) {
            n && (n.__ = u);
          })), $ = 0; $ < h._sb.length; $++) h.__h.push(h._sb[$]);
          h._sb = [], h.__h.length && e.push(h);
          break n;
        }
        null != h.componentWillUpdate && h.componentWillUpdate(b, h.__s, M), S && null != h.componentDidUpdate && h.__h.push((function() {
          h.componentDidUpdate(v, y, _);
        }));
      }
      if (h.context = M, h.props = b, h.__P = n, h.__e = !1, P = l.__r, A = 0, S) {
        for (h.state = h.__s, h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), 
        H = 0; H < h._sb.length; H++) h.__h.push(h._sb[H]);
        h._sb = [];
      } else do {
        h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), h.state = h.__s;
      } while (h.__d && ++A < 25);
      h.state = h.__s, null != h.getChildContext && (i = d(d({}, i), h.getChildContext())), 
      S && !p && null != h.getSnapshotBeforeUpdate && (_ = h.getSnapshotBeforeUpdate(v, y)), 
      L = a, null != a && a.type === k && null == a.key && (L = V(a.props.children)), 
      f = I(n, w(L) ? L : [ L ], u, t, i, r, o, e, f, c, s), h.base = u.__e, u.__u &= -161, 
      h.__h.length && e.push(h), m && (h.__E = h.__ = null);
    } catch (n) {
      if (u.__v = null, c || null != o) if (n.then) {
        for (u.__u |= c ? 160 : 128; f && 8 == f.nodeType && f.nextSibling; ) f = f.nextSibling;
        o[o.indexOf(f)] = null, u.__e = f;
      } else {
        for (T = o.length; T--; ) g(o[T]);
        z(u);
      } else u.__e = t.__e, u.__k = t.__k, n.then || z(u);
      l.__e(n, u, t);
    } else null == o && u.__v == t.__v ? (u.__k = t.__k, u.__e = t.__e) : f = u.__e = q(t.__e, u, t, i, r, o, e, c, s);
    return (a = l.diffed) && a(u), 128 & u.__u ? void 0 : f;
  }
  function z(n) {
    n && n.__c && (n.__c.__e = !0), n && n.__k && n.__k.forEach(z);
  }
  function N(n, u, t) {
    for (var i = 0; i < t.length; i++) B(t[i], t[++i], t[++i]);
    l.__c && l.__c(u, n), n.some((function(u) {
      try {
        n = u.__h, u.__h = [], n.some((function(n) {
          n.call(u);
        }));
      } catch (n) {
        l.__e(n, u.__v);
      }
    }));
  }
  function V(n) {
    return "object" != typeof n || null == n || n.__b && n.__b > 0 ? n : w(n) ? n.map(V) : d({}, n);
  }
  function q(u, t, i, r, o, e, f, c, s) {
    var a, h, v, y, d, _, m, b = i.props, k = t.props, x = t.type;
    if ("svg" == x ? o = "http://www.w3.org/2000/svg" : "math" == x ? o = "http://www.w3.org/1998/Math/MathML" : o || (o = "http://www.w3.org/1999/xhtml"), 
    null != e) for (a = 0; a < e.length; a++) if ((d = e[a]) && "setAttribute" in d == !!x && (x ? d.localName == x : 3 == d.nodeType)) {
      u = d, e[a] = null;
      break;
    }
    if (null == u) {
      if (null == x) return document.createTextNode(k);
      u = document.createElementNS(o, x, k.is && k), c && (l.__m && l.__m(t, e), c = !1), 
      e = null;
    }
    if (null == x) b === k || c && u.data == k || (u.data = k); else {
      if (e = e && n.call(u.childNodes), b = i.props || p, !c && null != e) for (b = {}, 
      a = 0; a < u.attributes.length; a++) b[(d = u.attributes[a]).name] = d.value;
      for (a in b) if (d = b[a], "children" == a) ; else if ("dangerouslySetInnerHTML" == a) v = d; else if (!(a in k)) {
        if ("value" == a && "defaultValue" in k || "checked" == a && "defaultChecked" in k) continue;
        j(u, a, null, d, o);
      }
      for (a in k) d = k[a], "children" == a ? y = d : "dangerouslySetInnerHTML" == a ? h = d : "value" == a ? _ = d : "checked" == a ? m = d : c && "function" != typeof d || b[a] === d || j(u, a, d, b[a], o);
      if (h) c || v && (h.__html == v.__html || h.__html == u.innerHTML) || (u.innerHTML = h.__html), 
      t.__k = []; else if (v && (u.innerHTML = ""), I("template" == t.type ? u.content : u, w(y) ? y : [ y ], t, i, r, "foreignObject" == x ? "http://www.w3.org/1999/xhtml" : o, e, f, e ? e[0] : i.__k && S(i, 0), c, s), 
      null != e) for (a = e.length; a--; ) g(e[a]);
      c || (a = "value", "progress" == x && null == _ ? u.removeAttribute("value") : null != _ && (_ !== u[a] || "progress" == x && !_ || "option" == x && _ != b[a]) && j(u, a, _, b[a], o), 
      a = "checked", null != m && m != u[a] && j(u, a, m, b[a], o));
    }
    return u;
  }
  function B(n, u, t) {
    try {
      if ("function" == typeof n) {
        var i = "function" == typeof n.__u;
        i && n.__u(), i && null == u || (n.__u = n(u));
      } else n.current = u;
    } catch (n) {
      l.__e(n, t);
    }
  }
  function D(n, u, t) {
    var i, r;
    if (l.unmount && l.unmount(n), (i = n.ref) && (i.current && i.current != n.__e || B(i, null, u)), 
    null != (i = n.__c)) {
      if (i.componentWillUnmount) try {
        i.componentWillUnmount();
      } catch (n) {
        l.__e(n, u);
      }
      i.base = i.__P = null;
    }
    if (i = n.__k) for (r = 0; r < i.length; r++) i[r] && D(i[r], u, t || "function" != typeof n.type);
    t || g(n.__e), n.__c = n.__ = n.__e = void 0;
  }
  function E(n, l, u) {
    return this.constructor(n, u);
  }
  function G(u, t, i) {
    var r, o, e, f;
    t == document && (t = document.documentElement), l.__ && l.__(u, t), o = (r = "function" == typeof i) ? null : i && i.__k || t.__k, 
    e = [], f = [], O(t, u = (!r && i || t).__k = _(k, null, [ u ]), o || p, p, t.namespaceURI, !r && i ? [ i ] : o ? null : t.firstChild ? n.call(t.childNodes) : null, e, !r && i ? i : o ? o.__e : t.firstChild, r, f), 
    N(e, u, f);
  }
  function J(n, l) {
    G(n, l, J);
  }
  function K(l, u, t) {
    var i, r, o, e, f = d({}, l.props);
    for (o in l.type && l.type.defaultProps && (e = l.type.defaultProps), u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : f[o] = void 0 === u[o] && null != e ? e[o] : u[o];
    return arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : t), 
    m(l.type, f, i || l.key, r || l.ref, null);
  }
  function Q(n) {
    function l(n) {
      var u, t;
      return this.getChildContext || (u = new Set, (t = {})[l.__c] = this, this.getChildContext = function() {
        return t;
      }, this.componentWillUnmount = function() {
        u = null;
      }, this.shouldComponentUpdate = function(n) {
        this.props.value != n.value && u.forEach((function(n) {
          n.__e = !0, M(n);
        }));
      }, this.sub = function(n) {
        u.add(n);
        var l = n.componentWillUnmount;
        n.componentWillUnmount = function() {
          u && u.delete(n), l && l.call(n);
        };
      }), n.children;
    }
    return l.__c = "__cC" + h++, l.__ = n, l.Provider = l.__l = (l.Consumer = function(n, l) {
      return n.children(l);
    }).contextType = l, l;
  }
  n = v.slice, l = {
    __e: function(n, l, u, t) {
      for (var i, r, o; l = l.__; ) if ((i = l.__c) && !i.__) try {
        if ((r = i.constructor) && null != r.getDerivedStateFromError && (i.setState(r.getDerivedStateFromError(n)), 
        o = i.__d), null != i.componentDidCatch && (i.componentDidCatch(n, t || {}), o = i.__d), 
        o) return i.__E = i;
      } catch (l) {
        n = l;
      }
      throw n;
    }
  }, u = 0, function(n) {
    return null != n && null == n.constructor;
  }, x.prototype.setState = function(n, l) {
    var u;
    u = null != this.__s && this.__s != this.state ? this.__s : this.__s = d({}, this.state), 
    "function" == typeof n && (n = n(d({}, u), this.props)), n && d(u, n), null != n && this.__v && (l && this._sb.push(l), 
    M(this));
  }, x.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), M(this));
  }, x.prototype.render = k, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, 
  e = function(n, l) {
    return n.__v.__b - l.__v.__b;
  }, $.__r = 0, f = /(PointerCapture)$|Capture$/i, c = 0, s = F(!1), a = F(!0), h = 0;
}, function(module, exports, __webpack_require__) {
  if (false) ; else module.exports = __webpack_require__(94)();
}, function(module, exports, __webpack_require__) {
  (function(__filename) {
    function loadConstants() {
      const context = __webpack_require__(87);
      return context.keys().reduce((constants, key) => key.endsWith(__filename) ? constants : Object.assign(constants, context(key)), {});
    }
    module.exports = Object.assign(exports, loadConstants());
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "Component", (function() {
    return preact_module["a"];
  }));
  __webpack_require__.d(__webpack_exports__, "Fragment", (function() {
    return preact_module["b"];
  }));
  __webpack_require__.d(__webpack_exports__, "createContext", (function() {
    return preact_module["d"];
  }));
  __webpack_require__.d(__webpack_exports__, "createElement", (function() {
    return preact_module["e"];
  }));
  __webpack_require__.d(__webpack_exports__, "createRef", (function() {
    return preact_module["f"];
  }));
  __webpack_require__.d(__webpack_exports__, "useCallback", (function() {
    return q;
  }));
  __webpack_require__.d(__webpack_exports__, "useContext", (function() {
    return x;
  }));
  __webpack_require__.d(__webpack_exports__, "useDebugValue", (function() {
    return P;
  }));
  __webpack_require__.d(__webpack_exports__, "useEffect", (function() {
    return y;
  }));
  __webpack_require__.d(__webpack_exports__, "useErrorBoundary", (function() {
    return b;
  }));
  __webpack_require__.d(__webpack_exports__, "useId", (function() {
    return g;
  }));
  __webpack_require__.d(__webpack_exports__, "useImperativeHandle", (function() {
    return F;
  }));
  __webpack_require__.d(__webpack_exports__, "useLayoutEffect", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "useMemo", (function() {
    return T;
  }));
  __webpack_require__.d(__webpack_exports__, "useReducer", (function() {
    return h;
  }));
  __webpack_require__.d(__webpack_exports__, "useRef", (function() {
    return A;
  }));
  __webpack_require__.d(__webpack_exports__, "useState", (function() {
    return d;
  }));
  __webpack_require__.d(__webpack_exports__, "Children", (function() {
    return O;
  }));
  __webpack_require__.d(__webpack_exports__, "PureComponent", (function() {
    return N;
  }));
  __webpack_require__.d(__webpack_exports__, "StrictMode", (function() {
    return Cn;
  }));
  __webpack_require__.d(__webpack_exports__, "Suspense", (function() {
    return compat_module_P;
  }));
  __webpack_require__.d(__webpack_exports__, "SuspenseList", (function() {
    return compat_module_B;
  }));
  __webpack_require__.d(__webpack_exports__, "__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED", (function() {
    return hn;
  }));
  __webpack_require__.d(__webpack_exports__, "cloneElement", (function() {
    return _n;
  }));
  __webpack_require__.d(__webpack_exports__, "createFactory", (function() {
    return dn;
  }));
  __webpack_require__.d(__webpack_exports__, "createPortal", (function() {
    return $;
  }));
  __webpack_require__.d(__webpack_exports__, "default", (function() {
    return Rn;
  }));
  __webpack_require__.d(__webpack_exports__, "findDOMNode", (function() {
    return Sn;
  }));
  __webpack_require__.d(__webpack_exports__, "flushSync", (function() {
    return En;
  }));
  __webpack_require__.d(__webpack_exports__, "forwardRef", (function() {
    return compat_module_D;
  }));
  __webpack_require__.d(__webpack_exports__, "hydrate", (function() {
    return tn;
  }));
  __webpack_require__.d(__webpack_exports__, "isElement", (function() {
    return xn;
  }));
  __webpack_require__.d(__webpack_exports__, "isFragment", (function() {
    return pn;
  }));
  __webpack_require__.d(__webpack_exports__, "isMemo", (function() {
    return yn;
  }));
  __webpack_require__.d(__webpack_exports__, "isValidElement", (function() {
    return mn;
  }));
  __webpack_require__.d(__webpack_exports__, "lazy", (function() {
    return compat_module_z;
  }));
  __webpack_require__.d(__webpack_exports__, "memo", (function() {
    return M;
  }));
  __webpack_require__.d(__webpack_exports__, "render", (function() {
    return nn;
  }));
  __webpack_require__.d(__webpack_exports__, "startTransition", (function() {
    return R;
  }));
  __webpack_require__.d(__webpack_exports__, "unmountComponentAtNode", (function() {
    return bn;
  }));
  __webpack_require__.d(__webpack_exports__, "unstable_batchedUpdates", (function() {
    return gn;
  }));
  __webpack_require__.d(__webpack_exports__, "useDeferredValue", (function() {
    return compat_module_w;
  }));
  __webpack_require__.d(__webpack_exports__, "useInsertionEffect", (function() {
    return I;
  }));
  __webpack_require__.d(__webpack_exports__, "useSyncExternalStore", (function() {
    return compat_module_C;
  }));
  __webpack_require__.d(__webpack_exports__, "useTransition", (function() {
    return compat_module_k;
  }));
  __webpack_require__.d(__webpack_exports__, "version", (function() {
    return vn;
  }));
  var preact_module = __webpack_require__(1);
  var hooks_module_t, hooks_module_r, hooks_module_u, hooks_module_i, hooks_module_o = 0, f = [], hooks_module_c = preact_module["i"], hooks_module_e = hooks_module_c.__b, a = hooks_module_c.__r, v = hooks_module_c.diffed, hooks_module_l = hooks_module_c.__c, m = hooks_module_c.unmount, s = hooks_module_c.__;
  function p(n, t) {
    hooks_module_c.__h && hooks_module_c.__h(hooks_module_r, n, hooks_module_o || t), 
    hooks_module_o = 0;
    var u = hooks_module_r.__H || (hooks_module_r.__H = {
      __: [],
      __h: []
    });
    return n >= u.__.length && u.__.push({}), u.__[n];
  }
  function d(n) {
    return hooks_module_o = 1, h(D, n);
  }
  function h(n, u, i) {
    var o = p(hooks_module_t++, 2);
    if (o.t = n, !o.__c && (o.__ = [ i ? i(u) : D(void 0, u), function(n) {
      var t = o.__N ? o.__N[0] : o.__[0], r = o.t(t, n);
      t !== r && (o.__N = [ r, o.__[1] ], o.__c.setState({}));
    } ], o.__c = hooks_module_r, !hooks_module_r.__f)) {
      var f = function(n, t, r) {
        if (!o.__c.__H) return !0;
        var u = o.__c.__H.__.filter((function(n) {
          return !!n.__c;
        }));
        if (u.every((function(n) {
          return !n.__N;
        }))) return !c || c.call(this, n, t, r);
        var i = o.__c.props !== n;
        return u.forEach((function(n) {
          if (n.__N) {
            var t = n.__[0];
            n.__ = n.__N, n.__N = void 0, t !== n.__[0] && (i = !0);
          }
        })), c && c.call(this, n, t, r) || i;
      };
      hooks_module_r.__f = !0;
      var c = hooks_module_r.shouldComponentUpdate, e = hooks_module_r.componentWillUpdate;
      hooks_module_r.componentWillUpdate = function(n, t, r) {
        if (this.__e) {
          var u = c;
          c = void 0, f(n, t, r), c = u;
        }
        e && e.call(this, n, t, r);
      }, hooks_module_r.shouldComponentUpdate = f;
    }
    return o.__N || o.__;
  }
  function y(n, u) {
    var i = p(hooks_module_t++, 3);
    !hooks_module_c.__s && C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__H.__h.push(i));
  }
  function _(n, u) {
    var i = p(hooks_module_t++, 4);
    !hooks_module_c.__s && C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__h.push(i));
  }
  function A(n) {
    return hooks_module_o = 5, T((function() {
      return {
        current: n
      };
    }), []);
  }
  function F(n, t, r) {
    hooks_module_o = 6, _((function() {
      if ("function" == typeof n) {
        var r = n(t());
        return function() {
          n(null), r && "function" == typeof r && r();
        };
      }
      if (n) return n.current = t(), function() {
        return n.current = null;
      };
    }), null == r ? r : r.concat(n));
  }
  function T(n, r) {
    var u = p(hooks_module_t++, 7);
    return C(u.__H, r) && (u.__ = n(), u.__H = r, u.__h = n), u.__;
  }
  function q(n, t) {
    return hooks_module_o = 8, T((function() {
      return n;
    }), t);
  }
  function x(n) {
    var u = hooks_module_r.context[n.__c], i = p(hooks_module_t++, 9);
    return i.c = n, u ? (null == i.__ && (i.__ = !0, u.sub(hooks_module_r)), u.props.value) : n.__;
  }
  function P(n, t) {
    hooks_module_c.useDebugValue && hooks_module_c.useDebugValue(t ? t(n) : n);
  }
  function b(n) {
    var u = p(hooks_module_t++, 10), i = d();
    return u.__ = n, hooks_module_r.componentDidCatch || (hooks_module_r.componentDidCatch = function(n, t) {
      u.__ && u.__(n, t), i[1](n);
    }), [ i[0], function() {
      i[1](void 0);
    } ];
  }
  function g() {
    var n = p(hooks_module_t++, 11);
    if (!n.__) {
      for (var u = hooks_module_r.__v; null !== u && !u.__m && null !== u.__; ) u = u.__;
      var i = u.__m || (u.__m = [ 0, 0 ]);
      n.__ = "P" + i[0] + "-" + i[1]++;
    }
    return n.__;
  }
  function j() {
    for (var n; n = f.shift(); ) if (n.__P && n.__H) try {
      n.__H.__h.forEach(z), n.__H.__h.forEach(B), n.__H.__h = [];
    } catch (t) {
      n.__H.__h = [], hooks_module_c.__e(t, n.__v);
    }
  }
  hooks_module_c.__b = function(n) {
    hooks_module_r = null, hooks_module_e && hooks_module_e(n);
  }, hooks_module_c.__ = function(n, t) {
    n && t.__k && t.__k.__m && (n.__m = t.__k.__m), s && s(n, t);
  }, hooks_module_c.__r = function(n) {
    a && a(n), hooks_module_t = 0;
    var i = (hooks_module_r = n.__c).__H;
    i && (hooks_module_u === hooks_module_r ? (i.__h = [], hooks_module_r.__h = [], 
    i.__.forEach((function(n) {
      n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
    }))) : (i.__h.forEach(z), i.__h.forEach(B), i.__h = [], hooks_module_t = 0)), hooks_module_u = hooks_module_r;
  }, hooks_module_c.diffed = function(n) {
    v && v(n);
    var t = n.__c;
    t && t.__H && (t.__H.__h.length && (1 !== f.push(t) && hooks_module_i === hooks_module_c.requestAnimationFrame || ((hooks_module_i = hooks_module_c.requestAnimationFrame) || w)(j)), 
    t.__H.__.forEach((function(n) {
      n.u && (n.__H = n.u), n.u = void 0;
    }))), hooks_module_u = hooks_module_r = null;
  }, hooks_module_c.__c = function(n, t) {
    t.some((function(n) {
      try {
        n.__h.forEach(z), n.__h = n.__h.filter((function(n) {
          return !n.__ || B(n);
        }));
      } catch (r) {
        t.some((function(n) {
          n.__h && (n.__h = []);
        })), t = [], hooks_module_c.__e(r, n.__v);
      }
    })), hooks_module_l && hooks_module_l(n, t);
  }, hooks_module_c.unmount = function(n) {
    m && m(n);
    var t, r = n.__c;
    r && r.__H && (r.__H.__.forEach((function(n) {
      try {
        z(n);
      } catch (n) {
        t = n;
      }
    })), r.__H = void 0, t && hooks_module_c.__e(t, r.__v));
  };
  var k = "function" == typeof requestAnimationFrame;
  function w(n) {
    var t, r = function() {
      clearTimeout(u), k && cancelAnimationFrame(t), setTimeout(n);
    }, u = setTimeout(r, 35);
    k && (t = requestAnimationFrame(r));
  }
  function z(n) {
    var t = hooks_module_r, u = n.__c;
    "function" == typeof u && (n.__c = void 0, u()), hooks_module_r = t;
  }
  function B(n) {
    var t = hooks_module_r;
    n.__c = n.__(), hooks_module_r = t;
  }
  function C(n, t) {
    return !n || n.length !== t.length || t.some((function(t, r) {
      return t !== n[r];
    }));
  }
  function D(n, t) {
    return "function" == typeof t ? t(n) : t;
  }
  function compat_module_g(n, t) {
    for (var e in t) n[e] = t[e];
    return n;
  }
  function E(n, t) {
    for (var e in n) if ("__source" !== e && !(e in t)) return !0;
    for (var r in t) if ("__source" !== r && n[r] !== t[r]) return !0;
    return !1;
  }
  function compat_module_C(n, t) {
    var e = t(), r = d({
      t: {
        __: e,
        u: t
      }
    }), u = r[0].t, o = r[1];
    return _((function() {
      u.__ = e, u.u = t, compat_module_x(u) && o({
        t: u
      });
    }), [ n, e, t ]), y((function() {
      return compat_module_x(u) && o({
        t: u
      }), n((function() {
        compat_module_x(u) && o({
          t: u
        });
      }));
    }), [ n ]), e;
  }
  function compat_module_x(n) {
    var t, e, r = n.u, u = n.__;
    try {
      var o = r();
      return !((t = u) === (e = o) && (0 !== t || 1 / t == 1 / e) || t != t && e != e);
    } catch (n) {
      return !0;
    }
  }
  function R(n) {
    n();
  }
  function compat_module_w(n) {
    return n;
  }
  function compat_module_k() {
    return [ !1, R ];
  }
  var I = _;
  function N(n, t) {
    this.props = n, this.context = t;
  }
  function M(n, e) {
    function r(n) {
      var t = this.props.ref, r = t == n.ref;
      return !r && t && (t.call ? t(null) : t.current = null), e ? !e(this.props, n) || !r : E(this.props, n);
    }
    function u(e) {
      return this.shouldComponentUpdate = r, Object(preact_module["e"])(n, e);
    }
    return u.displayName = "Memo(" + (n.displayName || n.name) + ")", u.prototype.isReactComponent = !0, 
    u.__f = !0, u.type = n, u;
  }
  (N.prototype = new preact_module["a"]).isPureReactComponent = !0, N.prototype.shouldComponentUpdate = function(n, t) {
    return E(this.props, n) || E(this.state, t);
  };
  var compat_module_T = preact_module["i"].__b;
  preact_module["i"].__b = function(n) {
    n.type && n.type.__f && n.ref && (n.props.ref = n.ref, n.ref = null), compat_module_T && compat_module_T(n);
  };
  var compat_module_A = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
  function compat_module_D(n) {
    function t(t) {
      var e = compat_module_g({}, t);
      return delete e.ref, n(e, t.ref || null);
    }
    return t.$$typeof = compat_module_A, t.render = n, t.prototype.isReactComponent = t.__f = !0, 
    t.displayName = "ForwardRef(" + (n.displayName || n.name) + ")", t;
  }
  var L = function(n, t) {
    return null == n ? null : Object(preact_module["k"])(Object(preact_module["k"])(n).map(t));
  }, O = {
    map: L,
    forEach: L,
    count: function(n) {
      return n ? Object(preact_module["k"])(n).length : 0;
    },
    only: function(n) {
      var t = Object(preact_module["k"])(n);
      if (1 !== t.length) throw "Children.only";
      return t[0];
    },
    toArray: preact_module["k"]
  }, compat_module_F = preact_module["i"].__e;
  preact_module["i"].__e = function(n, t, e, r) {
    if (n.then) for (var u, o = t; o = o.__; ) if ((u = o.__c) && u.__c) return null == t.__e && (t.__e = e.__e, 
    t.__k = e.__k), u.__c(n, t);
    compat_module_F(n, t, e, r);
  };
  var U = preact_module["i"].unmount;
  function V(n, t, e) {
    return n && (n.__c && n.__c.__H && (n.__c.__H.__.forEach((function(n) {
      "function" == typeof n.__c && n.__c();
    })), n.__c.__H = null), null != (n = compat_module_g({}, n)).__c && (n.__c.__P === e && (n.__c.__P = t), 
    n.__c.__e = !0, n.__c = null), n.__k = n.__k && n.__k.map((function(n) {
      return V(n, t, e);
    }))), n;
  }
  function W(n, t, e) {
    return n && e && (n.__v = null, n.__k = n.__k && n.__k.map((function(n) {
      return W(n, t, e);
    })), n.__c && n.__c.__P === t && (n.__e && e.appendChild(n.__e), n.__c.__e = !0, 
    n.__c.__P = e)), n;
  }
  function compat_module_P() {
    this.__u = 0, this.o = null, this.__b = null;
  }
  function compat_module_j(n) {
    var t = n.__.__c;
    return t && t.__a && t.__a(n);
  }
  function compat_module_z(n) {
    var e, r, u;
    function o(o) {
      if (e || (e = n()).then((function(n) {
        r = n.default || n;
      }), (function(n) {
        u = n;
      })), u) throw u;
      if (!r) throw e;
      return Object(preact_module["e"])(r, o);
    }
    return o.displayName = "Lazy", o.__f = !0, o;
  }
  function compat_module_B() {
    this.i = null, this.l = null;
  }
  preact_module["i"].unmount = function(n) {
    var t = n.__c;
    t && t.__R && t.__R(), t && 32 & n.__u && (n.type = null), U && U(n);
  }, (compat_module_P.prototype = new preact_module["a"]).__c = function(n, t) {
    var e = t.__c, r = this;
    null == r.o && (r.o = []), r.o.push(e);
    var u = compat_module_j(r.__v), o = !1, i = function() {
      o || (o = !0, e.__R = null, u ? u(l) : l());
    };
    e.__R = i;
    var l = function() {
      if (!--r.__u) {
        if (r.state.__a) {
          var n = r.state.__a;
          r.__v.__k[0] = W(n, n.__c.__P, n.__c.__O);
        }
        var t;
        for (r.setState({
          __a: r.__b = null
        }); t = r.o.pop(); ) t.forceUpdate();
      }
    };
    r.__u++ || 32 & t.__u || r.setState({
      __a: r.__b = r.__v.__k[0]
    }), n.then(i, i);
  }, compat_module_P.prototype.componentWillUnmount = function() {
    this.o = [];
  }, compat_module_P.prototype.render = function(n, e) {
    if (this.__b) {
      if (this.__v.__k) {
        var r = document.createElement("div"), o = this.__v.__k[0].__c;
        this.__v.__k[0] = V(this.__b, r, o.__O = o.__P);
      }
      this.__b = null;
    }
    var i = e.__a && Object(preact_module["e"])(preact_module["b"], null, n.fallback);
    return i && (i.__u &= -33), [ Object(preact_module["e"])(preact_module["b"], null, e.__a ? null : n.children), i ];
  };
  var H = function(n, t, e) {
    if (++e[1] === e[0] && n.l.delete(t), n.props.revealOrder && ("t" !== n.props.revealOrder[0] || !n.l.size)) for (e = n.i; e; ) {
      for (;e.length > 3; ) e.pop()();
      if (e[1] < e[0]) break;
      n.i = e = e[2];
    }
  };
  function Z(n) {
    return this.getChildContext = function() {
      return n.context;
    }, n.children;
  }
  function Y(n) {
    var e = this, r = n.h;
    if (e.componentWillUnmount = function() {
      Object(preact_module["j"])(null, e.v), e.v = null, e.h = null;
    }, e.h && e.h !== r && e.componentWillUnmount(), !e.v) {
      for (var u = e.__v; null !== u && !u.__m && null !== u.__; ) u = u.__;
      e.h = r, e.v = {
        nodeType: 1,
        parentNode: r,
        childNodes: [],
        __k: {
          __m: u.__m
        },
        contains: function() {
          return !0;
        },
        insertBefore: function(n, t) {
          this.childNodes.push(n), e.h.insertBefore(n, t);
        },
        removeChild: function(n) {
          this.childNodes.splice(this.childNodes.indexOf(n) >>> 1, 1), e.h.removeChild(n);
        }
      };
    }
    Object(preact_module["j"])(Object(preact_module["e"])(Z, {
      context: e.context
    }, n.__v), e.v);
  }
  function $(n, e) {
    var r = Object(preact_module["e"])(Y, {
      __v: n,
      h: e
    });
    return r.containerInfo = e, r;
  }
  (compat_module_B.prototype = new preact_module["a"]).__a = function(n) {
    var t = this, e = compat_module_j(t.__v), r = t.l.get(n);
    return r[0]++, function(u) {
      var o = function() {
        t.props.revealOrder ? (r.push(u), H(t, n, r)) : u();
      };
      e ? e(o) : o();
    };
  }, compat_module_B.prototype.render = function(n) {
    this.i = null, this.l = new Map;
    var t = Object(preact_module["k"])(n.children);
    n.revealOrder && "b" === n.revealOrder[0] && t.reverse();
    for (var e = t.length; e--; ) this.l.set(t[e], this.i = [ 1, 0, this.i ]);
    return n.children;
  }, compat_module_B.prototype.componentDidUpdate = compat_module_B.prototype.componentDidMount = function() {
    var n = this;
    this.l.forEach((function(t, e) {
      H(n, e, t);
    }));
  };
  var compat_module_q = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103, G = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, J = /^on(Ani|Tra|Tou|BeforeInp|Compo)/, K = /[A-Z0-9]/g, Q = "undefined" != typeof document, X = function(n) {
    return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(n);
  };
  function nn(n, t, e) {
    return null == t.__k && (t.textContent = ""), Object(preact_module["j"])(n, t), 
    "function" == typeof e && e(), n ? n.__c : null;
  }
  function tn(n, t, e) {
    return Object(preact_module["h"])(n, t), "function" == typeof e && e(), n ? n.__c : null;
  }
  preact_module["a"].prototype.isReactComponent = {}, [ "componentWillMount", "componentWillReceiveProps", "componentWillUpdate" ].forEach((function(t) {
    Object.defineProperty(preact_module["a"].prototype, t, {
      configurable: !0,
      get: function() {
        return this["UNSAFE_" + t];
      },
      set: function(n) {
        Object.defineProperty(this, t, {
          configurable: !0,
          writable: !0,
          value: n
        });
      }
    });
  }));
  var en = preact_module["i"].event;
  function rn() {}
  function un() {
    return this.cancelBubble;
  }
  function on() {
    return this.defaultPrevented;
  }
  preact_module["i"].event = function(n) {
    return en && (n = en(n)), n.persist = rn, n.isPropagationStopped = un, n.isDefaultPrevented = on, 
    n.nativeEvent = n;
  };
  var ln, cn = {
    enumerable: !1,
    configurable: !0,
    get: function() {
      return this.class;
    }
  }, fn = preact_module["i"].vnode;
  preact_module["i"].vnode = function(n) {
    "string" == typeof n.type && function(n) {
      var t = n.props, e = n.type, u = {}, o = -1 === e.indexOf("-");
      for (var i in t) {
        var l = t[i];
        if (!("value" === i && "defaultValue" in t && null == l || Q && "children" === i && "noscript" === e || "class" === i || "className" === i)) {
          var c = i.toLowerCase();
          "defaultValue" === i && "value" in t && null == t.value ? i = "value" : "download" === i && !0 === l ? l = "" : "translate" === c && "no" === l ? l = !1 : "o" === c[0] && "n" === c[1] ? "ondoubleclick" === c ? i = "ondblclick" : "onchange" !== c || "input" !== e && "textarea" !== e || X(t.type) ? "onfocus" === c ? i = "onfocusin" : "onblur" === c ? i = "onfocusout" : J.test(i) && (i = c) : c = i = "oninput" : o && G.test(i) ? i = i.replace(K, "-$&").toLowerCase() : null === l && (l = void 0), 
          "oninput" === c && u[i = c] && (i = "oninputCapture"), u[i] = l;
        }
      }
      "select" == e && u.multiple && Array.isArray(u.value) && (u.value = Object(preact_module["k"])(t.children).forEach((function(n) {
        n.props.selected = -1 != u.value.indexOf(n.props.value);
      }))), "select" == e && null != u.defaultValue && (u.value = Object(preact_module["k"])(t.children).forEach((function(n) {
        n.props.selected = u.multiple ? -1 != u.defaultValue.indexOf(n.props.value) : u.defaultValue == n.props.value;
      }))), t.class && !t.className ? (u.class = t.class, Object.defineProperty(u, "className", cn)) : (t.className && !t.class || t.class && t.className) && (u.class = u.className = t.className), 
      n.props = u;
    }(n), n.$$typeof = compat_module_q, fn && fn(n);
  };
  var an = preact_module["i"].__r;
  preact_module["i"].__r = function(n) {
    an && an(n), ln = n.__c;
  };
  var sn = preact_module["i"].diffed;
  preact_module["i"].diffed = function(n) {
    sn && sn(n);
    var t = n.props, e = n.__e;
    null != e && "textarea" === n.type && "value" in t && t.value !== e.value && (e.value = null == t.value ? "" : t.value), 
    ln = null;
  };
  var hn = {
    ReactCurrentDispatcher: {
      current: {
        readContext: function(n) {
          return ln.__n[n.__c].props.value;
        },
        useCallback: q,
        useContext: x,
        useDebugValue: P,
        useDeferredValue: compat_module_w,
        useEffect: y,
        useId: g,
        useImperativeHandle: F,
        useInsertionEffect: I,
        useLayoutEffect: _,
        useMemo: T,
        useReducer: h,
        useRef: A,
        useState: d,
        useSyncExternalStore: compat_module_C,
        useTransition: compat_module_k
      }
    }
  }, vn = "18.3.1";
  function dn(n) {
    return preact_module["e"].bind(null, n);
  }
  function mn(n) {
    return !!n && n.$$typeof === compat_module_q;
  }
  function pn(n) {
    return mn(n) && n.type === preact_module["b"];
  }
  function yn(n) {
    return !!n && !!n.displayName && ("string" == typeof n.displayName || n.displayName instanceof String) && n.displayName.startsWith("Memo(");
  }
  function _n(n) {
    return mn(n) ? preact_module["c"].apply(null, arguments) : n;
  }
  function bn(n) {
    return !!n.__k && (Object(preact_module["j"])(null, n), !0);
  }
  function Sn(n) {
    return n && (n.base || 1 === n.nodeType && n) || null;
  }
  var gn = function(n, t) {
    return n(t);
  }, En = function(n, t) {
    return n(t);
  }, Cn = preact_module["b"], xn = mn, Rn = {
    useState: d,
    useId: g,
    useReducer: h,
    useEffect: y,
    useLayoutEffect: _,
    useInsertionEffect: I,
    useTransition: compat_module_k,
    useDeferredValue: compat_module_w,
    useSyncExternalStore: compat_module_C,
    startTransition: R,
    useRef: A,
    useImperativeHandle: F,
    useMemo: T,
    useCallback: q,
    useContext: x,
    useDebugValue: P,
    version: "18.3.1",
    Children: O,
    render: nn,
    hydrate: tn,
    unmountComponentAtNode: bn,
    createPortal: $,
    createElement: preact_module["e"],
    createContext: preact_module["d"],
    createFactory: dn,
    cloneElement: _n,
    createRef: preact_module["f"],
    Fragment: preact_module["b"],
    isValidElement: mn,
    isElement: xn,
    isFragment: pn,
    isMemo: yn,
    findDOMNode: Sn,
    Component: preact_module["a"],
    PureComponent: N,
    memo: M,
    forwardRef: compat_module_D,
    flushSync: En,
    unstable_batchedUpdates: gn,
    StrictMode: Cn,
    Suspense: compat_module_P,
    SuspenseList: compat_module_B,
    lazy: compat_module_z,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: hn
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const svgTagNames = __webpack_require__(83);
  const flatten = __webpack_require__(84);
  const IS_NON_DIMENSIONAL = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
  const excludeSvgTags = [ "a", "audio", "canvas", "iframe", "script", "video" ];
  const svgTags = svgTagNames.filter(name => !excludeSvgTags.includes(name));
  const isSVG = tagName => svgTags.includes(tagName);
  const setCSSProps = (el, style) => {
    Object.keys(style).forEach(name => {
      let value = style[name];
      if ("number" === typeof value && !IS_NON_DIMENSIONAL.test(name)) value += "px";
      el.style[name] = value;
    });
  };
  const createElement = tagName => {
    if (isSVG(tagName)) return document.createElementNS("http://www.w3.org/2000/svg", tagName);
    if (tagName === DocumentFragment) return document.createDocumentFragment();
    return document.createElement(tagName);
  };
  const setAttribute = (el, name, value) => {
    if (void 0 === value || null === value) return;
    if (/^xlink[AHRST]/.test(name)) el.setAttributeNS("http://www.w3.org/1999/xlink", name.replace("xlink", "xlink:").toLowerCase(), value); else el.setAttribute(name, value);
  };
  const build = (tagName, attrs, children) => {
    const el = createElement(tagName);
    Object.keys(attrs).forEach(name => {
      const value = attrs[name];
      if ("class" === name || "className" === name) setAttribute(el, "class", value); else if ("style" === name) setCSSProps(el, value); else if (0 === name.indexOf("on")) {
        const eventName = name.slice(2).toLowerCase();
        el.addEventListener(eventName, value);
      } else if ("dangerouslySetInnerHTML" === name) el.innerHTML = value.__html; else if ("key" !== name && false !== value) setAttribute(el, name, true === value ? "" : value);
    });
    if (!attrs.dangerouslySetInnerHTML) el.appendChild(children);
    return el;
  };
  function h(tagName, attrs) {
    const childrenArgs = [].slice.apply(arguments, [ 2 ]);
    const children = document.createDocumentFragment();
    flatten(childrenArgs).forEach(child => {
      if (child instanceof Node) children.appendChild(child); else if ("boolean" !== typeof child && "undefined" !== typeof child && null !== child) children.appendChild(document.createTextNode(child));
    });
    return build(tagName, attrs || {}, children);
  }
  const React = {
    createElement: h,
    Fragment: "function" === typeof DocumentFragment ? DocumentFragment : () => {}
  };
  module.exports = React;
  module.exports.h = h;
  module.exports.default = React;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const ManyKeysMap = __webpack_require__(81);
  const pDefer = __webpack_require__(82);
  const cache = new ManyKeysMap;
  const isDomReady = () => "interactive" === document.readyState || "complete" === document.readyState;
  const elementReady = (selector, {target = document, stopOnDomReady = true, timeout = 1 / 0} = {}) => {
    const cacheKeys = [ target, selector, stopOnDomReady, timeout ];
    const cachedPromise = cache.get(cacheKeys);
    if (cachedPromise) return cachedPromise;
    let rafId;
    const deferred = pDefer();
    const {promise} = deferred;
    cache.set(cacheKeys, promise);
    const stop = () => {
      cancelAnimationFrame(rafId);
      cache.delete(cacheKeys, promise);
      deferred.resolve();
    };
    if (timeout !== 1 / 0) setTimeout(stop, timeout);
    (function check() {
      const element = target.querySelector(selector);
      if (element) {
        deferred.resolve(element);
        stop();
      } else if (stopOnDomReady && isDomReady()) stop(); else rafId = requestAnimationFrame(check);
    })();
    return Object.assign(promise, {
      stop
    });
  };
  module.exports = elementReady;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var is_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27);
  var is_promise__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(is_promise__WEBPACK_IMPORTED_MODULE_0__);
  __webpack_exports__["a"] = iterable => new Promise(resolve => {
    const total = iterable.length;
    let count = 0;
    let done = false;
    if (0 === total) return resolve(true);
    function check(value) {
      if (!value) return fail();
      if (++count === total) {
        done = true;
        resolve(true);
      }
    }
    function fail() {
      done = true;
      resolve(false);
    }
    for (const item of iterable) {
      if (done) return;
      if (is_promise__WEBPACK_IMPORTED_MODULE_0___default()(item)) item.then(check, fail); else check(item);
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var is_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(27);
  var is_promise__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(is_promise__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(30);
  var _libs_noop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(21);
  function toBooleanPromise(x) {
    return "boolean" === typeof x ? x : is_promise__WEBPACK_IMPORTED_MODULE_0___default()(x) ? x.then(toBooleanPromise) : Promise.resolve(true);
  }
  __webpack_exports__["a"] = module => {
    let promise;
    const {install = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], uninstall = _libs_noop__WEBPACK_IMPORTED_MODULE_2__["a"], ...rest} = module;
    _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_1__["a"].addListener(uninstall);
    return {
      ...rest,
      ready() {
        return promise || (promise = toBooleanPromise(install()));
      }
    };
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _libs_Deferred__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13);
  var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3);
  let id = 0;
  const deferreds = {};
  const broadcastListeners = [];
  function eventHandler(event) {
    const {type, from, senderId, message} = event.detail;
    if (type === _constants__WEBPACK_IMPORTED_MODULE_5__["BROADCASTING_MESSAGE"]) bridge.broadcast(message); else if ("background" === from) {
      const d = deferreds[senderId];
      d.resolve(message);
      delete deferreds[senderId];
    }
  }
  const bridge = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      window.addEventListener(_constants__WEBPACK_IMPORTED_MODULE_5__["BRIDGE_EVENT_TYPE"], eventHandler);
    },
    uninstall() {
      window.removeEventListener(_constants__WEBPACK_IMPORTED_MODULE_5__["BRIDGE_EVENT_TYPE"], eventHandler);
    },
    registerBroadcastListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__["a"])(broadcastListeners, fn);
    },
    unregisterBroadcastListener(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__["a"])(broadcastListeners, fn);
    },
    broadcast(message) {
      Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_0__["a"])({
        fns: broadcastListeners,
        args: [ message ]
      });
    },
    postMessage(message) {
      const senderId = id++;
      const d = deferreds[senderId] = new _libs_Deferred__WEBPACK_IMPORTED_MODULE_2__["a"];
      const event = new CustomEvent(_constants__WEBPACK_IMPORTED_MODULE_5__["BRIDGE_EVENT_TYPE"], {
        detail: {
          from: "page",
          senderId,
          message
        }
      });
      window.dispatchEvent(event);
      return d.promise;
    }
  });
  __webpack_exports__["a"] = bridge;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return functionOnce;
  }));
  var functionOnce = once;
  function once(fn) {
    var called, value;
    if ("function" !== typeof fn) throw new Error("expected a function but got " + fn);
    return function() {
      if (called) return value;
      called = true;
      value = fn.apply(this, arguments);
      fn = void 0;
      return value;
    };
  }
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(useSourceMap) {
    var list = [];
    list.toString = function() {
      return this.map((function(item) {
        var content = cssWithMappingToString(item, useSourceMap);
        if (item[2]) return "@media ".concat(item[2], " {").concat(content, "}");
        return content;
      })).join("");
    };
    list.i = function(modules, mediaQuery, dedupe) {
      if ("string" === typeof modules) modules = [ [ null, modules, "" ] ];
      var alreadyImportedModules = {};
      if (dedupe) for (var i = 0; i < this.length; i++) {
        var id = this[i][0];
        if (null != id) alreadyImportedModules[id] = true;
      }
      for (var _i = 0; _i < modules.length; _i++) {
        var item = [].concat(modules[_i]);
        if (dedupe && alreadyImportedModules[item[0]]) continue;
        if (mediaQuery) if (!item[2]) item[2] = mediaQuery; else item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        list.push(item);
      }
    };
    return list;
  };
  function cssWithMappingToString(item, useSourceMap) {
    var content = item[1] || "";
    var cssMapping = item[3];
    if (!cssMapping) return content;
    if (useSourceMap && "function" === typeof btoa) {
      var sourceMapping = toComment(cssMapping);
      var sourceURLs = cssMapping.sources.map((function(source) {
        return "/*# sourceURL=".concat(cssMapping.sourceRoot || "").concat(source, " */");
      }));
      return [ content ].concat(sourceURLs).concat([ sourceMapping ]).join("\n");
    }
    return [ content ].join("\n");
  }
  function toComment(sourceMap) {
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    return "/*# ".concat(data, " */");
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  (function(global) {
    var __spreadArray = (void 0, function(to, from, pack) {
      if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
      return to.concat(ar || Array.prototype.slice.call(from));
    });
    var config = {
      defaults: {},
      errorType: null,
      polyfills: {
        fetch: null,
        FormData: null,
        URLSearchParams: null,
        performance: null,
        PerformanceObserver: null,
        AbortController: null
      },
      polyfill: function(p, _a) {
        var _b = void 0 === _a ? {} : _a, _c = _b.doThrow, doThrow = void 0 === _c ? true : _c, _d = _b.instance, instance = void 0 === _d ? false : _d;
        var args = [];
        for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
        var res = this.polyfills[p] || ("undefined" !== typeof self ? self[p] : null) || ("undefined" !== typeof global ? global[p] : null);
        if (doThrow && !res) throw new Error(p + " is not defined");
        return instance && res ? new (res.bind.apply(res, __spreadArray([ void 0 ], args, false))) : res;
      }
    };
    __webpack_exports__["a"] = config;
  }).call(this, __webpack_require__(85));
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    const index = array.indexOf(element);
    if (-1 !== index) array.splice(index, 1);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var __assign = (void 0, function() {
    __assign = Object.assign || function(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  });
  var __spreadArray = (void 0, function(to, from, pack) {
    if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  });
  var mix = function(one, two, mergeArrays) {
    if (void 0 === mergeArrays) mergeArrays = false;
    if (!one || !two || "object" !== typeof one || "object" !== typeof two) return one;
    var clone = __assign({}, one);
    for (var prop in two) if (two.hasOwnProperty(prop)) if (two[prop] instanceof Array && one[prop] instanceof Array) clone[prop] = mergeArrays ? __spreadArray(__spreadArray([], one[prop], true), two[prop], true) : two[prop]; else if ("object" === typeof two[prop] && "object" === typeof one[prop]) clone[prop] = mix(one[prop], two[prop], mergeArrays); else clone[prop] = two[prop];
    return clone;
  };
  var config = __webpack_require__(12);
  var onMatch = function(entries, name, callback, _performance) {
    if (!entries.getEntriesByName) return false;
    var matches = entries.getEntriesByName(name);
    if (matches && matches.length > 0) {
      callback(matches.reverse()[0]);
      if (_performance.clearMeasures) _performance.clearMeasures(name);
      perfs.callbacks.delete(name);
      if (perfs.callbacks.size < 1) {
        perfs.observer.disconnect();
        if (_performance.clearResourceTimings) _performance.clearResourceTimings();
      }
      return true;
    }
    return false;
  };
  var lazyObserver = function(_performance, _observer) {
    if (!perfs.observer && _performance && _observer) {
      perfs.observer = new _observer((function(entries) {
        perfs.callbacks.forEach((function(callback, name) {
          onMatch(entries, name, callback, _performance);
        }));
      }));
      if (_performance.clearResourceTimings) _performance.clearResourceTimings();
    }
    return perfs.observer;
  };
  var perfs = {
    callbacks: new Map,
    observer: null,
    observe: function(name, callback) {
      if (!name || !callback) return;
      var _performance = config["a"].polyfill("performance", {
        doThrow: false
      });
      var _observer = config["a"].polyfill("PerformanceObserver", {
        doThrow: false
      });
      if (!lazyObserver(_performance, _observer)) return;
      if (!onMatch(_performance, name, callback, _performance)) {
        if (perfs.callbacks.size < 1) perfs.observer.observe({
          entryTypes: [ "resource", "measure" ]
        });
        perfs.callbacks.set(name, callback);
      }
    }
  };
  var dist_perfs = perfs;
  var middlewareHelper = function(middlewares) {
    return function(fetchFunction) {
      return 0 === middlewares.length ? fetchFunction : 1 === middlewares.length ? middlewares[0](fetchFunction) : middlewares.reduceRight((function(acc, curr, idx) {
        return idx === middlewares.length - 2 ? curr(acc(fetchFunction)) : curr(acc);
      }));
    };
  };
  var WretchErrorWrapper = function() {
    function WretchErrorWrapper(error) {
      this.error = error;
    }
    return WretchErrorWrapper;
  }();
  var resolver = function(wretcher) {
    var url = wretcher._url, _catchers = wretcher._catchers, resolvers = wretcher._resolvers, middlewares = wretcher._middlewares, opts = wretcher._options;
    var catchers = new Map(_catchers);
    var finalOptions = mix(config["a"].defaults, opts);
    var fetchController = config["a"].polyfill("AbortController", {
      doThrow: false,
      instance: true
    });
    if (!finalOptions["signal"] && fetchController) finalOptions["signal"] = fetchController.signal;
    var timeout = {
      ref: null,
      clear: function() {
        if (timeout.ref) {
          clearTimeout(timeout.ref);
          timeout.ref = null;
        }
      }
    };
    var fetchRequest = middlewareHelper(middlewares)(config["a"].polyfill("fetch"))(url, finalOptions);
    var throwingPromise = fetchRequest.catch((function(error) {
      throw new WretchErrorWrapper(error);
    })).then((function(response) {
      timeout.clear();
      if (!response.ok) {
        if ("opaque" === response.type) {
          var err = new Error("Opaque response");
          err["status"] = response.status;
          err["response"] = response;
          throw err;
        }
        return response[config["a"].errorType || "text"]().then((function(msg) {
          var err = new Error(msg);
          err[config["a"].errorType || "text"] = msg;
          err["status"] = response.status;
          err["response"] = response;
          throw err;
        }));
      }
      return response;
    }));
    var catchersWrapper = function(promise) {
      return promise.catch((function(err) {
        timeout.clear();
        var error = err instanceof WretchErrorWrapper ? err.error : err;
        if (err instanceof WretchErrorWrapper && catchers.has("__fromFetch")) return catchers.get("__fromFetch")(error, wretcher); else if (catchers.has(error.status)) return catchers.get(error.status)(error, wretcher); else if (catchers.has(error.name)) return catchers.get(error.name)(error, wretcher); else throw error;
      }));
    };
    var bodyParser = function(funName) {
      return function(cb) {
        return funName ? catchersWrapper(throwingPromise.then((function(_) {
          return _ && _[funName]();
        })).then((function(_) {
          return cb ? cb(_) : _;
        }))) : catchersWrapper(throwingPromise.then((function(_) {
          return cb ? cb(_) : _;
        })));
      };
    };
    var responseChain = {
      res: bodyParser(null),
      json: bodyParser("json"),
      blob: bodyParser("blob"),
      formData: bodyParser("formData"),
      arrayBuffer: bodyParser("arrayBuffer"),
      text: bodyParser("text"),
      perfs: function(cb) {
        fetchRequest.then((function(res) {
          return dist_perfs.observe(res.url, cb);
        })).catch((function() {}));
        return responseChain;
      },
      setTimeout: function(time, controller) {
        if (void 0 === controller) controller = fetchController;
        timeout.clear();
        timeout.ref = setTimeout((function() {
          return controller.abort();
        }), time);
        return responseChain;
      },
      controller: function() {
        return [ fetchController, responseChain ];
      },
      error: function(errorId, cb) {
        catchers.set(errorId, cb);
        return responseChain;
      },
      badRequest: function(cb) {
        return responseChain.error(400, cb);
      },
      unauthorized: function(cb) {
        return responseChain.error(401, cb);
      },
      forbidden: function(cb) {
        return responseChain.error(403, cb);
      },
      notFound: function(cb) {
        return responseChain.error(404, cb);
      },
      timeout: function(cb) {
        return responseChain.error(408, cb);
      },
      internalError: function(cb) {
        return responseChain.error(500, cb);
      },
      fetchError: function(cb) {
        return responseChain.error("__fromFetch", cb);
      },
      onAbort: function(cb) {
        return responseChain.error("AbortError", cb);
      }
    };
    return resolvers.reduce((function(chain, r) {
      return r(chain, wretcher);
    }), responseChain);
  };
  var wretcher_assign = (void 0, function() {
    wretcher_assign = Object.assign || function(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return wretcher_assign.apply(this, arguments);
  });
  var wretcher_spreadArray = (void 0, function(to, from, pack) {
    if (pack || 2 === arguments.length) for (var ar, i = 0, l = from.length; i < l; i++) if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  });
  var JSON_MIME = "application/json";
  var CONTENT_TYPE_HEADER = "Content-Type";
  function extractContentType(headers) {
    var _a;
    if (void 0 === headers) headers = {};
    return null === (_a = Object.entries(headers).find((function(_a) {
      var k = _a[0];
      return k.toLowerCase() === CONTENT_TYPE_HEADER.toLowerCase();
    }))) || void 0 === _a ? void 0 : _a[1];
  }
  function isLikelyJsonMime(value) {
    return /^application\/.*json.*/.test(value);
  }
  var wretcher_Wretcher = function() {
    function Wretcher(_url, _options, _catchers, _resolvers, _middlewares, _deferredChain) {
      if (void 0 === _catchers) _catchers = new Map;
      if (void 0 === _resolvers) _resolvers = [];
      if (void 0 === _middlewares) _middlewares = [];
      if (void 0 === _deferredChain) _deferredChain = [];
      this._url = _url;
      this._options = _options;
      this._catchers = _catchers;
      this._resolvers = _resolvers;
      this._middlewares = _middlewares;
      this._deferredChain = _deferredChain;
    }
    Wretcher.factory = function(url, options) {
      if (void 0 === url) url = "";
      if (void 0 === options) options = {};
      return new Wretcher(url, options);
    };
    Wretcher.prototype.selfFactory = function(_a) {
      var _b = void 0 === _a ? {} : _a, _c = _b.url, url = void 0 === _c ? this._url : _c, _d = _b.options, options = void 0 === _d ? this._options : _d, _e = _b.catchers, catchers = void 0 === _e ? this._catchers : _e, _f = _b.resolvers, resolvers = void 0 === _f ? this._resolvers : _f, _g = _b.middlewares, middlewares = void 0 === _g ? this._middlewares : _g, _h = _b.deferredChain, deferredChain = void 0 === _h ? this._deferredChain : _h;
      return new Wretcher(url, wretcher_assign({}, options), new Map(catchers), wretcher_spreadArray([], resolvers, true), wretcher_spreadArray([], middlewares, true), wretcher_spreadArray([], deferredChain, true));
    };
    Wretcher.prototype.defaults = function(options, mixin) {
      if (void 0 === mixin) mixin = false;
      config["a"].defaults = mixin ? mix(config["a"].defaults, options) : options;
      return this;
    };
    Wretcher.prototype.errorType = function(method) {
      config["a"].errorType = method;
      return this;
    };
    Wretcher.prototype.polyfills = function(polyfills) {
      config["a"].polyfills = wretcher_assign(wretcher_assign({}, config["a"].polyfills), polyfills);
      return this;
    };
    Wretcher.prototype.url = function(url, replace) {
      if (void 0 === replace) replace = false;
      if (replace) return this.selfFactory({
        url
      });
      var split = this._url.split("?");
      return this.selfFactory({
        url: split.length > 1 ? split[0] + url + "?" + split[1] : this._url + url
      });
    };
    Wretcher.prototype.options = function(options, mixin) {
      if (void 0 === mixin) mixin = true;
      return this.selfFactory({
        options: mixin ? mix(this._options, options) : options
      });
    };
    Wretcher.prototype.query = function(qp, replace) {
      if (void 0 === replace) replace = false;
      return this.selfFactory({
        url: appendQueryParams(this._url, qp, replace)
      });
    };
    Wretcher.prototype.headers = function(headerValues) {
      return this.selfFactory({
        options: mix(this._options, {
          headers: headerValues || {}
        })
      });
    };
    Wretcher.prototype.accept = function(headerValue) {
      return this.headers({
        Accept: headerValue
      });
    };
    Wretcher.prototype.content = function(headerValue) {
      var _a;
      return this.headers((_a = {}, _a[CONTENT_TYPE_HEADER] = headerValue, _a));
    };
    Wretcher.prototype.auth = function(headerValue) {
      return this.headers({
        Authorization: headerValue
      });
    };
    Wretcher.prototype.catcher = function(errorId, catcher) {
      var newMap = new Map(this._catchers);
      newMap.set(errorId, catcher);
      return this.selfFactory({
        catchers: newMap
      });
    };
    Wretcher.prototype.signal = function(controller) {
      return this.selfFactory({
        options: wretcher_assign(wretcher_assign({}, this._options), {
          signal: controller.signal
        })
      });
    };
    Wretcher.prototype.resolve = function(doResolve, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        resolvers: clear ? [ doResolve ] : wretcher_spreadArray(wretcher_spreadArray([], this._resolvers, true), [ doResolve ], false)
      });
    };
    Wretcher.prototype.defer = function(callback, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        deferredChain: clear ? [ callback ] : wretcher_spreadArray(wretcher_spreadArray([], this._deferredChain, true), [ callback ], false)
      });
    };
    Wretcher.prototype.middlewares = function(middlewares, clear) {
      if (void 0 === clear) clear = false;
      return this.selfFactory({
        middlewares: clear ? middlewares : wretcher_spreadArray(wretcher_spreadArray([], this._middlewares, true), middlewares, true)
      });
    };
    Wretcher.prototype.method = function(method, options, body) {
      if (void 0 === options) options = {};
      if (void 0 === body) body = null;
      var base = this.options(wretcher_assign(wretcher_assign({}, options), {
        method
      }));
      var contentType = extractContentType(base._options.headers);
      var jsonify = "object" === typeof body && (!base._options.headers || !contentType || isLikelyJsonMime(contentType));
      base = !body ? base : jsonify ? base.json(body, contentType) : base.body(body);
      return resolver(base._deferredChain.reduce((function(acc, curr) {
        return curr(acc, acc._url, acc._options);
      }), base));
    };
    Wretcher.prototype.get = function(options) {
      return this.method("GET", options);
    };
    Wretcher.prototype.delete = function(options) {
      return this.method("DELETE", options);
    };
    Wretcher.prototype.put = function(body, options) {
      return this.method("PUT", options, body);
    };
    Wretcher.prototype.post = function(body, options) {
      return this.method("POST", options, body);
    };
    Wretcher.prototype.patch = function(body, options) {
      return this.method("PATCH", options, body);
    };
    Wretcher.prototype.head = function(options) {
      return this.method("HEAD", options);
    };
    Wretcher.prototype.opts = function(options) {
      return this.method("OPTIONS", options);
    };
    Wretcher.prototype.replay = function(options) {
      return this.method(this._options.method, options);
    };
    Wretcher.prototype.body = function(contents) {
      return this.selfFactory({
        options: wretcher_assign(wretcher_assign({}, this._options), {
          body: contents
        })
      });
    };
    Wretcher.prototype.json = function(jsObject, contentType) {
      var currentContentType = extractContentType(this._options.headers);
      return this.content(contentType || isLikelyJsonMime(currentContentType) && currentContentType || JSON_MIME).body(JSON.stringify(jsObject));
    };
    Wretcher.prototype.formData = function(formObject, recursive) {
      if (void 0 === recursive) recursive = false;
      return this.body(convertFormData(formObject, recursive));
    };
    Wretcher.prototype.formUrl = function(input) {
      return this.body("string" === typeof input ? input : convertFormUrl(input)).content("application/x-www-form-urlencoded");
    };
    return Wretcher;
  }();
  var appendQueryParams = function(url, qp, replace) {
    var queryString;
    if ("string" === typeof qp) queryString = qp; else {
      var usp = config["a"].polyfill("URLSearchParams", {
        instance: true
      });
      for (var key in qp) if (qp[key] instanceof Array) for (var _i = 0, _a = qp[key]; _i < _a.length; _i++) {
        var val = _a[_i];
        usp.append(key, val);
      } else usp.append(key, qp[key]);
      queryString = usp.toString();
    }
    var split = url.split("?");
    if (!queryString) return replace ? split[0] : url;
    if (replace || split.length < 2) return split[0] + "?" + queryString;
    return url + "&" + queryString;
  };
  function convertFormData(formObject, recursive, formData, ancestors) {
    if (void 0 === recursive) recursive = false;
    if (void 0 === formData) formData = config["a"].polyfill("FormData", {
      instance: true
    });
    if (void 0 === ancestors) ancestors = [];
    Object.entries(formObject).forEach((function(_a) {
      var key = _a[0], value = _a[1];
      var formKey = ancestors.reduce((function(acc, ancestor) {
        return acc ? "".concat(acc, "[").concat(ancestor, "]") : ancestor;
      }), null);
      formKey = formKey ? "".concat(formKey, "[").concat(key, "]") : key;
      if (value instanceof Array) for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
        var item = value_1[_i];
        formData.append(formKey + "[]", item);
      } else if (recursive && "object" === typeof value && (!(recursive instanceof Array) || !recursive.includes(key))) {
        if (null !== value) convertFormData(value, recursive, formData, wretcher_spreadArray(wretcher_spreadArray([], ancestors, true), [ key ], false));
      } else formData.append(formKey, value);
    }));
    return formData;
  }
  function encodeQueryValue(key, value) {
    return encodeURIComponent(key) + "=" + encodeURIComponent("object" === typeof value ? JSON.stringify(value) : "" + value);
  }
  function convertFormUrl(formObject) {
    return Object.keys(formObject).map((function(key) {
      var value = formObject[key];
      if (value instanceof Array) return value.map((function(v) {
        return encodeQueryValue(key, v);
      })).join("&");
      return encodeQueryValue(key, value);
    })).join("&");
  }
  var factory = wretcher_Wretcher.factory;
  factory["default"] = wretcher_Wretcher.factory;
  __webpack_exports__["a"] = factory;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, element) => {
    if (!array.includes(element)) array.push(element);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  let outputLevel = 1;
  if (true) outputLevel = 2;
  function log(level, logger, ...message) {
    if (level >= outputLevel) logger("[SpaceFanfou]", ...message);
  }
  __webpack_exports__["a"] = {
    debug(...message) {
      log(0, console.log, ...message);
    },
    info(...message) {
      log(1, console.log, ...message);
    },
    error(...message) {
      log(2, console.error, ...message);
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var dot_prop__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(39);
  var dot_prop__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(dot_prop__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_Deferred__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28);
  const CHECKING_INTERVAL = 16;
  const libs = new Map;
  const pending = new Set;
  let timer;
  function hasRequested(libName) {
    return libs.has(libName);
  }
  function request(libName) {
    libs.set(libName, new _libs_Deferred__WEBPACK_IMPORTED_MODULE_1__["a"]);
    pending.add(libName);
    setTimer();
  }
  function setTimer() {
    if (timer) return;
    timer = setInterval(check, CHECKING_INTERVAL);
  }
  function clearTimer() {
    if (!timer) return;
    clearInterval(timer);
    timer = null;
  }
  function check() {
    for (const libName of pending) {
      const lib = dot_prop__WEBPACK_IMPORTED_MODULE_0___default.a.get(window, libName);
      if ("undefined" !== typeof lib) {
        pending.delete(libName);
        libs.get(libName).resolve(lib);
      }
    }
    if (!pending.size) clearTimer();
  }
  function resolve(libName) {
    return libs.get(libName).promise;
  }
  __webpack_exports__["a"] = libName => {
    if (!hasRequested(libName)) request(libName);
    return resolve(libName);
  };
}, function(module, exports) {
  module.exports = pick;
  function pick(obj, select) {
    var result = {};
    if ("string" === typeof select) select = [].slice.call(arguments, 1);
    var len = select.length;
    for (var i = 0; i < len; i++) {
      var key = select[i];
      if (key in obj) result[key] = obj[key];
    }
    return result;
  }
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  /*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/  (function() {
    "use strict";
    var hasOwn = {}.hasOwnProperty;
    function classNames() {
      var classes = "";
      for (var i = 0; i < arguments.length; i++) {
        var arg = arguments[i];
        if (arg) classes = appendClass(classes, parseValue(arg));
      }
      return classes;
    }
    function parseValue(arg) {
      if ("string" === typeof arg || "number" === typeof arg) return arg;
      if ("object" !== typeof arg) return "";
      if (Array.isArray(arg)) return classNames.apply(null, arg);
      if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes("[native code]")) return arg.toString();
      var classes = "";
      for (var key in arg) if (hasOwn.call(arg, key) && arg[key]) classes = appendClass(classes, key);
      return classes;
    }
    function appendClass(value, newClass) {
      if (!newClass) return value;
      if (value) return value + " " + newClass;
      return value + newClass;
    }
    if (true, module.exports) {
      classNames.default = classNames;
      module.exports = classNames;
    } else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function() {
      return classNames;
    }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  })();
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var defined__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35);
  var defined__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(defined__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);
  function defaultExceptionHandler(error) {
    _libs_log__WEBPACK_IMPORTED_MODULE_1__["a"].error(error);
  }
  __webpack_exports__["a"] = opts => {
    let fn;
    if ("function" === typeof opts) {
      fn = opts;
      opts = {};
    } else fn = opts.fn;
    const exceptionHandler = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.exceptionHandler, defaultExceptionHandler);
    const args = defined__WEBPACK_IMPORTED_MODULE_0___default()(opts.args, []);
    try {
      fn(...args);
    } catch (error) {
      exceptionHandler(error);
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = () => {};
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20);
  var _libs_noop__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);
  function forever() {
    return false;
  }
  async function keepRetry(opts) {
    const {checker, executor = _libs_noop__WEBPACK_IMPORTED_MODULE_1__["a"], delay = 100, until = forever, resolve, reject} = opts;
    if (await checker()) {
      Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__["a"])(executor);
      resolve(true);
    } else if (until()) reject(); else setTimeout(keepRetry, delay, opts);
  }
  __webpack_exports__["a"] = opts => new Promise((resolve, reject) => {
    keepRetry({
      ...opts,
      resolve,
      reject
    });
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20);
  __webpack_exports__["a"] = opts => {
    if (Array.isArray(opts)) opts = {
      fns: opts
    };
    const {fns, ...restOpts} = opts;
    for (const fn of fns) Object(_libs_safelyInvokeFn__WEBPACK_IMPORTED_MODULE_0__["a"])({
      fn,
      ...restOpts
    });
  };
}, function(module, exports) {
  module.exports = function(ms) {
    return new Promise((function(resolve) {
      setTimeout(resolve, ms);
    }));
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var select_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  var just_once__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10);
  var _libs_findElementWithSpecifiedContentInArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(26);
  __webpack_exports__["a"] = Object(just_once__WEBPACK_IMPORTED_MODULE_1__["a"])(() => {
    const navLinks = select_dom__WEBPACK_IMPORTED_MODULE_0__["a"].all("#navigation li a");
    const profilePageLink = Object(_libs_findElementWithSpecifiedContentInArray__WEBPACK_IMPORTED_MODULE_2__["a"])(navLinks, "我的空间");
    return profilePageLink.href;
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = (array, search) => array.find(element => {
    if ("string" === typeof search) return element.textContent.trim() === search; else if (search instanceof RegExp) return search.test(element.textContent);
    throw new Error("search 必须为字符串或正则表达式");
  });
}, function(module, exports) {
  module.exports = isPromise;
  module.exports.default = isPromise;
  function isPromise(obj) {
    return !!obj && ("object" === typeof obj || "function" === typeof obj) && "function" === typeof obj.then;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return Deferred;
  }));
  class Deferred {
    constructor() {
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
      Object.freeze(this);
    }
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_exports__["a"] = html => {
    const parser = new DOMParser;
    const document = parser.parseFromString(html, "text/html");
    return document;
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3);
  __webpack_exports__["a"] = {
    trigger() {
      const event = new CustomEvent(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"]);
      window.dispatchEvent(event);
    },
    addListener(fn) {
      window.addEventListener(_constants__WEBPACK_IMPORTED_MODULE_0__["EXTENSION_UNLOADED_EVENT_TYPE"], fn, {
        once: true
      });
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var invariant = function(condition, format, a, b, c, d, e, f) {
    if (false) ;
    if (!condition) {
      var error;
      if (void 0 === format) error = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings."); else {
        var args = [ a, b, c, d, e, f ];
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, (function() {
          return args[argIndex++];
        })));
        error.name = "Invariant Violation";
      }
      error.framesToPop = 1;
      throw error;
    }
  };
  module.exports = invariant;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return fadeIn;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return fadeOut;
  }));
  var p_sleep__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(24);
  var p_sleep__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(p_sleep__WEBPACK_IMPORTED_MODULE_0__);
  async function fade(element, duration, start, end) {
    const {opacity, transition} = element.style;
    element.style.transition = "unset !important";
    element.style.opacity = start;
    element.style.transition = `opacity ${duration}ms`;
    await p_sleep__WEBPACK_IMPORTED_MODULE_0___default()(0);
    element.style.opacity = end;
    await p_sleep__WEBPACK_IMPORTED_MODULE_0___default()(duration);
    element.style.transition = transition;
    element.style.transition = opacity;
  }
  function fadeIn(element, duration) {
    return fade(element, duration, 0, 1);
  }
  function fadeOut(element, duration) {
    return fade(element, duration, 1, 0);
  }
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
  /*!
 * JavaScript Cookie v2.2.1
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */  (function(factory) {
    var registeredInModuleLoader;
    if (true) {
      !(__WEBPACK_AMD_DEFINE_FACTORY__ = factory, __WEBPACK_AMD_DEFINE_RESULT__ = "function" === typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__, 
      void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
      registeredInModuleLoader = true;
    }
    if (true) {
      module.exports = factory();
      registeredInModuleLoader = true;
    }
    if (!registeredInModuleLoader) {
      var OldCookies = window.Cookies;
      var api = window.Cookies = factory();
      api.noConflict = function() {
        window.Cookies = OldCookies;
        return api;
      };
    }
  })((function() {
    function extend() {
      var i = 0;
      var result = {};
      for (;i < arguments.length; i++) {
        var attributes = arguments[i];
        for (var key in attributes) result[key] = attributes[key];
      }
      return result;
    }
    function decode(s) {
      return s.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent);
    }
    function init(converter) {
      function api() {}
      function set(key, value, attributes) {
        if ("undefined" === typeof document) return;
        attributes = extend({
          path: "/"
        }, api.defaults, attributes);
        if ("number" === typeof attributes.expires) attributes.expires = new Date(1 * new Date + 864e5 * attributes.expires);
        attributes.expires = attributes.expires ? attributes.expires.toUTCString() : "";
        try {
          var result = JSON.stringify(value);
          if (/^[\{\[]/.test(result)) value = result;
        } catch (e) {}
        value = converter.write ? converter.write(value, key) : encodeURIComponent(String(value)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
        key = encodeURIComponent(String(key)).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/[\(\)]/g, escape);
        var stringifiedAttributes = "";
        for (var attributeName in attributes) {
          if (!attributes[attributeName]) continue;
          stringifiedAttributes += "; " + attributeName;
          if (true === attributes[attributeName]) continue;
          stringifiedAttributes += "=" + attributes[attributeName].split(";")[0];
        }
        return document.cookie = key + "=" + value + stringifiedAttributes;
      }
      function get(key, json) {
        if ("undefined" === typeof document) return;
        var jar = {};
        var cookies = document.cookie ? document.cookie.split("; ") : [];
        var i = 0;
        for (;i < cookies.length; i++) {
          var parts = cookies[i].split("=");
          var cookie = parts.slice(1).join("=");
          if (!json && '"' === cookie.charAt(0)) cookie = cookie.slice(1, -1);
          try {
            var name = decode(parts[0]);
            cookie = (converter.read || converter)(cookie, name) || decode(cookie);
            if (json) try {
              cookie = JSON.parse(cookie);
            } catch (e) {}
            jar[name] = cookie;
            if (key === name) break;
          } catch (e) {}
        }
        return key ? jar[key] : jar;
      }
      api.set = set;
      api.get = function(key) {
        return get(key, false);
      };
      api.getJSON = function(key) {
        return get(key, true);
      };
      api.remove = function(key, attributes) {
        set(key, "", extend(attributes, {
          expires: -1
        }));
      };
      api.defaults = {};
      api.withConverter = init;
      return api;
    }
    return init((function() {}));
  }));
}, function(module, exports) {
  module.exports = trigger;
  var eventTypes = {
    load: "HTMLEvents",
    unload: "HTMLEvents",
    abort: "HTMLEvents",
    error: "HTMLEvents",
    select: "HTMLEvents",
    change: "HTMLEvents",
    submit: "HTMLEvents",
    reset: "HTMLEvents",
    focus: "HTMLEvents",
    blur: "HTMLEvents",
    resize: "HTMLEvents",
    scroll: "HTMLEvents",
    input: "HTMLEvents",
    keyup: "KeyboardEvent",
    keydown: "KeyboardEvent",
    click: "MouseEvents",
    dblclick: "MouseEvents",
    mousedown: "MouseEvents",
    mouseup: "MouseEvents",
    mouseover: "MouseEvents",
    mousemove: "MouseEvents",
    mouseout: "MouseEvents",
    contextmenu: "MouseEvents"
  };
  var defaults = {
    clientX: 0,
    clientY: 0,
    button: 0,
    ctrlKey: false,
    altKey: false,
    shiftKey: false,
    metaKey: false,
    bubbles: true,
    cancelable: true,
    view: document.defaultView,
    key: "",
    location: 0,
    modifiers: "",
    repeat: 0,
    locale: ""
  };
  function trigger(el, name, options) {
    var event, type;
    options = options || {};
    for (var attr in defaults) if (!options.hasOwnProperty(attr)) options[attr] = defaults[attr];
    if (document.createEvent) {
      type = eventTypes[name] || "CustomEvent";
      event = document.createEvent(type);
      initializers[type](el, name, event, options);
      el.dispatchEvent(event);
    } else {
      event = document.createEventObject();
      for (var key in options) event[key] = options[key];
      el.fireEvent("on" + name, event);
    }
  }
  var initializers = {
    HTMLEvents: function(el, name, event, o) {
      return event.initEvent(name, o.bubbles, o.cancelable);
    },
    KeyboardEvent: function(el, name, event, o) {
      var key = "key" in o ? o.key : "";
      var charCode;
      var modifiers;
      var location = "location" in o ? o.location : 0;
      if (event.initKeyboardEvent) {
        if (false in o) {
          modifiers = [];
          if (o.ctrlKey) modifiers.push("Ctrl");
          if (o.altKey) modifiers.push("Alt");
          if (o.ctrlKey && o.altKey) modifiers.push("AltGraph");
          if (o.shiftKey) modifiers.push("Shift");
          if (o.metaKey) modifiers.push("Meta");
          modifiers = modifiers.join(" ");
        } else modifiers = o.modifiers;
        return event.initKeyboardEvent(name, o.bubbles, o.cancelable, o.view, key, location, modifiers, o.repeat, o.locale);
      } else {
        charCode = "charCode" in o ? o.charCode : key.charCodeAt(0) || 0;
        return event.initKeyEvent(name, o.bubbles, o.cancelable, o.view, o.ctrlKey, o.altKey, o.shiftKey, o.metaKey, charCode, key);
      }
    },
    MouseEvents: function(el, name, event, o) {
      var screenX = "screenX" in o ? o.screenX : o.clientX;
      var screenY = "screenY" in o ? o.screenY : o.clientY;
      var clicks;
      var button;
      if ("detail" in o) clicks = o.detail; else if ("dblclick" === name) clicks = 2; else clicks = 1;
      if ("contextmenu" === name) button = button = o.button || 2;
      return event.initMouseEvent(name, o.bubbles, o.cancelable, o.view, clicks, screenX, screenY, o.clientX, o.clientY, o.ctrlKey, o.altKey, o.shiftKey, o.metaKey, button, el);
    },
    CustomEvent: function(el, name, event, o) {
      return event.initCustomEvent(name, o.bubbles, o.cancelable, o.detail);
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    for (var i = 0; i < arguments.length; i++) if ("undefined" !== typeof arguments[i]) return arguments[i];
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return injectBeforeFirstScriptOrAppendToHead;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return insertBeforeBody;
  }));
  var _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);
  var _libs_log__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  function appendToHead(element) {
    document.head.append(element);
  }
  function injectBeforeFirstScriptOrAppendToHead(element) {
    const firstScript = document.getElementsByTagName("script")[0];
    if (firstScript) firstScript.before(element); else appendToHead(element);
  }
  function insertBeforeBody(element) {
    if (document.body) document.body.before(element); else document.documentElement.append(element);
  }
  __webpack_exports__["a"] = opts => {
    var _context;
    const {type, url, code, async, mount = appendToHead, dataset} = opts;
    let element;
    if ("style" === type && code) {
      element = document.createElement("style");
      element.setAttribute("type", "text/css");
      element.append(document.createTextNode(code));
    } else if ("style" === type && url) {
      element = document.createElement("link");
      element.setAttribute("rel", "stylesheet");
      element.setAttribute("type", "text/css");
      element.setAttribute("href", url);
    } else if ("script" === type && code) {
      element = document.createElement("script");
      element.setAttribute("type", "text/javascript");
      element.append(document.createTextNode(code));
    } else if ("script" === type && url) {
      element = document.createElement("script");
      element.setAttribute("type", "text/javascript");
      element.setAttribute("src", url);
      async && element.setAttribute("async", "");
    }
    if (!element) return _libs_log__WEBPACK_IMPORTED_MODULE_1__["a"].error("非法参数：", opts);
    if (dataset) Object.assign(element.dataset, dataset);
    element.classList.add(_constants__WEBPACK_IMPORTED_MODULE_2__["ASSET_CLASSNAME"]);
    mount(element);
    _libs_extensionUnloaded__WEBPACK_IMPORTED_MODULE_0__["a"].addListener((_context = element).remove.bind(_context));
    return element;
  };
}, function(module, exports, __webpack_require__) {
  (function(global, factory) {
    true ? factory(exports) : void 0;
  })(0, (function(exports) {
    "use strict";
    const LOWER_CASE$1 = "LOWER_CASE";
    const UPPER_CASE$1 = "UPPER_CASE";
    const CAMEL_CASE$1 = "CAMEL_CASE";
    const PASCAL_CASE$1 = "PASCAL_CASE";
    const KEBAB_CASE$1 = "KEBAB_CASE";
    const SNAKE_CASE$1 = "SNAKE_CASE";
    const TRAIN_CASE$1 = "TRAIN_CASE";
    const LOWER_CASE = /^[^A-Z]+$/;
    const UPPER_CASE = /^[^a-z]+$/;
    const CAMEL_CASE = /^[a-z]+(?:[A-Z][a-z\d]+)*$/;
    const PASCAL_CASE = /^[A-Z][a-z\d]+(?:[A-Z][a-z\d]+)*$/;
    const KEBAB_CASE = /^[a-z][a-z\d]+(-[a-z\d]+)+$/;
    const SNAKE_CASE = /^[a-z][a-z\d]+(_[a-z\d]+)+$/;
    const TRAIN_CASE = /^[A-Z][a-z\d]+(-[A-Z][a-z\d]+)+$/;
    const FRAGMENT = /([A-Za-z\d]+)+/g;
    const isString = _isString;
    const isLowerCase = _is(LOWER_CASE);
    const isUpperCase = _is(UPPER_CASE);
    const isCamelCase = _is(CAMEL_CASE);
    const isPascalCase = _is(PASCAL_CASE);
    const isKebabCase = _is(KEBAB_CASE);
    const isSnakeCase = _is(SNAKE_CASE);
    const isTrainCase = _is(TRAIN_CASE);
    const caseOf = _caseOf;
    const toLowerCase = _toLowerCase;
    const toUpperCase = _toUpperCase;
    const toCamelCase = _toCamelCase;
    const toPascalCase = _toPascalCase;
    const toKebabCase = _toKebabCase;
    const toSnakeCase = _toSnakeCase;
    const toTrainCase = _toTrainCase;
    function _isString(any) {
      return "string" === typeof any || null !== any && "object" === typeof any && any.constructor === String;
    }
    function _is(pattern) {
      return function(str) {
        return isString(str) ? pattern.test(str) : false;
      };
    }
    function _caseOf(str) {
      if (isCamelCase(str)) return CAMEL_CASE$1; else if (isPascalCase(str)) return PASCAL_CASE$1; else if (isKebabCase(str)) return KEBAB_CASE$1; else if (isSnakeCase(str)) return SNAKE_CASE$1; else if (isTrainCase(str)) return TRAIN_CASE$1; else if (isLowerCase(str)) return LOWER_CASE$1; else if (isUpperCase(str)) return UPPER_CASE$1; else return null;
    }
    function _toLowerCase(str) {
      return String.prototype.toLowerCase.call(String(str));
    }
    function _toUpperCase(str) {
      return String.prototype.toUpperCase.call(String(str));
    }
    function _toCamelCase(str) {
      return _fragment(_toLowerCase(String(str))).map((frag, idx) => 0 === idx ? frag : _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toPascalCase(str) {
      return _fragment(_toLowerCase(String(str))).map(frag => _toUpperCase(frag[0]) + _tail(frag)).join("");
    }
    function _toKebabCase(str) {
      return _fragment(_toLowerCase(String(str))).join("-");
    }
    function _toSnakeCase(str) {
      return _fragment(_toLowerCase(String(str))).join("_");
    }
    function _toTrainCase(str) {
      return _fragment(toLowerCase(String(str))).map(frag => toUpperCase(frag[0]) + _tail(frag)).join("-");
    }
    function _tail(str) {
      return String.prototype.slice.call(str, 1);
    }
    function _fragment(str) {
      return String.prototype.match.call(str, FRAGMENT);
    }
    exports.caseOf = caseOf;
    exports.isCamelCase = isCamelCase;
    exports.isKebabCase = isKebabCase;
    exports.isLowerCase = isLowerCase;
    exports.isPascalCase = isPascalCase;
    exports.isSnakeCase = isSnakeCase;
    exports.isString = isString;
    exports.isTrainCase = isTrainCase;
    exports.isUpperCase = isUpperCase;
    exports.toCamelCase = toCamelCase;
    exports.toKebabCase = toKebabCase;
    exports.toLowerCase = toLowerCase;
    exports.toPascalCase = toPascalCase;
    exports.toSnakeCase = toSnakeCase;
    exports.toTrainCase = toTrainCase;
    exports.toUpperCase = toUpperCase;
  }));
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(url, options) {
    if (!options) options = {};
    url = url && url.__esModule ? url.default : url;
    if ("string" !== typeof url) return url;
    if (/^['"].*['"]$/.test(url)) url = url.slice(1, -1);
    if (options.hash) url += options.hash;
    if (/["'() \t\n]/.test(url) || options.needQuotes) return '"'.concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), '"');
    return url;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isObj = __webpack_require__(86);
  const disallowedKeys = [ "__proto__", "prototype", "constructor" ];
  const isValidPath = pathSegments => !pathSegments.some(segment => disallowedKeys.includes(segment));
  function getPathSegments(path) {
    const pathArray = path.split(".");
    const parts = [];
    for (let i = 0; i < pathArray.length; i++) {
      let p = pathArray[i];
      while ("\\" === p[p.length - 1] && void 0 !== pathArray[i + 1]) {
        p = p.slice(0, -1) + ".";
        p += pathArray[++i];
      }
      parts.push(p);
    }
    if (!isValidPath(parts)) return [];
    return parts;
  }
  module.exports = {
    get(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return void 0 === value ? object : value;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return;
      for (let i = 0; i < pathArray.length; i++) {
        if (!Object.prototype.propertyIsEnumerable.call(object, pathArray[i])) return value;
        object = object[pathArray[i]];
        if (void 0 === object || null === object) {
          if (i !== pathArray.length - 1) return value;
          break;
        }
      }
      return object;
    },
    set(object, path, value) {
      if (!isObj(object) || "string" !== typeof path) return object;
      const root = object;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (!isObj(object[p])) object[p] = {};
        if (i === pathArray.length - 1) object[p] = value;
        object = object[p];
      }
      return root;
    },
    delete(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      for (let i = 0; i < pathArray.length; i++) {
        const p = pathArray[i];
        if (i === pathArray.length - 1) {
          delete object[p];
          return true;
        }
        object = object[p];
        if (!isObj(object)) return false;
      }
    },
    has(object, path) {
      if (!isObj(object) || "string" !== typeof path) return false;
      const pathArray = getPathSegments(path);
      if (0 === pathArray.length) return false;
      for (let i = 0; i < pathArray.length; i++) if (isObj(object)) {
        if (!(pathArray[i] in object)) return false;
        object = object[pathArray[i]];
      } else return false;
      return true;
    }
  };
}, function(module, exports) {
  module.exports = debounce;
  function debounce(fn, wait, callFirst) {
    var timeout = null;
    var debouncedFn = null;
    var clear = function() {
      if (timeout) {
        clearTimeout(timeout);
        debouncedFn = null;
        timeout = null;
      }
    };
    var flush = function() {
      var call = debouncedFn;
      clear();
      if (call) call();
    };
    var debounceWrapper = function() {
      if (!wait) return fn.apply(this, arguments);
      var context = this;
      var args = arguments;
      var callNow = callFirst && !timeout;
      clear();
      debouncedFn = function() {
        fn.apply(context, args);
      };
      timeout = setTimeout((function() {
        timeout = null;
        if (!callNow) {
          var call = debouncedFn;
          debouncedFn = null;
          return call();
        }
      }), wait);
      if (callNow) return debouncedFn();
    };
    debounceWrapper.cancel = clear;
    debounceWrapper.flush = flush;
    return debounceWrapper;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13);
  const CHECKING_INTERVAL = 32;
  let timerId = null;
  let prevY = -1;
  const listeners = [];
  function handler() {
    const currY = scrollManager.getScrollTop();
    if (-1 !== prevY && currY !== prevY) Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_1__["a"])(listeners);
    prevY = currY;
  }
  const scrollManager = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_0__["a"])({
    install() {
      if (timerId) return;
      timerId = setInterval(handler, CHECKING_INTERVAL);
      handler();
    },
    uninstall() {
      if (!timerId) return;
      clearInterval(timerId);
      timerId = null;
    },
    addListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_2__["a"])(listeners, fn);
    },
    removeListener(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_3__["a"])(listeners, fn);
    },
    getScrollTop() {
      return Math.max(document.documentElement ? document.documentElement.scrollTop : 0, document.body ? document.body.scrollTop : 0);
    }
  });
  __webpack_exports__["default"] = scrollManager;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.getScrollTop = getScrollTop;
  exports.getScrollLeft = getScrollLeft;
  exports.getArrowSpacing = getArrowSpacing;
  exports.getScrollParent = getScrollParent;
  exports.noArrowDistance = exports.bodyPadding = exports.minArrowPadding = void 0;
  var minArrowPadding = 5;
  exports.minArrowPadding = minArrowPadding;
  var bodyPadding = 10;
  exports.bodyPadding = bodyPadding;
  var noArrowDistance = 3;
  exports.noArrowDistance = noArrowDistance;
  function getScrollTop() {
    return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  }
  function getScrollLeft() {
    return window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0;
  }
  function getArrowSpacing(props) {
    var defaultArrowSpacing = props.arrow ? props.arrowSize : noArrowDistance;
    return "number" === typeof props.distance ? props.distance : defaultArrowSpacing;
  }
  function getScrollParent(element) {
    var style = getComputedStyle(element);
    var scrollParent = window;
    if ("fixed" !== style.position) {
      var parent = element.parentElement;
      while (parent) {
        var parentStyle = getComputedStyle(parent);
        if (/(auto|scroll)/.test(parentStyle.overflow + parentStyle.overflowY + parentStyle.overflowX)) {
          scrollParent = parent;
          parent = void 0;
        } else parent = parent.parentElement;
      }
    }
    return scrollParent;
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  (function(__filename) {
    var _content_modules__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(44);
    function loadModules() {
      const modules = {};
      const context = __webpack_require__(152);
      for (const key of context.keys()) {
        if (key.endsWith(__filename)) continue;
        const moduleName = key.replace(/^\.\/|\.js$/g, "");
        const module = context(key).default;
        modules[moduleName] = module;
      }
      return modules;
    }
    __webpack_exports__["default"] = {
      ..._content_modules__WEBPACK_IMPORTED_MODULE_0__["default"],
      ...loadModules()
    };
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  (function(__filename) {
    function loadModules() {
      const modules = {};
      const context = __webpack_require__(148);
      for (const key of context.keys()) {
        if (key.endsWith(__filename)) continue;
        const moduleName = key.replace(/^\.\/|\.js$/g, "");
        const module = context(key).default;
        modules[moduleName] = module;
      }
      return modules;
    }
    __webpack_exports__["default"] = loadModules();
  }).call(this, "/index.js");
}, function(module, exports, __webpack_require__) {
  "use strict";
  const stripAnsi = __webpack_require__(113);
  const isFullwidthCodePoint = __webpack_require__(115);
  const emojiRegex = __webpack_require__(116);
  const stringWidth = string => {
    if ("string" !== typeof string || 0 === string.length) return 0;
    string = stripAnsi(string);
    if (0 === string.length) return 0;
    string = string.replace(emojiRegex(), "  ");
    let width = 0;
    for (let i = 0; i < string.length; i++) {
      const code = string.codePointAt(i);
      if (code <= 31 || code >= 127 && code <= 159) continue;
      if (code >= 768 && code <= 879) continue;
      if (code > 65535) i++;
      width += isFullwidthCodePoint(code) ? 2 : 1;
    }
    return width;
  };
  module.exports = stringWidth;
  module.exports.default = stringWidth;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = positions;
  var _getDirection = _interopRequireDefault(__webpack_require__(97));
  var _functions = __webpack_require__(42);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = null != arguments[i] ? arguments[i] : {};
      var ownKeys = Object.keys(source);
      if ("function" === typeof Object.getOwnPropertySymbols) ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter((function(sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      })));
      ownKeys.forEach((function(key) {
        _defineProperty(target, key, source[key]);
      }));
    }
    return target;
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    }); else obj[key] = value;
    return obj;
  }
  function getTipMaxWidth() {
    return "undefined" !== typeof document ? document.documentElement.clientWidth - 2 * _functions.bodyPadding : 1e3;
  }
  function parseAlignMode(direction) {
    var directionArray = direction.split("-");
    if (directionArray.length > 1) return directionArray[1];
    return "middle";
  }
  function getUpDownPosition(tip, target, state, direction, alignMode, props) {
    var left = -1e7;
    var top;
    var transform = state.showTip ? void 0 : "translateX(-10000000px)";
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    if (tip) {
      var scrollLeft = (0, _functions.getScrollLeft)();
      var targetRect = target.getBoundingClientRect();
      var targetLeft = targetRect.left + scrollLeft;
      var halfTargetWidth = Math.round(target.offsetWidth / 2);
      var tipWidth = Math.min(getTipMaxWidth(), tip.offsetWidth);
      var arrowCenter = targetLeft + halfTargetWidth;
      var arrowLeft = arrowCenter - props.arrowSize;
      var arrowRight = arrowCenter + props.arrowSize;
      if ("start" === alignMode) left = props.arrow ? Math.min(arrowLeft, targetLeft) : targetLeft; else if ("end" === alignMode) {
        var rightWithArrow = Math.max(arrowRight, targetLeft + target.offsetWidth);
        var rightEdge = props.arrow ? rightWithArrow : targetLeft + target.offsetWidth;
        left = Math.max(rightEdge - tipWidth, _functions.bodyPadding + scrollLeft);
      } else {
        var centeredLeft = targetLeft + halfTargetWidth - Math.round(tipWidth / 2);
        var availableSpaceOnLeft = _functions.bodyPadding + scrollLeft;
        left = Math.max(centeredLeft, availableSpaceOnLeft);
      }
      var rightOfTip = left + tipWidth;
      var rightOfScreen = scrollLeft + document.documentElement.clientWidth - _functions.bodyPadding;
      var rightOverhang = rightOfTip - rightOfScreen;
      if (rightOverhang > 0) left -= rightOverhang;
      if ("up" === direction) top = targetRect.top + (0, _functions.getScrollTop)() - (tip.offsetHeight + arrowSpacing); else top = targetRect.bottom + (0, 
      _functions.getScrollTop)() + arrowSpacing;
    }
    return {
      left,
      top,
      transform
    };
  }
  function getLeftRightPosition(tip, target, state, direction, alignMode, props) {
    var left = -1e7;
    var top = 0;
    var transform = state.showTip ? void 0 : "translateX(-10000000px)";
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var arrowPadding = props.arrow ? _functions.minArrowPadding : 0;
    if (tip) {
      var scrollTop = (0, _functions.getScrollTop)();
      var scrollLeft = (0, _functions.getScrollLeft)();
      var targetRect = target.getBoundingClientRect();
      var targetTop = targetRect.top + scrollTop;
      var halfTargetHeight = Math.round(target.offsetHeight / 2);
      var arrowTop = targetTop + halfTargetHeight - props.arrowSize;
      var arrowBottom = targetRect.top + scrollTop + halfTargetHeight + props.arrowSize;
      if ("start" === alignMode) top = props.arrow ? Math.min(targetTop, arrowTop) : targetTop; else if ("end" === alignMode) {
        var topForBottomAlign = targetRect.bottom + scrollTop - tip.offsetHeight;
        top = props.arrow ? Math.max(topForBottomAlign, arrowBottom - tip.offsetHeight) : topForBottomAlign;
      } else {
        var centeredTop = Math.max(targetTop + halfTargetHeight - Math.round(tip.offsetHeight / 2), _functions.bodyPadding + scrollTop);
        top = Math.min(centeredTop, arrowTop - arrowPadding);
      }
      var bottomOverhang = top - scrollTop + tip.offsetHeight + _functions.bodyPadding - window.innerHeight;
      if (bottomOverhang > 0) top = Math.max(top - bottomOverhang, arrowBottom + arrowPadding - tip.offsetHeight);
      if ("right" === direction) left = targetRect.right + arrowSpacing + scrollLeft; else left = targetRect.left - arrowSpacing - tip.offsetWidth + scrollLeft;
    }
    return {
      left,
      top,
      transform
    };
  }
  function getArrowStyles(target, tip, direction, state, props) {
    if (!target || !props.arrow) return {
      positionStyles: {
        top: "0",
        left: "-10000000px"
      }
    };
    var targetRect = target.getBoundingClientRect();
    var halfTargetHeight = Math.round(target.offsetHeight / 2);
    var halfTargetWidth = Math.round(target.offsetWidth / 2);
    var scrollTop = (0, _functions.getScrollTop)();
    var scrollLeft = (0, _functions.getScrollLeft)();
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var borderStyles = {};
    var positionStyles = {};
    switch (direction) {
     case "right":
      borderStyles.borderTop = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderBottom = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderRight = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderRightWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderRightStyle = "solid";
      }
      positionStyles.top = state.showTip && tip ? targetRect.top + scrollTop + halfTargetHeight - props.arrowSize : "-10000000px";
      positionStyles.left = targetRect.right + scrollLeft + arrowSpacing - props.arrowSize;
      break;

     case "left":
      borderStyles.borderTop = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderBottom = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderLeft = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderLeftWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderLeftStyle = "solid";
      }
      positionStyles.top = state.showTip && tip ? targetRect.top + scrollTop + halfTargetHeight - props.arrowSize : "-10000000px";
      positionStyles.left = targetRect.left + scrollLeft - arrowSpacing - 1;
      break;

     case "up":
      borderStyles.borderLeft = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderRight = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderTop = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderTopWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderTopStyle = "solid";
      }
      positionStyles.left = state.showTip && tip ? targetRect.left + scrollLeft + halfTargetWidth - props.arrowSize : "-10000000px";
      positionStyles.top = targetRect.top + scrollTop - arrowSpacing;
      break;

     case "down":
     default:
      borderStyles.borderLeft = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderRight = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderBottom = "10px solid ".concat(props.background); else {
        borderStyles.borderBottomWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderBottomStyle = "solid";
      }
      positionStyles.left = state.showTip && tip ? targetRect.left + scrollLeft + halfTargetWidth - props.arrowSize : "-10000000px";
      positionStyles.top = targetRect.bottom + scrollTop + arrowSpacing - props.arrowSize;
      break;
    }
    return {
      borderStyles,
      positionStyles
    };
  }
  function positions(direction, forceDirection, tip, target, state, props) {
    var alignMode = parseAlignMode(direction);
    var trimmedDirection = direction.split("-")[0];
    var realDirection = trimmedDirection;
    if (!forceDirection && tip) {
      var testArrowStyles = props.arrow && getArrowStyles(target, tip, trimmedDirection, state, props);
      realDirection = (0, _getDirection["default"])(trimmedDirection, tip, target, props, _functions.bodyPadding, testArrowStyles);
    }
    var maxWidth = getTipMaxWidth();
    var width;
    if (tip) {
      var spacer = tip.style.width ? 0 : 1;
      width = Math.min(tip.offsetWidth, maxWidth) + spacer;
    }
    var tipPosition = "up" === realDirection || "down" === realDirection ? getUpDownPosition(tip, target, state, realDirection, alignMode, props) : getLeftRightPosition(tip, target, state, realDirection, alignMode, props);
    return {
      tip: _objectSpread({}, tipPosition, {
        maxWidth,
        width
      }),
      arrow: getArrowStyles(target, tip, realDirection, state, props),
      realDirection
    };
  }
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  function reduce(arr, fn, accumulator) {
    var idx = -1;
    var len = arr.length;
    if (!accumulator && len > 0) accumulator = arr[++idx];
    while (++idx < len) accumulator = fn(accumulator, arr[idx], idx, arr);
    return accumulator;
  }
  function intersectClientRects() {
    return reduce(Array.prototype.slice.call(arguments), (function(acc, cur) {
      var clip = {
        top: Math.max(acc.top, cur.top),
        left: Math.max(acc.left, cur.left),
        right: Math.min(acc.right, cur.right),
        bottom: Math.min(acc.bottom, cur.bottom)
      };
      clip.width = clip.right - clip.left;
      clip.height = clip.bottom - clip.top;
      return clip;
    }));
  }
  if (true, "undefined" !== typeof module.exports) module.exports = intersectClientRects; else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
  __WEBPACK_AMD_DEFINE_RESULT__ = function() {
    return intersectClientRects;
  }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  var elementOffset = __webpack_require__(98);
  var boundingClientRect = __webpack_require__(100);
  if (true, "undefined" !== typeof module.exports) module.exports = getElementClientRect; else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
  __WEBPACK_AMD_DEFINE_RESULT__ = function() {
    return getElementClientRect;
  }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  function getElementClientRect(element) {
    var offset = elementOffset(element);
    var rect = getBoundingClientRect(element);
    var elemHeight = rect.bottom - rect.top;
    return {
      left: offset.left,
      top: offset.top,
      right: rect.right,
      bottom: offset.top + elemHeight,
      width: rect.right - offset.left,
      height: elemHeight
    };
  }
  function getZoomFactor() {
    var factor = 1;
    if (document.body.getBoundingClientRect) {
      var rect = document.body.getBoundingClientRect();
      var physicalW = rect.right - rect.left;
      var logicalW = document.body.offsetWidth;
      factor = Math.round(physicalW / logicalW * 100) / 100;
    }
    return factor;
  }
  function getScrollPosition(object, scrolled) {
    if (!object) return;
    scrolled.x += object.scrollLeft;
    scrolled.y += object.scrollTop;
    if ("html" != object.tagName.toLowerCase()) getScrollPosition(object.parentNode, scrolled);
  }
  function getElementOffset(object, offset) {
    if (!object) return;
    offset.x += object.offsetLeft;
    offset.y += object.offsetTop;
    getElementOffset(object.offsetParent, offset);
  }
  function getBoundingClientRect(node, x, y, w, h) {
    var rect = boundingClientRect(node);
    if (void 0 !== node.getBoundingClientRect) {
      rect = node.getBoundingClientRect();
      x = rect.left, y = rect.top, w = rect.right - rect.left, h = rect.bottom - rect.top;
      if ("microsoft internet explorer" == navigator.appName.toLowerCase()) {
        x -= document.documentElement.clientLeft;
        y -= document.documentElement.clientTop;
        var zoomFactor = getZoomFactor();
        if (1 != zoomFactor) {
          x = Math.round(x / zoomFactor);
          y = Math.round(y / zoomFactor);
          w = Math.round(w / zoomFactor);
          h = Math.round(h / zoomFactor);
        }
        rect = {
          left: x,
          top: y,
          width: w,
          height: h,
          right: x + w,
          bottom: y + h
        };
      }
    } else {
      var offset = {
        x: 0,
        y: 0
      };
      getElementOffset(node, offset);
      var scrolled = {
        x: 0,
        y: 0
      };
      getScrollPosition(node.parentNode, scrolled);
      x = offset.x - scrolled.x;
      y = offset.y - scrolled.y;
      w = node.offsetWidth;
      h = node.offsetHeight;
      return {
        left: x,
        top: y,
        width: w,
        height: h,
        right: x + w,
        bottom: y + h
      };
    }
    return rect;
  }
}, function(module, exports) {
  module.exports = getDocument;
  var DOCUMENT_NODE = 9;
  function isDocument(d) {
    return d && d.nodeType === DOCUMENT_NODE;
  }
  function getDocument(node) {
    if (isDocument(node)) return node; else if (isDocument(node.ownerDocument)) return node.ownerDocument; else if (isDocument(node.document)) return node.document; else if (node.parentNode) return getDocument(node.parentNode); else if (node.commonAncestorContainer) return getDocument(node.commonAncestorContainer); else if (node.startContainer) return getDocument(node.startContainer); else if (node.anchorNode) return getDocument(node.anchorNode);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/question-mark.svg";
}, function(module, exports, __webpack_require__) {
  var require;
  (function(f) {
    if (true) module.exports = f(); else ;
  })((function() {
    return function() {
      function r(e, n, t) {
        function o(i, f) {
          if (!n[i]) {
            if (!e[i]) {
              var c = "function" == typeof require && require;
              if (!f && c) return require(i, !0);
              if (u) return u(i, !0);
              var a = new Error("Cannot find module '" + i + "'");
              throw a.code = "MODULE_NOT_FOUND", a;
            }
            var p = n[i] = {
              exports: {}
            };
            e[i][0].call(p.exports, (function(r) {
              var n = e[i][1][r];
              return o(n || r);
            }), p, p.exports, r, e, n, t);
          }
          return n[i].exports;
        }
        for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
        return o;
      }
      return r;
    }()({
      1: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        require("./utils");
        var _TributeEvents = _interopRequireDefault(require("./TributeEvents"));
        var _TributeMenuEvents = _interopRequireDefault(require("./TributeMenuEvents"));
        var _TributeRange = _interopRequireDefault(require("./TributeRange"));
        var _TributeSearch = _interopRequireDefault(require("./TributeSearch"));
        function _interopRequireDefault(obj) {
          return obj && obj.__esModule ? obj : {
            default: obj
          };
        }
        function _slicedToArray(arr, i) {
          return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
        }
        function _nonIterableRest() {
          throw new TypeError("Invalid attempt to destructure non-iterable instance");
        }
        function _iterableToArrayLimit(arr, i) {
          var _arr = [];
          var _n = true;
          var _d = false;
          var _e = void 0;
          try {
            for (var _s, _i = arr[Symbol.iterator](); !(_n = (_s = _i.next()).done); _n = true) {
              _arr.push(_s.value);
              if (i && _arr.length === i) break;
            }
          } catch (err) {
            _d = true;
            _e = err;
          } finally {
            try {
              if (!_n && null != _i["return"]) _i["return"]();
            } finally {
              if (_d) throw _e;
            }
          }
          return _arr;
        }
        function _arrayWithHoles(arr) {
          if (Array.isArray(arr)) return arr;
        }
        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        function _createClass(Constructor, protoProps, staticProps) {
          if (protoProps) _defineProperties(Constructor.prototype, protoProps);
          if (staticProps) _defineProperties(Constructor, staticProps);
          return Constructor;
        }
        var Tribute = function() {
          function Tribute(_ref) {
            var _this = this;
            var _ref$values = _ref.values, values = void 0 === _ref$values ? null : _ref$values, _ref$iframe = _ref.iframe, iframe = void 0 === _ref$iframe ? null : _ref$iframe, _ref$selectClass = _ref.selectClass, selectClass = void 0 === _ref$selectClass ? "highlight" : _ref$selectClass, _ref$containerClass = _ref.containerClass, containerClass = void 0 === _ref$containerClass ? "tribute-container" : _ref$containerClass, _ref$itemClass = _ref.itemClass, itemClass = void 0 === _ref$itemClass ? "" : _ref$itemClass, _ref$trigger = _ref.trigger, trigger = void 0 === _ref$trigger ? "@" : _ref$trigger, _ref$autocompleteMode = _ref.autocompleteMode, autocompleteMode = void 0 === _ref$autocompleteMode ? false : _ref$autocompleteMode, _ref$selectTemplate = _ref.selectTemplate, selectTemplate = void 0 === _ref$selectTemplate ? null : _ref$selectTemplate, _ref$menuItemTemplate = _ref.menuItemTemplate, menuItemTemplate = void 0 === _ref$menuItemTemplate ? null : _ref$menuItemTemplate, _ref$lookup = _ref.lookup, lookup = void 0 === _ref$lookup ? "key" : _ref$lookup, _ref$fillAttr = _ref.fillAttr, fillAttr = void 0 === _ref$fillAttr ? "value" : _ref$fillAttr, _ref$collection = _ref.collection, collection = void 0 === _ref$collection ? null : _ref$collection, _ref$menuContainer = _ref.menuContainer, menuContainer = void 0 === _ref$menuContainer ? null : _ref$menuContainer, _ref$noMatchTemplate = _ref.noMatchTemplate, noMatchTemplate = void 0 === _ref$noMatchTemplate ? null : _ref$noMatchTemplate, _ref$requireLeadingSp = _ref.requireLeadingSpace, requireLeadingSpace = void 0 === _ref$requireLeadingSp ? true : _ref$requireLeadingSp, _ref$allowSpaces = _ref.allowSpaces, allowSpaces = void 0 === _ref$allowSpaces ? false : _ref$allowSpaces, _ref$replaceTextSuffi = _ref.replaceTextSuffix, replaceTextSuffix = void 0 === _ref$replaceTextSuffi ? null : _ref$replaceTextSuffi, _ref$positionMenu = _ref.positionMenu, positionMenu = void 0 === _ref$positionMenu ? true : _ref$positionMenu, _ref$spaceSelectsMatc = _ref.spaceSelectsMatch, spaceSelectsMatch = void 0 === _ref$spaceSelectsMatc ? false : _ref$spaceSelectsMatc, _ref$searchOpts = _ref.searchOpts, searchOpts = void 0 === _ref$searchOpts ? {} : _ref$searchOpts, _ref$menuItemLimit = _ref.menuItemLimit, menuItemLimit = void 0 === _ref$menuItemLimit ? null : _ref$menuItemLimit;
            _classCallCheck(this, Tribute);
            this.autocompleteMode = autocompleteMode;
            this.menuSelected = 0;
            this.current = {};
            this.inputEvent = false;
            this.isActive = false;
            this.menuContainer = menuContainer;
            this.allowSpaces = allowSpaces;
            this.replaceTextSuffix = replaceTextSuffix;
            this.positionMenu = positionMenu;
            this.hasTrailingSpace = false;
            this.spaceSelectsMatch = spaceSelectsMatch;
            if (this.autocompleteMode) {
              trigger = "";
              allowSpaces = false;
            }
            if (values) this.collection = [ {
              trigger,
              iframe,
              selectClass,
              containerClass,
              itemClass,
              selectTemplate: (selectTemplate || Tribute.defaultSelectTemplate).bind(this),
              menuItemTemplate: (menuItemTemplate || Tribute.defaultMenuItemTemplate).bind(this),
              noMatchTemplate: function(t) {
                if ("function" === typeof t) return t.bind(_this);
                return noMatchTemplate || function() {
                  return "";
                }.bind(_this);
              }(noMatchTemplate),
              lookup,
              fillAttr,
              values,
              requireLeadingSpace,
              searchOpts,
              menuItemLimit
            } ]; else if (collection) {
              if (this.autocompleteMode) console.warn("Tribute in autocomplete mode does not work for collections");
              this.collection = collection.map((function(item) {
                return {
                  trigger: item.trigger || trigger,
                  iframe: item.iframe || iframe,
                  selectClass: item.selectClass || selectClass,
                  containerClass: item.containerClass || containerClass,
                  itemClass: item.itemClass || itemClass,
                  selectTemplate: (item.selectTemplate || Tribute.defaultSelectTemplate).bind(_this),
                  menuItemTemplate: (item.menuItemTemplate || Tribute.defaultMenuItemTemplate).bind(_this),
                  noMatchTemplate: function(t) {
                    if ("function" === typeof t) return t.bind(_this);
                    return null;
                  }(noMatchTemplate),
                  lookup: item.lookup || lookup,
                  fillAttr: item.fillAttr || fillAttr,
                  values: item.values,
                  requireLeadingSpace: item.requireLeadingSpace,
                  searchOpts: item.searchOpts || searchOpts,
                  menuItemLimit: item.menuItemLimit || menuItemLimit
                };
              }));
            } else throw new Error("[Tribute] No collection specified.");
            new _TributeRange["default"](this);
            new _TributeEvents["default"](this);
            new _TributeMenuEvents["default"](this);
            new _TributeSearch["default"](this);
          }
          _createClass(Tribute, [ {
            key: "triggers",
            value: function() {
              return this.collection.map((function(config) {
                return config.trigger;
              }));
            }
          }, {
            key: "attach",
            value: function(el) {
              if (!el) throw new Error("[Tribute] Must pass in a DOM node or NodeList.");
              if ("undefined" !== typeof jQuery && el instanceof jQuery) el = el.get();
              if (el.constructor === NodeList || el.constructor === HTMLCollection || el.constructor === Array) {
                var length = el.length;
                for (var i = 0; i < length; ++i) this._attach(el[i]);
              } else this._attach(el);
            }
          }, {
            key: "_attach",
            value: function(el) {
              if (el.hasAttribute("data-tribute")) console.warn("Tribute was already bound to " + el.nodeName);
              this.ensureEditable(el);
              this.events.bind(el);
              el.setAttribute("data-tribute", true);
            }
          }, {
            key: "ensureEditable",
            value: function(element) {
              if (-1 === Tribute.inputTypes().indexOf(element.nodeName)) if (element.contentEditable) element.contentEditable = true; else throw new Error("[Tribute] Cannot bind to " + element.nodeName);
            }
          }, {
            key: "createMenu",
            value: function(containerClass) {
              var wrapper = this.range.getDocument().createElement("div"), ul = this.range.getDocument().createElement("ul");
              wrapper.className = containerClass;
              wrapper.appendChild(ul);
              if (this.menuContainer) return this.menuContainer.appendChild(wrapper);
              return this.range.getDocument().body.appendChild(wrapper);
            }
          }, {
            key: "showMenuFor",
            value: function(element, scrollTo) {
              var _this2 = this;
              if (this.isActive && this.current.element === element && this.current.mentionText === this.currentMentionTextSnapshot) return;
              this.currentMentionTextSnapshot = this.current.mentionText;
              if (!this.menu) {
                this.menu = this.createMenu(this.current.collection.containerClass);
                element.tributeMenu = this.menu;
                this.menuEvents.bind(this.menu);
              }
              this.isActive = true;
              this.menuSelected = 0;
              if (!this.current.mentionText) this.current.mentionText = "";
              var processValues = function(values) {
                if (!_this2.isActive) return;
                var items = _this2.search.filter(_this2.current.mentionText, values, {
                  pre: _this2.current.collection.searchOpts.pre || "<span>",
                  post: _this2.current.collection.searchOpts.post || "</span>",
                  skip: _this2.current.collection.searchOpts.skip,
                  extract: function(el) {
                    if ("string" === typeof _this2.current.collection.lookup) return el[_this2.current.collection.lookup]; else if ("function" === typeof _this2.current.collection.lookup) return _this2.current.collection.lookup(el, _this2.current.mentionText); else throw new Error("Invalid lookup attribute, lookup must be string or function.");
                  }
                });
                if (_this2.current.collection.menuItemLimit) items = items.slice(0, _this2.current.collection.menuItemLimit);
                _this2.current.filteredItems = items;
                var ul = _this2.menu.querySelector("ul");
                _this2.range.positionMenuAtCaret(scrollTo);
                if (!items.length) {
                  var noMatchEvent = new CustomEvent("tribute-no-match", {
                    detail: _this2.menu
                  });
                  _this2.current.element.dispatchEvent(noMatchEvent);
                  if ("function" === typeof _this2.current.collection.noMatchTemplate && !_this2.current.collection.noMatchTemplate() || !_this2.current.collection.noMatchTemplate) _this2.hideMenu(); else "function" === typeof _this2.current.collection.noMatchTemplate ? ul.innerHTML = _this2.current.collection.noMatchTemplate() : ul.innerHTML = _this2.current.collection.noMatchTemplate;
                  return;
                }
                ul.innerHTML = "";
                var fragment = _this2.range.getDocument().createDocumentFragment();
                items.forEach((function(item, index) {
                  var li = _this2.range.getDocument().createElement("li");
                  li.setAttribute("data-index", index);
                  li.className = _this2.current.collection.itemClass;
                  li.addEventListener("mousemove", (function(e) {
                    var _this2$_findLiTarget = _this2._findLiTarget(e.target), _this2$_findLiTarget2 = _slicedToArray(_this2$_findLiTarget, 2), index = (_this2$_findLiTarget2[0], 
                    _this2$_findLiTarget2[1]);
                    if (0 !== e.movementY) _this2.events.setActiveLi(index);
                  }));
                  if (_this2.menuSelected === index) li.classList.add(_this2.current.collection.selectClass);
                  li.innerHTML = _this2.current.collection.menuItemTemplate(item);
                  fragment.appendChild(li);
                }));
                ul.appendChild(fragment);
              };
              if ("function" === typeof this.current.collection.values) this.current.collection.values(this.current.mentionText, processValues); else processValues(this.current.collection.values);
            }
          }, {
            key: "_findLiTarget",
            value: function(el) {
              if (!el) return [];
              var index = el.getAttribute("data-index");
              return !index ? this._findLiTarget(el.parentNode) : [ el, index ];
            }
          }, {
            key: "showMenuForCollection",
            value: function(element, collectionIndex) {
              if (element !== document.activeElement) this.placeCaretAtEnd(element);
              this.current.collection = this.collection[collectionIndex || 0];
              this.current.externalTrigger = true;
              this.current.element = element;
              if (element.isContentEditable) this.insertTextAtCursor(this.current.collection.trigger); else this.insertAtCaret(element, this.current.collection.trigger);
              this.showMenuFor(element);
            }
          }, {
            key: "placeCaretAtEnd",
            value: function(el) {
              el.focus();
              if ("undefined" != typeof window.getSelection && "undefined" != typeof document.createRange) {
                var range = document.createRange();
                range.selectNodeContents(el);
                range.collapse(false);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
              } else if ("undefined" != typeof document.body.createTextRange) {
                var textRange = document.body.createTextRange();
                textRange.moveToElementText(el);
                textRange.collapse(false);
                textRange.select();
              }
            }
          }, {
            key: "insertTextAtCursor",
            value: function(text) {
              var sel, range;
              sel = window.getSelection();
              range = sel.getRangeAt(0);
              range.deleteContents();
              var textNode = document.createTextNode(text);
              range.insertNode(textNode);
              range.selectNodeContents(textNode);
              range.collapse(false);
              sel.removeAllRanges();
              sel.addRange(range);
            }
          }, {
            key: "insertAtCaret",
            value: function(textarea, text) {
              var scrollPos = textarea.scrollTop;
              var caretPos = textarea.selectionStart;
              var front = textarea.value.substring(0, caretPos);
              var back = textarea.value.substring(textarea.selectionEnd, textarea.value.length);
              textarea.value = front + text + back;
              caretPos += text.length;
              textarea.selectionStart = caretPos;
              textarea.selectionEnd = caretPos;
              textarea.focus();
              textarea.scrollTop = scrollPos;
            }
          }, {
            key: "hideMenu",
            value: function() {
              if (this.menu) {
                this.menu.style.cssText = "display: none;";
                this.isActive = false;
                this.menuSelected = 0;
                this.current = {};
              }
            }
          }, {
            key: "selectItemAtIndex",
            value: function(index, originalEvent) {
              index = parseInt(index);
              if ("number" !== typeof index || isNaN(index)) return;
              var item = this.current.filteredItems[index];
              var content = this.current.collection.selectTemplate(item);
              if (null !== content) this.replaceText(content, originalEvent, item);
            }
          }, {
            key: "replaceText",
            value: function(content, originalEvent, item) {
              this.range.replaceTriggerText(content, true, true, originalEvent, item);
            }
          }, {
            key: "_append",
            value: function(collection, newValues, replace) {
              if ("function" === typeof collection.values) throw new Error("Unable to append to values, as it is a function."); else if (!replace) collection.values = collection.values.concat(newValues); else collection.values = newValues;
            }
          }, {
            key: "append",
            value: function(collectionIndex, newValues, replace) {
              var index = parseInt(collectionIndex);
              if ("number" !== typeof index) throw new Error("please provide an index for the collection to update.");
              var collection = this.collection[index];
              this._append(collection, newValues, replace);
            }
          }, {
            key: "appendCurrent",
            value: function(newValues, replace) {
              if (this.isActive) this._append(this.current.collection, newValues, replace); else throw new Error("No active state. Please use append instead and pass an index.");
            }
          }, {
            key: "detach",
            value: function(el) {
              if (!el) throw new Error("[Tribute] Must pass in a DOM node or NodeList.");
              if ("undefined" !== typeof jQuery && el instanceof jQuery) el = el.get();
              if (el.constructor === NodeList || el.constructor === HTMLCollection || el.constructor === Array) {
                var length = el.length;
                for (var i = 0; i < length; ++i) this._detach(el[i]);
              } else this._detach(el);
            }
          }, {
            key: "_detach",
            value: function(el) {
              var _this3 = this;
              this.events.unbind(el);
              if (el.tributeMenu) this.menuEvents.unbind(el.tributeMenu);
              setTimeout((function() {
                el.removeAttribute("data-tribute");
                _this3.isActive = false;
                if (el.tributeMenu) el.tributeMenu.remove();
              }));
            }
          } ], [ {
            key: "defaultSelectTemplate",
            value: function(item) {
              if ("undefined" === typeof item) return null;
              if (this.range.isContentEditable(this.current.element)) return '<span class="tribute-mention">' + (this.current.collection.trigger + item.original[this.current.collection.fillAttr]) + "</span>";
              return this.current.collection.trigger + item.original[this.current.collection.fillAttr];
            }
          }, {
            key: "defaultMenuItemTemplate",
            value: function(matchItem) {
              return matchItem.string;
            }
          }, {
            key: "inputTypes",
            value: function() {
              return [ "TEXTAREA", "INPUT" ];
            }
          } ]);
          return Tribute;
        }();
        var _default = Tribute;
        exports["default"] = _default;
        module.exports = exports.default;
      }, {
        "./TributeEvents": 2,
        "./TributeMenuEvents": 3,
        "./TributeRange": 4,
        "./TributeSearch": 5,
        "./utils": 7
      } ],
      2: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        function _createClass(Constructor, protoProps, staticProps) {
          if (protoProps) _defineProperties(Constructor.prototype, protoProps);
          if (staticProps) _defineProperties(Constructor, staticProps);
          return Constructor;
        }
        var TributeEvents = function() {
          function TributeEvents(tribute) {
            _classCallCheck(this, TributeEvents);
            this.tribute = tribute;
            this.tribute.events = this;
          }
          _createClass(TributeEvents, [ {
            key: "bind",
            value: function(element) {
              element.boundKeydown = this.keydown.bind(element, this);
              element.boundKeyup = this.keyup.bind(element, this);
              element.boundInput = this.input.bind(element, this);
              element.addEventListener("keydown", element.boundKeydown, false);
              element.addEventListener("keyup", element.boundKeyup, false);
              element.addEventListener("input", element.boundInput, false);
            }
          }, {
            key: "unbind",
            value: function(element) {
              element.removeEventListener("keydown", element.boundKeydown, false);
              element.removeEventListener("keyup", element.boundKeyup, false);
              element.removeEventListener("input", element.boundInput, false);
              delete element.boundKeydown;
              delete element.boundKeyup;
              delete element.boundInput;
            }
          }, {
            key: "keydown",
            value: function(instance, event) {
              if (instance.shouldDeactivate(event)) {
                instance.tribute.isActive = false;
                instance.tribute.hideMenu();
              }
              var element = this;
              instance.commandEvent = false;
              TributeEvents.keys().forEach((function(o) {
                if (o.key === event.keyCode) {
                  instance.commandEvent = true;
                  instance.callbacks()[o.value.toLowerCase()](event, element);
                }
              }));
            }
          }, {
            key: "input",
            value: function(instance, event) {
              instance.inputEvent = true;
              instance.keyup.call(this, instance, event);
            }
          }, {
            key: "click",
            value: function(instance, event) {
              var tribute = instance.tribute;
              if (tribute.menu && tribute.menu.contains(event.target)) {
                var li = event.target;
                event.preventDefault();
                event.stopPropagation();
                while ("li" !== li.nodeName.toLowerCase()) {
                  li = li.parentNode;
                  if (!li || li === tribute.menu) throw new Error("cannot find the <li> container for the click");
                }
                tribute.selectItemAtIndex(li.getAttribute("data-index"), event);
                tribute.hideMenu();
              } else if (tribute.current.element && !tribute.current.externalTrigger) {
                tribute.current.externalTrigger = false;
                setTimeout((function() {
                  return tribute.hideMenu();
                }));
              }
            }
          }, {
            key: "keyup",
            value: function(instance, event) {
              if (instance.inputEvent) instance.inputEvent = false;
              instance.updateSelection(this);
              if (27 === event.keyCode) return;
              if (!instance.tribute.allowSpaces && instance.tribute.hasTrailingSpace) {
                instance.tribute.hasTrailingSpace = false;
                instance.commandEvent = true;
                instance.callbacks()["space"](event, this);
                return;
              }
              if (!instance.tribute.isActive) if (instance.tribute.autocompleteMode) instance.callbacks().triggerChar(event, this, ""); else {
                var keyCode = instance.getKeyCode(instance, this, event);
                if (isNaN(keyCode) || !keyCode) return;
                var trigger = instance.tribute.triggers().find((function(trigger) {
                  return trigger.charCodeAt(0) === keyCode;
                }));
                if ("undefined" !== typeof trigger) instance.callbacks().triggerChar(event, this, trigger);
              }
              if ((instance.tribute.current.trigger || instance.tribute.autocompleteMode) && false === instance.commandEvent || instance.tribute.isActive && 8 === event.keyCode) instance.tribute.showMenuFor(this, true);
            }
          }, {
            key: "shouldDeactivate",
            value: function(event) {
              if (!this.tribute.isActive) return false;
              if (0 === this.tribute.current.mentionText.length) {
                var eventKeyPressed = false;
                TributeEvents.keys().forEach((function(o) {
                  if (event.keyCode === o.key) eventKeyPressed = true;
                }));
                return !eventKeyPressed;
              }
              return false;
            }
          }, {
            key: "getKeyCode",
            value: function(instance, el, event) {
              var tribute = instance.tribute;
              var info = tribute.range.getTriggerInfo(false, tribute.hasTrailingSpace, true, tribute.allowSpaces, tribute.autocompleteMode);
              if (info) return info.mentionTriggerChar.charCodeAt(0); else return false;
            }
          }, {
            key: "updateSelection",
            value: function(el) {
              this.tribute.current.element = el;
              var info = this.tribute.range.getTriggerInfo(false, this.tribute.hasTrailingSpace, true, this.tribute.allowSpaces, this.tribute.autocompleteMode);
              if (info) {
                this.tribute.current.selectedPath = info.mentionSelectedPath;
                this.tribute.current.mentionText = info.mentionText;
                this.tribute.current.selectedOffset = info.mentionSelectedOffset;
              }
            }
          }, {
            key: "callbacks",
            value: function() {
              var _this = this;
              return {
                triggerChar: function(e, el, trigger) {
                  var tribute = _this.tribute;
                  tribute.current.trigger = trigger;
                  var collectionItem = tribute.collection.find((function(item) {
                    return item.trigger === trigger;
                  }));
                  tribute.current.collection = collectionItem;
                  if (tribute.inputEvent) tribute.showMenuFor(el, true);
                },
                enter: function(e, el) {
                  if (_this.tribute.isActive && _this.tribute.current.filteredItems) {
                    e.preventDefault();
                    e.stopPropagation();
                    setTimeout((function() {
                      _this.tribute.selectItemAtIndex(_this.tribute.menuSelected, e);
                      _this.tribute.hideMenu();
                    }), 0);
                  }
                },
                escape: function(e, el) {
                  if (_this.tribute.isActive) {
                    e.preventDefault();
                    e.stopPropagation();
                    _this.tribute.isActive = false;
                    _this.tribute.hideMenu();
                  }
                },
                tab: function(e, el) {
                  _this.callbacks().enter(e, el);
                },
                space: function(e, el) {
                  if (_this.tribute.isActive) if (_this.tribute.spaceSelectsMatch) _this.callbacks().enter(e, el); else if (!_this.tribute.allowSpaces) {
                    e.stopPropagation();
                    setTimeout((function() {
                      _this.tribute.hideMenu();
                      _this.tribute.isActive = false;
                    }), 0);
                  }
                },
                up: function(e, el) {
                  if (_this.tribute.isActive && _this.tribute.current.filteredItems) {
                    e.preventDefault();
                    e.stopPropagation();
                    var count = _this.tribute.current.filteredItems.length, selected = _this.tribute.menuSelected;
                    if (count > selected && selected > 0) {
                      _this.tribute.menuSelected--;
                      _this.setActiveLi();
                    } else if (0 === selected) {
                      _this.tribute.menuSelected = count - 1;
                      _this.setActiveLi();
                      _this.tribute.menu.scrollTop = _this.tribute.menu.scrollHeight;
                    }
                  }
                },
                down: function(e, el) {
                  if (_this.tribute.isActive && _this.tribute.current.filteredItems) {
                    e.preventDefault();
                    e.stopPropagation();
                    var count = _this.tribute.current.filteredItems.length - 1, selected = _this.tribute.menuSelected;
                    if (count > selected) {
                      _this.tribute.menuSelected++;
                      _this.setActiveLi();
                    } else if (count === selected) {
                      _this.tribute.menuSelected = 0;
                      _this.setActiveLi();
                      _this.tribute.menu.scrollTop = 0;
                    }
                  }
                },
                delete: function(e, el) {
                  if (_this.tribute.isActive && _this.tribute.current.mentionText.length < 1) _this.tribute.hideMenu(); else if (_this.tribute.isActive) _this.tribute.showMenuFor(el);
                }
              };
            }
          }, {
            key: "setActiveLi",
            value: function(index) {
              var lis = this.tribute.menu.querySelectorAll("li"), length = lis.length >>> 0;
              if (index) this.tribute.menuSelected = parseInt(index);
              for (var i = 0; i < length; i++) {
                var li = lis[i];
                if (i === this.tribute.menuSelected) {
                  li.classList.add(this.tribute.current.collection.selectClass);
                  var liClientRect = li.getBoundingClientRect();
                  var menuClientRect = this.tribute.menu.getBoundingClientRect();
                  if (liClientRect.bottom > menuClientRect.bottom) {
                    var scrollDistance = liClientRect.bottom - menuClientRect.bottom;
                    this.tribute.menu.scrollTop += scrollDistance;
                  } else if (liClientRect.top < menuClientRect.top) {
                    var _scrollDistance = menuClientRect.top - liClientRect.top;
                    this.tribute.menu.scrollTop -= _scrollDistance;
                  }
                } else li.classList.remove(this.tribute.current.collection.selectClass);
              }
            }
          }, {
            key: "getFullHeight",
            value: function(elem, includeMargin) {
              var height = elem.getBoundingClientRect().height;
              if (includeMargin) {
                var style = elem.currentStyle || window.getComputedStyle(elem);
                return height + parseFloat(style.marginTop) + parseFloat(style.marginBottom);
              }
              return height;
            }
          } ], [ {
            key: "keys",
            value: function() {
              return [ {
                key: 9,
                value: "TAB"
              }, {
                key: 8,
                value: "DELETE"
              }, {
                key: 13,
                value: "ENTER"
              }, {
                key: 27,
                value: "ESCAPE"
              }, {
                key: 32,
                value: "SPACE"
              }, {
                key: 38,
                value: "UP"
              }, {
                key: 40,
                value: "DOWN"
              } ];
            }
          } ]);
          return TributeEvents;
        }();
        var _default = TributeEvents;
        exports["default"] = _default;
        module.exports = exports.default;
      }, {} ],
      3: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        function _createClass(Constructor, protoProps, staticProps) {
          if (protoProps) _defineProperties(Constructor.prototype, protoProps);
          if (staticProps) _defineProperties(Constructor, staticProps);
          return Constructor;
        }
        var TributeMenuEvents = function() {
          function TributeMenuEvents(tribute) {
            _classCallCheck(this, TributeMenuEvents);
            this.tribute = tribute;
            this.tribute.menuEvents = this;
            this.menu = this.tribute.menu;
          }
          _createClass(TributeMenuEvents, [ {
            key: "bind",
            value: function(menu) {
              var _this = this;
              this.menuClickEvent = this.tribute.events.click.bind(null, this);
              this.menuContainerScrollEvent = this.debounce((function() {
                if (_this.tribute.isActive) _this.tribute.showMenuFor(_this.tribute.current.element, false);
              }), 300, false);
              this.windowResizeEvent = this.debounce((function() {
                if (_this.tribute.isActive) _this.tribute.range.positionMenuAtCaret(true);
              }), 300, false);
              this.tribute.range.getDocument().addEventListener("MSPointerDown", this.menuClickEvent, false);
              this.tribute.range.getDocument().addEventListener("mousedown", this.menuClickEvent, false);
              window.addEventListener("resize", this.windowResizeEvent);
              if (this.menuContainer) this.menuContainer.addEventListener("scroll", this.menuContainerScrollEvent, false); else window.addEventListener("scroll", this.menuContainerScrollEvent);
            }
          }, {
            key: "unbind",
            value: function(menu) {
              this.tribute.range.getDocument().removeEventListener("mousedown", this.menuClickEvent, false);
              this.tribute.range.getDocument().removeEventListener("MSPointerDown", this.menuClickEvent, false);
              window.removeEventListener("resize", this.windowResizeEvent);
              if (this.menuContainer) this.menuContainer.removeEventListener("scroll", this.menuContainerScrollEvent, false); else window.removeEventListener("scroll", this.menuContainerScrollEvent);
            }
          }, {
            key: "debounce",
            value: function(func, wait, immediate) {
              var _this2 = this, _arguments = arguments;
              var timeout;
              return function() {
                var context = _this2, args = _arguments;
                var later = function() {
                  timeout = null;
                  if (!immediate) func.apply(context, args);
                };
                var callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
              };
            }
          } ]);
          return TributeMenuEvents;
        }();
        var _default = TributeMenuEvents;
        exports["default"] = _default;
        module.exports = exports.default;
      }, {} ],
      4: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        require("./utils");
        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        function _createClass(Constructor, protoProps, staticProps) {
          if (protoProps) _defineProperties(Constructor.prototype, protoProps);
          if (staticProps) _defineProperties(Constructor, staticProps);
          return Constructor;
        }
        var TributeRange = function() {
          function TributeRange(tribute) {
            _classCallCheck(this, TributeRange);
            this.tribute = tribute;
            this.tribute.range = this;
          }
          _createClass(TributeRange, [ {
            key: "getDocument",
            value: function() {
              var iframe;
              if (this.tribute.current.collection) iframe = this.tribute.current.collection.iframe;
              if (!iframe) return document;
              return iframe.contentWindow.document;
            }
          }, {
            key: "positionMenuAtCaret",
            value: function(scrollTo) {
              var _this = this;
              var coordinates, context = this.tribute.current;
              var info = this.getTriggerInfo(false, this.tribute.hasTrailingSpace, true, this.tribute.allowSpaces, this.tribute.autocompleteMode);
              if ("undefined" !== typeof info) {
                if (!this.tribute.positionMenu) {
                  this.tribute.menu.style.cssText = "display: block;";
                  return;
                }
                if (!this.isContentEditable(context.element)) coordinates = this.getTextAreaOrInputUnderlinePosition(this.tribute.current.element, info.mentionPosition); else coordinates = this.getContentEditableCaretPosition(info.mentionPosition);
                this.tribute.menu.style.cssText = "top: ".concat(coordinates.top, "px;\n                                     left: ").concat(coordinates.left, "px;\n                                     right: ").concat(coordinates.right, "px;\n                                     bottom: ").concat(coordinates.bottom, "px;\n                                     position: absolute;\n                                     display: block;");
                if ("auto" === coordinates.left) this.tribute.menu.style.left = "auto";
                if ("auto" === coordinates.top) this.tribute.menu.style.top = "auto";
                if (scrollTo) this.scrollIntoView();
                window.setTimeout((function() {
                  var menuDimensions = {
                    width: _this.tribute.menu.offsetWidth,
                    height: _this.tribute.menu.offsetHeight
                  };
                  var menuIsOffScreen = _this.isMenuOffScreen(coordinates, menuDimensions);
                  var menuIsOffScreenHorizontally = window.innerWidth > menuDimensions.width && (menuIsOffScreen.left || menuIsOffScreen.right);
                  var menuIsOffScreenVertically = window.innerHeight > menuDimensions.height && (menuIsOffScreen.top || menuIsOffScreen.bottom);
                  if (menuIsOffScreenHorizontally || menuIsOffScreenVertically) {
                    _this.tribute.menu.style.cssText = "display: none";
                    _this.positionMenuAtCaret(scrollTo);
                  }
                }), 0);
              } else this.tribute.menu.style.cssText = "display: none";
            }
          }, {
            key: "selectElement",
            value: function(targetElement, path, offset) {
              var range;
              var elem = targetElement;
              if (path) for (var i = 0; i < path.length; i++) {
                elem = elem.childNodes[path[i]];
                if (void 0 === elem) return;
                while (elem.length < offset) {
                  offset -= elem.length;
                  elem = elem.nextSibling;
                }
                if (0 === elem.childNodes.length && !elem.length) elem = elem.previousSibling;
              }
              var sel = this.getWindowSelection();
              range = this.getDocument().createRange();
              range.setStart(elem, offset);
              range.setEnd(elem, offset);
              range.collapse(true);
              try {
                sel.removeAllRanges();
              } catch (error) {}
              sel.addRange(range);
              targetElement.focus();
            }
          }, {
            key: "replaceTriggerText",
            value: function(text, requireLeadingSpace, hasTrailingSpace, originalEvent, item) {
              var info = this.getTriggerInfo(true, hasTrailingSpace, requireLeadingSpace, this.tribute.allowSpaces, this.tribute.autocompleteMode);
              if (void 0 !== info) {
                var context = this.tribute.current;
                var replaceEvent = new CustomEvent("tribute-replaced", {
                  detail: {
                    item,
                    instance: context,
                    context: info,
                    event: originalEvent
                  }
                });
                if (!this.isContentEditable(context.element)) {
                  var myField = this.tribute.current.element;
                  var textSuffix = "string" == typeof this.tribute.replaceTextSuffix ? this.tribute.replaceTextSuffix : " ";
                  text += textSuffix;
                  var startPos = info.mentionPosition;
                  var endPos = info.mentionPosition + info.mentionText.length + textSuffix.length;
                  if (!this.tribute.autocompleteMode) endPos += info.mentionTriggerChar.length - 1;
                  myField.value = myField.value.substring(0, startPos) + text + myField.value.substring(endPos, myField.value.length);
                  myField.selectionStart = startPos + text.length;
                  myField.selectionEnd = startPos + text.length;
                } else {
                  var _textSuffix = "string" == typeof this.tribute.replaceTextSuffix ? this.tribute.replaceTextSuffix : " ";
                  text += _textSuffix;
                  var _endPos = info.mentionPosition + info.mentionText.length;
                  if (!this.tribute.autocompleteMode) _endPos += info.mentionTriggerChar.length;
                  this.pasteHtml(text, info.mentionPosition, _endPos);
                }
                context.element.dispatchEvent(new CustomEvent("input", {
                  bubbles: true
                }));
                context.element.dispatchEvent(replaceEvent);
              }
            }
          }, {
            key: "pasteHtml",
            value: function(html, startPos, endPos) {
              var range, sel;
              sel = this.getWindowSelection();
              range = this.getDocument().createRange();
              range.setStart(sel.anchorNode, startPos);
              range.setEnd(sel.anchorNode, endPos);
              range.deleteContents();
              var el = this.getDocument().createElement("div");
              el.innerHTML = html;
              var node, lastNode, frag = this.getDocument().createDocumentFragment();
              while (node = el.firstChild) lastNode = frag.appendChild(node);
              range.insertNode(frag);
              if (lastNode) {
                range = range.cloneRange();
                range.setStartAfter(lastNode);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
              }
            }
          }, {
            key: "getWindowSelection",
            value: function() {
              if (this.tribute.collection.iframe) return this.tribute.collection.iframe.contentWindow.getSelection();
              return window.getSelection();
            }
          }, {
            key: "getNodePositionInParent",
            value: function(element) {
              if (null === element.parentNode) return 0;
              for (var i = 0; i < element.parentNode.childNodes.length; i++) {
                var node = element.parentNode.childNodes[i];
                if (node === element) return i;
              }
            }
          }, {
            key: "getContentEditableSelectedPath",
            value: function(ctx) {
              var sel = this.getWindowSelection();
              var selected = sel.anchorNode;
              var path = [];
              var offset;
              if (null != selected) {
                var i;
                var ce = selected.contentEditable;
                while (null !== selected && "true" !== ce) {
                  i = this.getNodePositionInParent(selected);
                  path.push(i);
                  selected = selected.parentNode;
                  if (null !== selected) ce = selected.contentEditable;
                }
                path.reverse();
                offset = sel.getRangeAt(0).startOffset;
                return {
                  selected,
                  path,
                  offset
                };
              }
            }
          }, {
            key: "getTextPrecedingCurrentSelection",
            value: function() {
              var context = this.tribute.current, text = "";
              if (!this.isContentEditable(context.element)) {
                var textComponent = this.tribute.current.element;
                if (textComponent) {
                  var startPos = textComponent.selectionStart;
                  if (textComponent.value && startPos >= 0) text = textComponent.value.substring(0, startPos);
                }
              } else {
                var selectedElem = this.getWindowSelection().anchorNode;
                if (null != selectedElem) {
                  var workingNodeContent = selectedElem.textContent;
                  var selectStartOffset = this.getWindowSelection().getRangeAt(0).startOffset;
                  if (workingNodeContent && selectStartOffset >= 0) text = workingNodeContent.substring(0, selectStartOffset);
                }
              }
              return text;
            }
          }, {
            key: "getLastWordInText",
            value: function(text) {
              text = text.replace(/\u00A0/g, " ");
              var wordsArray = text.split(/\s+/);
              var worldsCount = wordsArray.length - 1;
              return wordsArray[worldsCount].trim();
            }
          }, {
            key: "getTriggerInfo",
            value: function(menuAlreadyActive, hasTrailingSpace, requireLeadingSpace, allowSpaces, isAutocomplete) {
              var _this2 = this;
              var ctx = this.tribute.current;
              var selected, path, offset;
              if (!this.isContentEditable(ctx.element)) selected = this.tribute.current.element; else {
                var selectionInfo = this.getContentEditableSelectedPath(ctx);
                if (selectionInfo) {
                  selected = selectionInfo.selected;
                  path = selectionInfo.path;
                  offset = selectionInfo.offset;
                }
              }
              var effectiveRange = this.getTextPrecedingCurrentSelection();
              var lastWordOfEffectiveRange = this.getLastWordInText(effectiveRange);
              if (isAutocomplete) return {
                mentionPosition: effectiveRange.length - lastWordOfEffectiveRange.length,
                mentionText: lastWordOfEffectiveRange,
                mentionSelectedElement: selected,
                mentionSelectedPath: path,
                mentionSelectedOffset: offset
              };
              if (void 0 !== effectiveRange && null !== effectiveRange) {
                var mostRecentTriggerCharPos = -1;
                var triggerChar;
                this.tribute.collection.forEach((function(config) {
                  var c = config.trigger;
                  var idx = config.requireLeadingSpace ? _this2.lastIndexWithLeadingSpace(effectiveRange, c) : effectiveRange.lastIndexOf(c);
                  if (idx > mostRecentTriggerCharPos) {
                    mostRecentTriggerCharPos = idx;
                    triggerChar = c;
                    requireLeadingSpace = config.requireLeadingSpace;
                  }
                }));
                if (mostRecentTriggerCharPos >= 0 && (0 === mostRecentTriggerCharPos || !requireLeadingSpace || /[\xA0\s]/g.test(effectiveRange.substring(mostRecentTriggerCharPos - 1, mostRecentTriggerCharPos)))) {
                  var currentTriggerSnippet = effectiveRange.substring(mostRecentTriggerCharPos + triggerChar.length, effectiveRange.length);
                  triggerChar = effectiveRange.substring(mostRecentTriggerCharPos, mostRecentTriggerCharPos + triggerChar.length);
                  var firstSnippetChar = currentTriggerSnippet.substring(0, 1);
                  var leadingSpace = currentTriggerSnippet.length > 0 && (" " === firstSnippetChar || " " === firstSnippetChar);
                  if (hasTrailingSpace) currentTriggerSnippet = currentTriggerSnippet.trim();
                  var regex = allowSpaces ? /[^\S ]/g : /[\xA0\s]/g;
                  this.tribute.hasTrailingSpace = regex.test(currentTriggerSnippet);
                  if (!leadingSpace && (menuAlreadyActive || !regex.test(currentTriggerSnippet))) return {
                    mentionPosition: mostRecentTriggerCharPos,
                    mentionText: currentTriggerSnippet,
                    mentionSelectedElement: selected,
                    mentionSelectedPath: path,
                    mentionSelectedOffset: offset,
                    mentionTriggerChar: triggerChar
                  };
                }
              }
            }
          }, {
            key: "lastIndexWithLeadingSpace",
            value: function(str, trigger) {
              var reversedStr = str.split("").reverse().join("");
              var index = -1;
              for (var cidx = 0, len = str.length; cidx < len; cidx++) {
                var firstChar = cidx === str.length - 1;
                var leadingSpace = /\s/.test(reversedStr[cidx + 1]);
                var match = true;
                for (var triggerIdx = trigger.length - 1; triggerIdx >= 0; triggerIdx--) if (trigger[triggerIdx] !== reversedStr[cidx - triggerIdx]) {
                  match = false;
                  break;
                }
                if (match && (firstChar || leadingSpace)) {
                  index = str.length - 1 - cidx;
                  break;
                }
              }
              return index;
            }
          }, {
            key: "isContentEditable",
            value: function(element) {
              return "INPUT" !== element.nodeName && "TEXTAREA" !== element.nodeName;
            }
          }, {
            key: "isMenuOffScreen",
            value: function(coordinates, menuDimensions) {
              var windowWidth = window.innerWidth;
              var windowHeight = window.innerHeight;
              var doc = document.documentElement;
              var windowLeft = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
              var windowTop = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
              var menuTop = "number" === typeof coordinates.top ? coordinates.top : windowTop + windowHeight - coordinates.bottom - menuDimensions.height;
              var menuRight = "number" === typeof coordinates.right ? coordinates.right : coordinates.left + menuDimensions.width;
              var menuBottom = "number" === typeof coordinates.bottom ? coordinates.bottom : coordinates.top + menuDimensions.height;
              var menuLeft = "number" === typeof coordinates.left ? coordinates.left : windowLeft + windowWidth - coordinates.right - menuDimensions.width;
              return {
                top: menuTop < Math.floor(windowTop),
                right: menuRight > Math.ceil(windowLeft + windowWidth),
                bottom: menuBottom > Math.ceil(windowTop + windowHeight),
                left: menuLeft < Math.floor(windowLeft)
              };
            }
          }, {
            key: "getMenuDimensions",
            value: function() {
              var dimensions = {
                width: null,
                height: null
              };
              this.tribute.menu.style.cssText = "top: 0px;\n                                 left: 0px;\n                                 position: fixed;\n                                 display: block;\n                                 visibility; hidden;";
              dimensions.width = this.tribute.menu.offsetWidth;
              dimensions.height = this.tribute.menu.offsetHeight;
              this.tribute.menu.style.cssText = "display: none;";
              return dimensions;
            }
          }, {
            key: "getTextAreaOrInputUnderlinePosition",
            value: function(element, position, flipped) {
              var properties = [ "direction", "boxSizing", "width", "height", "overflowX", "overflowY", "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "fontStyle", "fontVariant", "fontWeight", "fontStretch", "fontSize", "fontSizeAdjust", "lineHeight", "fontFamily", "textAlign", "textTransform", "textIndent", "textDecoration", "letterSpacing", "wordSpacing" ];
              var isFirefox = null !== window.mozInnerScreenX;
              var div = this.getDocument().createElement("div");
              div.id = "input-textarea-caret-position-mirror-div";
              this.getDocument().body.appendChild(div);
              var style = div.style;
              var computed = window.getComputedStyle ? getComputedStyle(element) : element.currentStyle;
              style.whiteSpace = "pre-wrap";
              if ("INPUT" !== element.nodeName) style.wordWrap = "break-word";
              style.position = "absolute";
              style.visibility = "hidden";
              properties.forEach((function(prop) {
                style[prop] = computed[prop];
              }));
              if (isFirefox) {
                style.width = "".concat(parseInt(computed.width) - 2, "px");
                if (element.scrollHeight > parseInt(computed.height)) style.overflowY = "scroll";
              } else style.overflow = "hidden";
              div.textContent = element.value.substring(0, position);
              if ("INPUT" === element.nodeName) div.textContent = div.textContent.replace(/\s/g, " ");
              var span = this.getDocument().createElement("span");
              span.textContent = element.value.substring(position) || ".";
              div.appendChild(span);
              var rect = element.getBoundingClientRect();
              var doc = document.documentElement;
              var windowLeft = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
              var windowTop = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
              var top = 0;
              var left = 0;
              if (this.menuContainerIsBody) {
                top = rect.top;
                left = rect.left;
              }
              var coordinates = {
                top: top + windowTop + span.offsetTop + parseInt(computed.borderTopWidth) + parseInt(computed.fontSize) - element.scrollTop,
                left: left + windowLeft + span.offsetLeft + parseInt(computed.borderLeftWidth)
              };
              var windowWidth = window.innerWidth;
              var windowHeight = window.innerHeight;
              var menuDimensions = this.getMenuDimensions();
              var menuIsOffScreen = this.isMenuOffScreen(coordinates, menuDimensions);
              if (menuIsOffScreen.right) {
                coordinates.right = windowWidth - coordinates.left;
                coordinates.left = "auto";
              }
              var parentHeight = this.tribute.menuContainer ? this.tribute.menuContainer.offsetHeight : this.getDocument().body.offsetHeight;
              if (menuIsOffScreen.bottom) {
                var parentRect = this.tribute.menuContainer ? this.tribute.menuContainer.getBoundingClientRect() : this.getDocument().body.getBoundingClientRect();
                var scrollStillAvailable = parentHeight - (windowHeight - parentRect.top);
                coordinates.bottom = scrollStillAvailable + (windowHeight - rect.top - span.offsetTop);
                coordinates.top = "auto";
              }
              menuIsOffScreen = this.isMenuOffScreen(coordinates, menuDimensions);
              if (menuIsOffScreen.left) {
                coordinates.left = windowWidth > menuDimensions.width ? windowLeft + windowWidth - menuDimensions.width : windowLeft;
                delete coordinates.right;
              }
              if (menuIsOffScreen.top) {
                coordinates.top = windowHeight > menuDimensions.height ? windowTop + windowHeight - menuDimensions.height : windowTop;
                delete coordinates.bottom;
              }
              this.getDocument().body.removeChild(div);
              return coordinates;
            }
          }, {
            key: "getContentEditableCaretPosition",
            value: function(selectedNodePosition) {
              var range;
              var sel = this.getWindowSelection();
              range = this.getDocument().createRange();
              range.setStart(sel.anchorNode, selectedNodePosition);
              range.setEnd(sel.anchorNode, selectedNodePosition);
              range.collapse(false);
              var rect = range.getBoundingClientRect();
              var doc = document.documentElement;
              var windowLeft = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
              var windowTop = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
              var left = rect.left;
              var top = rect.top;
              var coordinates = {
                left: left + windowLeft,
                top: top + rect.height + windowTop
              };
              var windowWidth = window.innerWidth;
              var windowHeight = window.innerHeight;
              var menuDimensions = this.getMenuDimensions();
              var menuIsOffScreen = this.isMenuOffScreen(coordinates, menuDimensions);
              if (menuIsOffScreen.right) {
                coordinates.left = "auto";
                coordinates.right = windowWidth - rect.left - windowLeft;
              }
              var parentHeight = this.tribute.menuContainer ? this.tribute.menuContainer.offsetHeight : this.getDocument().body.offsetHeight;
              if (menuIsOffScreen.bottom) {
                var parentRect = this.tribute.menuContainer ? this.tribute.menuContainer.getBoundingClientRect() : this.getDocument().body.getBoundingClientRect();
                var scrollStillAvailable = parentHeight - (windowHeight - parentRect.top);
                coordinates.top = "auto";
                coordinates.bottom = scrollStillAvailable + (windowHeight - rect.top);
              }
              menuIsOffScreen = this.isMenuOffScreen(coordinates, menuDimensions);
              if (menuIsOffScreen.left) {
                coordinates.left = windowWidth > menuDimensions.width ? windowLeft + windowWidth - menuDimensions.width : windowLeft;
                delete coordinates.right;
              }
              if (menuIsOffScreen.top) {
                coordinates.top = windowHeight > menuDimensions.height ? windowTop + windowHeight - menuDimensions.height : windowTop;
                delete coordinates.bottom;
              }
              if (!this.menuContainerIsBody) {
                coordinates.left = coordinates.left ? coordinates.left - this.tribute.menuContainer.offsetLeft : coordinates.left;
                coordinates.top = coordinates.top ? coordinates.top - this.tribute.menuContainer.offsetTop : coordinates.top;
              }
              return coordinates;
            }
          }, {
            key: "scrollIntoView",
            value: function(elem) {
              var clientRect, reasonableBuffer = 20;
              var maxScrollDisplacement = 100;
              var e = this.menu;
              if ("undefined" === typeof e) return;
              while (void 0 === clientRect || 0 === clientRect.height) {
                clientRect = e.getBoundingClientRect();
                if (0 === clientRect.height) {
                  e = e.childNodes[0];
                  if (void 0 === e || !e.getBoundingClientRect) return;
                }
              }
              var elemTop = clientRect.top;
              var elemBottom = elemTop + clientRect.height;
              if (elemTop < 0) window.scrollTo(0, window.pageYOffset + clientRect.top - reasonableBuffer); else if (elemBottom > window.innerHeight) {
                var maxY = window.pageYOffset + clientRect.top - reasonableBuffer;
                if (maxY - window.pageYOffset > maxScrollDisplacement) maxY = window.pageYOffset + maxScrollDisplacement;
                var targetY = window.pageYOffset - (window.innerHeight - elemBottom);
                if (targetY > maxY) targetY = maxY;
                window.scrollTo(0, targetY);
              }
            }
          }, {
            key: "menuContainerIsBody",
            get: function() {
              return this.tribute.menuContainer === document.body || !this.tribute.menuContainer;
            }
          } ]);
          return TributeRange;
        }();
        var _default = TributeRange;
        exports["default"] = _default;
        module.exports = exports.default;
      }, {
        "./utils": 7
      } ],
      5: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        function _classCallCheck(instance, Constructor) {
          if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        function _createClass(Constructor, protoProps, staticProps) {
          if (protoProps) _defineProperties(Constructor.prototype, protoProps);
          if (staticProps) _defineProperties(Constructor, staticProps);
          return Constructor;
        }
        var TributeSearch = function() {
          function TributeSearch(tribute) {
            _classCallCheck(this, TributeSearch);
            this.tribute = tribute;
            this.tribute.search = this;
          }
          _createClass(TributeSearch, [ {
            key: "simpleFilter",
            value: function(pattern, array) {
              var _this = this;
              return array.filter((function(string) {
                return _this.test(pattern, string);
              }));
            }
          }, {
            key: "test",
            value: function(pattern, string) {
              return null !== this.match(pattern, string);
            }
          }, {
            key: "match",
            value: function(pattern, string, opts) {
              opts = opts || {};
              string.length;
              var pre = opts.pre || "", post = opts.post || "", compareString = opts.caseSensitive && string || string.toLowerCase();
              if (opts.skip) return {
                rendered: string,
                score: 0
              };
              pattern = opts.caseSensitive && pattern || pattern.toLowerCase();
              var patternCache = this.traverse(compareString, pattern, 0, 0, []);
              if (!patternCache) return null;
              return {
                rendered: this.render(string, patternCache.cache, pre, post),
                score: patternCache.score
              };
            }
          }, {
            key: "traverse",
            value: function(string, pattern, stringIndex, patternIndex, patternCache) {
              if (pattern.length === patternIndex) return {
                score: this.calculateScore(patternCache),
                cache: patternCache.slice()
              };
              if (string.length === stringIndex || pattern.length - patternIndex > string.length - stringIndex) return;
              var c = pattern[patternIndex];
              var index = string.indexOf(c, stringIndex);
              var best, temp;
              while (index > -1) {
                patternCache.push(index);
                temp = this.traverse(string, pattern, index + 1, patternIndex + 1, patternCache);
                patternCache.pop();
                if (!temp) return best;
                if (!best || best.score < temp.score) best = temp;
                index = string.indexOf(c, index + 1);
              }
              return best;
            }
          }, {
            key: "calculateScore",
            value: function(patternCache) {
              var score = 0;
              var temp = 1;
              patternCache.forEach((function(index, i) {
                if (i > 0) if (patternCache[i - 1] + 1 === index) temp += temp + 1; else temp = 1;
                score += temp;
              }));
              return score;
            }
          }, {
            key: "render",
            value: function(string, indices, pre, post) {
              var rendered = string.substring(0, indices[0]);
              indices.forEach((function(index, i) {
                rendered += pre + string[index] + post + string.substring(index + 1, indices[i + 1] ? indices[i + 1] : string.length);
              }));
              return rendered;
            }
          }, {
            key: "filter",
            value: function(pattern, arr, opts) {
              var _this2 = this;
              opts = opts || {};
              return arr.reduce((function(prev, element, idx, arr) {
                var str = element;
                if (opts.extract) {
                  str = opts.extract(element);
                  if (!str) str = "";
                }
                var rendered = _this2.match(pattern, str, opts);
                if (null != rendered) prev[prev.length] = {
                  string: rendered.rendered,
                  score: rendered.score,
                  index: idx,
                  original: element
                };
                return prev;
              }), []).sort((function(a, b) {
                var compare = b.score - a.score;
                if (compare) return compare;
                return a.index - b.index;
              }));
            }
          } ]);
          return TributeSearch;
        }();
        var _default = TributeSearch;
        exports["default"] = _default;
        module.exports = exports.default;
      }, {} ],
      6: [ function(require, module, exports) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
          value: true
        });
        exports["default"] = void 0;
        var _Tribute = _interopRequireDefault(require("./Tribute"));
        function _interopRequireDefault(obj) {
          return obj && obj.__esModule ? obj : {
            default: obj
          };
        }
        var _default = _Tribute["default"];
        exports["default"] = _default;
        module.exports = exports.default;
      }, {
        "./Tribute": 1
      } ],
      7: [ function(require, module, exports) {
        "use strict";
        if (!Array.prototype.find) Array.prototype.find = function(predicate) {
          if (null === this) throw new TypeError("Array.prototype.find called on null or undefined");
          if ("function" !== typeof predicate) throw new TypeError("predicate must be a function");
          var list = Object(this);
          var length = list.length >>> 0;
          var thisArg = arguments[1];
          var value;
          for (var i = 0; i < length; i++) {
            value = list[i];
            if (predicate.call(thisArg, value, i, list)) return value;
          }
          return;
        };
        if (window && "function" !== typeof window.CustomEvent) {
          var CustomEvent = function(event, params) {
            params = params || {
              bubbles: false,
              cancelable: false,
              detail: void 0
            };
            var evt = document.createEvent("CustomEvent");
            evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
            return evt;
          };
          if ("undefined" !== typeof window.Event) CustomEvent.prototype = window.Event.prototype;
          window.CustomEvent = CustomEvent;
        }
      }, {} ]
    }, {}, [ 6 ])(6);
  }));
}, function(module, exports, __webpack_require__) {
  "use strict";
  const arrayMoveMutate = (array, from, to) => {
    const startIndex = to < 0 ? array.length + to : to;
    const item = array.splice(from, 1)[0];
    array.splice(startIndex, 0, item);
  };
  const arrayMove = (array, from, to) => {
    array = array.slice();
    arrayMoveMutate(array, from, to);
    return array;
  };
  module.exports = arrayMove;
  module.exports.default = arrayMove;
  module.exports.mutate = arrayMoveMutate;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = void 0;
  var _react = _interopRequireDefault(__webpack_require__(4));
  var _propTypes = _interopRequireDefault(__webpack_require__(2));
  var _Portal = _interopRequireWildcard(__webpack_require__(96));
  var _position = _interopRequireDefault(__webpack_require__(46));
  var _functions = __webpack_require__(42);
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) return obj; else {
      var newObj = {};
      if (null != obj) for (var key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) {
        var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {};
        if (desc.get || desc.set) Object.defineProperty(newObj, key, desc); else newObj[key] = obj[key];
      }
      newObj["default"] = obj;
      return newObj;
    }
  }
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _typeof(obj) {
    if ("function" === typeof Symbol && "symbol" === typeof Symbol.iterator) _typeof = function(obj) {
      return typeof obj;
    }; else _typeof = function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    return _typeof(obj);
  }
  function _extends() {
    _extends = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
      }
      return target;
    };
    return _extends.apply(this, arguments);
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = null != arguments[i] ? arguments[i] : {};
      var ownKeys = Object.keys(source);
      if ("function" === typeof Object.getOwnPropertySymbols) ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter((function(sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      })));
      ownKeys.forEach((function(key) {
        _defineProperty(target, key, source[key]);
      }));
    }
    return target;
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
  }
  function _possibleConstructorReturn(self, call) {
    if (call && ("object" === _typeof(call) || "function" === typeof call)) return call;
    return _assertThisInitialized(self);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _assertThisInitialized(self) {
    if (void 0 === self) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _inherits(subClass, superClass) {
    if ("function" !== typeof superClass && null !== superClass) throw new TypeError("Super expression must either be null or a function");
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    }); else obj[key] = value;
    return obj;
  }
  var defaultColor = "#fff";
  var defaultBg = "#333";
  var resizeThrottle = 100;
  var resizeThreshold = 5;
  var stopProp = function(e) {
    return e.stopPropagation();
  };
  var Tooltip = function(_React$Component) {
    _inherits(Tooltip, _React$Component);
    _createClass(Tooltip, null, [ {
      key: "getDerivedStateFromProps",
      value: function(nextProps) {
        return _Portal.isBrowser && nextProps.isOpen ? {
          hasBeenShown: true
        } : null;
      }
    } ]);
    function Tooltip() {
      var _this;
      _classCallCheck(this, Tooltip);
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Tooltip).call(this));
      _defineProperty(_assertThisInitialized(_this), "debounceTimeout", false);
      _defineProperty(_assertThisInitialized(_this), "hoverTimeout", false);
      _this.state = {
        showTip: false,
        hasHover: false,
        ignoreShow: false,
        hasBeenShown: false
      };
      _this.showTip = _this.showTip.bind(_assertThisInitialized(_this));
      _this.hideTip = _this.hideTip.bind(_assertThisInitialized(_this));
      _this.checkHover = _this.checkHover.bind(_assertThisInitialized(_this));
      _this.toggleTip = _this.toggleTip.bind(_assertThisInitialized(_this));
      _this.startHover = _this.startHover.bind(_assertThisInitialized(_this));
      _this.endHover = _this.endHover.bind(_assertThisInitialized(_this));
      _this.listenResizeScroll = _this.listenResizeScroll.bind(_assertThisInitialized(_this));
      _this.handleResizeScroll = _this.handleResizeScroll.bind(_assertThisInitialized(_this));
      _this.bodyTouchStart = _this.bodyTouchStart.bind(_assertThisInitialized(_this));
      _this.bodyTouchEnd = _this.bodyTouchEnd.bind(_assertThisInitialized(_this));
      _this.targetTouchStart = _this.targetTouchStart.bind(_assertThisInitialized(_this));
      _this.targetTouchEnd = _this.targetTouchEnd.bind(_assertThisInitialized(_this));
      return _this;
    }
    _createClass(Tooltip, [ {
      key: "componentDidMount",
      value: function() {
        if (this.props.isOpen) this.setState({
          isOpen: true
        });
        this.scrollParent = (0, _functions.getScrollParent)(this.target);
        window.addEventListener("resize", this.listenResizeScroll);
        this.scrollParent.addEventListener("scroll", this.listenResizeScroll);
        window.addEventListener("touchstart", this.bodyTouchStart);
        window.addEventListener("touchEnd", this.bodyTouchEnd);
      }
    }, {
      key: "componentDidUpdate",
      value: function(_, prevState) {
        if (!this.state.hasBeenShown && this.props.isOpen) {
          this.setState({
            hasBeenShown: true
          });
          return setTimeout(this.showTip, 0);
        }
        if (!prevState.hasBeenShown && this.state.hasBeenShown) this.showTip();
      }
    }, {
      key: "componentWillUnmount",
      value: function() {
        window.removeEventListener("resize", this.listenResizeScroll);
        this.scrollParent.removeEventListener("scroll", this.listenResizeScroll);
        window.removeEventListener("touchstart", this.bodyTouchStart);
        window.removeEventListener("touchEnd", this.bodyTouchEnd);
        clearTimeout(this.debounceTimeout);
        clearTimeout(this.hoverTimeout);
      }
    }, {
      key: "listenResizeScroll",
      value: function() {
        clearTimeout(this.debounceTimeout);
        this.debounceTimeout = setTimeout(this.handleResizeScroll, resizeThrottle);
        if (this.state.targetTouch) this.setState({
          targetTouch: void 0
        });
      }
    }, {
      key: "handleResizeScroll",
      value: function() {
        if (this.state.showTip) {
          var clientWidth = Math.round(document.documentElement.clientWidth / resizeThreshold) * resizeThreshold;
          this.setState({
            clientWidth
          });
        }
      }
    }, {
      key: "targetTouchStart",
      value: function() {
        this.setState({
          targetTouch: true
        });
      }
    }, {
      key: "targetTouchEnd",
      value: function() {
        if (this.state.targetTouch) this.toggleTip();
      }
    }, {
      key: "bodyTouchEnd",
      value: function() {
        if (this.state.targetTouch) this.setState({
          targetTouch: void 0
        });
      }
    }, {
      key: "bodyTouchStart",
      value: function(e) {
        if (!(this.target && this.target.contains(e.target)) && !(this.tip && this.tip.contains(e.target)) && !this.props.isOpen) this.hideTip();
      }
    }, {
      key: "toggleTip",
      value: function() {
        this.state.showTip ? this.hideTip() : this.showTip();
      }
    }, {
      key: "showTip",
      value: function() {
        var _this2 = this;
        if (!this.state.hasBeenShown) return this.setState({
          hasBeenShown: true
        });
        if (!this.state.showTip) this.setState({
          showTip: true
        }, (function() {
          if ("function" === typeof _this2.props.onToggle) _this2.props.onToggle(_this2.state.showTip);
        }));
      }
    }, {
      key: "hideTip",
      value: function() {
        var _this3 = this;
        this.setState({
          hasHover: false
        });
        if (this.state.showTip) this.setState({
          showTip: false
        }, (function() {
          if ("function" === typeof _this3.props.onToggle) _this3.props.onToggle(_this3.state.showTip);
        }));
      }
    }, {
      key: "startHover",
      value: function() {
        if (!this.state.ignoreShow) {
          this.setState({
            hasHover: true
          });
          clearTimeout(this.hoverTimeout);
          this.hoverTimeout = setTimeout(this.checkHover, this.props.hoverDelay);
        }
      }
    }, {
      key: "endHover",
      value: function() {
        this.setState({
          hasHover: false
        });
        clearTimeout(this.hoverTimeout);
        this.hoverTimeout = setTimeout(this.checkHover, this.props.mouseOutDelay || this.props.hoverDelay);
      }
    }, {
      key: "checkHover",
      value: function() {
        this.state.hasHover ? this.showTip() : this.hideTip();
      }
    }, {
      key: "render",
      value: function() {
        var _this4 = this;
        var _this$props = this.props, arrow = _this$props.arrow, arrowSize = _this$props.arrowSize, background = _this$props.background, className = _this$props.className, children = _this$props.children, color = _this$props.color, content = _this$props.content, direction = _this$props.direction, distance = _this$props.distance, eventOff = _this$props.eventOff, eventOn = _this$props.eventOn, eventToggle = _this$props.eventToggle, forceDirection = _this$props.forceDirection, isOpen = _this$props.isOpen, mouseOutDelay = _this$props.mouseOutDelay, padding = _this$props.padding, styles = _this$props.styles, TagName = _this$props.tagName, tipContentHover = _this$props.tipContentHover, tipContentClassName = _this$props.tipContentClassName, useDefaultStyles = _this$props.useDefaultStyles, useHover = _this$props.useHover, arrowContent = _this$props.arrowContent;
        var isControlledByProps = "undefined" !== typeof isOpen && null !== isOpen;
        var showTip = isControlledByProps ? isOpen : this.state.showTip;
        var wrapperStyles = _objectSpread({
          position: "relative"
        }, styles);
        var props = {
          style: wrapperStyles,
          ref: function(target) {
            _this4.target = target;
          },
          className
        };
        var portalProps = {
          onClick: stopProp
        };
        if (eventOff) props[eventOff] = this.hideTip;
        if (eventOn) props[eventOn] = this.showTip;
        if (eventToggle) props[eventToggle] = this.toggleTip; else if (useHover && !isControlledByProps) {
          props.onMouseEnter = this.startHover;
          props.onMouseLeave = tipContentHover || mouseOutDelay ? this.endHover : this.hideTip;
          props.onTouchStart = this.targetTouchStart;
          props.onTouchEnd = this.targetTouchEnd;
          if (tipContentHover) {
            portalProps.onMouseEnter = this.startHover;
            portalProps.onMouseLeave = this.endHover;
            portalProps.onTouchStart = stopProp;
          }
        }
        var tipPortal;
        if (this.state.hasBeenShown) {
          var currentPositions = (0, _position["default"])(direction, forceDirection, this.tip, this.target, _objectSpread({}, this.state, {
            showTip
          }), {
            background: useDefaultStyles ? defaultBg : background,
            arrow,
            arrowSize,
            distance
          });
          var tipStyles = _objectSpread({}, currentPositions.tip, {
            background: useDefaultStyles ? defaultBg : background,
            color: useDefaultStyles ? defaultColor : color,
            padding,
            boxSizing: "border-box",
            zIndex: this.props.zIndex,
            position: "absolute",
            display: "inline-block"
          });
          var arrowStyles = _objectSpread({}, currentPositions.arrow.positionStyles, arrowContent ? {} : currentPositions.arrow.borderStyles, {
            position: "absolute",
            width: "0px",
            height: "0px",
            zIndex: this.props.zIndex + 1
          });
          tipPortal = _react["default"].createElement(_Portal["default"], null, _react["default"].createElement("div", _extends({}, portalProps, {
            className: "undefined" !== typeof tipContentClassName ? tipContentClassName : className
          }), _react["default"].createElement("span", {
            className: "react-tooltip-lite",
            style: tipStyles,
            ref: function(tip) {
              _this4.tip = tip;
            }
          }, content), _react["default"].createElement("span", {
            className: "react-tooltip-lite-arrow react-tooltip-lite-".concat(currentPositions.realDirection, "-arrow"),
            style: arrowStyles
          }, arrowContent)));
        }
        return _react["default"].createElement(TagName, props, children, tipPortal);
      }
    } ]);
    return Tooltip;
  }(_react["default"].Component);
  _defineProperty(Tooltip, "propTypes", {
    arrow: _propTypes["default"].bool,
    arrowSize: _propTypes["default"].number,
    background: _propTypes["default"].string,
    children: _propTypes["default"].node.isRequired,
    className: _propTypes["default"].string,
    color: _propTypes["default"].string,
    content: _propTypes["default"].node.isRequired,
    direction: _propTypes["default"].string,
    distance: _propTypes["default"].number,
    eventOff: _propTypes["default"].string,
    eventOn: _propTypes["default"].string,
    eventToggle: _propTypes["default"].string,
    forceDirection: _propTypes["default"].bool,
    hoverDelay: _propTypes["default"].number,
    isOpen: _propTypes["default"].bool,
    mouseOutDelay: _propTypes["default"].number,
    padding: _propTypes["default"].oneOfType([ _propTypes["default"].string, _propTypes["default"].number ]),
    styles: _propTypes["default"].object,
    tagName: _propTypes["default"].string,
    tipContentHover: _propTypes["default"].bool,
    tipContentClassName: _propTypes["default"].string,
    useDefaultStyles: _propTypes["default"].bool,
    useHover: _propTypes["default"].bool,
    zIndex: _propTypes["default"].number,
    onToggle: _propTypes["default"].func,
    arrowContent: _propTypes["default"].node
  });
  _defineProperty(Tooltip, "defaultProps", {
    arrow: true,
    arrowSize: 10,
    background: "",
    className: "",
    color: "",
    direction: "up",
    distance: void 0,
    eventOff: void 0,
    eventOn: void 0,
    eventToggle: void 0,
    forceDirection: false,
    hoverDelay: 200,
    isOpen: void 0,
    mouseOutDelay: void 0,
    padding: "10px",
    styles: {},
    tagName: "div",
    tipContentHover: false,
    tipContentClassName: void 0,
    useDefaultStyles: false,
    useHover: true,
    zIndex: 1e3,
    onToggle: void 0,
    arrowContent: null
  });
  var _default = Tooltip;
  exports["default"] = _default;
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  var getIntersectClientRects = __webpack_require__(47);
  var getElementClientRect = __webpack_require__(48);
  var getViewportPosition = __webpack_require__(101);
  var elementInDocument = __webpack_require__(102);
  var elementStyle = __webpack_require__(103);
  if (true, "undefined" !== typeof module.exports) module.exports = elementVisible; else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
  __WEBPACK_AMD_DEFINE_RESULT__ = function() {
    return elementVisible;
  }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  function isElement(o) {
    return "object" === typeof HTMLElement ? o instanceof HTMLElement : o && "object" === typeof o && null !== o && 1 === o.nodeType && "string" === typeof o.nodeName;
  }
  function elementVisible(element, threshold) {
    var currentNode = element;
    var viewportRect;
    var clientRect;
    var clientRectArea;
    var visibleClientRect;
    var visibleClientRectArea;
    var visibleRatio;
    threshold = +threshold || 1;
    if (!element || !isElement(element)) throw new Error("Element is mandatory");
    var doc = element.ownerDocument;
    if (threshold <= 0) throw new Error("Threshold value must be greater than 0");
    do {
      if ("0" === elementStyle(currentNode, "opacity") || "none" === elementStyle(currentNode, "display") || "hidden" === elementStyle(currentNode, "visibility")) return false;
    } while ((currentNode = currentNode.parentNode) !== document && currentNode);
    if (elementInDocument(element, threshold)) {
      clientRect = getElementClientRect(element);
      viewportRect = getViewportPosition(doc.defaultView || doc.parentWindow);
      visibleClientRect = getIntersectClientRects(clientRect, viewportRect);
      clientRectArea = clientRect.width * clientRect.height;
      visibleClientRectArea = visibleClientRect.width * visibleClientRect.height;
      visibleRatio = +clientRectArea ? visibleClientRectArea / clientRectArea : 0;
      return visibleRatio >= threshold;
    }
    return false;
  }
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  function _defineProperty(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    }); else obj[key] = value;
    return obj;
  }
  var ACTIVE = "active";
  var IDLE = "idle";
  var DEFAULT_INITIAL_STATE = ACTIVE;
  var DEFAULT_ACTIVITY_EVENTS = [ "click", "mousemove", "keydown", "DOMMouseScroll", "mousewheel", "mousedown", "touchstart", "touchmove", "focus" ];
  var DEFAULT_INACTIVITY_EVENTS = [ "blur", "visibilitychange" ];
  var DEFAULT_IGNORED_EVENTS_WHEN_IDLE = [ "mousemove" ];
  var hidden = void 0, visibilityChangeEvent = void 0;
  if ("undefined" !== typeof document.hidden) {
    hidden = "hidden";
    visibilityChangeEvent = "visibilitychange";
  } else {
    var prefixes = [ "webkit", "moz", "ms" ];
    for (var i = 0; i < prefixes.length; i++) {
      var prefix = prefixes[i];
      if ("undefined" !== typeof document[prefix + "Hidden"]) {
        hidden = prefix + "Hidden";
        visibilityChangeEvent = prefix + "visibilitychange";
        break;
      }
    }
  }
  var activityDetector = function() {
    var _listeners;
    var _ref = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, _ref$activityEvents = _ref.activityEvents, activityEvents = void 0 === _ref$activityEvents ? DEFAULT_ACTIVITY_EVENTS : _ref$activityEvents, _ref$inactivityEvents = _ref.inactivityEvents, inactivityEvents = void 0 === _ref$inactivityEvents ? DEFAULT_INACTIVITY_EVENTS : _ref$inactivityEvents, _ref$ignoredEventsWhe = _ref.ignoredEventsWhenIdle, ignoredEventsWhenIdle = void 0 === _ref$ignoredEventsWhe ? DEFAULT_IGNORED_EVENTS_WHEN_IDLE : _ref$ignoredEventsWhe, _ref$timeToIdle = _ref.timeToIdle, timeToIdle = void 0 === _ref$timeToIdle ? 3e4 : _ref$timeToIdle, _ref$initialState = _ref.initialState, initialState = void 0 === _ref$initialState ? DEFAULT_INITIAL_STATE : _ref$initialState, _ref$autoInit = _ref.autoInit, autoInit = void 0 === _ref$autoInit ? true : _ref$autoInit;
    var listeners = (_listeners = {}, _defineProperty(_listeners, ACTIVE, []), _defineProperty(_listeners, IDLE, []), 
    _listeners);
    var state = void 0;
    var timer = void 0;
    var setState = function setState(newState) {
      clearTimeout(timer);
      if (newState === ACTIVE) timer = setTimeout((function() {
        return setState(IDLE);
      }), timeToIdle);
      if (state !== newState) {
        state = newState;
        listeners[state].forEach((function(l) {
          return l();
        }));
      }
    };
    var handleUserActivityEvent = function(event) {
      if (state === ACTIVE || ignoredEventsWhenIdle.indexOf(event.type) < 0) setState(ACTIVE);
    };
    var handleUserInactivityEvent = function() {
      setState(IDLE);
    };
    var handleVisibilityChangeEvent = function() {
      setState(document[hidden] ? IDLE : ACTIVE);
    };
    var init = function() {
      var firstState = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : DEFAULT_INITIAL_STATE;
      setState(firstState === ACTIVE ? ACTIVE : IDLE);
      activityEvents.forEach((function(eventName) {
        return window.addEventListener(eventName, handleUserActivityEvent);
      }));
      inactivityEvents.filter((function(eventName) {
        return "visibilitychange" !== eventName;
      })).forEach((function(eventName) {
        return window.addEventListener(eventName, handleUserInactivityEvent);
      }));
      if (inactivityEvents.indexOf("visibilitychange") >= 0 && visibilityChangeEvent) document.addEventListener(visibilityChangeEvent, handleVisibilityChangeEvent);
    };
    var on = function(eventName, listener) {
      listeners[eventName].push(listener);
      var off = function() {
        var index = listeners[eventName].indexOf(listener);
        if (index >= 0) listeners[eventName].splice(index, 1);
      };
      return off;
    };
    var stop = function() {
      listeners[ACTIVE] = [];
      listeners[IDLE] = [];
      clearTimeout(timer);
      activityEvents.forEach((function(eventName) {
        return window.removeEventListener(eventName, handleUserActivityEvent);
      }));
      inactivityEvents.forEach((function(eventName) {
        return window.removeEventListener(eventName, handleUserInactivityEvent);
      }));
      if (visibilityChangeEvent) document.removeEventListener(visibilityChangeEvent, handleVisibilityChangeEvent);
    };
    if (autoInit) init(initialState);
    return {
      on,
      stop,
      init
    };
  };
  exports.default = activityDetector;
}, function(module, exports, __webpack_require__) {
  "use strict";
  /*!
 * is-number <https://github.com/jonschlinkert/is-number>
 *
 * Copyright (c) 2014-present, Jon Schlinkert.
 * Released under the MIT License.
 */  module.exports = function(num) {
    if ("number" === typeof num) return num - num === 0;
    if ("string" === typeof num && "" !== num.trim()) return Number.isFinite ? Number.isFinite(+num) : isFinite(+num);
    return false;
  };
}, function(module, exports, __webpack_require__) {
  /*!
 * array-last <https://github.com/jonschlinkert/array-last>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */
  var isNumber = __webpack_require__(106);
  module.exports = function(arr, n) {
    if (!Array.isArray(arr)) throw new Error("expected the first argument to be an array");
    var len = arr.length;
    if (0 === len) return null;
    n = isNumber(n) ? +n : 1;
    if (1 === n) return arr[len - 1];
    var res = new Array(n);
    while (n--) res[n] = arr[--len];
    return res;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const retry = __webpack_require__(107);
  const networkErrorMsgs = [ "Failed to fetch", "NetworkError when attempting to fetch resource.", "The Internet connection appears to be offline.", "Network request failed" ];
  class AbortError extends Error {
    constructor(message) {
      super();
      if (message instanceof Error) {
        this.originalError = message;
        ({message} = message);
      } else {
        this.originalError = new Error(message);
        this.originalError.stack = this.stack;
      }
      this.name = "AbortError";
      this.message = message;
    }
  }
  const decorateErrorWithCounts = (error, attemptNumber, options) => {
    const retriesLeft = options.retries - (attemptNumber - 1);
    error.attemptNumber = attemptNumber;
    error.retriesLeft = retriesLeft;
    return error;
  };
  const isNetworkError = errorMessage => networkErrorMsgs.includes(errorMessage);
  const pRetry = (input, options) => new Promise((resolve, reject) => {
    options = {
      onFailedAttempt: () => {},
      retries: 10,
      ...options
    };
    const operation = retry.operation(options);
    operation.attempt(async attemptNumber => {
      try {
        resolve(await input(attemptNumber));
      } catch (error) {
        if (!(error instanceof Error)) {
          reject(new TypeError(`Non-error was thrown: "${error}". You should only throw errors.`));
          return;
        }
        if (error instanceof AbortError) {
          operation.stop();
          reject(error.originalError);
        } else if (error instanceof TypeError && !isNetworkError(error.message)) {
          operation.stop();
          reject(error);
        } else {
          decorateErrorWithCounts(error, attemptNumber, options);
          try {
            await options.onFailedAttempt(error);
          } catch (error) {
            reject(error);
            return;
          }
          if (!operation.retry(error)) reject(operation.mainError());
        }
      }
    });
  });
  module.exports = pRetry;
  module.exports.default = pRetry;
  module.exports.AbortError = AbortError;
}, function(module, exports, __webpack_require__) {
  "use strict";
  var parse = __webpack_require__(110);
  var URLSearchParams = __webpack_require__(111);
  var defaultRegex = [ /{([\w]+)}/g, /:([a-zA-Z][\w]+)/g ];
  var fixedEncodeURIComponent = function(str) {
    return encodeURIComponent(str).replace(/[!'()*]/g, (function(c) {
      return "%" + c.charCodeAt(0).toString(16);
    }));
  };
  function transformUrl(urlTemplate) {
    var params = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    var options = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
    var matcher = options.matcher;
    var matchers = matcher ? [ matcher ].concat(defaultRegex) : defaultRegex;
    var matches = [];
    var usedParams = [];
    var getParamValue = function(key) {
      if (key in params) {
        usedParams.push(key);
        return params[key];
      }
      throw new Error("Param (".concat(key, ") not provided for url template: ").concat(urlTemplate));
    };
    matchers.forEach((function(m) {
      var re = new RegExp(m);
      var match;
      while (null != (match = re.exec(urlTemplate))) matches.push(match);
    }));
    var replacedUrl = matches.reduce((function(acc, cur) {
      var full = cur[0];
      var key = cur[1];
      var value = getParamValue(key);
      return acc.replace(full, fixedEncodeURIComponent(value));
    }), urlTemplate);
    var _parse = parse(replacedUrl), urlPart = _parse.url, query = _parse.query, _parse$hash = _parse.hash, hashPart = void 0 === _parse$hash ? "" : _parse$hash;
    var searchParams = new URLSearchParams(query);
    Object.keys(params).forEach((function(key) {
      if (usedParams.indexOf(key) < 0) {
        var values = params[key];
        (Array.isArray(values) ? values : [ values ]).forEach((function(value) {
          searchParams.append(key, value);
        }));
      }
    }));
    searchParams.sort();
    var queryPart = searchParams.toString();
    queryPart = queryPart ? "?" + queryPart : "";
    return "".concat(urlPart).concat(queryPart).concat(hashPart);
  }
  module.exports = transformUrl;
}, function(module, exports) {
  module.exports = SafeParseCallback;
  function SafeParseCallback(obj, reviver, callback) {
    if (2 === arguments.length) {
      callback = reviver;
      reviver = null;
    }
    var json;
    try {
      json = JSON.parse(obj, reviver);
    } catch (err) {
      return callback(err);
    }
    callback(null, json);
  }
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(117);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(118);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(119);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(120);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(121);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(122);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(123);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(124);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(126);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(132);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(133);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(134);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(136);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(137);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(140);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(142);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(143);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  var result = __webpack_require__(144);
  if (result && result.__esModule) result = result.default;
  if ("string" === typeof result) module.exports = result; else module.exports = result.toString();
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && "object" == typeof a && "object" == typeof b) {
      if (a.constructor !== b.constructor) return false;
      var length, i, keys;
      if (Array.isArray(a)) {
        length = a.length;
        if (length != b.length) return false;
        for (i = length; 0 !== i--; ) if (!equal(a[i], b[i])) return false;
        return true;
      }
      if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
      if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
      if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
      keys = Object.keys(a);
      length = keys.length;
      if (length !== Object.keys(b).length) return false;
      for (i = length; 0 !== i--; ) if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
      for (i = length; 0 !== i--; ) {
        var key = keys[i];
        if (!equal(a[key], b[key])) return false;
      }
      return true;
    }
    return a !== a && b !== b;
  };
}, function(module, exports, __webpack_require__) {
  (function(process) {
    module.exports = process.env.PROMISE_QUEUE_COVERAGE ? __webpack_require__(146) : __webpack_require__(147);
  }).call(this, __webpack_require__(145));
}, function(module, exports, __webpack_require__) {
  "use strict";
  const nullKey = Symbol("null");
  let keyCounter = 0;
  module.exports = class extends Map {
    constructor() {
      super();
      this._objectHashes = new WeakMap;
      this._symbolHashes = new Map;
      this._publicKeys = new Map;
      const [pairs] = arguments;
      if (null === pairs || void 0 === pairs) return;
      if ("function" !== typeof pairs[Symbol.iterator]) throw new TypeError(typeof pairs + " is not iterable (cannot read property Symbol(Symbol.iterator))");
      for (const [keys, value] of pairs) this.set(keys, value);
    }
    _getPublicKeys(keys, create = false) {
      if (!Array.isArray(keys)) throw new TypeError("The keys parameter must be an array");
      const privateKey = this._getPrivateKey(keys, create);
      let publicKey;
      if (privateKey && this._publicKeys.has(privateKey)) publicKey = this._publicKeys.get(privateKey); else if (create) {
        publicKey = [ ...keys ];
        this._publicKeys.set(privateKey, publicKey);
      }
      return {
        privateKey,
        publicKey
      };
    }
    _getPrivateKey(keys, create = false) {
      const privateKeys = [];
      for (let key of keys) {
        if (null === key) key = nullKey;
        const hashes = "object" === typeof key || "function" === typeof key ? "_objectHashes" : "symbol" === typeof key ? "_symbolHashes" : false;
        if (!hashes) privateKeys.push(key); else if (this[hashes].has(key)) privateKeys.push(this[hashes].get(key)); else if (create) {
          const privateKey = `@@mkm-ref-${keyCounter++}@@`;
          this[hashes].set(key, privateKey);
          privateKeys.push(privateKey);
        } else return false;
      }
      return JSON.stringify(privateKeys);
    }
    set(keys, value) {
      const {publicKey} = this._getPublicKeys(keys, true);
      return super.set(publicKey, value);
    }
    get(keys) {
      const {publicKey} = this._getPublicKeys(keys);
      return super.get(publicKey);
    }
    has(keys) {
      const {publicKey} = this._getPublicKeys(keys);
      return super.has(publicKey);
    }
    delete(keys) {
      const {publicKey, privateKey} = this._getPublicKeys(keys);
      return Boolean(publicKey && super.delete(publicKey) && this._publicKeys.delete(privateKey));
    }
    clear() {
      super.clear();
      this._symbolHashes.clear();
      this._publicKeys.clear();
    }
    get [Symbol.toStringTag]() {
      return "ManyKeysMap";
    }
    get size() {
      return super.size;
    }
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const pDefer = () => {
    const deferred = {};
    deferred.promise = new Promise((resolve, reject) => {
      deferred.resolve = resolve;
      deferred.reject = reject;
    });
    return deferred;
  };
  module.exports = pDefer;
}, function(module) {
  module.exports = JSON.parse('["a","altGlyph","altGlyphDef","altGlyphItem","animate","animateColor","animateMotion","animateTransform","animation","audio","canvas","circle","clipPath","color-profile","cursor","defs","desc","discard","ellipse","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","filter","font","font-face","font-face-format","font-face-name","font-face-src","font-face-uri","foreignObject","g","glyph","glyphRef","handler","hatch","hatchpath","hkern","iframe","image","line","linearGradient","listener","marker","mask","mesh","meshgradient","meshpatch","meshrow","metadata","missing-glyph","mpath","path","pattern","polygon","polyline","prefetch","radialGradient","rect","script","set","solidColor","solidcolor","stop","style","svg","switch","symbol","tbreak","text","textArea","textPath","title","tref","tspan","unknown","use","video","view","vkern"]');
}, function(module, exports, __webpack_require__) {
  "use strict";
  /*!
 * arr-flatten <https://github.com/jonschlinkert/arr-flatten>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */  module.exports = function(arr) {
    return flat(arr, []);
  };
  function flat(arr, res) {
    var cur, i = 0;
    var len = arr.length;
    for (;i < len; i++) {
      cur = arr[i];
      Array.isArray(cur) ? flat(cur, res) : res.push(cur);
    }
    return res;
  }
}, function(module, exports) {
  var g;
  g = function() {
    return this;
  }();
  try {
    g = g || new Function("return this")();
  } catch (e) {
    if ("object" === typeof window) g = window;
  }
  module.exports = g;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = value => {
    const type = typeof value;
    return null !== value && ("object" === type || "function" === type);
  };
}, function(module, exports, __webpack_require__) {
  var map = {
    "./action-types.js": 88,
    "./assets.js": 89,
    "./custom-event-types.js": 90,
    "./extension-origin.js": 91,
    "./index.js": 3,
    "./message-types.js": 92,
    "./others.js": 93
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 87;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "STORAGE_READ", (function() {
    return STORAGE_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_WRITE", (function() {
    return STORAGE_WRITE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_DELETE", (function() {
    return STORAGE_DELETE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_CHANGED", (function() {
    return STORAGE_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ", (function() {
    return SETTINGS_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ_ALL", (function() {
    return SETTINGS_READ_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_WRITE_ALL", (function() {
    return SETTINGS_WRITE_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_CHANGED", (function() {
    return SETTINGS_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "GET_OPTION_DEFS", (function() {
    return GET_OPTION_DEFS;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_FETCH_GET", (function() {
    return PROXIED_FETCH_GET;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_AUDIO", (function() {
    return PROXIED_AUDIO;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_CREATE_TAB", (function() {
    return PROXIED_CREATE_TAB;
  }));
  const STORAGE_READ = "STORAGE_READ";
  const STORAGE_WRITE = "STORAGE_WRITE";
  const STORAGE_DELETE = "STORAGE_DELETE";
  const STORAGE_CHANGED = "STORAGE_CHANGED";
  const SETTINGS_READ = "SETTINGS_READ";
  const SETTINGS_READ_ALL = "SETTINGS_READ_ALL";
  const SETTINGS_WRITE_ALL = "SETTINGS_WRITE_ALL";
  const SETTINGS_CHANGED = "SETTINGS_CHANGED";
  const GET_OPTION_DEFS = "GET_OPTION_DEFS";
  const PROXIED_FETCH_GET = "PROXIED_FETCH_GET";
  const PROXIED_AUDIO = "PROXIED_AUDIO";
  const PROXIED_CREATE_TAB = "PROXIED_CREATE_TAB";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "ASSET_CLASSNAME", (function() {
    return ASSET_CLASSNAME;
  }));
  const ASSET_CLASSNAME = "sf-asset";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BRIDGE_EVENT_TYPE", (function() {
    return BRIDGE_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "POST_STATUS_SUCCESS_EVENT_TYPE", (function() {
    return POST_STATUS_SUCCESS_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_UNLOADED_EVENT_TYPE", (function() {
    return EXTENSION_UNLOADED_EVENT_TYPE;
  }));
  const BRIDGE_EVENT_TYPE = "SpaceFanfouBridgeMessage";
  const POST_STATUS_SUCCESS_EVENT_TYPE = "SpaceFanfouPostStatusSuccess";
  const EXTENSION_UNLOADED_EVENT_TYPE = "SpaceFanfouUnloaded";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER_RE", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER_RE;
  }));
  const EXTENSION_ORIGIN_PLACEHOLDER = "<EXTENSION_ORIGIN_PLACEHOLDER>";
  const EXTENSION_ORIGIN_PLACEHOLDER_RE = new RegExp(EXTENSION_ORIGIN_PLACEHOLDER, "g");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BROADCASTING_MESSAGE", (function() {
    return BROADCASTING_MESSAGE;
  }));
  __webpack_require__.d(__webpack_exports__, "CONVERSATIONAL_MESSAGE", (function() {
    return CONVERSATIONAL_MESSAGE;
  }));
  const BROADCASTING_MESSAGE = "BROADCASTING_MESSAGE";
  const CONVERSATIONAL_MESSAGE = "CONVERSATIONAL_MESSAGE";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "CONTROL_PLACEHOLDER", (function() {
    return CONTROL_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_KEY_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_KEY_IS_EXTENSION_UPGRADED;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED;
  }));
  const CONTROL_PLACEHOLDER = "<CONTROL_PLACEHOLDER>";
  const STORAGE_KEY_IS_EXTENSION_UPGRADED = "is-extension-upgraded";
  const STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED = "session";
}, function(module, exports, __webpack_require__) {
  "use strict";
  var ReactPropTypesSecret = __webpack_require__(95);
  function emptyFunction() {}
  function emptyFunctionWithReset() {}
  emptyFunctionWithReset.resetWarningCache = emptyFunction;
  module.exports = function() {
    function shim(props, propName, componentName, location, propFullName, secret) {
      if (secret === ReactPropTypesSecret) return;
      var err = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
      err.name = "Invariant Violation";
      throw err;
    }
    shim.isRequired = shim;
    function getShim() {
      return shim;
    }
    var ReactPropTypes = {
      array: shim,
      bigint: shim,
      bool: shim,
      func: shim,
      number: shim,
      object: shim,
      string: shim,
      symbol: shim,
      any: shim,
      arrayOf: getShim,
      element: shim,
      elementType: shim,
      instanceOf: getShim,
      node: shim,
      objectOf: getShim,
      oneOf: getShim,
      oneOfType: getShim,
      shape: getShim,
      exact: getShim,
      checkPropTypes: emptyFunctionWithReset,
      resetWarningCache: emptyFunction
    };
    ReactPropTypes.PropTypes = ReactPropTypes;
    return ReactPropTypes;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  module.exports = ReactPropTypesSecret;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = exports.isBrowser = void 0;
  var _react = _interopRequireDefault(__webpack_require__(4));
  var _propTypes = _interopRequireDefault(__webpack_require__(2));
  var _reactDom = _interopRequireDefault(__webpack_require__(4));
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _typeof(obj) {
    if ("function" === typeof Symbol && "symbol" === typeof Symbol.iterator) _typeof = function(obj) {
      return typeof obj;
    }; else _typeof = function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    return _typeof(obj);
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && ("object" === _typeof(call) || "function" === typeof call)) return call;
    return _assertThisInitialized(self);
  }
  function _assertThisInitialized(self) {
    if (void 0 === self) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _inherits(subClass, superClass) {
    if ("function" !== typeof superClass && null !== superClass) throw new TypeError("Super expression must either be null or a function");
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  var useCreatePortal = "function" === typeof _reactDom["default"].createPortal;
  var isBrowser = "undefined" !== typeof window;
  exports.isBrowser = isBrowser;
  var Portal = function(_React$Component) {
    _inherits(Portal, _React$Component);
    function Portal(props) {
      var _this;
      _classCallCheck(this, Portal);
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Portal).call(this, props));
      if (isBrowser) {
        _this.container = document.createElement("div");
        document.body.appendChild(_this.container);
        _this.renderLayer();
      }
      return _this;
    }
    _createClass(Portal, [ {
      key: "componentDidUpdate",
      value: function() {
        this.renderLayer();
      }
    }, {
      key: "componentWillUnmount",
      value: function() {
        if (!useCreatePortal) _reactDom["default"].unmountComponentAtNode(this.container);
        document.body.removeChild(this.container);
      }
    }, {
      key: "renderLayer",
      value: function() {
        if (!useCreatePortal) _reactDom["default"].unstable_renderSubtreeIntoContainer(this, this.props.children, this.container);
      }
    }, {
      key: "render",
      value: function() {
        if (useCreatePortal) return _reactDom["default"].createPortal(this.props.children, this.container);
        return null;
      }
    } ]);
    return Portal;
  }(_react["default"].Component);
  Portal.propTypes = {
    children: _propTypes["default"].node.isRequired
  };
  var _default = Portal;
  exports["default"] = _default;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = getDirection;
  var _functions = __webpack_require__(42);
  function checkLeftRightWidthSufficient(tip, target, distance, bodyPadding) {
    var targetRect = target.getBoundingClientRect();
    var deadSpace = Math.min(targetRect.left, document.documentElement.clientWidth - targetRect.right);
    return tip.offsetWidth + target.offsetWidth + distance + bodyPadding + deadSpace < document.documentElement.clientWidth;
  }
  function checkTargetSufficientlyVisible(target, tip, props) {
    var targetRect = target.getBoundingClientRect();
    var bottomOverhang = targetRect.bottom > window.innerHeight;
    var topOverhang = targetRect.top < 0;
    if (topOverhang && bottomOverhang) return true;
    if (target.offsetHeight > tip.offsetHeight) {
      var halfTargetHeight = target.offsetHeight / 2;
      var arrowClearance = props.arrowSize + _functions.minArrowPadding;
      var bottomOverhangAmount = targetRect.bottom - window.innerHeight;
      var topOverhangAmount = -targetRect.top;
      var targetCenterToBottomOfWindow = halfTargetHeight - bottomOverhangAmount;
      var targetCenterToTopOfWindow = halfTargetHeight - topOverhangAmount;
      return targetCenterToBottomOfWindow >= arrowClearance && targetCenterToTopOfWindow >= arrowClearance;
    }
    return !bottomOverhang && !topOverhang;
  }
  function checkForArrowOverhang(props, arrowStyles, bodyPadding) {
    var scrollLeft = (0, _functions.getScrollLeft)();
    var hasLeftClearance = arrowStyles.positionStyles.left - scrollLeft > bodyPadding;
    var hasRightClearance = arrowStyles.positionStyles.left + 2 * props.arrowSize < scrollLeft + document.documentElement.clientWidth - bodyPadding;
    return !hasLeftClearance || !hasRightClearance;
  }
  function getDirection(currentDirection, tip, target, props, bodyPadding, arrowStyles, recursive) {
    if (!target) return currentDirection;
    var targetRect = target.getBoundingClientRect();
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var heightOfTipWithArrow = tip.offsetHeight + arrowSpacing + bodyPadding;
    var spaceBelowTarget = window.innerHeight - targetRect.bottom;
    var spaceAboveTarget = targetRect.top;
    var hasSpaceBelow = spaceBelowTarget >= heightOfTipWithArrow;
    var hasSpaceAbove = spaceAboveTarget >= heightOfTipWithArrow;
    switch (currentDirection) {
     case "right":
      if (!checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding) || !checkTargetSufficientlyVisible(target, tip, props)) return getDirection("up", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (document.documentElement.clientWidth - targetRect.right < tip.offsetWidth + arrowSpacing + bodyPadding) return "left";
      return "right";

     case "left":
      if (!checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding) || !checkTargetSufficientlyVisible(target, tip, props)) return getDirection("up", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (targetRect.left < tip.offsetWidth + arrowSpacing + bodyPadding) return "right";
      return "left";

     case "up":
      if (!recursive && arrowStyles && checkForArrowOverhang(props, arrowStyles, bodyPadding)) return getDirection("left", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (!hasSpaceAbove) {
        if (hasSpaceBelow) return "down";
        if (!recursive && checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      }
      return "up";

     case "down":
     default:
      if (!recursive && arrowStyles && checkForArrowOverhang(props, arrowStyles, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (!hasSpaceBelow) {
        if (hasSpaceAbove) return "up";
        if (!recursive && checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      }
      return "down";
    }
  }
}, function(module, exports, __webpack_require__) {
  /*!
 * Based on document-offset@1.0.4
 * https://www.npmjs.com/package/document-offset
 * MIT
 *
 * Remove dom-support package dependency due to maintain browser compatibility IE6+
 */
  var getDocument = __webpack_require__(49);
  var withinElement = __webpack_require__(99);
  module.exports = function(el) {
    var doc = getDocument(el);
    if (!doc) return;
    if (!withinElement(el, doc)) return;
    var body = doc.body;
    if (body === el) return bodyOffset(el);
    var box = {
      top: 0,
      left: 0
    };
    if ("undefined" !== typeof el.getBoundingClientRect) {
      box = el.getBoundingClientRect();
      if (el.collapsed && 0 === box.left && 0 === box.top) {
        var span = doc.createElement("span");
        span.appendChild(doc.createTextNode("​"));
        el.insertNode(span);
        box = span.getBoundingClientRect();
        var spanParent = span.parentNode;
        spanParent.removeChild(span);
        spanParent.normalize();
      }
    }
    var docEl = doc.documentElement;
    var clientTop = docEl.clientTop || body.clientTop || 0;
    var clientLeft = docEl.clientLeft || body.clientLeft || 0;
    var scrollTop = window.pageYOffset || docEl.scrollTop;
    var scrollLeft = window.pageXOffset || docEl.scrollLeft;
    return {
      top: box.top + scrollTop - clientTop,
      left: box.left + scrollLeft - clientLeft
    };
  };
  function bodyOffset(body) {
    var top = body.offsetTop;
    var left = body.offsetLeft;
    if (1 !== document.body.offsetTop) {
      top += parseFloat(body.style.marginTop || 0);
      left += parseFloat(body.style.marginLeft || 0);
    }
    return {
      top,
      left
    };
  }
}, function(module, exports) {
  module.exports = function(child, parent) {
    if (!child) return false;
    if (child.commonAncestorContainer) child = child.commonAncestorContainer; else if (child.endContainer) child = child.endContainer;
    var node = child;
    while (node = node.parentNode) if (node == parent) return true;
    return false;
  };
}, function(module, exports, __webpack_require__) {
  var getDocument = __webpack_require__(49);
  module.exports = getBoundingClientRect;
  function getBoundingClientRect(node) {
    var rect = null;
    var doc = getDocument(node);
    if (3 === node.nodeType) {
      var range = doc.createRange();
      range.selectNodeContents(node);
      node = range;
    }
    if ("function" === typeof node.getBoundingClientRect) {
      rect = node.getBoundingClientRect();
      if (node.startContainer && 0 === rect.left && 0 === rect.top) {
        var span = doc.createElement("span");
        span.appendChild(doc.createTextNode("​"));
        node.insertNode(span);
        rect = span.getBoundingClientRect();
        var spanParent = span.parentNode;
        spanParent.removeChild(span);
        spanParent.normalize();
      }
    }
    return rect;
  }
}, function(module, exports) {
  function viewportPosition(win) {
    win = win || window;
    var doc = win.document;
    var docElem = doc.documentElement || doc.body.parentNode || doc.body;
    var w = docElem.clientWidth;
    var h = docElem.clientHeight;
    var l = void 0 !== win.pageXOffset ? win.pageXOffset : docElem.scrollLeft;
    var t = void 0 !== win.pageYOffset ? win.pageYOffset : docElem.scrollTop;
    return {
      top: t,
      right: l + w,
      left: l,
      bottom: t + h,
      width: w,
      height: h
    };
  }
  module.exports = viewportPosition;
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  var getIntersectClientRects = __webpack_require__(47);
  var getElementClientRect = __webpack_require__(48);
  if (true, "undefined" !== typeof module.exports) module.exports = inDocument; else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], 
  __WEBPACK_AMD_DEFINE_RESULT__ = function() {
    return inDocument;
  }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  function inDocument(el, threshold) {
    threshold = threshold || 1;
    var elemRect = getElementClientRect(el);
    var doc = el.ownerDocument;
    var docWidth = Math.max(doc.body.clientWidth, doc.documentElement.offsetWidth, doc.documentElement.scrollWidth);
    var docHeight = Math.max(doc.body.clientHeight, doc.documentElement.offsetHeight, doc.documentElement.scrollHeight);
    var docRect = {
      top: 0,
      left: 0,
      right: docWidth,
      bottom: docHeight,
      width: docWidth,
      height: docHeight
    };
    var clip = getIntersectClientRects(elemRect, docRect);
    var isElemInsideOfDocument = elemRect.left >= 0 && elemRect.right <= docWidth && elemRect.top >= 0 && elemRect.bottom <= docHeight;
    var isElemHasIntersectWithDocument = clip.left >= 0 && clip.right <= docWidth && clip.top >= 0 && clip.bottom <= docHeight && Math.abs(clip.width) > 0 && Math.abs(clip.height) > 0;
    var intersectArea = 0;
    var elementArea = 0;
    var areaRatio = 0;
    if (isElemHasIntersectWithDocument) {
      intersectArea = clip.width * clip.height;
      elementArea = elemRect.width * elemRect.height;
      areaRatio = +elementArea ? intersectArea / elementArea : 0;
      isElemHasIntersectWithDocument = areaRatio >= threshold;
    }
    return isElemInsideOfDocument || isElemHasIntersectWithDocument;
  }
}, function(module, exports, __webpack_require__) {
  var kebabCase = __webpack_require__(104);
  function elementStyle(element, name, value) {
    if ("object" === typeof name) {
      var style = name;
      for (name in style) elementStyle(element, kebabCase(name), style[name]);
      return style;
    }
    var doc = element.ownerDocument;
    var win = doc.defaultView || doc.parentWindow;
    if (!win.getComputedStyle) win.getComputedStyle = function(el, pseudo) {
      this.el = el;
      this.getPropertyValue = function(prop) {
        var re = /(\-([a-z]){1})/g;
        if ("float" === prop) prop = "styleFloat";
        if (re.test(prop)) prop = prop.replace(re, (function() {
          return arguments[2].toUpperCase();
        }));
        return el.currentStyle[prop] ? el.currentStyle[prop] : null;
      };
      return this;
    };
    if (3 === arguments.length) {
      element.style[kebabCase.reverse("float" === name ? "cssFloat" : name)] = value || "";
      return value;
    }
    return win.getComputedStyle(element, null).getPropertyValue(kebabCase("cssFloat" === name ? "float" : name));
  }
  module.exports = elementStyle;
}, function(module, exports, __webpack_require__) {
  "use strict";
  var KEBAB_REGEX = /[A-Z\u00C0-\u00D6\u00D8-\u00DE]/g;
  var REVERSE_REGEX = /-[a-z\u00E0-\u00F6\u00F8-\u00FE]/g;
  module.exports = exports = function(str) {
    return str.replace(KEBAB_REGEX, (function(match) {
      return "-" + match.toLowerCase();
    }));
  };
  exports.reverse = function(str) {
    return str.replace(REVERSE_REGEX, (function(match) {
      return match.slice(1).toUpperCase();
    }));
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "/assets/sounds/dingdong.mp3";
}, function(module, exports, __webpack_require__) {
  "use strict";
  /*!
 * is-number <https://github.com/jonschlinkert/is-number>
 *
 * Copyright (c) 2014-2017, Jon Schlinkert.
 * Released under the MIT License.
 */  module.exports = function(num) {
    var type = typeof num;
    if ("string" === type || num instanceof String) {
      if (!num.trim()) return false;
    } else if ("number" !== type && !(num instanceof Number)) return false;
    return num - num + 1 >= 0;
  };
}, function(module, exports, __webpack_require__) {
  module.exports = __webpack_require__(108);
}, function(module, exports, __webpack_require__) {
  var RetryOperation = __webpack_require__(109);
  exports.operation = function(options) {
    var timeouts = exports.timeouts(options);
    return new RetryOperation(timeouts, {
      forever: options && (options.forever || options.retries === 1 / 0),
      unref: options && options.unref,
      maxRetryTime: options && options.maxRetryTime
    });
  };
  exports.timeouts = function(options) {
    if (options instanceof Array) return [].concat(options);
    var opts = {
      retries: 10,
      factor: 2,
      minTimeout: 1e3,
      maxTimeout: 1 / 0,
      randomize: false
    };
    for (var key in options) opts[key] = options[key];
    if (opts.minTimeout > opts.maxTimeout) throw new Error("minTimeout is greater than maxTimeout");
    var timeouts = [];
    for (var i = 0; i < opts.retries; i++) timeouts.push(this.createTimeout(i, opts));
    if (options && options.forever && !timeouts.length) timeouts.push(this.createTimeout(i, opts));
    timeouts.sort((function(a, b) {
      return a - b;
    }));
    return timeouts;
  };
  exports.createTimeout = function(attempt, opts) {
    var random = opts.randomize ? Math.random() + 1 : 1;
    var timeout = Math.round(random * Math.max(opts.minTimeout, 1) * Math.pow(opts.factor, attempt));
    timeout = Math.min(timeout, opts.maxTimeout);
    return timeout;
  };
  exports.wrap = function(obj, options, methods) {
    if (options instanceof Array) {
      methods = options;
      options = null;
    }
    if (!methods) {
      methods = [];
      for (var key in obj) if ("function" === typeof obj[key]) methods.push(key);
    }
    for (var i = 0; i < methods.length; i++) {
      var method = methods[i];
      var original = obj[method];
      obj[method] = function(original) {
        var op = exports.operation(options);
        var args = Array.prototype.slice.call(arguments, 1);
        var callback = args.pop();
        args.push((function(err) {
          if (op.retry(err)) return;
          if (err) arguments[0] = op.mainError();
          callback.apply(this, arguments);
        }));
        op.attempt((function() {
          original.apply(obj, args);
        }));
      }.bind(obj, original);
      obj[method].options = options;
    }
  };
}, function(module, exports) {
  function RetryOperation(timeouts, options) {
    if ("boolean" === typeof options) options = {
      forever: options
    };
    this._originalTimeouts = JSON.parse(JSON.stringify(timeouts));
    this._timeouts = timeouts;
    this._options = options || {};
    this._maxRetryTime = options && options.maxRetryTime || 1 / 0;
    this._fn = null;
    this._errors = [];
    this._attempts = 1;
    this._operationTimeout = null;
    this._operationTimeoutCb = null;
    this._timeout = null;
    this._operationStart = null;
    this._timer = null;
    if (this._options.forever) this._cachedTimeouts = this._timeouts.slice(0);
  }
  module.exports = RetryOperation;
  RetryOperation.prototype.reset = function() {
    this._attempts = 1;
    this._timeouts = this._originalTimeouts.slice(0);
  };
  RetryOperation.prototype.stop = function() {
    if (this._timeout) clearTimeout(this._timeout);
    if (this._timer) clearTimeout(this._timer);
    this._timeouts = [];
    this._cachedTimeouts = null;
  };
  RetryOperation.prototype.retry = function(err) {
    if (this._timeout) clearTimeout(this._timeout);
    if (!err) return false;
    var currentTime = (new Date).getTime();
    if (err && currentTime - this._operationStart >= this._maxRetryTime) {
      this._errors.push(err);
      this._errors.unshift(new Error("RetryOperation timeout occurred"));
      return false;
    }
    this._errors.push(err);
    var timeout = this._timeouts.shift();
    if (void 0 === timeout) if (this._cachedTimeouts) {
      this._errors.splice(0, this._errors.length - 1);
      timeout = this._cachedTimeouts.slice(-1);
    } else return false;
    var self = this;
    this._timer = setTimeout((function() {
      self._attempts++;
      if (self._operationTimeoutCb) {
        self._timeout = setTimeout((function() {
          self._operationTimeoutCb(self._attempts);
        }), self._operationTimeout);
        if (self._options.unref) self._timeout.unref();
      }
      self._fn(self._attempts);
    }), timeout);
    if (this._options.unref) this._timer.unref();
    return true;
  };
  RetryOperation.prototype.attempt = function(fn, timeoutOps) {
    this._fn = fn;
    if (timeoutOps) {
      if (timeoutOps.timeout) this._operationTimeout = timeoutOps.timeout;
      if (timeoutOps.cb) this._operationTimeoutCb = timeoutOps.cb;
    }
    var self = this;
    if (this._operationTimeoutCb) this._timeout = setTimeout((function() {
      self._operationTimeoutCb();
    }), self._operationTimeout);
    this._operationStart = (new Date).getTime();
    this._fn(this._attempts);
  };
  RetryOperation.prototype.try = function(fn) {
    console.log("Using RetryOperation.try() is deprecated");
    this.attempt(fn);
  };
  RetryOperation.prototype.start = function(fn) {
    console.log("Using RetryOperation.start() is deprecated");
    this.attempt(fn);
  };
  RetryOperation.prototype.start = RetryOperation.prototype.try;
  RetryOperation.prototype.errors = function() {
    return this._errors;
  };
  RetryOperation.prototype.attempts = function() {
    return this._attempts;
  };
  RetryOperation.prototype.mainError = function() {
    if (0 === this._errors.length) return null;
    var counts = {};
    var mainError = null;
    var mainErrorCount = 0;
    for (var i = 0; i < this._errors.length; i++) {
      var error = this._errors[i];
      var message = error.message;
      var count = (counts[message] || 0) + 1;
      counts[message] = count;
      if (count >= mainErrorCount) {
        mainError = error;
        mainErrorCount = count;
      }
    }
    return mainError;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function(url) {
    var parsed = {};
    var q = url.indexOf("?");
    var h = url.indexOf("#");
    var hasQuery = !!~q;
    var hasHash = !!~h;
    parsed.url = url.slice(0, hasQuery && q || hasHash && h || url.length);
    if (hasQuery) parsed.query = url.slice(q, hasHash && h || url.length);
    if (hasHash) parsed.hash = url.slice(h);
    return parsed;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var URLSearchParams = "undefined" !== typeof window && window.URLSearchParams;
  if (!URLSearchParams) URLSearchParams = __webpack_require__(112);
  module.exports = URLSearchParams;
}, function(module, exports) {
  /*! (c) Andrea Giammarchi - ISC */
  var self = this || {};
  try {
    (function(URLSearchParams, plus) {
      if (new URLSearchParams("q=%2B").get("q") !== plus || new URLSearchParams({
        q: plus
      }).get("q") !== plus || new URLSearchParams([ [ "q", plus ] ]).get("q") !== plus || "q=%0A" !== new URLSearchParams("q=\n").toString() || "q=+%26" !== new URLSearchParams({
        q: " &"
      }).toString() || "q=%25zx" !== new URLSearchParams({
        q: "%zx"
      }).toString()) throw URLSearchParams;
      self.URLSearchParams = URLSearchParams;
    })(URLSearchParams, "+");
  } catch (URLSearchParams) {
    (function(Object, String, isArray) {
      "use strict";
      var create = Object.create;
      var defineProperty = Object.defineProperty;
      var find = /[!'\(\)~]|%20|%00/g;
      var findPercentSign = /%(?![0-9a-fA-F]{2})/g;
      var plus = /\+/g;
      var replace = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
      };
      var proto = {
        append: function(key, value) {
          appendTo(this._ungap, key, value);
        },
        delete: function(key) {
          delete this._ungap[key];
        },
        get: function(key) {
          return this.has(key) ? this._ungap[key][0] : null;
        },
        getAll: function(key) {
          return this.has(key) ? this._ungap[key].slice(0) : [];
        },
        has: function(key) {
          return key in this._ungap;
        },
        set: function(key, value) {
          this._ungap[key] = [ String(value) ];
        },
        forEach: function(callback, thisArg) {
          var self = this;
          for (var key in self._ungap) self._ungap[key].forEach(invoke, key);
          function invoke(value) {
            callback.call(thisArg, value, String(key), self);
          }
        },
        toJSON: function() {
          return {};
        },
        toString: function() {
          var query = [];
          for (var key in this._ungap) {
            var encoded = encode(key);
            for (var i = 0, value = this._ungap[key]; i < value.length; i++) query.push(encoded + "=" + encode(value[i]));
          }
          return query.join("&");
        }
      };
      for (var key in proto) defineProperty(URLSearchParams.prototype, key, {
        configurable: true,
        writable: true,
        value: proto[key]
      });
      self.URLSearchParams = URLSearchParams;
      function URLSearchParams(query) {
        var dict = create(null);
        defineProperty(this, "_ungap", {
          value: dict
        });
        switch (true) {
         case !query:
          break;

         case "string" === typeof query:
          if ("?" === query.charAt(0)) query = query.slice(1);
          for (var pairs = query.split("&"), i = 0, length = pairs.length; i < length; i++) {
            var value = pairs[i];
            var index = value.indexOf("=");
            if (-1 < index) appendTo(dict, decode(value.slice(0, index)), decode(value.slice(index + 1))); else if (value.length) appendTo(dict, decode(value), "");
          }
          break;

         case isArray(query):
          for (i = 0, length = query.length; i < length; i++) {
            value = query[i];
            appendTo(dict, value[0], value[1]);
          }
          break;

         case "forEach" in query:
          query.forEach(addEach, dict);
          break;

         default:
          for (var key in query) appendTo(dict, key, query[key]);
        }
      }
      function addEach(value, key) {
        appendTo(this, key, value);
      }
      function appendTo(dict, key, value) {
        var res = isArray(value) ? value.join(",") : value;
        if (key in dict) dict[key].push(res); else dict[key] = [ res ];
      }
      function decode(str) {
        return decodeURIComponent(str.replace(findPercentSign, "%25").replace(plus, " "));
      }
      function encode(str) {
        return encodeURIComponent(str).replace(find, replacer);
      }
      function replacer(match) {
        return replace[match];
      }
    })(Object, String, Array.isArray);
  }
  (function(URLSearchParamsProto) {
    var iterable = false;
    try {
      iterable = !!Symbol.iterator;
    } catch (o_O) {}
    if (!("forEach" in URLSearchParamsProto)) URLSearchParamsProto.forEach = function(callback, thisArg) {
      var self = this;
      var names = Object.create(null);
      this.toString().replace(/=[\s\S]*?(?:&|$)/g, "=").split("=").forEach((function(name) {
        if (!name.length || name in names) return;
        (names[name] = self.getAll(name)).forEach((function(value) {
          callback.call(thisArg, value, name, self);
        }));
      }));
    };
    if (!("keys" in URLSearchParamsProto)) URLSearchParamsProto.keys = function() {
      return iterator(this, (function(value, key) {
        this.push(key);
      }));
    };
    if (!("values" in URLSearchParamsProto)) URLSearchParamsProto.values = function() {
      return iterator(this, (function(value, key) {
        this.push(value);
      }));
    };
    if (!("entries" in URLSearchParamsProto)) URLSearchParamsProto.entries = function() {
      return iterator(this, (function(value, key) {
        this.push([ key, value ]);
      }));
    };
    if (iterable && !(Symbol.iterator in URLSearchParamsProto)) URLSearchParamsProto[Symbol.iterator] = URLSearchParamsProto.entries;
    if (!("sort" in URLSearchParamsProto)) URLSearchParamsProto.sort = function() {
      var i, key, value, entries = this.entries(), entry = entries.next(), done = entry.done, keys = [], values = Object.create(null);
      while (!done) {
        value = entry.value;
        key = value[0];
        keys.push(key);
        if (!(key in values)) values[key] = [];
        values[key].push(value[1]);
        entry = entries.next();
        done = entry.done;
      }
      keys.sort();
      for (i = 0; i < keys.length; i++) this.delete(keys[i]);
      for (i = 0; i < keys.length; i++) {
        key = keys[i];
        this.append(key, values[key].shift());
      }
    };
    function iterator(self, callback) {
      var items = [];
      self.forEach(callback, items);
      return iterable ? items[Symbol.iterator]() : {
        next: function() {
          var value = items.shift();
          return {
            done: void 0 === value,
            value
          };
        }
      };
    }
    (function(Object) {
      var dP = Object.defineProperty, gOPD = Object.getOwnPropertyDescriptor, createSearchParamsPollute = function(search) {
        function append(name, value) {
          URLSearchParamsProto.append.call(this, name, value);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        function del(name) {
          URLSearchParamsProto.delete.call(this, name);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        function set(name, value) {
          URLSearchParamsProto.set.call(this, name, value);
          name = this.toString();
          search.set.call(this._usp, name ? "?" + name : "");
        }
        return function(sp, value) {
          sp.append = append;
          sp.delete = del;
          sp.set = set;
          return dP(sp, "_usp", {
            configurable: true,
            writable: true,
            value
          });
        };
      }, createSearchParamsCreate = function(polluteSearchParams) {
        return function(obj, sp) {
          dP(obj, "_searchParams", {
            configurable: true,
            writable: true,
            value: polluteSearchParams(sp, obj)
          });
          return sp;
        };
      }, updateSearchParams = function(sp) {
        var append = sp.append;
        sp.append = URLSearchParamsProto.append;
        URLSearchParams.call(sp, sp._usp.search.slice(1));
        sp.append = append;
      }, verifySearchParams = function(obj, Class) {
        if (!(obj instanceof Class)) throw new TypeError("'searchParams' accessed on an object that does not implement interface " + Class.name);
      }, upgradeClass = function(Class) {
        var createSearchParams, ClassProto = Class.prototype, searchParams = gOPD(ClassProto, "searchParams"), href = gOPD(ClassProto, "href"), search = gOPD(ClassProto, "search");
        if (!searchParams && search && search.set) {
          createSearchParams = createSearchParamsCreate(createSearchParamsPollute(search));
          Object.defineProperties(ClassProto, {
            href: {
              get: function() {
                return href.get.call(this);
              },
              set: function(value) {
                var sp = this._searchParams;
                href.set.call(this, value);
                if (sp) updateSearchParams(sp);
              }
            },
            search: {
              get: function() {
                return search.get.call(this);
              },
              set: function(value) {
                var sp = this._searchParams;
                search.set.call(this, value);
                if (sp) updateSearchParams(sp);
              }
            },
            searchParams: {
              get: function() {
                verifySearchParams(this, Class);
                return this._searchParams || createSearchParams(this, new URLSearchParams(this.search.slice(1)));
              },
              set: function(sp) {
                verifySearchParams(this, Class);
                createSearchParams(this, sp);
              }
            }
          });
        }
      };
      try {
        upgradeClass(HTMLAnchorElement);
        if (/^function|object$/.test(typeof URL) && URL.prototype) upgradeClass(URL);
      } catch (meh) {}
    })(Object);
  })(self.URLSearchParams.prototype);
  module.exports = self.URLSearchParams;
}, function(module, exports, __webpack_require__) {
  "use strict";
  const ansiRegex = __webpack_require__(114);
  module.exports = string => "string" === typeof string ? string.replace(ansiRegex(), "") : string;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = ({onlyFirst = false} = {}) => {
    const pattern = [ "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)", "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))" ].join("|");
    return new RegExp(pattern, onlyFirst ? void 0 : "g");
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isFullwidthCodePoint = codePoint => {
    if (Number.isNaN(codePoint)) return false;
    if (codePoint >= 4352 && (codePoint <= 4447 || 9001 === codePoint || 9002 === codePoint || 11904 <= codePoint && codePoint <= 12871 && 12351 !== codePoint || 12880 <= codePoint && codePoint <= 19903 || 19968 <= codePoint && codePoint <= 42182 || 43360 <= codePoint && codePoint <= 43388 || 44032 <= codePoint && codePoint <= 55203 || 63744 <= codePoint && codePoint <= 64255 || 65040 <= codePoint && codePoint <= 65049 || 65072 <= codePoint && codePoint <= 65131 || 65281 <= codePoint && codePoint <= 65376 || 65504 <= codePoint && codePoint <= 65510 || 110592 <= codePoint && codePoint <= 110593 || 127488 <= codePoint && codePoint <= 127569 || 131072 <= codePoint && codePoint <= 262141)) return true;
    return false;
  };
  module.exports = isFullwidthCodePoint;
  module.exports.default = isFullwidthCodePoint;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    return /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F|\uD83D\uDC68(?:\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68\uD83C\uDFFB|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|[\u2695\u2696\u2708]\uFE0F|\uD83D[\uDC66\uDC67]|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708])\uFE0F|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C[\uDFFB-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)\uD83C\uDFFB|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB\uDFFC])|\uD83D\uDC69(?:\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB-\uDFFD])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83C\uDFF4\u200D\u2620)\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDF6\uD83C\uDDE6|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDBB\uDDD2-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5\uDEEB\uDEEC\uDEF4-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
  };
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#requests h2 {\n  position: relative;\n}\n#sf-friend-requests-manager {\n  position: absolute;\n  right: 0;\n  bottom: 5px;\n}\n#stream > ol > li {\n  padding-right: 31px !important;\n}\n.sf-friend-request-checkbox {\n  position: absolute;\n  right: 8px;\n  bottom: 12px;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#sf-friends-and-followers-manager {\n  float: right;\n  margin-top: -27px;\n  margin-right: 5px;\n}\n#sf-friends-and-followers-manager a.bl {\n  width: 85px;\n  display: inline-block;\n  float: none;\n}\n#sf-friends-and-followers-manager input[type="checkbox"] {\n  margin-left: 12px;\n}\n#stream > ol > li {\n  position: relative;\n  padding-right: 30px !important;\n}\n.sf-friend-or-follower-checkbox {\n  position: absolute;\n  right: 5px;\n  bottom: 12px;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#sf-batch-remove-private-messages {\n  position: absolute;\n  right: 9px;\n  bottom: 5px;\n}\n#sf-batch-remove-private-messages a.bl {\n  width: 60px;\n  float: none;\n  letter-spacing: 0;\n  cursor: pointer;\n}\n#sf-batch-remove-private-messages input[type="checkbox"] {\n  margin-left: 8px;\n  cursor: pointer;\n}\n#stream > ol > li {\n  position: relative;\n}\n#stream > ol > li .sf-private-message-checkbox {\n  position: absolute;\n  right: 9px;\n  bottom: 15px;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#info {\n  position: relative;\n}\n#sf-batch-remove-statuses {\n  position: absolute;\n  right: 10px;\n  bottom: 5px;\n}\n#sf-batch-remove-statuses select {\n  height: 21px;\n}\n#sf-batch-remove-statuses a.bl {\n  float: right;\n  margin-left: 5px;\n  cursor: pointer;\n}\n#stream > ol > li {\n  position: relative;\n  min-height: 96px;\n}\n#stream.sf-multiple-selection-active li:not(.sf-multiple-selection-in-range) {\n  opacity: 0.6;\n}\n.sf-status-checkbox {\n  position: absolute;\n  right: 10px;\n  bottom: 9px;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, ".tribute-container {\n  transform: translateY(10px);\n  background-color: rgba(255, 255, 255, 0.95);\n  border-radius: 3px;\n  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);\n  z-index: 10;\n}\n.tribute-container ul {\n  list-style: none;\n  padding: 0;\n  margin: auto;\n  border-radius: 3px;\n  overflow: hidden;\n}\n.tribute-container li {\n  display: block;\n  padding: 6px;\n  border-bottom: 1px solid #e5e5e5;\n  cursor: pointer;\n  line-height: 24px;\n  width: 300px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  color: #000;\n}\n.tribute-container li:last-of-type {\n  border-bottom: 0;\n}\n.tribute-container img {\n  border-radius: 2px;\n  width: 24px;\n  height: 24px;\n  display: inline-block;\n  margin-right: 10px;\n}\n.tribute-container strong {\n  color: #06c;\n  border-bottom: 1px solid #06c;\n}\n.tribute-container small {\n  font-size: smaller;\n  color: #777;\n  font-weight: normal;\n}\n.tribute-container li:hover,\n.tribute-container .highlight {\n  background: #06c;\n  color: #fff;\n}\n.tribute-container li:hover strong,\n.tribute-container .highlight strong {\n  color: #fff;\n  font-weight: bold;\n  border-bottom-color: rgba(255, 255, 255, 0.8);\n}\n.tribute-container li:hover small,\n.tribute-container .highlight small {\n  color: rgba(255, 255, 255, 0.8);\n}\n.tribute-container .no-match {\n  color: #999;\n  cursor: not-allowed;\n  text-decoration: line-through;\n}\n.tribute-container .no-match:hover {\n  color: rgba(255, 255, 255, 0.8);\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#savedsearchs .sf-new::after {\n  display: inline-block;\n  margin: 1px 4px;\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n  content: " ";\n  background: rgba(230, 50, 0, 0.75);\n  animation: sf-fade-in 200ms;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#ZoomToAlbum > a[href="null"] {\n  display: none;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(38);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(50);
  var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(125);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
  exports.push([ module.i, "#sf-favorite-fanfouers-list {\n  display: none;\n  margin-bottom: 15px;\n}\n#sf-favorite-fanfouers-list.sf-is-ready {\n  display: block;\n}\n#sf-favorite-fanfouers-list p {\n  margin-right: 15px;\n}\n#sf-favorite-fanfouers-list a {\n  cursor: pointer;\n}\n#sf-favorite-fanfouers-list .sf-tip {\n  margin-right: 15px;\n  width: 10px;\n  float: right;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ') center no-repeat;\n  background-size: 10px;\n  color: transparent;\n  cursor: help;\n}\n.sf-favorite-fanfouer-item {\n  transition-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n}\n.sf-favorite-fanfouer-item a {\n  position: relative;\n}\n.sf-favorite-fanfouer-item .sf-drag-handle {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  height: 13px;\n  opacity: 0;\n  cursor: grab;\n}\n.sf-favorite-fanfouer-item .sf-drag-handle::before,\n.sf-favorite-fanfouer-item .sf-drag-handle::after {\n  content: "";\n  display: block;\n  position: absolute;\n}\n.sf-favorite-fanfouer-item .sf-drag-handle::before {\n  top: 3px;\n  left: 3px;\n  right: 3px;\n  height: 7px;\n  background: rgba(255, 255, 255, 0.85);\n  border-radius: 4px;\n}\n.sf-favorite-fanfouer-item .sf-drag-handle::after {\n  left: 7px;\n  right: 7px;\n  height: 100%;\n  background-position: center;\n  background-image: url(' + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");\n  background-repeat: repeat-x;\n  background-size: 3px;\n  opacity: 0.3;\n}\n.sf-favorite-fanfouer-item:hover .sf-drag-handle {\n  opacity: 1;\n}\n.sf-favorite-fanfouer-sortable-helper {\n  margin: -4px 0 0 -4px !important;\n  padding: 4px;\n  width: 56px !important;\n  background: rgba(255, 255, 255, 0.9);\n  border-radius: 4px;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);\n  pointer-events: auto !important;\n}\n.sf-favorite-fanfouer-sortable-helper .sf-drag-handle {\n  opacity: 1;\n  cursor: grabbing !important;\n}\n.sf-favorite-fanfouers-tooltip .react-tooltip-lite {\n  margin-left: 5px;\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/drag-handle-dots.png";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(38);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(127);
  var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(128);
  var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(129);
  var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(130);
  var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(131);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
  var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
  var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
  var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
  exports.push([ module.i, '#avatar {\n  position: relative;\n  overflow: hidden;\n}\n#sf-favorited-status-indicator {\n  position: absolute;\n  content: "";\n  width: 32px;\n  height: 32px;\n  top: 0;\n  right: 0;\n  z-index: 1;\n  opacity: 0;\n  border-top-right-radius: 2px;\n  display: inline-block;\n  pointer-events: none;\n  background: url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") right top no-repeat;\n  transform: translate(16px, -16px);\n  transition-property: transform, opacity;\n  transition-duration: 200ms;\n}\n#sf-favorited-status-indicator.sf-is-favorited {\n  opacity: 0.85;\n  transform: translate(0, 0);\n}\n#sf-favorited-status-toggler {\n  cursor: pointer;\n  width: 20px;\n  height: 16px;\n  margin: 3px 0 1px 4px;\n  opacity: 0;\n  display: inline-block;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");\n  transition: opacity 200ms;\n}\n#info:hover #sf-favorited-status-toggler {\n  opacity: 1;\n}\n#sf-favorited-status-toggler:not(.sf-is-favorited):hover {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ");\n}\n#sf-favorited-status-toggler.sf-is-favorited {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ");\n}\n#sf-favorited-status-toggler.sf-is-favorited:hover {\n  opacity: 0.75 !important;\n}\n#sf-favorited-status-toggler:active {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") !important;\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/star.svg";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmJ4PSJodHRwczovL2JveHktc3ZnLmNvbSI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjE0OC45MzMiIHkxPSIxMTYuOTU3IiB4Mj0iMTQ4LjkzMyIgeTI9IjIxMi4wNjIiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE2LjgxNyAtMTkuODgpIHNjYWxlKC4xNjk5OCkiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzhjOGM4YyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2NjYyIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxwYXRoIGQ9Ik04LjQ5OSAwTDEwLjYgNi4wNDVsNi4zOTkuMTMtNS4xIDMuODY3IDEuODUzIDYuMTI1LTUuMjUzLTMuNjU1LTUuMjUzIDMuNjU1IDEuODUzLTYuMTI1LTUuMS0zLjg2NyA2LjM5OS0uMTN6IiBieDpzaGFwZT0ic3RhciA4LjQ5OSA4LjkzNyA4LjkzNyA4LjkzNyAwLjQgNSAxQDgzNGEwYmY4IiBmaWxsPSJ1cmwoI2EpIi8+PC9zdmc+";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmJ4PSJodHRwczovL2JveHktc3ZnLmNvbSI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjE0OC45MzMiIHkxPSIxMTYuOTU3IiB4Mj0iMTQ4LjkzMyIgeTI9IjIxMi4wNjIiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE2LjgxNyAtMTkuODgpIHNjYWxlKC4xNjk5OCkiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzhjOGM4YyIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzhjOGM4YyIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxwYXRoIGQ9Ik04LjQ5OSAwTDEwLjYgNi4wNDVsNi4zOTkuMTMtNS4xIDMuODY3IDEuODUzIDYuMTI1LTUuMjUzLTMuNjU1LTUuMjUzIDMuNjU1IDEuODUzLTYuMTI1LTUuMS0zLjg2NyA2LjM5OS0uMTN6IiBieDpzaGFwZT0ic3RhciA4LjQ5OSA4LjkzNyA4LjkzNyA4LjkzNyAwLjQgNSAxQDgzNGEwYmY4IiBmaWxsPSJ1cmwoI2EpIi8+PC9zdmc+";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmJ4PSJodHRwczovL2JveHktc3ZnLmNvbSI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjE0OC45MzMiIHkxPSIxMTYuOTU3IiB4Mj0iMTQ4LjkzMyIgeTI9IjIxMi4wNjIiIGdyYWRpZW50VHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTE2Ljc1OCAtMTkuOTIyKSBzY2FsZSguMTY5OTgpIiBzcHJlYWRNZXRob2Q9InBhZCI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmRlZDYwIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZjdjOTMzIi8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PHBhdGggZD0iTTguNDk5IDBMMTAuNiA2LjA0NWw2LjM5OS4xMy01LjEgMy44NjcgMS44NTMgNi4xMjUtNS4yNTMtMy42NTUtNS4yNTMgMy42NTUgMS44NTMtNi4xMjUtNS4xLTMuODY3IDYuMzk5LS4xM3oiIGJ4OnNoYXBlPSJzdGFyIDguNDk5IDguOTM3IDguOTM3IDguOTM3IDAuNCA1IDFAODM0YTBiZjgiIGZpbGw9InVybCgjYSkiLz48L3N2Zz4=";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOmJ4PSJodHRwczovL2JveHktc3ZnLmNvbSI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjE0OC45MzMiIHkxPSIxMTYuOTU3IiB4Mj0iMTQ4LjkzMyIgeTI9IjIxMi4wNjIiIGdyYWRpZW50VHJhbnNmb3JtPSJtYXRyaXgoLjE2OTk3IC0uMDAxNjggLjAwMTY3IC4xNjkxNSAtMTcuMDEgLTE5LjUzMykiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzNiNzBiMCIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzg0YzBlYiIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxwYXRoIGQ9Ik04LjQ5OSAwTDEwLjYgNi4wNDVsNi4zOTkuMTMtNS4xIDMuODY3IDEuODUzIDYuMTI1LTUuMjUzLTMuNjU1LTUuMjUzIDMuNjU1IDEuODUzLTYuMTI1LTUuMS0zLjg2NyA2LjM5OS0uMTN6IiBieDpzaGFwZT0ic3RhciA4LjQ5OSA4LjkzNyA4LjkzNyA4LjkzNyAwLjQgNSAxQDgzNGEwYmY4IiBmaWxsPSJ1cmwoI2EpIi8+PC9zdmc+";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#phupdate textarea {\n  transition: all 300ms;\n}\n.actpost .formbutton,\n#u_button {\n  transition-property: opacity;\n  transition-duration: 300ms;\n}\n.sf-floating-status-form {\n  position: fixed;\n  top: 0;\n  z-index: 6;\n  background: linear-gradient(to bottom, #ffffff 0%, rgba(255, 255, 255, 0.9) 30%, rgba(255, 255, 255, 0.9) 75%, rgba(255, 255, 255, 0) 100%);\n  border-bottom: none;\n  padding: 10px 0;\n  transition: background-image 300ms;\n}\n.sf-floating-status-form.sf-status-form-textarea-empty:not(.sf-status-form-textarea-focused) {\n  background: linear-gradient(to bottom, #ffffff 0%, rgba(255, 255, 255, 0.9) 30%, rgba(255, 255, 255, 0.9) 60%, rgba(255, 255, 255, 0) 80%);\n}\nbody:not(.sf-show-dnd-upload-tip) .sf-floating-status-form.sf-status-form-textarea-empty:not(.sf-status-form-textarea-focused) textarea {\n  height: 20px !important;\n}\n.sf-floating-status-form.sf-status-form-textarea-focused textarea {\n  height: 4.6em !important;\n}\n.sf-floating-status-form #sf-counter {\n  text-shadow: 0 1px 1px #fff;\n}\n.sf-floating-status-form .actpost .formbutton,\n.sf-floating-status-form #u_button,\n.sf-floating-status-form .upload-button-wrapper,\n.sf-floating-status-form .location-button-wrapper,\n.sf-floating-status-form #sf-counter {\n  opacity: 0;\n}\n.sf-floating-status-form:hover .actpost .formbutton,\n.sf-floating-status-form:hover #u_button,\n.sf-floating-status-form:hover .upload-button-wrapper,\n.sf-floating-status-form:hover .location-button-wrapper,\n.sf-floating-status-form:hover #sf-counter {\n  opacity: 1;\n}\n#phupdate.sf-floating-status-form .act {\n  display: block;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#PopupBox {\n  display: none !important;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(38);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(135);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  exports.push([ module.i, "#pagination-totop {\n  position: fixed;\n  display: block;\n  bottom: 15px;\n  transform: translateX(768px);\n  width: 45px;\n  height: 45px;\n  padding: 0;\n  margin: 0;\n  border-radius: 50px;\n  background-color: rgba(0, 0, 0, 0.5);\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n  background-repeat: no-repeat;\n  background-position: center;\n  background-size: 27px;\n  border: 0 !important;\n  cursor: pointer;\n  color: transparent !important;\n  text-indent: -9999px;\n}\n#pagination-totop:hover {\n  background-color: #000;\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/arrow-up.svg";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#timeline-notification.sf-is-scrolling a::before {\n  border-width: 1px;\n  border-style: solid;\n  border-color: #FDE6BE transparent #E3CEAB #FDE0B0;\n  border-radius: 2px 0 0 2px;\n  background: linear-gradient(to bottom, rgba(255, 255, 255, 0), rgba(253, 230, 190, 0.4));\n}\n#timeline-notification.sf-is-scrolling a[data-scroll-count="1"]::before {\n  width: 33%;\n}\n#timeline-notification.sf-is-scrolling a[data-scroll-count="2"]::before {\n  width: 66%;\n}\n#timeline-notification.sf-is-scrolling a[data-scroll-count="3"]::before {\n  width: 100%;\n  border-radius: 2px;\n  border-right-color: #FDE0B0;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(38);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(138);
  var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(139);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
  exports.push([ module.i, "li.buffered + .sf-contextual-statuses-container {\n  display: none;\n}\n.sf-contextual-statuses-container .sf-contextual-statuses {\n  padding-left: 30px;\n}\n.sf-contextual-statuses-container .sf-toggle,\n.sf-contextual-statuses-container .sf-indicator {\n  position: relative;\n  margin-left: 81%;\n  margin-top: -1.8em;\n  width: 65px;\n  height: 1.8em;\n  border: 0;\n  border-radius: 3px 3px 0 0;\n  border-top-right-radius: 3px;\n  font-size: 90%;\n  line-height: 1.8em;\n  text-align: center;\n  background-color: rgba(0, 0, 0, 0.05);\n  color: #666;\n  cursor: pointer;\n  animation: sf-fade-in 400ms;\n}\n.sf-contextual-statuses-container .sf-toggle:hover,\n.sf-contextual-statuses-container .sf-indicator:hover {\n  background-color: rgba(0, 0, 0, 0.075);\n}\n.sf-contextual-statuses-container .sf-toggle:active,\n.sf-contextual-statuses-container .sf-indicator:active {\n  background-color: rgba(0, 0, 0, 0.125);\n}\n.sf-contextual-statuses-container .sf-toggle:focus,\n.sf-contextual-statuses-container .sf-indicator:focus {\n  outline: 0;\n}\n.sf-contextual-statuses-container .sf-toggle.sf-repost,\n.sf-contextual-statuses-container .sf-toggle.sf-reply {\n  padding: 0 0 0 21px;\n  background-position: 9px center;\n  background-repeat: no-repeat;\n}\n.sf-contextual-statuses-container .sf-toggle.sf-repost {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n}\n.sf-contextual-statuses-container .sf-toggle.sf-reply {\n  background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ');\n}\n.sf-contextual-statuses-container .sf-indicator.sf-waiting {\n  background-image: url("https://static2.fanfou.com/img/ajax.gif");\n  background-repeat: no-repeat;\n  background-position: center;\n  cursor: progress;\n}\n.sf-contextual-statuses-container .sf-indicator.sf-not-available {\n  text-decoration: line-through;\n  cursor: not-allowed;\n}\n#stream ol .sf-contextual-statuses-container li {\n  min-height: 38px;\n  width: 100%;\n  padding: 6px 30px 6px 52px;\n  border-left: 1px solid #eee;\n  font-size: 12px;\n  animation: sf-fade-in 400ms;\n}\n#stream ol .sf-contextual-statuses-container li.sf-last {\n  border-bottom-color: #ddd;\n}\n#stream ol .sf-contextual-statuses-container li .avatar {\n  margin-left: -41px;\n}\n#stream ol .sf-contextual-statuses-container li .avatar img {\n  width: 32px;\n  height: 32px;\n}\nli[sf-contextual-statuses] .content .photo.zoom {\n  margin-bottom: 18px;\n}\n', "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwLjQgMC42MTYgMTQuMiAxMy4wMjkiIHdpZHRoPSIxNC4yIiBoZWlnaHQ9IjEzLjAyOSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNLjQgNC41MTZoNi45djUuMjI5SC40VjQuNTE2em0xNC4yIDIuNjE1bC03LjMgNi41MTRWLjYxNmw3LjMgNi41MTV6IiBmaWxsPSIjY2NjIi8+PC9zdmc+";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDE2MCAxNyAxMyIgd2lkdGg9IjE3IiBoZWlnaHQ9IjEzIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Ik04LjUgMTYwTDAgMTY1LjYzOWw4LjUgNS42Mzh2LTMuNzU5czYuMzc1IDAgOC41IDUuNDgyYzAtOS4yNDEtOC41LTkuMjQxLTguNS05LjI0MVYxNjB6IiBmaWxsPSIjY2NjIi8+PC9zdmc+";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(38);
  var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(141);
  var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(50);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
  var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
  exports.push([ module.i, ".sf-sidebar-statistics {\n  padding-bottom: 1em !important;\n}\n.sf-sidebar-statistics-item {\n  margin: 0 15px;\n  font-size: 12px;\n}\n.sf-sidebar-statistics-item.sf-is-protected {\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat;\n  background-position: right 1px center;\n  background-size: 8px 10px;\n}\n.sf-sidebar-statistics-item .sf-tip {\n  width: 10px;\n  float: right;\n  background: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") center no-repeat;\n  background-size: 10px;\n  color: transparent;\n  opacity: 0;\n  transition: 200ms opacity;\n}\n.sf-sidebar-statistics-item:hover .sf-tip {\n  opacity: 1;\n  cursor: help;\n}\n.sf-sidebar-statistics-item a {\n  padding: 0 !important;\n  background: none !important;\n  box-shadow: none !important;\n  font-weight: normal !important;\n}\n.sf-sidebar-statistics-progressbar {\n  display: block;\n  height: 5px;\n}\n.sf-sidebar-statistics-progressbar > span {\n  display: block;\n  height: 5px;\n  width: 0;\n  transition: width 750ms ease-in-out;\n}\n.sf-sidebar-statistics-progressbar.sf-red {\n  background: rgba(244, 67, 54, 0.1);\n}\n.sf-sidebar-statistics-progressbar.sf-red > span {\n  background: #f44336;\n}\n.sf-sidebar-statistics-progressbar.sf-green {\n  background: rgba(76, 175, 80, 0.1);\n}\n.sf-sidebar-statistics-progressbar.sf-green > span {\n  background: #4caf50;\n}\n.sf-sidebar-statistics-progressbar.sf-blue {\n  background: rgba(33, 150, 243, 0.1);\n}\n.sf-sidebar-statistics-progressbar.sf-blue > span {\n  background: #2196f3;\n}\n", "" ]);
  module.exports = exports;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_exports__["default"] = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/protected.svg";
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#phupdate .textarea-wrapper {\n  position: relative;\n}\n#sf-dnd-upload-tip {\n  display: none;\n  position: absolute;\n  top: 4px;\n  right: 4px;\n  bottom: 4px;\n  left: 4px;\n  border: 1px dashed #2196f3;\n  border-radius: 3px;\n  background: rgba(255, 255, 255, 0.9);\n  align-items: center;\n  justify-content: center;\n  font-size: 14px;\n  user-select: none;\n  animation: sf-fade-in 200ms;\n}\nbody.sf-show-dnd-upload-tip #sf-dnd-upload-tip {\n  display: flex;\n}\n#sf-dnd-upload-tip img {\n  width: 16px;\n  margin-right: 6px;\n  opacity: 0.6;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, "#phupdate .tip {\n  display: none !important;\n}\n#phupdate .actpost {\n  display: table;\n  width: auto !important;\n}\n#phupdate .act .loading {\n  display: inline-block;\n}\n#sf-counter,\n#phupdate .act .formbutton {\n  display: table-cell;\n  vertical-align: middle;\n}\n#sf-counter {\n  padding-right: 8px;\n  color: #444;\n  transition: all 300ms;\n}\n#sf-counter.sf-warning {\n  color: #795548;\n}\n#sf-counter.sf-exceeded {\n  color: #c62828;\n}\n", "" ]);
  module.exports = exports;
}, function(module, exports, __webpack_require__) {
  var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(11);
  exports = ___CSS_LOADER_API_IMPORT___(false);
  exports.push([ module.i, '#user_top.sf-is-ready {\n  position: absolute;\n  width: 202px;\n  z-index: 2;\n  border-radius: 3px;\n  margin: -5px 0 0 -5px;\n  padding: 5px;\n}\n#user_top.sf-is-ready:hover {\n  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);\n  background-color: #fff;\n}\n#user_top.sf-is-ready + #reminder {\n  margin-top: 47px;\n}\n#user_top > a img {\n  width: 32px;\n  height: 32px;\n  margin-right: 10px;\n}\n#user_top > h3::after {\n  content: "\\25BE";\n  margin-left: 7px;\n  opacity: 0.5;\n}\n#sf-user-switcher {\n  display: none;\n  position: relative;\n  margin-top: 6px;\n  border-top: 1px solid #e5e5e5;\n  font-size: 12px;\n  line-height: 24px;\n}\n#user_top.sf-is-ready:hover #sf-user-switcher {\n  display: block;\n}\n#sf-user-switcher a:hover {\n  cursor: pointer;\n}\n#sf-user-switcher .sf-user-item {\n  display: table;\n  width: 100%;\n}\n#sf-user-switcher .sf-user-item:hover {\n  background-color: rgba(0, 0, 0, 0.025);\n}\n#sf-user-switcher .sf-user-item .sf-user-info,\n#sf-user-switcher .sf-user-item .sf-del-icon {\n  display: table-cell;\n  vertical-align: middle;\n}\n#sf-user-switcher .sf-user-item .sf-user-info {\n  width: 100%;\n  height: auto;\n}\n#sf-user-switcher .sf-user-item .sf-user-info img {\n  float: left;\n  width: 16px;\n  height: 16px;\n  margin: 5px;\n}\n#sf-user-switcher .sf-user-item .sf-del-icon {\n  width: 12px;\n  margin: 0 4px;\n  cursor: pointer;\n  visibility: hidden;\n}\n#sf-user-switcher .sf-user-item:hover .sf-del-icon {\n  visibility: visible;\n}\n#sf-user-switcher .sf-add-new-user {\n  padding: 4px 0 1px;\n}\n#sf-user-switcher .sf-add-new-user:not(:first-child) {\n  border-top: 1px solid #e5e5e5;\n}\n#sf-user-switcher .sf-add-new-user .formbutton {\n  letter-spacing: 0;\n  padding: 3px 6px;\n}\n', "" ]);
  module.exports = exports;
}, function(module, exports) {
  var process = module.exports = {};
  var cachedSetTimeout;
  var cachedClearTimeout;
  function defaultSetTimout() {
    throw new Error("setTimeout has not been defined");
  }
  function defaultClearTimeout() {
    throw new Error("clearTimeout has not been defined");
  }
  (function() {
    try {
      if ("function" === typeof setTimeout) cachedSetTimeout = setTimeout; else cachedSetTimeout = defaultSetTimout;
    } catch (e) {
      cachedSetTimeout = defaultSetTimout;
    }
    try {
      if ("function" === typeof clearTimeout) cachedClearTimeout = clearTimeout; else cachedClearTimeout = defaultClearTimeout;
    } catch (e) {
      cachedClearTimeout = defaultClearTimeout;
    }
  })();
  function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) return setTimeout(fun, 0);
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
      cachedSetTimeout = setTimeout;
      return setTimeout(fun, 0);
    }
    try {
      return cachedSetTimeout(fun, 0);
    } catch (e) {
      try {
        return cachedSetTimeout.call(null, fun, 0);
      } catch (e) {
        return cachedSetTimeout.call(this, fun, 0);
      }
    }
  }
  function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) return clearTimeout(marker);
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
      cachedClearTimeout = clearTimeout;
      return clearTimeout(marker);
    }
    try {
      return cachedClearTimeout(marker);
    } catch (e) {
      try {
        return cachedClearTimeout.call(null, marker);
      } catch (e) {
        return cachedClearTimeout.call(this, marker);
      }
    }
  }
  var queue = [];
  var draining = false;
  var currentQueue;
  var queueIndex = -1;
  function cleanUpNextTick() {
    if (!draining || !currentQueue) return;
    draining = false;
    if (currentQueue.length) queue = currentQueue.concat(queue); else queueIndex = -1;
    if (queue.length) drainQueue();
  }
  function drainQueue() {
    if (draining) return;
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;
    var len = queue.length;
    while (len) {
      currentQueue = queue;
      queue = [];
      while (++queueIndex < len) if (currentQueue) currentQueue[queueIndex].run();
      queueIndex = -1;
      len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
  }
  process.nextTick = function(fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) for (var i = 1; i < arguments.length; i++) args[i - 1] = arguments[i];
    queue.push(new Item(fun, args));
    if (1 === queue.length && !draining) runTimeout(drainQueue);
  };
  function Item(fun, array) {
    this.fun = fun;
    this.array = array;
  }
  Item.prototype.run = function() {
    this.fun.apply(null, this.array);
  };
  process.title = "browser";
  process.browser = true;
  process.env = {};
  process.argv = [];
  process.version = "";
  process.versions = {};
  function noop() {}
  process.on = noop;
  process.addListener = noop;
  process.once = noop;
  process.off = noop;
  process.removeListener = noop;
  process.removeAllListeners = noop;
  process.emit = noop;
  process.prependListener = noop;
  process.prependOnceListener = noop;
  process.listeners = function(name) {
    return [];
  };
  process.binding = function(name) {
    throw new Error("process.binding is not supported");
  };
  process.cwd = function() {
    return "/";
  };
  process.chdir = function(dir) {
    throw new Error("process.chdir is not supported");
  };
  process.umask = function() {
    return 0;
  };
}, function(module, exports) {}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;
  (function(root, factory) {
    "use strict";
    if ((true, module.exports) && true) module.exports = factory(); else if (true) !(__WEBPACK_AMD_DEFINE_FACTORY__ = factory, 
    __WEBPACK_AMD_DEFINE_RESULT__ = "function" === typeof __WEBPACK_AMD_DEFINE_FACTORY__ ? __WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module) : __WEBPACK_AMD_DEFINE_FACTORY__, 
    void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  })(0, (function() {
    "use strict";
    var LocalPromise = "undefined" !== typeof Promise ? Promise : function() {
      return {
        then: function() {
          throw new Error("Queue.configure() before use Queue");
        }
      };
    };
    var noop = function() {};
    var resolveWith = function(value) {
      if (value && "function" === typeof value.then) return value;
      return new LocalPromise((function(resolve) {
        resolve(value);
      }));
    };
    function Queue(maxPendingPromises, maxQueuedPromises, options) {
      this.options = options = options || {};
      this.pendingPromises = 0;
      this.maxPendingPromises = "undefined" !== typeof maxPendingPromises ? maxPendingPromises : 1 / 0;
      this.maxQueuedPromises = "undefined" !== typeof maxQueuedPromises ? maxQueuedPromises : 1 / 0;
      this.queue = [];
    }
    Queue.configure = function(GlobalPromise) {
      LocalPromise = GlobalPromise;
    };
    Queue.prototype.add = function(promiseGenerator) {
      var self = this;
      return new LocalPromise((function(resolve, reject, notify) {
        if (self.queue.length >= self.maxQueuedPromises) {
          reject(new Error("Queue limit reached"));
          return;
        }
        self.queue.push({
          promiseGenerator,
          resolve,
          reject,
          notify: notify || noop
        });
        self._dequeue();
      }));
    };
    Queue.prototype.getPendingLength = function() {
      return this.pendingPromises;
    };
    Queue.prototype.getQueueLength = function() {
      return this.queue.length;
    };
    Queue.prototype._dequeue = function() {
      var self = this;
      if (this.pendingPromises >= this.maxPendingPromises) return false;
      var item = this.queue.shift();
      if (!item) {
        if (this.options.onEmpty) this.options.onEmpty();
        return false;
      }
      try {
        this.pendingPromises++;
        resolveWith(item.promiseGenerator()).then((function(value) {
          self.pendingPromises--;
          item.resolve(value);
          self._dequeue();
        }), (function(err) {
          self.pendingPromises--;
          item.reject(err);
          self._dequeue();
        }), (function(message) {
          item.notify(message);
        }));
      } catch (err) {
        self.pendingPromises--;
        item.reject(err);
        self._dequeue();
      }
      return true;
    };
    return Queue;
  }));
}, function(module, exports, __webpack_require__) {
  var map = {
    "./index.js": 44,
    "./notification.js": 149,
    "./scrollManager.js": 41,
    "./statusFormIntersectionObserver.js": 150,
    "./storage.js": 160,
    "./timelineElementObserver.js": 151
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 148;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var dom_chef__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5);
  var select_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(0);
  var element_ready__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6);
  var element_ready__WEBPACK_IMPORTED_MODULE_2___default = __webpack_require__.n(element_ready__WEBPACK_IMPORTED_MODULE_2__);
  var p_sleep__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24);
  var p_sleep__WEBPACK_IMPORTED_MODULE_3___default = __webpack_require__.n(p_sleep__WEBPACK_IMPORTED_MODULE_3__);
  var _libs_fade__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32);
  const FADE_DURATION = 500;
  const STAY_DURATION = 3500;
  const CLASSNAME_INFO = "sysmsg";
  const CLASSNAME_ERROR = "errmsg";
  let container;
  let header;
  function removeExisitingNotifications() {
    const elements = select_dom__WEBPACK_IMPORTED_MODULE_1__["a"].all(`.${CLASSNAME_INFO}, .${CLASSNAME_ERROR}`, container);
    for (const element of elements) element.remove();
  }
  function createNotification(className, text) {
    const element = Object(dom_chef__WEBPACK_IMPORTED_MODULE_0__["h"])("div", {
      className
    }, text);
    header.after(element);
    return element;
  }
  async function animate(element) {
    await Object(_libs_fade__WEBPACK_IMPORTED_MODULE_4__["a"])(element, FADE_DURATION);
    await p_sleep__WEBPACK_IMPORTED_MODULE_3___default()(STAY_DURATION);
    await Object(_libs_fade__WEBPACK_IMPORTED_MODULE_4__["b"])(element, FADE_DURATION);
    element.remove();
  }
  __webpack_exports__["default"] = {
    async ready() {
      container = await element_ready__WEBPACK_IMPORTED_MODULE_2___default()("#container");
      header = await element_ready__WEBPACK_IMPORTED_MODULE_2___default()("#header");
      return container && header;
    },
    create(type, text) {
      removeExisitingNotifications();
      return animate(createNotification(type, text));
    },
    INFO: CLASSNAME_INFO,
    ERROR: CLASSNAME_ERROR
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var element_ready__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
  var element_ready__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(element_ready__WEBPACK_IMPORTED_MODULE_0__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(13);
  let observer;
  let spy;
  const listeners = [];
  function createSpy(update) {
    const documentRect = document.documentElement.getBoundingClientRect();
    const updateRect = update.getBoundingClientRect();
    const updateOffset = updateRect.top - documentRect.top;
    spy = document.createElement("div");
    spy.classList.add("sf-spy");
    spy.style.position = "absolute";
    spy.style.top = updateOffset - 11 + "px";
    spy.style.pointerEvents = "none";
    document.body.append(spy);
    return spy;
  }
  function intersectionObserverCallback([{intersectionRatio}]) {
    const isIntersected = intersectionRatio > 0;
    Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_2__["a"])({
      fns: listeners,
      args: [ isIntersected ]
    });
  }
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    async install() {
      const update = await element_ready__WEBPACK_IMPORTED_MODULE_0___default()("#phupdate");
      if (update) {
        createSpy(update);
        observer = new IntersectionObserver(intersectionObserverCallback);
        observer.observe(spy);
      }
      return !!update;
    },
    uninstall() {
      if (observer) {
        observer.disconnect();
        spy.remove();
        observer = spy = null;
        listeners.length = 0;
      }
    },
    addListener(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_3__["a"])(listeners, fn);
    },
    removeListener(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_4__["a"])(listeners, fn);
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var select_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  var element_ready__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6);
  var element_ready__WEBPACK_IMPORTED_MODULE_1___default = __webpack_require__.n(element_ready__WEBPACK_IMPORTED_MODULE_1__);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
  var _libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23);
  var _libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15);
  var _libs_arrayRemove__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13);
  let stream;
  let observer;
  const map = new WeakMap;
  const callbacks = [];
  function callCallbacks(...args) {
    Object(_libs_safelyInvokeFns__WEBPACK_IMPORTED_MODULE_3__["a"])({
      fns: callbacks,
      args
    });
  }
  function streamMutationObserver(mutationRecords) {
    for (const {addedNodes, removedNodes} of mutationRecords) {
      for (const addedOl of addedNodes) {
        const subObserver = new MutationObserver(olMutationObserver);
        subObserver.observe(addedOl, {
          childList: true
        });
        map.set(addedOl, subObserver);
        callCallbacks([ {
          addedNodes: Array.from(addedOl.children),
          removedNodes: []
        } ]);
      }
      for (const removedOl of removedNodes) {
        const subObserver = map.get(removedOl);
        subObserver.disconnect();
        callCallbacks([ {
          addedNodes: [],
          removedNodes: Array.from(removedOl.children)
        } ]);
      }
    }
  }
  function olMutationObserver(mutationRecords) {
    callCallbacks(mutationRecords.map(mutationRecord => ({
      ...mutationRecord,
      addedNodes: Array.from(mutationRecord.addedNodes),
      removedNodes: Array.from(mutationRecord.removedNodes)
    })));
  }
  function getStatusLists() {
    return select_dom__WEBPACK_IMPORTED_MODULE_0__["a"].all(":scope>ol", stream);
  }
  function getStatuses() {
    return select_dom__WEBPACK_IMPORTED_MODULE_0__["a"].all(":scope>ol>li", stream);
  }
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_2__["a"])({
    async install() {
      stream = await element_ready__WEBPACK_IMPORTED_MODULE_1___default()("#stream");
      if (stream) {
        observer = new MutationObserver(streamMutationObserver);
        observer.observe(stream, {
          childList: true
        });
        streamMutationObserver([ {
          addedNodes: getStatusLists(),
          removedNodes: []
        } ]);
      }
      return !!stream;
    },
    uninstall() {
      if (observer) {
        observer.disconnect();
        observer = null;
        callbacks.length = 0;
      }
    },
    addCallback(fn) {
      Object(_libs_arrayUniquePush__WEBPACK_IMPORTED_MODULE_4__["a"])(callbacks, fn);
      fn([ {
        addedNodes: getStatuses(),
        removedNodes: []
      } ]);
    },
    removeCallback(fn) {
      Object(_libs_arrayRemove__WEBPACK_IMPORTED_MODULE_5__["a"])(callbacks, fn);
      fn([ {
        addedNodes: [],
        removedNodes: getStatuses()
      } ]);
    }
  });
}, function(module, exports, __webpack_require__) {
  var map = {
    "./checkMyNewStatus.js": 159,
    "./index.js": 43,
    "./proxiedAudio.js": 153,
    "./proxiedCreateTab.js": 154,
    "./proxiedFetch.js": 155,
    "./storage.js": 156
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 152;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _environment_bridge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].ready();
    },
    play(audioUrl) {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["PROXIED_AUDIO"],
        payload: {
          audioUrl
        }
      });
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _environment_bridge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].ready();
    },
    create(args) {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["PROXIED_CREATE_TAB"],
        payload: args
      });
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _environment_bridge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].ready();
    },
    get(args) {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["PROXIED_FETCH_GET"],
        payload: args
      });
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _environment_bridge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9);
  var _libs_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
  var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  __webpack_exports__["default"] = Object(_libs_wrapper__WEBPACK_IMPORTED_MODULE_1__["a"])({
    install() {
      return _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].ready();
    },
    async read(key, storageAreaName) {
      const {value} = await _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_READ"],
        payload: {
          storageAreaName,
          key
        }
      });
      return value;
    },
    async write(key, value, storageAreaName) {
      await _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_WRITE"],
        payload: {
          storageAreaName,
          key,
          value
        }
      });
    },
    async delete(key, storageAreaName) {
      await _environment_bridge__WEBPACK_IMPORTED_MODULE_0__["a"].postMessage({
        action: _constants__WEBPACK_IMPORTED_MODULE_2__["STORAGE_DELETE"],
        payload: {
          storageAreaName,
          key
        }
      });
    }
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var _page_namespaceObject = {};
  __webpack_require__.r(_page_namespaceObject);
  __webpack_require__.d(_page_namespaceObject, "default", (function() {
    return _page;
  }));
  var friend_requests_page_namespaceObject = {};
  __webpack_require__.r(friend_requests_page_namespaceObject);
  __webpack_require__.d(friend_requests_page_namespaceObject, "default", (function() {
    return friend_requests_page;
  }));
  var friends_and_followers_page_namespaceObject = {};
  __webpack_require__.r(friends_and_followers_page_namespaceObject);
  __webpack_require__.d(friends_and_followers_page_namespaceObject, "default", (function() {
    return friends_and_followers_page;
  }));
  var batch_remove_private_messages_page_namespaceObject = {};
  __webpack_require__.r(batch_remove_private_messages_page_namespaceObject);
  __webpack_require__.d(batch_remove_private_messages_page_namespaceObject, "default", (function() {
    return batch_remove_private_messages_page;
  }));
  var batch_remove_statuses_page_namespaceObject = {};
  __webpack_require__.r(batch_remove_statuses_page_namespaceObject);
  __webpack_require__.d(batch_remove_statuses_page_namespaceObject, "default", (function() {
    return batch_remove_statuses_page;
  }));
  var disable_old_one_page_namespaceObject = {};
  __webpack_require__.r(disable_old_one_page_namespaceObject);
  __webpack_require__.d(disable_old_one_page_namespaceObject, "default", (function() {
    return disable_old_one_page;
  }));
  var enable_new_one_page_namespaceObject = {};
  __webpack_require__.r(enable_new_one_page_namespaceObject);
  __webpack_require__.d(enable_new_one_page_namespaceObject, "default", (function() {
    return enable_new_one_page;
  }));
  var check_friendship_page_namespaceObject = {};
  __webpack_require__.r(check_friendship_page_namespaceObject);
  __webpack_require__.d(check_friendship_page_namespaceObject, "default", (function() {
    return check_friendship_page;
  }));
  var sidebar_indicators_page_namespaceObject = {};
  __webpack_require__.r(sidebar_indicators_page_namespaceObject);
  __webpack_require__.d(sidebar_indicators_page_namespaceObject, "default", (function() {
    return sidebar_indicators_page;
  }));
  var enrich_statuses_page_namespaceObject = {};
  __webpack_require__.r(enrich_statuses_page_namespaceObject);
  __webpack_require__.d(enrich_statuses_page_namespaceObject, "default", (function() {
    return enrich_statuses_page;
  }));
  var home_page_namespaceObject = {};
  __webpack_require__.r(home_page_namespaceObject);
  __webpack_require__.d(home_page_namespaceObject, "default", (function() {
    return home_page;
  }));
  var user_profile_page_namespaceObject = {};
  __webpack_require__.r(user_profile_page_namespaceObject);
  __webpack_require__.d(user_profile_page_namespaceObject, "default", (function() {
    return user_profile_page;
  }));
  var fix_photo_zoom_page_namespaceObject = {};
  __webpack_require__.r(fix_photo_zoom_page_namespaceObject);
  __webpack_require__.d(fix_photo_zoom_page_namespaceObject, "default", (function() {
    return fix_photo_zoom_page;
  }));
  var floating_status_form_page_namespaceObject = {};
  __webpack_require__.r(floating_status_form_page_namespaceObject);
  __webpack_require__.d(floating_status_form_page_namespaceObject, "default", (function() {
    return floating_status_form_page;
  }));
  var replay_and_repost_page_namespaceObject = {};
  __webpack_require__.r(replay_and_repost_page_namespaceObject);
  __webpack_require__.d(replay_and_repost_page_namespaceObject, "default", (function() {
    return replay_and_repost_page;
  }));
  var go_top_button_page_namespaceObject = {};
  __webpack_require__.r(go_top_button_page_namespaceObject);
  __webpack_require__.d(go_top_button_page_namespaceObject, "default", (function() {
    return go_top_button_page;
  }));
  var keyboard_shortcuts_page_namespaceObject = {};
  __webpack_require__.r(keyboard_shortcuts_page_namespaceObject);
  __webpack_require__.d(keyboard_shortcuts_page_namespaceObject, "default", (function() {
    return keyboard_shortcuts_page;
  }));
  var process_unread_statuses_page_namespaceObject = {};
  __webpack_require__.r(process_unread_statuses_page_namespaceObject);
  __webpack_require__.d(process_unread_statuses_page_namespaceObject, "default", (function() {
    return process_unread_statuses_page;
  }));
  var scroll_to_show_page_namespaceObject = {};
  __webpack_require__.r(scroll_to_show_page_namespaceObject);
  __webpack_require__.d(scroll_to_show_page_namespaceObject, "default", (function() {
    return scroll_to_show_page;
  }));
  var photo_album_page_namespaceObject = {};
  __webpack_require__.r(photo_album_page_namespaceObject);
  __webpack_require__.d(photo_album_page_namespaceObject, "default", (function() {
    return photo_album_page;
  }));
  var photo_entry_page_namespaceObject = {};
  __webpack_require__.r(photo_entry_page_namespaceObject);
  __webpack_require__.d(photo_entry_page_namespaceObject, "default", (function() {
    return photo_entry_page;
  }));
  var status_page_namespaceObject = {};
  __webpack_require__.r(status_page_namespaceObject);
  __webpack_require__.d(status_page_namespaceObject, "default", (function() {
    return status_page;
  }));
  var timeline_page_namespaceObject = {};
  __webpack_require__.r(timeline_page_namespaceObject);
  __webpack_require__.d(timeline_page_namespaceObject, "default", (function() {
    return timeline_page;
  }));
  var share_new_avatar_page_namespaceObject = {};
  __webpack_require__.r(share_new_avatar_page_namespaceObject);
  __webpack_require__.d(share_new_avatar_page_namespaceObject, "default", (function() {
    return share_new_avatar_page;
  }));
  var show_contextual_statuses_page_namespaceObject = {};
  __webpack_require__.r(show_contextual_statuses_page_namespaceObject);
  __webpack_require__.d(show_contextual_statuses_page_namespaceObject, "default", (function() {
    return show_contextual_statuses_page;
  }));
  var fix_reply_and_repost_page_namespaceObject = {};
  __webpack_require__.r(fix_reply_and_repost_page_namespaceObject);
  __webpack_require__.d(fix_reply_and_repost_page_namespaceObject, "default", (function() {
    return fix_reply_and_repost_page;
  }));
  var sidebar_statistics_page_namespaceObject = {};
  __webpack_require__.r(sidebar_statistics_page_namespaceObject);
  __webpack_require__.d(sidebar_statistics_page_namespaceObject, "default", (function() {
    return sidebar_statistics_page;
  }));
  var ajax_form_page_namespaceObject = {};
  __webpack_require__.r(ajax_form_page_namespaceObject);
  __webpack_require__.d(ajax_form_page_namespaceObject, "default", (function() {
    return ajax_form_page;
  }));
  var autofocus_textarea_page_namespaceObject = {};
  __webpack_require__.r(autofocus_textarea_page_namespaceObject);
  __webpack_require__.d(autofocus_textarea_page_namespaceObject, "default", (function() {
    return autofocus_textarea_page;
  }));
  var fix_dnd_upload_page_namespaceObject = {};
  __webpack_require__.r(fix_dnd_upload_page_namespaceObject);
  __webpack_require__.d(fix_dnd_upload_page_namespaceObject, "default", (function() {
    return fix_dnd_upload_page;
  }));
  var fix_upload_images_page_namespaceObject = {};
  __webpack_require__.r(fix_upload_images_page_namespaceObject);
  __webpack_require__.d(fix_upload_images_page_namespaceObject, "default", (function() {
    return fix_upload_images_page;
  }));
  var paste_image_from_clipboard_page_namespaceObject = {};
  __webpack_require__.r(paste_image_from_clipboard_page_namespaceObject);
  __webpack_require__.d(paste_image_from_clipboard_page_namespaceObject, "default", (function() {
    return paste_image_from_clipboard_page;
  }));
  var refresh_status_count_page_namespaceObject = {};
  __webpack_require__.r(refresh_status_count_page_namespaceObject);
  __webpack_require__.d(refresh_status_count_page_namespaceObject, "default", (function() {
    return refresh_status_count_page;
  }));
  var revoke_event_listeners_page_namespaceObject = {};
  __webpack_require__.r(revoke_event_listeners_page_namespaceObject);
  __webpack_require__.d(revoke_event_listeners_page_namespaceObject, "default", (function() {
    return revoke_event_listeners_page;
  }));
  var textarea_state_page_namespaceObject = {};
  __webpack_require__.r(textarea_state_page_namespaceObject);
  __webpack_require__.d(textarea_state_page_namespaceObject, "default", (function() {
    return textarea_state_page;
  }));
  var update_timestamps_page_namespaceObject = {};
  __webpack_require__.r(update_timestamps_page_namespaceObject);
  __webpack_require__.d(update_timestamps_page_namespaceObject, "default", (function() {
    return update_timestamps_page;
  }));
  var login_form_page_namespaceObject = {};
  __webpack_require__.r(login_form_page_namespaceObject);
  __webpack_require__.d(login_form_page_namespaceObject, "default", (function() {
    return login_form_page;
  }));
  var user_switcher_page_namespaceObject = {};
  __webpack_require__.r(user_switcher_page_namespaceObject);
  __webpack_require__.d(user_switcher_page_namespaceObject, "default", (function() {
    return user_switcher_page;
  }));
  var metadata_namespaceObject = {};
  __webpack_require__.r(metadata_namespaceObject);
  __webpack_require__.d(metadata_namespaceObject, "options", (function() {
    return metadata_options;
  }));
  var batch_manage_relationships_metadata_namespaceObject = {};
  __webpack_require__.r(batch_manage_relationships_metadata_namespaceObject);
  __webpack_require__.d(batch_manage_relationships_metadata_namespaceObject, "options", (function() {
    return batch_manage_relationships_metadata_options;
  }));
  var batch_remove_private_messages_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_private_messages_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_private_messages_metadata_namespaceObject, "options", (function() {
    return batch_remove_private_messages_metadata_options;
  }));
  var batch_remove_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(batch_remove_statuses_metadata_namespaceObject);
  __webpack_require__.d(batch_remove_statuses_metadata_namespaceObject, "options", (function() {
    return batch_remove_statuses_metadata_options;
  }));
  var better_at_autocomplete_metadata_namespaceObject = {};
  __webpack_require__.r(better_at_autocomplete_metadata_namespaceObject);
  __webpack_require__.d(better_at_autocomplete_metadata_namespaceObject, "isSoldered", (function() {
    return metadata_isSoldered;
  }));
  var box_shadows_metadata_namespaceObject = {};
  __webpack_require__.r(box_shadows_metadata_namespaceObject);
  __webpack_require__.d(box_shadows_metadata_namespaceObject, "options", (function() {
    return box_shadows_metadata_options;
  }));
  var check_friendship_metadata_namespaceObject = {};
  __webpack_require__.r(check_friendship_metadata_namespaceObject);
  __webpack_require__.d(check_friendship_metadata_namespaceObject, "options", (function() {
    return check_friendship_metadata_options;
  }));
  var check_saved_searches_metadata_namespaceObject = {};
  __webpack_require__.r(check_saved_searches_metadata_namespaceObject);
  __webpack_require__.d(check_saved_searches_metadata_namespaceObject, "options", (function() {
    return check_saved_searches_metadata_options;
  }));
  var enrich_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(enrich_statuses_metadata_namespaceObject);
  __webpack_require__.d(enrich_statuses_metadata_namespaceObject, "options", (function() {
    return enrich_statuses_metadata_options;
  }));
  var favorite_fanfouers_metadata_namespaceObject = {};
  __webpack_require__.r(favorite_fanfouers_metadata_namespaceObject);
  __webpack_require__.d(favorite_fanfouers_metadata_namespaceObject, "options", (function() {
    return favorite_fanfouers_metadata_options;
  }));
  var fix_photo_zoom_metadata_namespaceObject = {};
  __webpack_require__.r(fix_photo_zoom_metadata_namespaceObject);
  __webpack_require__.d(fix_photo_zoom_metadata_namespaceObject, "isSoldered", (function() {
    return fix_photo_zoom_metadata_isSoldered;
  }));
  var floating_status_form_metadata_namespaceObject = {};
  __webpack_require__.r(floating_status_form_metadata_namespaceObject);
  __webpack_require__.d(floating_status_form_metadata_namespaceObject, "options", (function() {
    return floating_status_form_metadata_options;
  }));
  var go_top_button_metadata_namespaceObject = {};
  __webpack_require__.r(go_top_button_metadata_namespaceObject);
  __webpack_require__.d(go_top_button_metadata_namespaceObject, "isSoldered", (function() {
    return go_top_button_metadata_isSoldered;
  }));
  var google_analytics_metadata_namespaceObject = {};
  __webpack_require__.r(google_analytics_metadata_namespaceObject);
  __webpack_require__.d(google_analytics_metadata_namespaceObject, "isSoldered", (function() {
    return google_analytics_metadata_isSoldered;
  }));
  var keyboard_shortcuts_metadata_namespaceObject = {};
  __webpack_require__.r(keyboard_shortcuts_metadata_namespaceObject);
  __webpack_require__.d(keyboard_shortcuts_metadata_namespaceObject, "isSoldered", (function() {
    return keyboard_shortcuts_metadata_isSoldered;
  }));
  var notifications_metadata_namespaceObject = {};
  __webpack_require__.r(notifications_metadata_namespaceObject);
  __webpack_require__.d(notifications_metadata_namespaceObject, "options", (function() {
    return notifications_metadata_options;
  }));
  var process_unread_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(process_unread_statuses_metadata_namespaceObject);
  __webpack_require__.d(process_unread_statuses_metadata_namespaceObject, "options", (function() {
    return process_unread_statuses_metadata_options;
  }));
  var remove_app_recommendations_metadata_namespaceObject = {};
  __webpack_require__.r(remove_app_recommendations_metadata_namespaceObject);
  __webpack_require__.d(remove_app_recommendations_metadata_namespaceObject, "options", (function() {
    return remove_app_recommendations_metadata_options;
  }));
  var remove_brackets_metadata_namespaceObject = {};
  __webpack_require__.r(remove_brackets_metadata_namespaceObject);
  __webpack_require__.d(remove_brackets_metadata_namespaceObject, "isSoldered", (function() {
    return remove_brackets_metadata_isSoldered;
  }));
  var remove_logo_beta_metadata_namespaceObject = {};
  __webpack_require__.r(remove_logo_beta_metadata_namespaceObject);
  __webpack_require__.d(remove_logo_beta_metadata_namespaceObject, "options", (function() {
    return remove_logo_beta_metadata_options;
  }));
  var remove_personalized_theme_metadata_namespaceObject = {};
  __webpack_require__.r(remove_personalized_theme_metadata_namespaceObject);
  __webpack_require__.d(remove_personalized_theme_metadata_namespaceObject, "options", (function() {
    return remove_personalized_theme_metadata_options;
  }));
  var retinafy_photos_metadata_namespaceObject = {};
  __webpack_require__.r(retinafy_photos_metadata_namespaceObject);
  __webpack_require__.d(retinafy_photos_metadata_namespaceObject, "isSoldered", (function() {
    return retinafy_photos_metadata_isSoldered;
  }));
  var share_new_avatar_metadata_namespaceObject = {};
  __webpack_require__.r(share_new_avatar_metadata_namespaceObject);
  __webpack_require__.d(share_new_avatar_metadata_namespaceObject, "isSoldered", (function() {
    return share_new_avatar_metadata_isSoldered;
  }));
  var share_to_fanfou_metadata_namespaceObject = {};
  __webpack_require__.r(share_to_fanfou_metadata_namespaceObject);
  __webpack_require__.d(share_to_fanfou_metadata_namespaceObject, "options", (function() {
    return share_to_fanfou_metadata_options;
  }));
  var show_contextual_statuses_metadata_namespaceObject = {};
  __webpack_require__.r(show_contextual_statuses_metadata_namespaceObject);
  __webpack_require__.d(show_contextual_statuses_metadata_namespaceObject, "options", (function() {
    return show_contextual_statuses_metadata_options;
  }));
  var sidebar_statistics_metadata_namespaceObject = {};
  __webpack_require__.r(sidebar_statistics_metadata_namespaceObject);
  __webpack_require__.d(sidebar_statistics_metadata_namespaceObject, "isSoldered", (function() {
    return sidebar_statistics_metadata_isSoldered;
  }));
  var status_form_enhancements_metadata_namespaceObject = {};
  __webpack_require__.r(status_form_enhancements_metadata_namespaceObject);
  __webpack_require__.d(status_form_enhancements_metadata_namespaceObject, "isSoldered", (function() {
    return status_form_enhancements_metadata_isSoldered;
  }));
  var translucent_sidebar_metadata_namespaceObject = {};
  __webpack_require__.r(translucent_sidebar_metadata_namespaceObject);
  __webpack_require__.d(translucent_sidebar_metadata_namespaceObject, "options", (function() {
    return translucent_sidebar_metadata_options;
  }));
  var update_timestamps_metadata_namespaceObject = {};
  __webpack_require__.r(update_timestamps_metadata_namespaceObject);
  __webpack_require__.d(update_timestamps_metadata_namespaceObject, "isSoldered", (function() {
    return update_timestamps_metadata_isSoldered;
  }));
  var user_switcher_metadata_namespaceObject = {};
  __webpack_require__.r(user_switcher_metadata_namespaceObject);
  __webpack_require__.d(user_switcher_metadata_namespaceObject, "isSoldered", (function() {
    return user_switcher_metadata_isSoldered;
  }));
  var _typeof = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(obj) {
    return typeof obj;
  } : function(obj) {
    return obj && "function" === typeof Symbol && obj.constructor === Symbol ? "symbol" : typeof obj;
  };
  var iselement_module = function(input) {
    return null != input && "object" === ("undefined" === typeof input ? "undefined" : _typeof(input)) && 1 === input.nodeType && "object" === _typeof(input.style) && "object" === _typeof(input.ownerDocument);
  };
  var delimiters = [ " ", "-", "_" ];
  function toKebabCase() {
    var input = arguments.length <= 0 || void 0 === arguments[0] ? "" : arguments[0];
    var characters = input.split("");
    var result = [];
    characters.forEach((function(character) {
      var lowercase_character = character.toLowerCase();
      if (character !== lowercase_character) result.push("-", lowercase_character); else if (-1 !== delimiters.indexOf(character)) result.push("-"); else result.push(character);
    }));
    return result.join("");
  }
  var re_color = /^rgb\((\d+),\s?(\d+),\s?(\d+)\)$/;
  var re_prop = /^(-?\d*\.?\d*)(.*)$/;
  function convertColorComponent(input) {
    var result = input.toString(16);
    if (result.length < 2) result = "0" + result;
    return result;
  }
  function parseColorProperty(value) {
    var matches = value.match(re_color);
    var result = {};
    result.unit = "rgb";
    result.value = [ parseInt(matches[1], 10), parseInt(matches[2], 10), parseInt(matches[3], 10) ];
    result.output = "#" + convertColorComponent(result.value[0]) + convertColorComponent(result.value[1]) + convertColorComponent(result.value[2]);
    return result;
  }
  function parseRegularProperty(value) {
    var result = {
      unit: "",
      value: null,
      output: "auto"
    };
    if ("auto" !== value) {
      var matches = value.match(re_prop);
      result.value = parseFloat(matches[1]);
      result.unit = matches[2];
      result.output = result.value + result.unit;
    }
    return result;
  }
  var parse_property_value = function(value) {
    var result = re_color.test(value) ? parseColorProperty(value) : parseRegularProperty(value);
    result.original = value;
    return result;
  };
  function fixWebcomponentsElement(element) {
    if ("undefined" !== typeof window.ShadowDOMPolyfill) {
      var is_native = -1 !== document.defaultView.getComputedStyle.toString().indexOf("[native code]");
      var is_wrapped = "undefined" !== typeof element.__impl4cf1e782hg__;
      if (is_native && is_wrapped) element = window.ShadowDOMPolyfill.unwrap(element);
      if (!is_native && !is_wrapped) element = window.ShadowDOMPolyfill.wrap(element);
    }
    return element;
  }
  function getStyleProperty(element, property) {
    property = toKebabCase(property);
    element = fixWebcomponentsElement(element);
    var value = document.defaultView.getComputedStyle(element, null).getPropertyValue(property);
    return parse_property_value(value);
  }
  function getStyle(element, property) {
    if (window.getComputedStyle) return getStyleProperty(element, property).original; else if (element.currentStyle) return element.currentStyle[property];
    return null;
  }
  function isVisible(element) {
    if (!iselement_module(element)) return false;
    var body_element = document.querySelector("body");
    var html_element = document.querySelector("html");
    if (!body_element || !body_element.contains(element)) return false;
    if ("hidden" === getStyle(element, "visibility")) return false;
    while (element && element !== body_element && element !== html_element) {
      if ("none" === getStyle(element, "display")) return false;
      if ("0" === getStyle(element, "opacity").toString()) return false;
      element = element.parentNode;
    }
    return true;
  }
  var is_visible_module = isVisible;
  var just_debounce_it = __webpack_require__(40);
  var just_debounce_it_default = __webpack_require__.n(just_debounce_it);
  var select_dom = __webpack_require__(0);
  var index_esm = __webpack_require__(10);
  var element_ready = __webpack_require__(6);
  var element_ready_default = __webpack_require__.n(element_ready);
  var js_cookie = __webpack_require__(33);
  var js_cookie_default = __webpack_require__.n(js_cookie);
  var getLoggedInUserId = Object(index_esm["a"])(() => js_cookie_default.a.get("u"));
  var getLoggedInUserProfilePageUrl = __webpack_require__(25);
  var is_promise = __webpack_require__(27);
  var is_promise_default = __webpack_require__.n(is_promise);
  var promiseAny = iterable => new Promise(resolve => {
    const total = iterable.length;
    let count = 0;
    let done = false;
    if (0 === total) return resolve(false);
    function check(value) {
      if (done) return;
      if (value) {
        done = true;
        resolve(true);
      } else fail();
    }
    function fail() {
      if (done) return;
      if (++count === total) {
        done = true;
        resolve(false);
      }
    }
    for (const item of iterable) {
      if (done) return;
      if (is_promise_default()(item)) item.then(check, fail); else check(item);
    }
  });
  var promiseEvery = __webpack_require__(7);
  function neg(x) {
    return is_promise_default()(x) ? x.then(neg) : !x;
  }
  function isHomePage() {
    return "/home" === window.location.pathname;
  }
  function isLoginPage() {
    return "/" === window.location.pathname || "/login" === window.location.pathname;
  }
  function isLoggedInUserProfilePage() {
    const userId = getLoggedInUserId();
    return userId && window.location.pathname.split("/")[1] === userId;
  }
  const isLoggedInUserFriendsListPage = Object(index_esm["a"])(async () => {
    if (!isFriendsListPage()) return false;
    await element_ready_default()("#stream");
    const urlA = Object(select_dom["a"])(".tabs .crumb").href;
    const urlB = Object(getLoggedInUserProfilePageUrl["a"])();
    return urlA === urlB;
  });
  const isLoggedInUserFollowersListPage = Object(index_esm["a"])(async () => {
    if (!isFollowersListPage()) return false;
    await element_ready_default()("#stream");
    const urlA = Object(select_dom["a"])(".tabs .crumb").href;
    const urlB = Object(getLoggedInUserProfilePageUrl["a"])();
    return urlA === urlB;
  });
  const isUserProfilePage = Object(index_esm["a"])(() => promiseAny([ element_ready_default()("#overlay-report"), isLoggedInUserProfilePage() ]));
  function isPhotoAlbumPage() {
    return window.location.pathname.startsWith("/album/");
  }
  function isPhotoEntryPage() {
    return window.location.pathname.startsWith("/photo/");
  }
  function isStatusPage() {
    return window.location.pathname.startsWith("/statuses/");
  }
  function isFavoritesPage() {
    return window.location.pathname.startsWith("/favorites/");
  }
  function isFriendsListPage() {
    return "friends" === window.location.pathname.split("/")[1];
  }
  function isFollowersListPage() {
    return "followers" === window.location.pathname.split("/")[1];
  }
  const isUserPage = Object(index_esm["a"])(() => promiseAny([ isUserProfilePage(), isPhotoAlbumPage(), isPhotoEntryPage(), isFavoritesPage(), isFriendsListPage(), isFollowersListPage() ]));
  Object(index_esm["a"])(() => {
    const userId = getLoggedInUserId();
    return promiseAny([ isLoggedInUserProfilePage(), Object(promiseEvery["a"])([ isUserPage(), window.location.pathname.split("/")[2] === userId ]) ]);
  });
  function isPrivateMessagePage() {
    return "privatemsg" === window.location.pathname.split("/")[1];
  }
  function isPublicTimelinePage() {
    return "/browse" === window.location.pathname;
  }
  function isFriendRequestPage() {
    return "/friend.request" === window.location.pathname;
  }
  const isTimelinePage = Object(index_esm["a"])(() => Object(promiseEvery["a"])([ element_ready_default()("#stream"), neg(isFriendRequestPage()) ]));
  const BUFFER = 500;
  const SCROLL_DEBOUNCE_WAIT = 250;
  var _page = context => {
    const {requireModules, elementCollection} = context;
    const {scrollManager} = requireModules([ "scrollManager" ]);
    const onScroll = just_debounce_it_default()(() => {
      if (!hasReachedBottom()) return;
      if (isLoading()) return;
      if (!isButtonVisible()) return;
      loadMore();
    }, SCROLL_DEBOUNCE_WAIT);
    elementCollection.add({
      buttonMore: "#pagination-more"
    });
    function loadMore() {
      elementCollection.get("buttonMore").click();
    }
    function hasReachedBottom() {
      const scrollY = scrollManager.getScrollTop() + document.documentElement.clientHeight;
      const buttonY = elementCollection.get("buttonMore").offsetTop;
      return buttonY <= scrollY + BUFFER;
    }
    function isLoading() {
      return elementCollection.get("buttonMore").classList.contains("loading");
    }
    function isButtonVisible() {
      return is_visible_module(elementCollection.get("buttonMore"));
    }
    return {
      applyWhen: () => Object(promiseEvery["a"])([ neg(isPublicTimelinePage()), elementCollection.ready("buttonMore") ]),
      onLoad() {
        scrollManager.addListener(onScroll);
      },
      onUnload() {
        scrollManager.removeListener(onScroll);
      }
    };
  };
  var dom_chef = __webpack_require__(5);
  var dist = __webpack_require__(14);
  var keepRetry = __webpack_require__(22);
  var isElementInDocument = element => {
    const root = element.ownerDocument.documentElement;
    const isInDocument = root.contains(element);
    return isInDocument;
  };
  const TIMEOUT_MS = 5e3;
  var untilElementRemoved = element => {
    const start = Date.now();
    return Object(keepRetry["a"])({
      checker: () => !isElementInDocument(element),
      until: () => Date.now() - start > TIMEOUT_MS
    });
  };
  var noop = __webpack_require__(21);
  var friend_requests_page = context => {
    const {elementCollection} = context;
    const CLASSNAME_CHECKBOX = "sf-friend-request-checkbox";
    const ACTION_TIP_MAP = {
      "friend.acceptadd": "确定要通过选中的 %n 个关注请求并请求回关吗？",
      "friend.accept": "确定要通过选中的 %n 个关注请求吗？",
      "friend.deny": "确定要忽略选中的 %n 个关注请求吗？"
    };
    const NO_REQUESTS_TIP = "目前没有关注请求";
    let container;
    const options = [ {
      label: "批量处理……"
    }, {
      label: "全选",
      handler: () => modifyCheckedStates(() => true)
    }, {
      label: "反选",
      handler: () => modifyCheckedStates(neg)
    }, {
      label: "取消选择",
      handler: () => modifyCheckedStates(() => false)
    }, {
      label: "接受请求并关注",
      handler: () => processFriendRequests("friend.acceptadd")
    }, {
      label: "接受请求",
      handler: () => processFriendRequests("friend.accept")
    }, {
      label: "忽略请求",
      handler: () => processFriendRequests("friend.deny")
    } ];
    elementCollection.add({
      countTip: "#requests h2"
    });
    function createContainer() {
      container = Object(dom_chef["h"])("div", {
        id: "sf-friend-requests-manager"
      }, Object(dom_chef["h"])("select", {
        onChange: onSelectChanged
      }, options.map((option, index) => Object(dom_chef["h"])("option", {
        key: index
      }, option.label))));
    }
    function addCheckbox(li) {
      const checkbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        className: CLASSNAME_CHECKBOX
      });
      li.append(checkbox);
    }
    function getAllCheckboxes() {
      return select_dom["a"].all("." + CLASSNAME_CHECKBOX);
    }
    function onSelectChanged(event) {
      const selectElement = event.target;
      const selectedOption = options[selectElement.selectedIndex];
      const handler = selectedOption.handler || noop["a"];
      handler();
      selectElement.selectedIndex = 0;
    }
    function modifyCheckedStates(fn) {
      for (const checkbox of getAllCheckboxes()) checkbox.checked = fn(checkbox.checked);
    }
    function processFriendRequests(action) {
      const checkedCheckboxes = getAllCheckboxes().filter(checkbox => checkbox.checked);
      const friendRequestsToProcess = checkedCheckboxes.map(checkbox => checkbox.parentElement);
      const count = checkedCheckboxes.length;
      const actionTip = ACTION_TIP_MAP[action].replace("%n", count);
      if (count && window.confirm(actionTip)) for (const li of friendRequestsToProcess) processFriendRequest(li, action);
    }
    async function processFriendRequest(li, action) {
      const button = Object(select_dom["a"])("a.post_act", li);
      const url = window.location.href;
      const data = {
        ajax: "yes",
        action,
        friend: Object(select_dom["a"])(".name", li).getAttribute("href").split("/").pop(),
        token: button.getAttribute("token")
      };
      await Object(dist["a"])(url).formUrl(data).post();
      window.FF.util.yFadeRemove(button, "li");
      await untilElementRemoved(li);
      countTipMinusOne();
    }
    function countTipMinusOne() {
      const {countTip} = elementCollection.getAll();
      const textNode = countTip.firstChild;
      const oldCount = parseInt(textNode.textContent.match(/^\d+/)[0], 10);
      const newCount = oldCount - 1;
      textNode.textContent = newCount ? textNode.textContent.replace(oldCount, newCount) : NO_REQUESTS_TIP;
    }
    return {
      applyWhen: () => isFriendRequestPage(),
      waitReady: () => element_ready_default()("#footer"),
      onLoad() {
        createContainer();
        for (const li of select_dom["a"].all("#stream > ol > li")) addCheckbox(li);
        elementCollection.get("countTip").append(container);
      },
      onUnload() {
        container.remove();
        container = null;
        for (const checkbox of getAllCheckboxes()) checkbox.remove();
      }
    };
  };
  const friends_and_followers_page_CLASSNAME_CHECKBOX = "sf-friend-or-follower-checkbox";
  const MESSAGE_CONFIRMING_FRIENDS = "确定要取消关注选定的 %n 个用户吗？";
  const MESSAGE_CONFIRMING_FOLLOWERS = "确定要删除选定的 %n 个用户吗？";
  var friends_and_followers_page = context => {
    const {requireModules, elementCollection} = context;
    const {notification} = requireModules([ "notification" ]);
    let container;
    let masterCheckbox;
    elementCollection.add({
      countTip: "#friends h2"
    });
    function createMasterCheckbox() {
      masterCheckbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        onChange: onMasterCheckboxChanged
      });
    }
    function createContainer() {
      const label = isFriendsListPage() ? "取消关注选定" : "删除选定用户";
      container = Object(dom_chef["h"])("div", {
        id: "sf-friends-and-followers-manager"
      }, Object(dom_chef["h"])("a", {
        className: "bl",
        onClick: onRemoveSelectedClicked
      }, label), masterCheckbox);
    }
    function addCheckbox(li) {
      const checkbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        className: friends_and_followers_page_CLASSNAME_CHECKBOX,
        onChange: onCheckboxChanged
      });
      li.append(checkbox);
    }
    function getAllCheckboxes() {
      return select_dom["a"].all("." + friends_and_followers_page_CLASSNAME_CHECKBOX);
    }
    function onMasterCheckboxChanged() {
      for (const checkbox of getAllCheckboxes()) checkbox.checked = masterCheckbox.checked;
    }
    function onCheckboxChanged() {
      const allCheckboxes = getAllCheckboxes();
      const checkedCheckboxes = allCheckboxes.filter(checkbox => checkbox.checked);
      if (0 === checkedCheckboxes.length) {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = false;
      } else if (checkedCheckboxes.length === allCheckboxes.length) {
        masterCheckbox.checked = true;
        masterCheckbox.indeterminate = false;
      } else {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = true;
      }
    }
    function onRemoveSelectedClicked() {
      const usersToRemove = getAllCheckboxes().filter(checkbox => checkbox.checked).map(checkbox => checkbox.parentElement);
      const count = usersToRemove.length;
      const confirmingMessage = isFriendsListPage() ? MESSAGE_CONFIRMING_FRIENDS : MESSAGE_CONFIRMING_FOLLOWERS;
      if (count && window.confirm(confirmingMessage.replace("%n", count))) usersToRemove.forEach(removeUser);
    }
    async function removeUser(li) {
      const button = Object(select_dom["a"])("[token]", li);
      const url = window.location.href;
      const data = {
        ajax: "yes",
        token: button.getAttribute("token")
      };
      const userId = Object(select_dom["a"])(".name", li).getAttribute("href").split("/").pop();
      if (isFriendsListPage()) {
        data.action = "friend.remove";
        data.friend = userId;
      } else {
        data.action = "follower.remove";
        data.follower = userId;
      }
      const response = await Object(dist["a"])(url).formUrl(data).post().json();
      if (response.status) {
        window.FF.util.yFadeRemove(button, "li");
        await untilElementRemoved(li);
        onCheckboxChanged();
      } else notification.create(notification.ERROR, response.msg);
    }
    return {
      applyWhen: () => promiseAny([ isLoggedInUserFriendsListPage(), isLoggedInUserFollowersListPage() ]),
      waitReady: () => element_ready_default()("#footer"),
      onLoad() {
        createMasterCheckbox();
        createContainer();
        for (const li of select_dom["a"].all("#stream > ol > li")) addCheckbox(li);
        elementCollection.get("countTip").after(container);
      },
      onUnload() {
        container.remove();
        container = masterCheckbox = null;
        for (const checkbox of getAllCheckboxes()) checkbox.remove();
      }
    };
  };
  const _page_CLASSNAME_CHECKBOX = "sf-private-message-checkbox";
  const MESSAGE_CONFIRMING = "确定要删除选定的 %n 条私信吗？";
  var batch_remove_private_messages_page = context => {
    const {requireModules} = context;
    const {notification} = requireModules([ "notification" ]);
    let container;
    let masterCheckbox;
    function createMasterCheckbox() {
      masterCheckbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        onChange: onMasterCheckboxChanged
      });
    }
    function createContainer() {
      container = Object(dom_chef["h"])("div", {
        id: "sf-batch-remove-private-messages"
      }, Object(dom_chef["h"])("a", {
        className: "bl",
        onClick: onRemoveSelectedClicked
      }, "删除选定"), masterCheckbox);
    }
    function addCheckbox(li) {
      const checkbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        className: _page_CLASSNAME_CHECKBOX,
        onChange: onCheckboxChanged
      });
      li.append(checkbox);
    }
    function getAllCheckboxes() {
      return select_dom["a"].all("." + _page_CLASSNAME_CHECKBOX);
    }
    function onMasterCheckboxChanged() {
      for (const checkbox of getAllCheckboxes()) checkbox.checked = masterCheckbox.checked;
    }
    function onCheckboxChanged() {
      const allCheckboxes = getAllCheckboxes();
      const checkedCheckboxes = allCheckboxes.filter(checkbox => checkbox.checked);
      if (0 === checkedCheckboxes.length) {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = false;
      } else if (checkedCheckboxes.length === allCheckboxes.length) {
        masterCheckbox.checked = true;
        masterCheckbox.indeterminate = false;
      } else {
        masterCheckbox.checked = false;
        masterCheckbox.indeterminate = true;
      }
    }
    function onRemoveSelectedClicked() {
      const privateMessagesToRemove = getAllCheckboxes().filter(checkbox => checkbox.checked).map(checkbox => checkbox.parentElement);
      const count = privateMessagesToRemove.length;
      if (count && window.confirm(MESSAGE_CONFIRMING.replace("%n", count))) privateMessagesToRemove.forEach(removePrivateMessage);
    }
    async function removePrivateMessage(li) {
      const button = Object(select_dom["a"])(":scope > .op > .delete", li);
      const url = button.href;
      const data = {
        ajax: "yes",
        action: "privatemsg.del",
        privatemsg: button.href.split("/").pop(),
        token: button.getAttribute("token")
      };
      const response = await Object(dist["a"])(url).formUrl(data).post().json();
      if (response.status) {
        window.FF.util.yFadeRemove(button, "li");
        await untilElementRemoved(li);
        onCheckboxChanged();
      } else notification.create(notification.ERROR, response.msg);
    }
    return {
      applyWhen: () => isPrivateMessagePage(),
      waitReady: () => element_ready_default()("#footer"),
      onLoad() {
        createMasterCheckbox();
        createContainer();
        for (const li of select_dom["a"].all("#stream > ol > li")) addCheckbox(li);
        Object(select_dom["a"])("#main .tabs").append(container);
      },
      onUnload() {
        container.remove();
        container = masterCheckbox = null;
        for (const checkbox of getAllCheckboxes()) checkbox.remove();
      }
    };
  };
  var collapseSelection = () => {
    getSelection().removeAllRanges();
  };
  const batch_remove_statuses_page_CLASSNAME_CHECKBOX = "sf-status-checkbox";
  const _page_MESSAGE_CONFIRMING = "确定要删除选定的 %n 条消息吗？";
  const CLASSNAME_MULTIPLE_SELECTION_ACTIVE = "sf-multiple-selection-active";
  const CLASSNAME_MULTIPLE_SELECTION_IN_RANGE = "sf-multiple-selection-in-range";
  var batch_remove_statuses_page = context => {
    const {requireModules, elementCollection, registerDOMEventListener} = context;
    const {notification} = requireModules([ "notification" ]);
    let container;
    const options = [ {
      label: "批量处理……"
    }, {
      label: "全选",
      handler: () => modifyCheckedStates(() => true)
    }, {
      label: "反选",
      handler: () => modifyCheckedStates((li, currentState) => !currentState)
    }, {
      label: "选中回复",
      handler() {
        modifyCheckedStates((li, currentState) => "reply" === getStatusType(li) || currentState);
      }
    }, {
      label: "选中转发",
      handler() {
        modifyCheckedStates((li, currentState) => "repost" === getStatusType(li) || currentState);
      }
    }, {
      label: "选中回复和转发",
      handler() {
        modifyCheckedStates((li, currentState) => "normal" !== getStatusType(li) || currentState);
      }
    }, {
      label: "取消选择",
      handler: () => modifyCheckedStates(() => false)
    } ];
    const multipleSelectionInitialState = {
      isActive: false,
      startingLi: null,
      previousSelected: []
    };
    const multipleSelectionState = {
      ...multipleSelectionInitialState
    };
    elementCollection.add({
      stream: "#stream",
      statuses: {
        selector: "#stream > ol > li",
        getAll: true
      }
    });
    registerDOMEventListener("stream", "click", onClick);
    registerDOMEventListener("statuses", "mouseenter", onMouseEnter);
    registerDOMEventListener(window, "keyup", onKeyUp);
    function createContainer() {
      container = Object(dom_chef["h"])("div", {
        id: "sf-batch-remove-statuses"
      }, Object(dom_chef["h"])("select", {
        onChange: onSelectChanged
      }, options.map((option, index) => Object(dom_chef["h"])("option", {
        key: index
      }, option.label))), Object(dom_chef["h"])("a", {
        className: "bl",
        onClick: onRemoveSelectedClicked
      }, "删除选定"));
    }
    function addCheckbox(li) {
      const checkbox = Object(dom_chef["h"])("input", {
        type: "checkbox",
        className: batch_remove_statuses_page_CLASSNAME_CHECKBOX
      });
      li.append(checkbox);
    }
    function getAllCheckboxes() {
      return select_dom["a"].all("." + batch_remove_statuses_page_CLASSNAME_CHECKBOX);
    }
    function onSelectChanged(event) {
      const selectElement = event.target;
      const selectedOption = options[selectElement.selectedIndex];
      const handler = selectedOption.handler || noop["a"];
      handler();
      selectElement.selectedIndex = 0;
    }
    function modifyCheckedStates(fn) {
      for (const checkbox of getAllCheckboxes()) {
        const li = checkbox.parentElement;
        const currentState = checkbox.checked;
        checkbox.checked = fn(li, currentState);
      }
    }
    function getStatusType(li) {
      const reply = Object(select_dom["a"])(":scope > .stamp > .reply", li);
      const text = (null === reply || void 0 === reply ? void 0 : reply.textContent) || "";
      let type = "normal";
      if (/^给.+的回复/.test(text)) type = "reply"; else if (text.startsWith("转自")) type = "repost";
      return type;
    }
    function getSelectedStatuses() {
      return getAllCheckboxes().filter(checkbox => checkbox.checked).map(checkbox => checkbox.parentElement);
    }
    async function onRemoveSelectedClicked() {
      const statusesToRemove = getSelectedStatuses();
      const count = statusesToRemove.length;
      if (count && window.confirm(_page_MESSAGE_CONFIRMING.replace("%n", count))) {
        await Promise.all(statusesToRemove.map(removeStatus));
        window.location.reload();
      }
    }
    async function removeStatus(li) {
      const button = Object(select_dom["a"])(":scope > .op > .delete", li);
      const [id, actionType] = button.href.split("/").reverse();
      const fieldName = actionType.split(".")[0];
      const url = window.location.href;
      const data = {
        ajax: "yes",
        action: actionType,
        [fieldName]: id,
        token: button.getAttribute("token")
      };
      const response = await Object(dist["a"])(url).formUrl(data).post().json();
      if (response.status) window.FF.util.yFadeRemove(button, "li"); else notification.create(notification.ERROR, response.msg);
    }
    function resetMultipleSelectionState() {
      Object.assign(multipleSelectionState, multipleSelectionInitialState);
    }
    function getRelatedLiFromEventObject(event) {
      return event.path.find(element => {
        var _element$matches;
        return null === (_element$matches = element.matches) || void 0 === _element$matches ? void 0 : _element$matches.call(element, "#stream > ol > li");
      });
    }
    function onClick(event) {
      const clickedLi = getRelatedLiFromEventObject(event);
      if (!event.shiftKey || !clickedLi) return;
      if (multipleSelectionState.isActive) stopMultipleSelection(); else startMultipleSelection(clickedLi);
      collapseSelection();
    }
    function onMouseEnter(event) {
      const relatedLi = getRelatedLiFromEventObject(event);
      if (event.shiftKey && multipleSelectionState.isActive && relatedLi) handleMultipleSelection(relatedLi);
    }
    function onKeyUp(event) {
      if ("Shift" === event.key && multipleSelectionState.isActive) cancelMultipleSelection();
    }
    function startMultipleSelection(startingLi) {
      resetMultipleSelectionState();
      Object.assign(multipleSelectionState, {
        isActive: true,
        startingLi,
        previousSelected: getSelectedStatuses()
      });
      elementCollection.get("stream").classList.add(CLASSNAME_MULTIPLE_SELECTION_ACTIVE);
      handleMultipleSelection(startingLi);
    }
    function handleMultipleSelection(currentLi) {
      const {startingLi, previousSelected} = multipleSelectionState;
      const allStatuses = elementCollection.get("statuses");
      const startingIndex = allStatuses.indexOf(startingLi);
      const currentIndex = allStatuses.indexOf(currentLi);
      const littleIndex = Math.min(startingIndex, currentIndex);
      const bigIndex = Math.max(startingIndex, currentIndex);
      allStatuses.forEach((li, index) => {
        const isInRange = littleIndex <= index && index <= bigIndex;
        const isPreviousSelected = previousSelected.includes(li);
        const checkbox = Object(select_dom["a"])("." + batch_remove_statuses_page_CLASSNAME_CHECKBOX, li);
        li.classList.toggle(CLASSNAME_MULTIPLE_SELECTION_IN_RANGE, isInRange);
        checkbox.checked = isInRange || isPreviousSelected;
      });
    }
    function stopMultipleSelection() {
      for (const li of elementCollection.get("statuses")) li.classList.remove(CLASSNAME_MULTIPLE_SELECTION_IN_RANGE);
      elementCollection.get("stream").classList.remove(CLASSNAME_MULTIPLE_SELECTION_ACTIVE);
      resetMultipleSelectionState();
    }
    function cancelMultipleSelection() {
      const {previousSelected} = multipleSelectionState;
      for (const li of elementCollection.get("statuses")) li.classList.remove(CLASSNAME_MULTIPLE_SELECTION_IN_RANGE);
      modifyCheckedStates(li => previousSelected.includes(li));
      elementCollection.get("stream").classList.remove(CLASSNAME_MULTIPLE_SELECTION_ACTIVE);
      resetMultipleSelectionState();
    }
    return {
      applyWhen: () => isLoggedInUserProfilePage(),
      waitReady: () => element_ready_default()("#footer"),
      onLoad() {
        createContainer();
        for (const li of elementCollection.get("statuses")) addCheckbox(li);
        Object(select_dom["a"])("#info").append(container);
      },
      onUnload() {
        container.remove();
        container = null;
        for (const checkbox of getAllCheckboxes()) checkbox.remove();
      }
    };
  };
  var requireFanfouLib = __webpack_require__(17);
  var disable_old_one_page = () => {
    let $textarea;
    return {
      async applyWhen() {
        const $ = await Object(requireFanfouLib["a"])("jQuery");
        const textarea = await element_ready_default()("#phupdate textarea");
        return textarea && ($textarea = $(textarea));
      },
      waitReady: () => Object(keepRetry["a"])({
        checker: () => {
          var _$textarea, _$textarea$autocomple;
          return false === (null === (_$textarea = $textarea) || void 0 === _$textarea ? void 0 : null === (_$textarea$autocomple = _$textarea.autocomplete) || void 0 === _$textarea$autocomple ? void 0 : _$textarea$autocomple.call(_$textarea, "option", "disabled"));
        },
        until: () => "complete" === document.readyState
      }),
      onLoad() {
        $textarea.autocomplete("disable");
      },
      onUnload() {
        $textarea.autocomplete("enable");
      }
    };
  };
  var dist_tribute = __webpack_require__(51);
  var tribute_default = __webpack_require__.n(dist_tribute);
  var compat_trigger_event = __webpack_require__(34);
  var compat_trigger_event_default = __webpack_require__.n(compat_trigger_event);
  var just_pick = __webpack_require__(18);
  var just_pick_default = __webpack_require__.n(just_pick);
  var parseQueryString = queryString => Object.fromEntries(new URLSearchParams(queryString).entries());
  var memoize = fn => {
    const cache = {};
    if (1 !== fn.length) throw new Error("fn 必须有且只有一个参数");
    const memoized = arg => {
      if (!cache.hasOwnProperty(arg)) cache[arg] = fn(arg);
      return cache[arg];
    };
    memoized.delete = arg => {
      delete cache[arg];
    };
    return memoized;
  };
  const helper = document.createElement("a");
  var parseUrl = memoize(url => {
    helper.href = url;
    return {
      ...just_pick_default()(helper, [ "protocol", "origin", "pathname" ]),
      domain: helper.hostname,
      query: parseQueryString(helper.search),
      hash: helper.hash.slice(1)
    };
  });
  var constants = __webpack_require__(3);
  var getExtensionOrigin = Object(index_esm["a"])(() => {
    let extensionId;
    extensionId = parseUrl(Object(select_dom["a"])(`.${constants["ASSET_CLASSNAME"]}[src]`).src).domain;
    return "chrome-extension://" + extensionId;
  });
  var replaceExtensionOrigin = code => {
    const extensionOrigin = getExtensionOrigin();
    const replacedCode = code.replace(constants["EXTENSION_ORIGIN_PLACEHOLDER_RE"], extensionOrigin);
    return replacedCode;
  };
  var unknown_user = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/unknown-user.jpg";
  const STORAGE_KEY = "friends-list";
  const STORAGE_AREA_NAME = "session";
  const EXPIRES = 3e5;
  var enable_new_one_page = context => {
    const {requireModules, elementCollection, registerDOMEventListener} = context;
    const {storage} = requireModules([ "storage" ]);
    const unknownUserAvatar = replaceExtensionOrigin(unknown_user);
    let tribute;
    elementCollection.add({
      textarea: "#phupdate textarea"
    });
    registerDOMEventListener("textarea", "tribute-replaced", onReplaced);
    function getStorageKeyForCurrentUser() {
      return STORAGE_KEY + "/" + getLoggedInUserId();
    }
    async function readFriendsListFromCache() {
      const {timestamp, friendsList} = await storage.read(getStorageKeyForCurrentUser(), STORAGE_AREA_NAME) || {};
      const now = Date.now();
      return timestamp && timestamp - now < EXPIRES ? friendsList : null;
    }
    async function writeFriendsListToCache(friendsList) {
      const timestamp = Date.now();
      await storage.write(getStorageKeyForCurrentUser(), {
        timestamp,
        friendsList
      }, STORAGE_AREA_NAME);
    }
    async function fetchFriendsList() {
      const response = await fetch("/home.ac_friends");
      const json = await response.json();
      await writeFriendsListToCache(json);
      return json;
    }
    function onReplaced() {
      const {textarea} = elementCollection.getAll();
      compat_trigger_event_default()(textarea, "change");
    }
    return {
      applyWhen: () => elementCollection.ready("textarea"),
      async onLoad() {
        tribute = new tribute_default.a({
          values: await readFriendsListFromCache() || await fetchFriendsList(),
          lookup: "label",
          fillAttr: "realname",
          menuItemTemplate(item) {
            const {photo_url} = item.original;
            const [nickname, userid] = item.string.split(" ");
            return `<img src="${photo_url}" />${nickname} <small>(${userid})</small>`;
          },
          noMatchTemplate: () => `<li class="no-match"><img src="${unknownUserAvatar}">没有匹配的用户</li>`,
          searchOpts: {
            pre: "<strong>",
            post: "</strong>"
          },
          menuItemLimit: 7
        });
        tribute.attach(elementCollection.get("textarea"));
      },
      onUnload() {
        tribute.detach(elementCollection.get("textarea"));
        tribute = null;
      }
    };
  };
  var parseHTML = __webpack_require__(29);
  var getCurrentPageOwnerUserId = Object(index_esm["a"])(async () => {
    const splitPathname = window.location.pathname.split("/");
    return await isUserProfilePage() ? splitPathname[1] : splitPathname[2];
  });
  var log = __webpack_require__(16);
  var check_friendship_page = context => {
    const {requireModules, elementCollection} = context;
    const {proxiedFetch} = requireModules([ "proxiedFetch" ]);
    const GENDER_PLACEHOLDER = "<GENDER_PLACEHOLDER>";
    const TEXT_INITIAL = `检查${GENDER_PLACEHOLDER}是否关注了你`;
    const TEXT_BUSY = "检查中……";
    const TEXT_IS_FOLLOWED = GENDER_PLACEHOLDER + "关注了你！";
    const TEXT_IS_NOT_FOLLOWED = GENDER_PLACEHOLDER + "没有关注你 :(";
    let checkButton;
    let hasChecked = false;
    elementCollection.add({
      panel: "#panel"
    });
    function initCheckButton() {
      let userviewLink = Object(select_dom["a"])("#userview_link");
      if (!userviewLink) {
        const h1 = Object(select_dom["a"])("h1", elementCollection.get("panel"));
        userviewLink = Object(dom_chef["h"])("p", {
          id: "userview_link"
        });
        h1.after(userviewLink);
      }
      checkButton = Object(dom_chef["h"])("a", {
        href: "javascript:void(0)",
        className: "label",
        onClick: checkFriendship
      });
      userviewLink.append(checkButton);
      setText(TEXT_INITIAL);
    }
    function removeCheckButton() {
      checkButton.remove();
      checkButton = null;
    }
    function getGender() {
      const re1 = /^性别：(男|女)$/;
      const element1 = select_dom["a"].all("#user_infos > ul > li:not(#bio)").find(element => re1.test(element.textContent));
      const matched1 = element1 && element1.textContent.match(re1);
      if (matched1) {
        const genderMap = {
          男: "他",
          女: "她"
        };
        return genderMap[matched1[1]];
      }
      const re2 = /^(他|她)关注的消息$/;
      const element2 = Object(select_dom["a"])("#userview_link .label");
      const matched2 = element2 && element2.textContent.match(re2);
      if (matched2) return matched2[1];
      return " TA ";
    }
    function setText(text) {
      checkButton.textContent = text.replace(GENDER_PLACEHOLDER, getGender()).trim();
    }
    async function fetchFollowersList(pageNumber) {
      const url = "https://m.fanfou.com/followers/p." + pageNumber;
      const {error: ajaxError, responseText: html} = await proxiedFetch.get({
        url
      });
      let followerIds, hasReachedEnd;
      if (ajaxError) {
        log["a"].error("加载关注者列表失败", ajaxError);
        followerIds = [];
        hasReachedEnd = true;
      } else {
        const document = Object(parseHTML["a"])(html);
        const items = select_dom["a"].all("ol > li > a > span.a", document);
        followerIds = items.map(item => item.textContent.replace(/^\(|\)$/g, ""));
        hasReachedEnd = !select_dom["a"].exists(`a[href="/followers/p.${pageNumber + 1}"]`, document);
      }
      return {
        followerIds,
        hasReachedEnd
      };
    }
    async function checkFriendship() {
      if (hasChecked) return;
      hasChecked = true;
      setText(TEXT_BUSY);
      const userId = await getCurrentPageOwnerUserId();
      let isFollowed = false;
      let pageNumber = 0;
      while (true) {
        const {followerIds, hasReachedEnd} = await fetchFollowersList(++pageNumber);
        if (!hasReachedEnd) isFollowed = followerIds.includes(userId);
        if (hasReachedEnd || isFollowed) break;
      }
      setText(isFollowed ? TEXT_IS_FOLLOWED : TEXT_IS_NOT_FOLLOWED);
    }
    return {
      applyWhen: () => Object(promiseEvery["a"])([ isUserProfilePage(), neg(isLoggedInUserProfilePage()) ]),
      waitReady: () => elementCollection.ready("panel"),
      onLoad() {
        initCheckButton();
      },
      onUnload() {
        removeCheckButton();
      }
    };
  };
  function SelectorSet() {
    if (!(this instanceof SelectorSet)) return new SelectorSet;
    this.size = 0;
    this.uid = 0;
    this.selectors = [];
    this.selectorObjects = {};
    this.indexes = Object.create(this.indexes);
    this.activeIndexes = [];
  }
  var docElem = window.document.documentElement;
  var matches = docElem.matches || docElem.webkitMatchesSelector || docElem.mozMatchesSelector || docElem.oMatchesSelector || docElem.msMatchesSelector;
  SelectorSet.prototype.matchesSelector = function(el, selector) {
    return matches.call(el, selector);
  };
  SelectorSet.prototype.querySelectorAll = function(selectors, context) {
    return context.querySelectorAll(selectors);
  };
  SelectorSet.prototype.indexes = [];
  var idRe = /^#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  SelectorSet.prototype.indexes.push({
    name: "ID",
    selector: function(sel) {
      var m;
      if (m = sel.match(idRe)) return m[0].slice(1);
    },
    element: function(el) {
      if (el.id) return [ el.id ];
    }
  });
  var classRe = /^\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  SelectorSet.prototype.indexes.push({
    name: "CLASS",
    selector: function(sel) {
      var m;
      if (m = sel.match(classRe)) return m[0].slice(1);
    },
    element: function(el) {
      var className = el.className;
      if (className) if ("string" === typeof className) return className.split(/\s/); else if ("object" === typeof className && "baseVal" in className) return className.baseVal.split(/\s/);
    }
  });
  var tagRe = /^((?:[\w\u00c0-\uFFFF\-]|\\.)+)/g;
  SelectorSet.prototype.indexes.push({
    name: "TAG",
    selector: function(sel) {
      var m;
      if (m = sel.match(tagRe)) return m[0].toUpperCase();
    },
    element: function(el) {
      return [ el.nodeName.toUpperCase() ];
    }
  });
  SelectorSet.prototype.indexes["default"] = {
    name: "UNIVERSAL",
    selector: function() {
      return true;
    },
    element: function() {
      return [ true ];
    }
  };
  var selector_set_next_Map;
  if ("function" === typeof window.Map) selector_set_next_Map = window.Map; else selector_set_next_Map = function() {
    function Map() {
      this.map = {};
    }
    Map.prototype.get = function(key) {
      return this.map[key + " "];
    };
    Map.prototype.set = function(key, value) {
      this.map[key + " "] = value;
    };
    return Map;
  }();
  var chunker = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g;
  function parseSelectorIndexes(allIndexes, selector) {
    allIndexes = allIndexes.slice(0).concat(allIndexes["default"]);
    var i, j, m, dup, key, index, allIndexesLen = allIndexes.length, rest = selector, indexes = [];
    do {
      chunker.exec("");
      if (m = chunker.exec(rest)) {
        rest = m[3];
        if (m[2] || !rest) for (i = 0; i < allIndexesLen; i++) {
          index = allIndexes[i];
          if (key = index.selector(m[1])) {
            j = indexes.length;
            dup = false;
            while (j--) if (indexes[j].index === index && indexes[j].key === key) {
              dup = true;
              break;
            }
            if (!dup) indexes.push({
              index,
              key
            });
            break;
          }
        }
      }
    } while (m);
    return indexes;
  }
  function findByPrototype(ary, proto) {
    var i, len, item;
    for (i = 0, len = ary.length; i < len; i++) {
      item = ary[i];
      if (proto.isPrototypeOf(item)) return item;
    }
  }
  SelectorSet.prototype.logDefaultIndexUsed = function() {};
  SelectorSet.prototype.add = function(selector, data) {
    var obj, i, indexProto, key, index, objs, selectorIndexes, selectorIndex, indexes = this.activeIndexes, selectors = this.selectors, selectorObjects = this.selectorObjects;
    if ("string" !== typeof selector) return;
    obj = {
      id: this.uid++,
      selector,
      data
    };
    selectorObjects[obj.id] = obj;
    selectorIndexes = parseSelectorIndexes(this.indexes, selector);
    for (i = 0; i < selectorIndexes.length; i++) {
      selectorIndex = selectorIndexes[i];
      key = selectorIndex.key;
      indexProto = selectorIndex.index;
      index = findByPrototype(indexes, indexProto);
      if (!index) {
        index = Object.create(indexProto);
        index.map = new selector_set_next_Map;
        indexes.push(index);
      }
      if (indexProto === this.indexes["default"]) this.logDefaultIndexUsed(obj);
      objs = index.map.get(key);
      if (!objs) {
        objs = [];
        index.map.set(key, objs);
      }
      objs.push(obj);
    }
    this.size++;
    selectors.push(selector);
  };
  SelectorSet.prototype.remove = function(selector, data) {
    if ("string" !== typeof selector) return;
    var selectorIndexes, selectorIndex, i, j, k, selIndex, objs, obj, indexes = this.activeIndexes, selectors = this.selectors = [], selectorObjects = this.selectorObjects, removedIds = {}, removeAll = 1 === arguments.length;
    selectorIndexes = parseSelectorIndexes(this.indexes, selector);
    for (i = 0; i < selectorIndexes.length; i++) {
      selectorIndex = selectorIndexes[i];
      j = indexes.length;
      while (j--) {
        selIndex = indexes[j];
        if (selectorIndex.index.isPrototypeOf(selIndex)) {
          objs = selIndex.map.get(selectorIndex.key);
          if (objs) {
            k = objs.length;
            while (k--) {
              obj = objs[k];
              if (obj.selector === selector && (removeAll || obj.data === data)) {
                objs.splice(k, 1);
                removedIds[obj.id] = true;
              }
            }
          }
          break;
        }
      }
    }
    for (i in removedIds) {
      delete selectorObjects[i];
      this.size--;
    }
    for (i in selectorObjects) selectors.push(selectorObjects[i].selector);
  };
  function sortById(a, b) {
    return a.id - b.id;
  }
  SelectorSet.prototype.queryAll = function(context) {
    if (!this.selectors.length) return [];
    var matches = {}, results = [];
    var els = this.querySelectorAll(this.selectors.join(", "), context);
    var i, j, len, len2, el, m, match, obj;
    for (i = 0, len = els.length; i < len; i++) {
      el = els[i];
      m = this.matches(el);
      for (j = 0, len2 = m.length; j < len2; j++) {
        obj = m[j];
        if (!matches[obj.id]) {
          match = {
            id: obj.id,
            selector: obj.selector,
            data: obj.data,
            elements: []
          };
          matches[obj.id] = match;
          results.push(match);
        } else match = matches[obj.id];
        match.elements.push(el);
      }
    }
    return results.sort(sortById);
  };
  SelectorSet.prototype.matches = function(el) {
    if (!el) return [];
    var i, j, k, len, len2, len3, index, keys, objs, obj, id;
    var indexes = this.activeIndexes, matchedIds = {}, matches = [];
    for (i = 0, len = indexes.length; i < len; i++) {
      index = indexes[i];
      keys = index.element(el);
      if (keys) for (j = 0, len2 = keys.length; j < len2; j++) if (objs = index.map.get(keys[j])) for (k = 0, 
      len3 = objs.length; k < len3; k++) {
        obj = objs[k];
        id = obj.id;
        if (!matchedIds[id] && this.matchesSelector(el, obj.selector)) {
          matchedIds[id] = true;
          matches.push(obj);
        }
      }
    }
    return matches.sort(sortById);
  };
  var bubbleEvents = {};
  var captureEvents = {};
  var propagationStopped = new WeakMap;
  var immediatePropagationStopped = new WeakMap;
  var currentTargets = new WeakMap;
  var currentTargetDesc = Object.getOwnPropertyDescriptor(Event.prototype, "currentTarget");
  function before(subject, verb, fn) {
    var source = subject[verb];
    subject[verb] = function() {
      fn.apply(subject, arguments);
      return source.apply(subject, arguments);
    };
    return subject;
  }
  function dist_matches(selectors, target, reverse) {
    var queue = [];
    var node = target;
    do {
      if (1 !== node.nodeType) break;
      var _matches = selectors.matches(node);
      if (_matches.length) {
        var matched = {
          node,
          observers: _matches
        };
        if (reverse) queue.unshift(matched); else queue.push(matched);
      }
    } while (node = node.parentElement);
    return queue;
  }
  function trackPropagation() {
    propagationStopped.set(this, true);
  }
  function trackImmediate() {
    propagationStopped.set(this, true);
    immediatePropagationStopped.set(this, true);
  }
  function getCurrentTarget() {
    return currentTargets.get(this) || null;
  }
  function defineCurrentTarget(event, getter) {
    if (!currentTargetDesc) return;
    Object.defineProperty(event, "currentTarget", {
      configurable: true,
      enumerable: true,
      get: getter || currentTargetDesc.get
    });
  }
  function canDispatch(event) {
    try {
      event.eventPhase;
      return true;
    } catch (_) {
      return false;
    }
  }
  function dispatch(event) {
    if (!canDispatch(event)) return;
    var events = 1 === event.eventPhase ? captureEvents : bubbleEvents;
    var selectors = events[event.type];
    if (!selectors) return;
    var queue = dist_matches(selectors, event.target, 1 === event.eventPhase);
    if (!queue.length) return;
    before(event, "stopPropagation", trackPropagation);
    before(event, "stopImmediatePropagation", trackImmediate);
    defineCurrentTarget(event, getCurrentTarget);
    for (var i = 0, len1 = queue.length; i < len1; i++) {
      if (propagationStopped.get(event)) break;
      var matched = queue[i];
      currentTargets.set(event, matched.node);
      for (var j = 0, len2 = matched.observers.length; j < len2; j++) {
        if (immediatePropagationStopped.get(event)) break;
        matched.observers[j].data.call(matched.node, event);
      }
    }
    currentTargets["delete"](event);
    defineCurrentTarget(event);
  }
  function on(name, selector, fn) {
    var options = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
    var capture = options.capture ? true : false;
    var events = capture ? captureEvents : bubbleEvents;
    var selectors = events[name];
    if (!selectors) {
      selectors = new SelectorSet;
      events[name] = selectors;
      document.addEventListener(name, dispatch, capture);
    }
    selectors.add(selector, fn);
  }
  function off(name, selector, fn) {
    var options = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
    var capture = options.capture ? true : false;
    var events = capture ? captureEvents : bubbleEvents;
    var selectors = events[name];
    if (!selectors) return;
    selectors.remove(selector, fn);
    if (selectors.size) return;
    delete events[name];
    document.removeEventListener(name, dispatch, capture);
  }
  const NEW_TIMESTAMP_STORAGE_KEY = "saved-searches/newTimestampUserMap";
  const NEW_TIMESTAMP_STORAGE_AREA_NAME = "local";
  const READ_TIMESTAMP_STORAGE_KEY = "saved-searches/readTimestampUserMap";
  const READ_TIMESTAMP_STORAGE_AREA_NAME = "sync";
  const SAVED_SEARCHES_READ = "SAVED_SEARCHES_READ";
  const SAVED_SEARCHES_WRITE = "SAVED_SEARCHES_WRITE";
  var bridge = __webpack_require__(9);
  const CLASSNAME_INDICATOR = "sf-new";
  const SELECTOR_KEYWORD_LINK = "#savedsearchs > ul > li > a";
  var sidebar_indicators_page = context => {
    const {elementCollection, registerBroadcastListener, unregisterBroadcastListener} = context;
    elementCollection.add({
      savedSearchs: "#savedsearchs"
    });
    async function checkUnread(keyword) {
      const userId = getLoggedInUserId();
      const hasUnread = await bridge["a"].postMessage({
        action: SAVED_SEARCHES_READ,
        payload: {
          userId,
          keyword
        }
      });
      return hasUnread;
    }
    async function markAsRead(keyword) {
      const userId = getLoggedInUserId();
      await bridge["a"].postMessage({
        action: SAVED_SEARCHES_WRITE,
        payload: {
          userId,
          keyword
        }
      });
    }
    function getItems() {
      const savedSearchs = elementCollection.get("savedSearchs");
      const elements = select_dom["a"].all(".label", savedSearchs);
      return elements.map(element => ({
        element,
        keyword: element.textContent.trim()
      }));
    }
    async function updateIndicators() {
      for (const {element, keyword} of getItems()) {
        const hasNew = await checkUnread(keyword);
        element.classList.toggle(CLASSNAME_INDICATOR, hasNew);
      }
    }
    function removeIndicators() {
      for (const {element} of getItems()) element.classList.remove(CLASSNAME_INDICATOR);
    }
    async function onClick(event) {
      const keywordLink = event.path.find(element => element.matches(SELECTOR_KEYWORD_LINK));
      const label = Object(select_dom["a"])(".label", keywordLink);
      const keyword = label.textContent.trim();
      label.classList.remove(CLASSNAME_INDICATOR);
      await markAsRead(keyword);
      await updateIndicators();
    }
    function isRelatedStorageChange({storageAreaName, key}) {
      if (storageAreaName === NEW_TIMESTAMP_STORAGE_AREA_NAME && key === NEW_TIMESTAMP_STORAGE_KEY) return true;
      if (storageAreaName === READ_TIMESTAMP_STORAGE_AREA_NAME && key === READ_TIMESTAMP_STORAGE_KEY) return true;
      return false;
    }
    function onBroadcast({action, payload}) {
      if (action === constants["STORAGE_CHANGED"] && isRelatedStorageChange(payload)) updateIndicators();
    }
    return {
      applyWhen: () => elementCollection.ready("savedSearchs"),
      onLoad() {
        updateIndicators();
        on("click", SELECTOR_KEYWORD_LINK, onClick, {
          capture: true
        });
        registerBroadcastListener(onBroadcast);
      },
      onUnload() {
        removeIndicators();
        off("click", SELECTOR_KEYWORD_LINK, onClick, {
          capture: true
        });
        unregisterBroadcastListener(onBroadcast);
      }
    };
  };
  const shortUrlServiceDomains = [ "fan.fo", "t.cn", "t.co", "fb.me", "goo.gl", "is.gd", "v.gd", "tinyurl.com", "tiny.cc", "bit.ly", "to.ly", "j.mp", "yep.it" ];
  function stripProtocol(url) {
    return url.replace(/^https?:\/\//, "");
  }
  function getDomain(url) {
    return stripProtocol(url).split("/")[0];
  }
  var isShortUrl = url => shortUrlServiceDomains.includes(getDomain(url));
  var compareDomains = (heystack, needle) => {
    heystack = heystack.split(".");
    needle = needle.split(".");
    if (needle.length > heystack.length) return false;
    while (needle.length) if (needle.pop() !== heystack.pop()) return false;
    return true;
  };
  var isExternalLink = link => !compareDomains(link.hostname, "fanfou.com");
  var isPlainLink = link => 1 === link.childNodes.length && "#text" === link.firstChild.nodeName;
  const createUrlUnshortener_STORAGE_AREA_NAME = "session";
  var createUrlUnshortener = ({storage, proxiedFetch}) => {
    async function unshortenUrl(shortUrl) {
      const cachedLongUrl = await readCache(shortUrl);
      if (cachedLongUrl) return cachedLongUrl;
      const {error, responseJSON} = await proxiedFetch.get({
        url: "https://setq.me/url_expand.json",
        query: {
          url_short: shortUrl
        },
        responseType: "json"
      });
      const {url_long: longUrl} = responseJSON || {};
      if (error || !longUrl) {
        memoized.delete(shortUrl);
        throw new Error(`展开短链接 ${shortUrl} 失败`);
      }
      await writeCache(shortUrl, longUrl);
      return longUrl;
    }
    function createStorageKey(shortUrl) {
      return "unshorten-url/" + shortUrl;
    }
    function readCache(shortUrl) {
      return storage.read(createStorageKey(shortUrl), createUrlUnshortener_STORAGE_AREA_NAME);
    }
    function writeCache(shortUrl, longUrl) {
      return storage.write(createStorageKey(shortUrl), longUrl, createUrlUnshortener_STORAGE_AREA_NAME);
    }
    const memoized = memoize(unshortenUrl);
    return memoized;
  };
  var urlTransformers = [ {
    isMatchingUrl: ({parsedUrl}) => "http:" === parsedUrl.protocol,
    transform: ({url}) => url.replace("http:", "https:")
  }, {
    isMatchingUrl: ({parsedUrl}) => "music.163.com" === parsedUrl.domain && "/" === parsedUrl.pathname && parsedUrl.hash.startsWith("/"),
    transform: ({parsedUrl}) => parsedUrl.origin + parsedUrl.hash
  } ];
  var node_modules_classnames = __webpack_require__(19);
  var classnames_default = __webpack_require__.n(node_modules_classnames);
  var prependElement = (parent, child) => parent.insertBefore(child, parent.firstChild);
  function isStatusHasPhoto(li) {
    return select_dom["a"].exists(":scope > .content > .photo.zoom", li);
  }
  function addPhotoToStatus(li, {isGIF = false, thumbnailUrl, originalUrl}) {
    var _window$YAHOO, _window$YAHOO$util, _window$YAHOO$util$Ev;
    if (isStatusHasPhoto(li)) return;
    const content = Object(select_dom["a"])(":scope > .content", li);
    const link = Object(dom_chef["h"])("a", {
      href: originalUrl,
      className: classnames_default()("photo", "zoom", {
        gif: isGIF
      })
    }, Object(dom_chef["h"])("img", {
      src: thumbnailUrl
    }), Object(dom_chef["h"])("span", null));
    prependElement(content, link);
    if (null !== (_window$YAHOO = window.YAHOO) && void 0 !== _window$YAHOO && null !== (_window$YAHOO$util = _window$YAHOO.util) && void 0 !== _window$YAHOO$util && null !== (_window$YAHOO$util$Ev = _window$YAHOO$util.Event) && void 0 !== _window$YAHOO$util$Ev && _window$YAHOO$util$Ev.DOMReady) window.FF.app.Zoom.init(li);
  }
  function convertToHttps(url) {
    return url.replace(/^http:\/\//, "https://");
  }
  var urlHandlers = [ {
    id: "weibo-image",
    isMatchingUrl: ({parsedUrl}) => compareDomains(parsedUrl.domain, "sinaimg.cn") && parsedUrl.pathname.endsWith(".jpg"),
    extractData({url, parsedUrl}) {
      const size = parsedUrl.pathname.split("/")[1];
      return {
        thumbnailUrl: convertToHttps(url).replace(size, "thumb300"),
        originalUrl: convertToHttps(url).replace(size, "large")
      };
    },
    applyData: addPhotoToStatus
  }, {
    id: "image",
    isMatchingUrl: ({parsedUrl}) => parsedUrl.pathname.endsWith(".jpg") || parsedUrl.pathname.endsWith(".jpeg") || parsedUrl.pathname.endsWith(".png") || parsedUrl.pathname.endsWith(".gif") || parsedUrl.pathname.endsWith(".webm") || parsedUrl.pathname.endsWith(".bmp"),
    extractData({url, parsedUrl}) {
      return {
        isGIF: parsedUrl.pathname.endsWith(".gif"),
        thumbnailUrl: url,
        originalUrl: url
      };
    },
    applyData: addPhotoToStatus
  } ];
  var isStatusElement = element => "li" === element.tagName.toLowerCase() && select_dom["a"].exists(":scope > .content", element) && select_dom["a"].exists(":scope > .stamp", element) && select_dom["a"].exists(":scope > .op", element);
  const URL_LENGTH_LIMIT = 30;
  const URL_ELLIPSIS = "...";
  var truncateUrl = url => {
    const originalLength = url.length;
    if (originalLength > URL_LENGTH_LIMIT) url = url.slice(0, URL_LENGTH_LIMIT - URL_ELLIPSIS.length) + URL_ELLIPSIS;
    return url;
  };
  const ATTRIBUTE_MARKER = "sf-status-enriched";
  var enrich_statuses_page = context => {
    const {requireModules} = context;
    const {storage, timelineElementObserver, proxiedFetch} = requireModules([ "storage", "timelineElementObserver", "proxiedFetch" ]);
    const unshortenUrl = createUrlUnshortener({
      storage,
      proxiedFetch
    });
    function isStatusProcessed(li) {
      return li.hasAttribute(ATTRIBUTE_MARKER);
    }
    function markStatusAsProcessed(li) {
      return li.setAttribute(ATTRIBUTE_MARKER, "");
    }
    function removeMarkers() {
      for (const li of select_dom["a"].all(`[${ATTRIBUTE_MARKER}]`)) li.removeAttribute(ATTRIBUTE_MARKER);
    }
    function getLinksInStatuses(li) {
      return select_dom["a"].all(".content a", li).filter(link => isExternalLink(link) && isPlainLink(link));
    }
    async function processShortUrl(link, url) {
      if (!isShortUrl(url)) return url;
      const longUrl = await unshortenUrl(url);
      const truncatedUrl = truncateUrl(longUrl);
      link.href = longUrl;
      link.textContent = truncatedUrl;
      link.title = longUrl;
      return longUrl;
    }
    function findUrlMatched(list, args) {
      return list.find(({isMatchingUrl}) => isMatchingUrl(args));
    }
    const transformUrl = memoize(url => {
      let parsedUrl, transformer;
      do {
        parsedUrl = parseUrl(url);
        transformer = findUrlMatched(urlTransformers, {
          url,
          parsedUrl
        });
        url = transformer ? transformer.transform({
          url,
          parsedUrl
        }) : url;
      } while (transformer);
      return url;
    });
    const extractData = async url => {
      const parsedUrl = parseUrl(url);
      const urlHandler = findUrlMatched(urlHandlers, {
        url,
        parsedUrl
      });
      return {
        urlHandlerId: urlHandler ? urlHandler.id : null,
        data: urlHandler ? await urlHandler.extractData({
          url,
          parsedUrl
        }) : null
      };
    };
    function applyData(li, urlHandlerId, data) {
      const urlHandler = urlHandlers.find(({id}) => id === urlHandlerId);
      urlHandler.applyData(li, data);
    }
    async function processLink(li, link) {
      let url = link.href;
      url = await processShortUrl(link, url);
      url = transformUrl(url);
      const {urlHandlerId, data} = await extractData(url);
      if (urlHandlerId) applyData(li, urlHandlerId, data);
    }
    function processStatus(li) {
      markStatusAsProcessed(li);
      for (const link of getLinksInStatuses(li)) processLink(li, link);
    }
    function mutationObserverCallback(mutationRecords) {
      for (const {addedNodes} of mutationRecords) for (const addedNode of addedNodes) if (isStatusElement(addedNode) && !isStatusProcessed(addedNode)) processStatus(addedNode);
    }
    return {
      applyWhen: () => isTimelinePage(),
      onLoad() {
        timelineElementObserver.addCallback(mutationObserverCallback);
      },
      onUnload() {
        timelineElementObserver.removeCallback(mutationObserverCallback);
        removeMarkers();
      }
    };
  };
  var compat_module = __webpack_require__(4);
  function _extends() {
    return _extends = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _extends.apply(null, arguments);
  }
  function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
  }
  function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
      var e, n, i, u, a = [], f = !0, o = !1;
      try {
        if (i = (t = t.call(r)).next, 0 === l) {
          if (Object(t) !== t) return;
          f = !1;
        } else for (;!(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0) ;
      } catch (r) {
        o = !0, n = r;
      } finally {
        try {
          if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
        } finally {
          if (o) throw n;
        }
      }
      return a;
    }
  }
  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
  }
  function typeof_typeof(o) {
    "@babel/helpers - typeof";
    return typeof_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
      return typeof o;
    } : function(o) {
      return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, typeof_typeof(o);
  }
  function toPrimitive(t, r) {
    if ("object" != typeof_typeof(t) || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof_typeof(i)) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function toPropertyKey(t) {
    var i = toPrimitive(t, "string");
    return "symbol" == typeof_typeof(i) ? i : i + "";
  }
  function _defineProperty(e, r, t) {
    return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _objectSpread(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? Object(arguments[r]) : {}, o = Object.keys(t);
      "function" == typeof Object.getOwnPropertySymbols && o.push.apply(o, Object.getOwnPropertySymbols(t).filter((function(e) {
        return Object.getOwnPropertyDescriptor(t, e).enumerable;
      }))), o.forEach((function(r) {
        _defineProperty(e, r, t[r]);
      }));
    }
    return e;
  }
  function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
      Object.defineProperty(e, toPropertyKey(o.key), o);
    }
  }
  function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
      writable: !1
    }), e;
  }
  function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  function _possibleConstructorReturn(t, e) {
    if (e && ("object" == typeof_typeof(e) || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return _assertThisInitialized(t);
  }
  function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t) {
      return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
  }
  function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
      return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
  }
  function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, {
      constructor: {
        value: t,
        writable: !0,
        configurable: !0
      }
    }), Object.defineProperty(t, "prototype", {
      writable: !1
    }), e && _setPrototypeOf(t, e);
  }
  var prop_types = __webpack_require__(2);
  var prop_types_default = __webpack_require__.n(prop_types);
  var browser = __webpack_require__(31);
  var browser_default = __webpack_require__.n(browser);
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  var react_sortable_hoc_esm_Manager = function() {
    function Manager() {
      _classCallCheck(this, Manager);
      _defineProperty(this, "refs", {});
    }
    _createClass(Manager, [ {
      key: "add",
      value: function(collection, ref) {
        if (!this.refs[collection]) this.refs[collection] = [];
        this.refs[collection].push(ref);
      }
    }, {
      key: "remove",
      value: function(collection, ref) {
        var index = this.getIndex(collection, ref);
        if (-1 !== index) this.refs[collection].splice(index, 1);
      }
    }, {
      key: "isActive",
      value: function() {
        return this.active;
      }
    }, {
      key: "getActive",
      value: function() {
        var _this = this;
        return this.refs[this.active.collection].find((function(_ref) {
          var node = _ref.node;
          return node.sortableInfo.index == _this.active.index;
        }));
      }
    }, {
      key: "getIndex",
      value: function(collection, ref) {
        return this.refs[collection].indexOf(ref);
      }
    }, {
      key: "getOrderedRefs",
      value: function() {
        var collection = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.active.collection;
        return this.refs[collection].sort(sortByIndex);
      }
    } ]);
    return Manager;
  }();
  function sortByIndex(_ref2, _ref3) {
    var index1 = _ref2.node.sortableInfo.index;
    var index2 = _ref3.node.sortableInfo.index;
    return index1 - index2;
  }
  function omit(obj, keysToOmit) {
    return Object.keys(obj).reduce((function(acc, key) {
      if (-1 === keysToOmit.indexOf(key)) acc[key] = obj[key];
      return acc;
    }), {});
  }
  var react_sortable_hoc_esm_events = {
    end: [ "touchend", "touchcancel", "mouseup" ],
    move: [ "touchmove", "mousemove" ],
    start: [ "touchstart", "mousedown" ]
  };
  var vendorPrefix = function() {
    if ("undefined" === typeof window || "undefined" === typeof document) return "";
    var styles = window.getComputedStyle(document.documentElement, "") || [ "-moz-hidden-iframe" ];
    var pre = (Array.prototype.slice.call(styles).join("").match(/-(moz|webkit|ms)-/) || "" === styles.OLink && [ "", "o" ])[1];
    switch (pre) {
     case "ms":
      return "ms";

     default:
      return pre && pre.length ? pre[0].toUpperCase() + pre.substr(1) : "";
    }
  }();
  function setInlineStyles(node, styles) {
    Object.keys(styles).forEach((function(key) {
      node.style[key] = styles[key];
    }));
  }
  function setTranslate3d(node, translate) {
    node.style["".concat(vendorPrefix, "Transform")] = null == translate ? "" : "translate3d(".concat(translate.x, "px,").concat(translate.y, "px,0)");
  }
  function setTransitionDuration(node, duration) {
    node.style["".concat(vendorPrefix, "TransitionDuration")] = null == duration ? "" : "".concat(duration, "ms");
  }
  function closest(el, fn) {
    while (el) {
      if (fn(el)) return el;
      el = el.parentNode;
    }
    return null;
  }
  function limit(min, max, value) {
    return Math.max(min, Math.min(value, max));
  }
  function getPixelValue(stringValue) {
    if ("px" === stringValue.substr(-2)) return parseFloat(stringValue);
    return 0;
  }
  function getElementMargin(element) {
    var style = window.getComputedStyle(element);
    return {
      bottom: getPixelValue(style.marginBottom),
      left: getPixelValue(style.marginLeft),
      right: getPixelValue(style.marginRight),
      top: getPixelValue(style.marginTop)
    };
  }
  function provideDisplayName(prefix, Component$$1) {
    var componentName = Component$$1.displayName || Component$$1.name;
    return componentName ? "".concat(prefix, "(").concat(componentName, ")") : prefix;
  }
  function getScrollAdjustedBoundingClientRect(node, scrollDelta) {
    var boundingClientRect = node.getBoundingClientRect();
    return {
      top: boundingClientRect.top + scrollDelta.top,
      left: boundingClientRect.left + scrollDelta.left
    };
  }
  function getPosition(event) {
    if (event.touches && event.touches.length) return {
      x: event.touches[0].pageX,
      y: event.touches[0].pageY
    }; else if (event.changedTouches && event.changedTouches.length) return {
      x: event.changedTouches[0].pageX,
      y: event.changedTouches[0].pageY
    }; else return {
      x: event.pageX,
      y: event.pageY
    };
  }
  function isTouchEvent(event) {
    return event.touches && event.touches.length || event.changedTouches && event.changedTouches.length;
  }
  function getEdgeOffset(node, parent) {
    var offset = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
      left: 0,
      top: 0
    };
    if (!node) return;
    var nodeOffset = {
      left: offset.left + node.offsetLeft,
      top: offset.top + node.offsetTop
    };
    if (node.parentNode === parent) return nodeOffset;
    return getEdgeOffset(node.parentNode, parent, nodeOffset);
  }
  function getTargetIndex(newIndex, prevIndex, oldIndex) {
    if (newIndex < oldIndex && newIndex > prevIndex) return newIndex - 1; else if (newIndex > oldIndex && newIndex < prevIndex) return newIndex + 1; else return newIndex;
  }
  function getLockPixelOffset(_ref) {
    var lockOffset = _ref.lockOffset, width = _ref.width, height = _ref.height;
    var offsetX = lockOffset;
    var offsetY = lockOffset;
    var unit = "px";
    if ("string" === typeof lockOffset) {
      var match = /^[+-]?\d*(?:\.\d*)?(px|%)$/.exec(lockOffset);
      browser_default()(null !== match, 'lockOffset value should be a number or a string of a number followed by "px" or "%". Given %s', lockOffset);
      offsetX = parseFloat(lockOffset);
      offsetY = parseFloat(lockOffset);
      unit = match[1];
    }
    browser_default()(isFinite(offsetX) && isFinite(offsetY), "lockOffset value should be a finite. Given %s", lockOffset);
    if ("%" === unit) {
      offsetX = offsetX * width / 100;
      offsetY = offsetY * height / 100;
    }
    return {
      x: offsetX,
      y: offsetY
    };
  }
  function getLockPixelOffsets(_ref2) {
    var height = _ref2.height, width = _ref2.width, lockOffset = _ref2.lockOffset;
    var offsets = Array.isArray(lockOffset) ? lockOffset : [ lockOffset, lockOffset ];
    browser_default()(2 === offsets.length, "lockOffset prop of SortableContainer should be a single value or an array of exactly two values. Given %s", lockOffset);
    var _offsets = _slicedToArray(offsets, 2), minLockOffset = _offsets[0], maxLockOffset = _offsets[1];
    return [ getLockPixelOffset({
      height,
      lockOffset: minLockOffset,
      width
    }), getLockPixelOffset({
      height,
      lockOffset: maxLockOffset,
      width
    }) ];
  }
  function isScrollable(el) {
    var computedStyle = window.getComputedStyle(el);
    var overflowRegex = /(auto|scroll)/;
    var properties = [ "overflow", "overflowX", "overflowY" ];
    return properties.find((function(property) {
      return overflowRegex.test(computedStyle[property]);
    }));
  }
  function getScrollingParent(el) {
    if (!(el instanceof HTMLElement)) return null; else if (isScrollable(el)) return el; else return getScrollingParent(el.parentNode);
  }
  function getContainerGridGap(element) {
    var style = window.getComputedStyle(element);
    if ("grid" === style.display) return {
      x: getPixelValue(style.gridColumnGap),
      y: getPixelValue(style.gridRowGap)
    };
    return {
      x: 0,
      y: 0
    };
  }
  var KEYCODE = {
    TAB: 9,
    ESC: 27,
    SPACE: 32,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40
  };
  var NodeType = {
    Anchor: "A",
    Button: "BUTTON",
    Canvas: "CANVAS",
    Input: "INPUT",
    Option: "OPTION",
    Textarea: "TEXTAREA",
    Select: "SELECT"
  };
  function cloneNode(node) {
    var selector = "input, textarea, select, canvas, [contenteditable]";
    var fields = node.querySelectorAll(selector);
    var clonedNode = node.cloneNode(true);
    var clonedFields = _toConsumableArray(clonedNode.querySelectorAll(selector));
    clonedFields.forEach((function(field, i) {
      if ("file" !== field.type) field.value = fields[i].value;
      if ("radio" === field.type && field.name) field.name = "__sortableClone__".concat(field.name);
      if (field.tagName === NodeType.Canvas && fields[i].width > 0 && fields[i].height > 0) {
        var destCtx = field.getContext("2d");
        destCtx.drawImage(fields[i], 0, 0);
      }
    }));
    return clonedNode;
  }
  function sortableHandle(WrappedComponent) {
    var _class, _temp;
    var config = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
      withRef: false
    };
    return _temp = _class = function(_React$Component) {
      _inherits(WithSortableHandle, _React$Component);
      function WithSortableHandle() {
        _classCallCheck(this, WithSortableHandle);
        return _possibleConstructorReturn(this, _getPrototypeOf(WithSortableHandle).apply(this, arguments));
      }
      _createClass(WithSortableHandle, [ {
        key: "componentDidMount",
        value: function() {
          var node = Object(compat_module["findDOMNode"])(this);
          node.sortableHandle = true;
        }
      }, {
        key: "getWrappedInstance",
        value: function() {
          browser_default()(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableHandle() call");
          return this.refs.wrappedInstance;
        }
      }, {
        key: "render",
        value: function() {
          var ref = config.withRef ? "wrappedInstance" : null;
          return Object(compat_module["createElement"])(WrappedComponent, _extends({
            ref
          }, this.props));
        }
      } ]);
      return WithSortableHandle;
    }(compat_module["Component"]), _defineProperty(_class, "displayName", provideDisplayName("sortableHandle", WrappedComponent)), 
    _temp;
  }
  function isSortableHandle(node) {
    return null != node.sortableHandle;
  }
  var react_sortable_hoc_esm_AutoScroller = function() {
    function AutoScroller(container, onScrollCallback) {
      _classCallCheck(this, AutoScroller);
      this.container = container;
      this.onScrollCallback = onScrollCallback;
    }
    _createClass(AutoScroller, [ {
      key: "clear",
      value: function() {
        if (null == this.interval) return;
        clearInterval(this.interval);
        this.interval = null;
      }
    }, {
      key: "update",
      value: function(_ref) {
        var _this = this;
        var translate = _ref.translate, minTranslate = _ref.minTranslate, maxTranslate = _ref.maxTranslate, width = _ref.width, height = _ref.height;
        var direction = {
          x: 0,
          y: 0
        };
        var speed = {
          x: 1,
          y: 1
        };
        var acceleration = {
          x: 10,
          y: 10
        };
        var _this$container = this.container, scrollTop = _this$container.scrollTop, scrollLeft = _this$container.scrollLeft, scrollHeight = _this$container.scrollHeight, scrollWidth = _this$container.scrollWidth, clientHeight = _this$container.clientHeight, clientWidth = _this$container.clientWidth;
        var isTop = 0 === scrollTop;
        var isBottom = scrollHeight - scrollTop - clientHeight === 0;
        var isLeft = 0 === scrollLeft;
        var isRight = scrollWidth - scrollLeft - clientWidth === 0;
        if (translate.y >= maxTranslate.y - height / 2 && !isBottom) {
          direction.y = 1;
          speed.y = acceleration.y * Math.abs((maxTranslate.y - height / 2 - translate.y) / height);
        } else if (translate.x >= maxTranslate.x - width / 2 && !isRight) {
          direction.x = 1;
          speed.x = acceleration.x * Math.abs((maxTranslate.x - width / 2 - translate.x) / width);
        } else if (translate.y <= minTranslate.y + height / 2 && !isTop) {
          direction.y = -1;
          speed.y = acceleration.y * Math.abs((translate.y - height / 2 - minTranslate.y) / height);
        } else if (translate.x <= minTranslate.x + width / 2 && !isLeft) {
          direction.x = -1;
          speed.x = acceleration.x * Math.abs((translate.x - width / 2 - minTranslate.x) / width);
        }
        if (this.interval) {
          this.clear();
          this.isAutoScrolling = false;
        }
        if (0 !== direction.x || 0 !== direction.y) this.interval = setInterval((function() {
          _this.isAutoScrolling = true;
          var offset = {
            left: speed.x * direction.x,
            top: speed.y * direction.y
          };
          _this.container.scrollTop += offset.top;
          _this.container.scrollLeft += offset.left;
          _this.onScrollCallback(offset);
        }), 5);
      }
    } ]);
    return AutoScroller;
  }();
  function defaultGetHelperDimensions(_ref) {
    var node = _ref.node;
    return {
      height: node.offsetHeight,
      width: node.offsetWidth
    };
  }
  function defaultShouldCancelStart(event) {
    var interactiveElements = [ NodeType.Input, NodeType.Textarea, NodeType.Select, NodeType.Option, NodeType.Button ];
    if (-1 !== interactiveElements.indexOf(event.target.tagName)) return true;
    if (closest(event.target, (function(el) {
      return "true" === el.contentEditable;
    }))) return true;
    return false;
  }
  var propTypes = {
    axis: prop_types_default.a.oneOf([ "x", "y", "xy" ]),
    contentWindow: prop_types_default.a.any,
    disableAutoscroll: prop_types_default.a.bool,
    distance: prop_types_default.a.number,
    getContainer: prop_types_default.a.func,
    getHelperDimensions: prop_types_default.a.func,
    helperClass: prop_types_default.a.string,
    helperContainer: prop_types_default.a.oneOfType([ prop_types_default.a.func, "undefined" === typeof HTMLElement ? prop_types_default.a.any : prop_types_default.a.instanceOf(HTMLElement) ]),
    hideSortableGhost: prop_types_default.a.bool,
    keyboardSortingTransitionDuration: prop_types_default.a.number,
    lockAxis: prop_types_default.a.string,
    lockOffset: prop_types_default.a.oneOfType([ prop_types_default.a.number, prop_types_default.a.string, prop_types_default.a.arrayOf(prop_types_default.a.oneOfType([ prop_types_default.a.number, prop_types_default.a.string ])) ]),
    lockToContainerEdges: prop_types_default.a.bool,
    onSortEnd: prop_types_default.a.func,
    onSortMove: prop_types_default.a.func,
    onSortOver: prop_types_default.a.func,
    onSortStart: prop_types_default.a.func,
    pressDelay: prop_types_default.a.number,
    pressThreshold: prop_types_default.a.number,
    keyCodes: prop_types_default.a.shape({
      lift: prop_types_default.a.arrayOf(prop_types_default.a.number),
      drop: prop_types_default.a.arrayOf(prop_types_default.a.number),
      cancel: prop_types_default.a.arrayOf(prop_types_default.a.number),
      up: prop_types_default.a.arrayOf(prop_types_default.a.number),
      down: prop_types_default.a.arrayOf(prop_types_default.a.number)
    }),
    shouldCancelStart: prop_types_default.a.func,
    transitionDuration: prop_types_default.a.number,
    updateBeforeSortStart: prop_types_default.a.func,
    useDragHandle: prop_types_default.a.bool,
    useWindowAsScrollContainer: prop_types_default.a.bool
  };
  var defaultKeyCodes = {
    lift: [ KEYCODE.SPACE ],
    drop: [ KEYCODE.SPACE ],
    cancel: [ KEYCODE.ESC ],
    up: [ KEYCODE.UP, KEYCODE.LEFT ],
    down: [ KEYCODE.DOWN, KEYCODE.RIGHT ]
  };
  var defaultProps = {
    axis: "y",
    disableAutoscroll: false,
    distance: 0,
    getHelperDimensions: defaultGetHelperDimensions,
    hideSortableGhost: true,
    lockOffset: "50%",
    lockToContainerEdges: false,
    pressDelay: 0,
    pressThreshold: 5,
    keyCodes: defaultKeyCodes,
    shouldCancelStart: defaultShouldCancelStart,
    transitionDuration: 300,
    useWindowAsScrollContainer: false
  };
  var omittedProps = Object.keys(propTypes);
  function validateProps(props) {
    browser_default()(!(props.distance && props.pressDelay), "Attempted to set both `pressDelay` and `distance` on SortableContainer, you may only use one or the other, not both at the same time.");
  }
  function _finallyRethrows(body, finalizer) {
    try {
      var result = body();
    } catch (e) {
      return finalizer(true, e);
    }
    if (result && result.then) return result.then(finalizer.bind(null, false), finalizer.bind(null, true));
    return finalizer(false, value);
  }
  function sortableContainer(WrappedComponent) {
    var _class, _temp;
    var config = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
      withRef: false
    };
    return _temp = _class = function(_React$Component) {
      _inherits(WithSortableContainer, _React$Component);
      function WithSortableContainer(props) {
        var _this;
        _classCallCheck(this, WithSortableContainer);
        _this = _possibleConstructorReturn(this, _getPrototypeOf(WithSortableContainer).call(this, props));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "state", {});
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleStart", (function(event) {
          var _this$props = _this.props, distance = _this$props.distance, shouldCancelStart = _this$props.shouldCancelStart;
          if (2 === event.button || shouldCancelStart(event)) return;
          _this.touched = true;
          _this.position = getPosition(event);
          var node = closest(event.target, (function(el) {
            return null != el.sortableInfo;
          }));
          if (node && node.sortableInfo && _this.nodeIsChild(node) && !_this.state.sorting) {
            var useDragHandle = _this.props.useDragHandle;
            var _node$sortableInfo = node.sortableInfo, index = _node$sortableInfo.index, collection = _node$sortableInfo.collection, disabled = _node$sortableInfo.disabled;
            if (disabled) return;
            if (useDragHandle && !closest(event.target, isSortableHandle)) return;
            _this.manager.active = {
              collection,
              index
            };
            if (!isTouchEvent(event) && event.target.tagName === NodeType.Anchor) event.preventDefault();
            if (!distance) if (0 === _this.props.pressDelay) _this.handlePress(event); else _this.pressTimer = setTimeout((function() {
              return _this.handlePress(event);
            }), _this.props.pressDelay);
          }
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "nodeIsChild", (function(node) {
          return node.sortableInfo.manager === _this.manager;
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleMove", (function(event) {
          var _this$props2 = _this.props, distance = _this$props2.distance, pressThreshold = _this$props2.pressThreshold;
          if (!_this.state.sorting && _this.touched && !_this._awaitingUpdateBeforeSortStart) {
            var position = getPosition(event);
            var delta = {
              x: _this.position.x - position.x,
              y: _this.position.y - position.y
            };
            var combinedDelta = Math.abs(delta.x) + Math.abs(delta.y);
            _this.delta = delta;
            if (!distance && (!pressThreshold || combinedDelta >= pressThreshold)) {
              clearTimeout(_this.cancelTimer);
              _this.cancelTimer = setTimeout(_this.cancel, 0);
            } else if (distance && combinedDelta >= distance && _this.manager.isActive()) _this.handlePress(event);
          }
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleEnd", (function() {
          _this.touched = false;
          _this.cancel();
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "cancel", (function() {
          var distance = _this.props.distance;
          var sorting = _this.state.sorting;
          if (!sorting) {
            if (!distance) clearTimeout(_this.pressTimer);
            _this.manager.active = null;
          }
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handlePress", (function(event) {
          try {
            var active = _this.manager.getActive();
            var _temp6 = function() {
              if (active) {
                var _temp7 = function() {
                  var index = _node.sortableInfo.index;
                  var margin = getElementMargin(_node);
                  var gridGap = getContainerGridGap(_this.container);
                  var containerBoundingRect = _this.scrollContainer.getBoundingClientRect();
                  var dimensions = _getHelperDimensions({
                    index,
                    node: _node,
                    collection: _collection
                  });
                  _this.node = _node;
                  _this.margin = margin;
                  _this.gridGap = gridGap;
                  _this.width = dimensions.width;
                  _this.height = dimensions.height;
                  _this.marginOffset = {
                    x: _this.margin.left + _this.margin.right + _this.gridGap.x,
                    y: Math.max(_this.margin.top, _this.margin.bottom, _this.gridGap.y)
                  };
                  _this.boundingClientRect = _node.getBoundingClientRect();
                  _this.containerBoundingRect = containerBoundingRect;
                  _this.index = index;
                  _this.newIndex = index;
                  _this.axis = {
                    x: _axis.indexOf("x") >= 0,
                    y: _axis.indexOf("y") >= 0
                  };
                  _this.offsetEdge = getEdgeOffset(_node, _this.container);
                  if (_isKeySorting) _this.initialOffset = getPosition(_objectSpread({}, event, {
                    pageX: _this.boundingClientRect.left,
                    pageY: _this.boundingClientRect.top
                  })); else _this.initialOffset = getPosition(event);
                  _this.initialScroll = {
                    left: _this.scrollContainer.scrollLeft,
                    top: _this.scrollContainer.scrollTop
                  };
                  _this.initialWindowScroll = {
                    left: window.pageXOffset,
                    top: window.pageYOffset
                  };
                  _this.helper = _this.helperContainer.appendChild(cloneNode(_node));
                  setInlineStyles(_this.helper, {
                    boxSizing: "border-box",
                    height: "".concat(_this.height, "px"),
                    left: "".concat(_this.boundingClientRect.left - margin.left, "px"),
                    pointerEvents: "none",
                    position: "fixed",
                    top: "".concat(_this.boundingClientRect.top - margin.top, "px"),
                    width: "".concat(_this.width, "px")
                  });
                  if (_isKeySorting) _this.helper.focus();
                  if (_hideSortableGhost) {
                    _this.sortableGhost = _node;
                    setInlineStyles(_node, {
                      opacity: 0,
                      visibility: "hidden"
                    });
                  }
                  _this.minTranslate = {};
                  _this.maxTranslate = {};
                  if (_isKeySorting) {
                    var _ref = _useWindowAsScrollContainer ? {
                      top: 0,
                      left: 0,
                      width: _this.contentWindow.innerWidth,
                      height: _this.contentWindow.innerHeight
                    } : _this.containerBoundingRect, containerTop = _ref.top, containerLeft = _ref.left, containerWidth = _ref.width, containerHeight = _ref.height;
                    var containerBottom = containerTop + containerHeight;
                    var containerRight = containerLeft + containerWidth;
                    if (_this.axis.x) {
                      _this.minTranslate.x = containerLeft - _this.boundingClientRect.left;
                      _this.maxTranslate.x = containerRight - (_this.boundingClientRect.left + _this.width);
                    }
                    if (_this.axis.y) {
                      _this.minTranslate.y = containerTop - _this.boundingClientRect.top;
                      _this.maxTranslate.y = containerBottom - (_this.boundingClientRect.top + _this.height);
                    }
                  } else {
                    if (_this.axis.x) {
                      _this.minTranslate.x = (_useWindowAsScrollContainer ? 0 : containerBoundingRect.left) - _this.boundingClientRect.left - _this.width / 2;
                      _this.maxTranslate.x = (_useWindowAsScrollContainer ? _this.contentWindow.innerWidth : containerBoundingRect.left + containerBoundingRect.width) - _this.boundingClientRect.left - _this.width / 2;
                    }
                    if (_this.axis.y) {
                      _this.minTranslate.y = (_useWindowAsScrollContainer ? 0 : containerBoundingRect.top) - _this.boundingClientRect.top - _this.height / 2;
                      _this.maxTranslate.y = (_useWindowAsScrollContainer ? _this.contentWindow.innerHeight : containerBoundingRect.top + containerBoundingRect.height) - _this.boundingClientRect.top - _this.height / 2;
                    }
                  }
                  if (_helperClass) _helperClass.split(" ").forEach((function(className) {
                    return _this.helper.classList.add(className);
                  }));
                  _this.listenerNode = event.touches ? _node : _this.contentWindow;
                  if (_isKeySorting) {
                    _this.listenerNode.addEventListener("wheel", _this.handleKeyEnd, true);
                    _this.listenerNode.addEventListener("mousedown", _this.handleKeyEnd, true);
                    _this.listenerNode.addEventListener("keydown", _this.handleKeyDown);
                  } else {
                    react_sortable_hoc_esm_events.move.forEach((function(eventName) {
                      return _this.listenerNode.addEventListener(eventName, _this.handleSortMove, false);
                    }));
                    react_sortable_hoc_esm_events.end.forEach((function(eventName) {
                      return _this.listenerNode.addEventListener(eventName, _this.handleSortEnd, false);
                    }));
                  }
                  _this.setState({
                    sorting: true,
                    sortingIndex: index
                  });
                  if (_onSortStart) _onSortStart({
                    node: _node,
                    index,
                    collection: _collection,
                    isKeySorting: _isKeySorting,
                    nodes: _this.manager.getOrderedRefs(),
                    helper: _this.helper
                  }, event);
                  if (_isKeySorting) _this.keyMove(0);
                };
                var _this$props3 = _this.props, _axis = _this$props3.axis, _getHelperDimensions = _this$props3.getHelperDimensions, _helperClass = _this$props3.helperClass, _hideSortableGhost = _this$props3.hideSortableGhost, updateBeforeSortStart = _this$props3.updateBeforeSortStart, _onSortStart = _this$props3.onSortStart, _useWindowAsScrollContainer = _this$props3.useWindowAsScrollContainer;
                var _node = active.node, _collection = active.collection;
                var _isKeySorting = _this.manager.isKeySorting;
                var _temp8 = function() {
                  if ("function" === typeof updateBeforeSortStart) {
                    _this._awaitingUpdateBeforeSortStart = true;
                    var _temp9 = _finallyRethrows((function() {
                      var index = _node.sortableInfo.index;
                      return Promise.resolve(updateBeforeSortStart({
                        collection: _collection,
                        index,
                        node: _node,
                        isKeySorting: _isKeySorting
                      }, event)).then((function() {}));
                    }), (function(_wasThrown, _result) {
                      _this._awaitingUpdateBeforeSortStart = false;
                      if (_wasThrown) throw _result;
                      return _result;
                    }));
                    if (_temp9 && _temp9.then) return _temp9.then((function() {}));
                  }
                }();
                return _temp8 && _temp8.then ? _temp8.then(_temp7) : _temp7(_temp8);
              }
            }();
            return Promise.resolve(_temp6 && _temp6.then ? _temp6.then((function() {})) : void 0);
          } catch (e) {
            return Promise.reject(e);
          }
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSortMove", (function(event) {
          var onSortMove = _this.props.onSortMove;
          if ("function" === typeof event.preventDefault) event.preventDefault();
          _this.updateHelperPosition(event);
          _this.animateNodes();
          _this.autoscroll();
          if (onSortMove) onSortMove(event);
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleSortEnd", (function(event) {
          var _this$props4 = _this.props, hideSortableGhost = _this$props4.hideSortableGhost, onSortEnd = _this$props4.onSortEnd;
          var _this$manager = _this.manager, collection = _this$manager.active.collection, isKeySorting = _this$manager.isKeySorting;
          var nodes = _this.manager.getOrderedRefs();
          if (_this.listenerNode) if (isKeySorting) {
            _this.listenerNode.removeEventListener("wheel", _this.handleKeyEnd, true);
            _this.listenerNode.removeEventListener("mousedown", _this.handleKeyEnd, true);
            _this.listenerNode.removeEventListener("keydown", _this.handleKeyDown);
          } else {
            react_sortable_hoc_esm_events.move.forEach((function(eventName) {
              return _this.listenerNode.removeEventListener(eventName, _this.handleSortMove);
            }));
            react_sortable_hoc_esm_events.end.forEach((function(eventName) {
              return _this.listenerNode.removeEventListener(eventName, _this.handleSortEnd);
            }));
          }
          _this.helper.parentNode.removeChild(_this.helper);
          if (hideSortableGhost && _this.sortableGhost) setInlineStyles(_this.sortableGhost, {
            opacity: "",
            visibility: ""
          });
          for (var i = 0, len = nodes.length; i < len; i++) {
            var _node2 = nodes[i];
            var el = _node2.node;
            _node2.edgeOffset = null;
            _node2.boundingClientRect = null;
            setTranslate3d(el, null);
            setTransitionDuration(el, null);
            _node2.translate = null;
          }
          _this.autoScroller.clear();
          _this.manager.active = null;
          _this.manager.isKeySorting = false;
          _this.setState({
            sorting: false,
            sortingIndex: null
          });
          if ("function" === typeof onSortEnd) onSortEnd({
            collection,
            newIndex: _this.newIndex,
            oldIndex: _this.index,
            isKeySorting,
            nodes
          }, event);
          _this.touched = false;
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "autoscroll", (function() {
          var disableAutoscroll = _this.props.disableAutoscroll;
          var isKeySorting = _this.manager.isKeySorting;
          if (disableAutoscroll) {
            _this.autoScroller.clear();
            return;
          }
          if (isKeySorting) {
            var translate = _objectSpread({}, _this.translate);
            var scrollX = 0;
            var scrollY = 0;
            if (_this.axis.x) {
              translate.x = Math.min(_this.maxTranslate.x, Math.max(_this.minTranslate.x, _this.translate.x));
              scrollX = _this.translate.x - translate.x;
            }
            if (_this.axis.y) {
              translate.y = Math.min(_this.maxTranslate.y, Math.max(_this.minTranslate.y, _this.translate.y));
              scrollY = _this.translate.y - translate.y;
            }
            _this.translate = translate;
            setTranslate3d(_this.helper, _this.translate);
            _this.scrollContainer.scrollLeft += scrollX;
            _this.scrollContainer.scrollTop += scrollY;
            return;
          }
          _this.autoScroller.update({
            height: _this.height,
            maxTranslate: _this.maxTranslate,
            minTranslate: _this.minTranslate,
            translate: _this.translate,
            width: _this.width
          });
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "onAutoScroll", (function(offset) {
          _this.translate.x += offset.left;
          _this.translate.y += offset.top;
          _this.animateNodes();
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleKeyDown", (function(event) {
          var keyCode = event.keyCode;
          var _this$props5 = _this.props, shouldCancelStart = _this$props5.shouldCancelStart, _this$props5$keyCodes = _this$props5.keyCodes, customKeyCodes = void 0 === _this$props5$keyCodes ? {} : _this$props5$keyCodes;
          var keyCodes = _objectSpread({}, defaultKeyCodes, customKeyCodes);
          if (_this.manager.active && !_this.manager.isKeySorting || !_this.manager.active && (!keyCodes.lift.includes(keyCode) || shouldCancelStart(event) || !_this.isValidSortingTarget(event))) return;
          event.stopPropagation();
          event.preventDefault();
          if (keyCodes.lift.includes(keyCode) && !_this.manager.active) _this.keyLift(event); else if (keyCodes.drop.includes(keyCode) && _this.manager.active) _this.keyDrop(event); else if (keyCodes.cancel.includes(keyCode)) {
            _this.newIndex = _this.manager.active.index;
            _this.keyDrop(event);
          } else if (keyCodes.up.includes(keyCode)) _this.keyMove(-1); else if (keyCodes.down.includes(keyCode)) _this.keyMove(1);
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyLift", (function(event) {
          var target = event.target;
          var node = closest(target, (function(el) {
            return null != el.sortableInfo;
          }));
          var _node$sortableInfo2 = node.sortableInfo, index = _node$sortableInfo2.index, collection = _node$sortableInfo2.collection;
          _this.initialFocusedNode = target;
          _this.manager.isKeySorting = true;
          _this.manager.active = {
            index,
            collection
          };
          _this.handlePress(event);
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyMove", (function(shift) {
          var nodes = _this.manager.getOrderedRefs();
          var lastIndex = nodes[nodes.length - 1].node.sortableInfo.index;
          var newIndex = _this.newIndex + shift;
          var prevIndex = _this.newIndex;
          if (newIndex < 0 || newIndex > lastIndex) return;
          _this.prevIndex = prevIndex;
          _this.newIndex = newIndex;
          var targetIndex = getTargetIndex(_this.newIndex, _this.prevIndex, _this.index);
          var target = nodes.find((function(_ref2) {
            var node = _ref2.node;
            return node.sortableInfo.index === targetIndex;
          }));
          var targetNode = target.node;
          var scrollDelta = _this.containerScrollDelta;
          var targetBoundingClientRect = target.boundingClientRect || getScrollAdjustedBoundingClientRect(targetNode, scrollDelta);
          var targetTranslate = target.translate || {
            x: 0,
            y: 0
          };
          var targetPosition = {
            top: targetBoundingClientRect.top + targetTranslate.y - scrollDelta.top,
            left: targetBoundingClientRect.left + targetTranslate.x - scrollDelta.left
          };
          var shouldAdjustForSize = prevIndex < newIndex;
          var sizeAdjustment = {
            x: shouldAdjustForSize && _this.axis.x ? targetNode.offsetWidth - _this.width : 0,
            y: shouldAdjustForSize && _this.axis.y ? targetNode.offsetHeight - _this.height : 0
          };
          _this.handleSortMove({
            pageX: targetPosition.left + sizeAdjustment.x,
            pageY: targetPosition.top + sizeAdjustment.y,
            ignoreTransition: 0 === shift
          });
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "keyDrop", (function(event) {
          _this.handleSortEnd(event);
          if (_this.initialFocusedNode) _this.initialFocusedNode.focus();
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "handleKeyEnd", (function(event) {
          if (_this.manager.active) _this.keyDrop(event);
        }));
        _defineProperty(_assertThisInitialized(_assertThisInitialized(_this)), "isValidSortingTarget", (function(event) {
          var useDragHandle = _this.props.useDragHandle;
          var target = event.target;
          var node = closest(target, (function(el) {
            return null != el.sortableInfo;
          }));
          return node && node.sortableInfo && !node.sortableInfo.disabled && (useDragHandle ? isSortableHandle(target) : target.sortableInfo);
        }));
        validateProps(props);
        _this.manager = new react_sortable_hoc_esm_Manager;
        _this.events = {
          end: _this.handleEnd,
          move: _this.handleMove,
          start: _this.handleStart
        };
        return _this;
      }
      _createClass(WithSortableContainer, [ {
        key: "getChildContext",
        value: function() {
          return {
            manager: this.manager
          };
        }
      }, {
        key: "componentDidMount",
        value: function() {
          var _this2 = this;
          var useWindowAsScrollContainer = this.props.useWindowAsScrollContainer;
          var container = this.getContainer();
          Promise.resolve(container).then((function(containerNode) {
            _this2.container = containerNode;
            _this2.document = _this2.container.ownerDocument || document;
            var contentWindow = _this2.props.contentWindow || _this2.document.defaultView || window;
            _this2.contentWindow = "function" === typeof contentWindow ? contentWindow() : contentWindow;
            _this2.scrollContainer = useWindowAsScrollContainer ? _this2.document.scrollingElement || _this2.document.documentElement : getScrollingParent(_this2.container) || _this2.container;
            _this2.autoScroller = new react_sortable_hoc_esm_AutoScroller(_this2.scrollContainer, _this2.onAutoScroll);
            Object.keys(_this2.events).forEach((function(key) {
              return react_sortable_hoc_esm_events[key].forEach((function(eventName) {
                return _this2.container.addEventListener(eventName, _this2.events[key], false);
              }));
            }));
            _this2.container.addEventListener("keydown", _this2.handleKeyDown);
          }));
        }
      }, {
        key: "componentWillUnmount",
        value: function() {
          var _this3 = this;
          if (this.helper && this.helper.parentNode) this.helper.parentNode.removeChild(this.helper);
          if (!this.container) return;
          Object.keys(this.events).forEach((function(key) {
            return react_sortable_hoc_esm_events[key].forEach((function(eventName) {
              return _this3.container.removeEventListener(eventName, _this3.events[key]);
            }));
          }));
          this.container.removeEventListener("keydown", this.handleKeyDown);
        }
      }, {
        key: "updateHelperPosition",
        value: function(event) {
          var _this$props6 = this.props, lockAxis = _this$props6.lockAxis, lockOffset = _this$props6.lockOffset, lockToContainerEdges = _this$props6.lockToContainerEdges, transitionDuration = _this$props6.transitionDuration, _this$props6$keyboard = _this$props6.keyboardSortingTransitionDuration, keyboardSortingTransitionDuration = void 0 === _this$props6$keyboard ? transitionDuration : _this$props6$keyboard;
          var isKeySorting = this.manager.isKeySorting;
          var ignoreTransition = event.ignoreTransition;
          var offset = getPosition(event);
          var translate = {
            x: offset.x - this.initialOffset.x,
            y: offset.y - this.initialOffset.y
          };
          translate.y -= window.pageYOffset - this.initialWindowScroll.top;
          translate.x -= window.pageXOffset - this.initialWindowScroll.left;
          this.translate = translate;
          if (lockToContainerEdges) {
            var _getLockPixelOffsets = getLockPixelOffsets({
              height: this.height,
              lockOffset,
              width: this.width
            }), _getLockPixelOffsets2 = _slicedToArray(_getLockPixelOffsets, 2), minLockOffset = _getLockPixelOffsets2[0], maxLockOffset = _getLockPixelOffsets2[1];
            var minOffset = {
              x: this.width / 2 - minLockOffset.x,
              y: this.height / 2 - minLockOffset.y
            };
            var maxOffset = {
              x: this.width / 2 - maxLockOffset.x,
              y: this.height / 2 - maxLockOffset.y
            };
            translate.x = limit(this.minTranslate.x + minOffset.x, this.maxTranslate.x - maxOffset.x, translate.x);
            translate.y = limit(this.minTranslate.y + minOffset.y, this.maxTranslate.y - maxOffset.y, translate.y);
          }
          if ("x" === lockAxis) translate.y = 0; else if ("y" === lockAxis) translate.x = 0;
          if (isKeySorting && keyboardSortingTransitionDuration && !ignoreTransition) setTransitionDuration(this.helper, keyboardSortingTransitionDuration);
          setTranslate3d(this.helper, translate);
        }
      }, {
        key: "animateNodes",
        value: function() {
          var _this$props7 = this.props, transitionDuration = _this$props7.transitionDuration, hideSortableGhost = _this$props7.hideSortableGhost, onSortOver = _this$props7.onSortOver;
          var containerScrollDelta = this.containerScrollDelta, windowScrollDelta = this.windowScrollDelta;
          var nodes = this.manager.getOrderedRefs();
          var sortingOffset = {
            left: this.offsetEdge.left + this.translate.x + containerScrollDelta.left,
            top: this.offsetEdge.top + this.translate.y + containerScrollDelta.top
          };
          var isKeySorting = this.manager.isKeySorting;
          var prevIndex = this.newIndex;
          this.newIndex = null;
          for (var i = 0, len = nodes.length; i < len; i++) {
            var _node3 = nodes[i].node;
            var index = _node3.sortableInfo.index;
            var width = _node3.offsetWidth;
            var height = _node3.offsetHeight;
            var offset = {
              height: this.height > height ? height / 2 : this.height / 2,
              width: this.width > width ? width / 2 : this.width / 2
            };
            var mustShiftBackward = isKeySorting && index > this.index && index <= prevIndex;
            var mustShiftForward = isKeySorting && index < this.index && index >= prevIndex;
            var translate = {
              x: 0,
              y: 0
            };
            var edgeOffset = nodes[i].edgeOffset;
            if (!edgeOffset) {
              edgeOffset = getEdgeOffset(_node3, this.container);
              nodes[i].edgeOffset = edgeOffset;
              if (isKeySorting) nodes[i].boundingClientRect = getScrollAdjustedBoundingClientRect(_node3, containerScrollDelta);
            }
            var nextNode = i < nodes.length - 1 && nodes[i + 1];
            var prevNode = i > 0 && nodes[i - 1];
            if (nextNode && !nextNode.edgeOffset) {
              nextNode.edgeOffset = getEdgeOffset(nextNode.node, this.container);
              if (isKeySorting) nextNode.boundingClientRect = getScrollAdjustedBoundingClientRect(nextNode.node, containerScrollDelta);
            }
            if (index === this.index) {
              if (hideSortableGhost) {
                this.sortableGhost = _node3;
                setInlineStyles(_node3, {
                  opacity: 0,
                  visibility: "hidden"
                });
              }
              continue;
            }
            if (transitionDuration) setTransitionDuration(_node3, transitionDuration);
            if (this.axis.x) {
              if (this.axis.y) {
                if (mustShiftForward || index < this.index && (sortingOffset.left + windowScrollDelta.left - offset.width <= edgeOffset.left && sortingOffset.top + windowScrollDelta.top <= edgeOffset.top + offset.height || sortingOffset.top + windowScrollDelta.top + offset.height <= edgeOffset.top)) {
                  translate.x = this.width + this.marginOffset.x;
                  if (edgeOffset.left + translate.x > this.containerBoundingRect.width - offset.width) if (nextNode) {
                    translate.x = nextNode.edgeOffset.left - edgeOffset.left;
                    translate.y = nextNode.edgeOffset.top - edgeOffset.top;
                  }
                  if (null === this.newIndex) this.newIndex = index;
                } else if (mustShiftBackward || index > this.index && (sortingOffset.left + windowScrollDelta.left + offset.width >= edgeOffset.left && sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top || sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top + height)) {
                  translate.x = -(this.width + this.marginOffset.x);
                  if (edgeOffset.left + translate.x < this.containerBoundingRect.left + offset.width) if (prevNode) {
                    translate.x = prevNode.edgeOffset.left - edgeOffset.left;
                    translate.y = prevNode.edgeOffset.top - edgeOffset.top;
                  }
                  this.newIndex = index;
                }
              } else if (mustShiftBackward || index > this.index && sortingOffset.left + windowScrollDelta.left + offset.width >= edgeOffset.left) {
                translate.x = -(this.width + this.marginOffset.x);
                this.newIndex = index;
              } else if (mustShiftForward || index < this.index && sortingOffset.left + windowScrollDelta.left <= edgeOffset.left + offset.width) {
                translate.x = this.width + this.marginOffset.x;
                if (null == this.newIndex) this.newIndex = index;
              }
            } else if (this.axis.y) if (mustShiftBackward || index > this.index && sortingOffset.top + windowScrollDelta.top + offset.height >= edgeOffset.top) {
              translate.y = -(this.height + this.marginOffset.y);
              this.newIndex = index;
            } else if (mustShiftForward || index < this.index && sortingOffset.top + windowScrollDelta.top <= edgeOffset.top + offset.height) {
              translate.y = this.height + this.marginOffset.y;
              if (null == this.newIndex) this.newIndex = index;
            }
            setTranslate3d(_node3, translate);
            nodes[i].translate = translate;
          }
          if (null == this.newIndex) this.newIndex = this.index;
          if (isKeySorting) this.newIndex = prevIndex;
          var oldIndex = isKeySorting ? this.prevIndex : prevIndex;
          if (onSortOver && this.newIndex !== oldIndex) onSortOver({
            collection: this.manager.active.collection,
            index: this.index,
            newIndex: this.newIndex,
            oldIndex,
            isKeySorting,
            nodes,
            helper: this.helper
          });
        }
      }, {
        key: "getWrappedInstance",
        value: function() {
          browser_default()(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableContainer() call");
          return this.refs.wrappedInstance;
        }
      }, {
        key: "getContainer",
        value: function() {
          var getContainer = this.props.getContainer;
          if ("function" !== typeof getContainer) return Object(compat_module["findDOMNode"])(this);
          return getContainer(config.withRef ? this.getWrappedInstance() : void 0);
        }
      }, {
        key: "render",
        value: function() {
          var ref = config.withRef ? "wrappedInstance" : null;
          return Object(compat_module["createElement"])(WrappedComponent, _extends({
            ref
          }, omit(this.props, omittedProps)));
        }
      }, {
        key: "helperContainer",
        get: function() {
          var helperContainer = this.props.helperContainer;
          if ("function" === typeof helperContainer) return helperContainer();
          return this.props.helperContainer || this.document.body;
        }
      }, {
        key: "containerScrollDelta",
        get: function() {
          var useWindowAsScrollContainer = this.props.useWindowAsScrollContainer;
          if (useWindowAsScrollContainer) return {
            left: 0,
            top: 0
          };
          return {
            left: this.scrollContainer.scrollLeft - this.initialScroll.left,
            top: this.scrollContainer.scrollTop - this.initialScroll.top
          };
        }
      }, {
        key: "windowScrollDelta",
        get: function() {
          return {
            left: this.contentWindow.pageXOffset - this.initialWindowScroll.left,
            top: this.contentWindow.pageYOffset - this.initialWindowScroll.top
          };
        }
      } ]);
      return WithSortableContainer;
    }(compat_module["Component"]), _defineProperty(_class, "displayName", provideDisplayName("sortableList", WrappedComponent)), 
    _defineProperty(_class, "defaultProps", defaultProps), _defineProperty(_class, "propTypes", propTypes), 
    _defineProperty(_class, "childContextTypes", {
      manager: prop_types_default.a.object.isRequired
    }), _temp;
  }
  var propTypes$1 = {
    index: prop_types_default.a.number.isRequired,
    collection: prop_types_default.a.oneOfType([ prop_types_default.a.number, prop_types_default.a.string ]),
    disabled: prop_types_default.a.bool
  };
  var omittedProps$1 = Object.keys(propTypes$1);
  function sortableElement(WrappedComponent) {
    var _class, _temp;
    var config = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
      withRef: false
    };
    return _temp = _class = function(_React$Component) {
      _inherits(WithSortableElement, _React$Component);
      function WithSortableElement() {
        _classCallCheck(this, WithSortableElement);
        return _possibleConstructorReturn(this, _getPrototypeOf(WithSortableElement).apply(this, arguments));
      }
      _createClass(WithSortableElement, [ {
        key: "componentDidMount",
        value: function() {
          this.register();
        }
      }, {
        key: "componentDidUpdate",
        value: function(prevProps) {
          if (this.node) {
            if (prevProps.index !== this.props.index) this.node.sortableInfo.index = this.props.index;
            if (prevProps.disabled !== this.props.disabled) this.node.sortableInfo.disabled = this.props.disabled;
          }
          if (prevProps.collection !== this.props.collection) {
            this.unregister(prevProps.collection);
            this.register();
          }
        }
      }, {
        key: "componentWillUnmount",
        value: function() {
          this.unregister();
        }
      }, {
        key: "register",
        value: function() {
          var _this$props = this.props, collection = _this$props.collection, disabled = _this$props.disabled, index = _this$props.index;
          var node = Object(compat_module["findDOMNode"])(this);
          node.sortableInfo = {
            collection,
            disabled,
            index,
            manager: this.context.manager
          };
          this.node = node;
          this.ref = {
            node
          };
          this.context.manager.add(collection, this.ref);
        }
      }, {
        key: "unregister",
        value: function() {
          var collection = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.props.collection;
          this.context.manager.remove(collection, this.ref);
        }
      }, {
        key: "getWrappedInstance",
        value: function() {
          browser_default()(config.withRef, "To access the wrapped instance, you need to pass in {withRef: true} as the second argument of the SortableElement() call");
          return this.refs.wrappedInstance;
        }
      }, {
        key: "render",
        value: function() {
          var ref = config.withRef ? "wrappedInstance" : null;
          return Object(compat_module["createElement"])(WrappedComponent, _extends({
            ref
          }, omit(this.props, omittedProps$1)));
        }
      } ]);
      return WithSortableElement;
    }(compat_module["Component"]), _defineProperty(_class, "displayName", provideDisplayName("sortableElement", WrappedComponent)), 
    _defineProperty(_class, "contextTypes", {
      manager: prop_types_default.a.object.isRequired
    }), _defineProperty(_class, "propTypes", propTypes$1), _defineProperty(_class, "defaultProps", {
      collection: 0
    }), _temp;
  }
  var p_sleep = __webpack_require__(24);
  var p_sleep_default = __webpack_require__.n(p_sleep);
  var array_move = __webpack_require__(52);
  var array_move_default = __webpack_require__.n(array_move);
  const STORAGE_KEY_FRIENDS_DATA = "favorite-fanfouers/friendsData";
  const STORAGE_AREA_NAME_FRIENDS_DATA = "sync";
  const createDefaultData = () => [ {
    userId: "fanfou",
    nickname: "饭否",
    avatarUrl: "//s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/37/9g.jpg?1181650871"
  } ];
  const createFriendsListReader = storage => async () => await storage.read(STORAGE_KEY_FRIENDS_DATA, STORAGE_AREA_NAME_FRIENDS_DATA) || createDefaultData();
  const createFriendsListWriter = storage => async data => {
    await storage.write(STORAGE_KEY_FRIENDS_DATA, data, STORAGE_AREA_NAME_FRIENDS_DATA);
  };
  const createStorageChangeHandler = callback => message => {
    if (message.action === constants["STORAGE_CHANGED"]) callback(message.payload);
  };
  var react_tooltip_lite_dist = __webpack_require__(53);
  var dist_default = __webpack_require__.n(react_tooltip_lite_dist);
  function Tooltip_extends() {
    return Tooltip_extends = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, Tooltip_extends.apply(null, arguments);
  }
  function patch() {
    const positionModule = __webpack_require__(46);
    const originalPositionFn = positionModule.default;
    positionModule.default = (...args) => {
      const result = originalPositionFn(...args);
      if ("undefined" === typeof result.tip.transform) result.tip.transform = null;
      return result;
    };
  }
  patch();
  const Tooltip_defaultProps = {
    arrowSize: 5,
    padding: "8px",
    distance: 10
  };
  function TooltipWithDefaultProps(props) {
    return Object(compat_module["createElement"])(dist_default.a, Tooltip_extends({}, Tooltip_defaultProps, props));
  }
  var fade = __webpack_require__(32);
  var preact_module = __webpack_require__(1);
  var preactRender = (vNode, callback) => {
    let container = document.createElement("div");
    Object(preact_module["j"])(vNode, container);
    if (callback) callback(container.firstChild);
    return function() {
      Object(compat_module["unmountComponentAtNode"])(container);
      container = null;
    };
  };
  var safelyInvokeFn = __webpack_require__(20);
  function readJSONFromLocalStorage(key) {
    let value = null;
    Object(safelyInvokeFn["a"])(() => {
      value = JSON.parse(localStorage.getItem(key));
    });
    return value;
  }
  var arrayRemove = __webpack_require__(13);
  const USER_GUIDE = [ "1. 在用户个人页面通过点击名字右方的星形图标添加饭友到列表", "2. 拖拽头像重新排序", "3. 按住 Shift 键点击头像删除", "4. 右击「有爱饭友」清空列表" ].join("\n");
  const CONFIRMING_MESSAGE = "确定要清空有爱饭友列表吗？请注意这个操作无法撤回。";
  const CLASSNAME_ITEM = "sf-favorite-fanfouer-item";
  const CLASSNAME_SORTABLE_HELPER = "sf-favorite-fanfouer-sortable-helper";
  const STORAGE_KEY_COLLAPSED_STATE = "favorite-fanfouers/isCollapsed";
  const STORAGE_AREA_NAME_COLLAPSED_STATE = "local";
  var home_page = context => {
    const {requireModules, registerBroadcastListener, unregisterBroadcastListener, elementCollection} = context;
    const {storage, proxiedCreateTab} = requireModules([ "storage", "proxiedCreateTab" ]);
    let unmount;
    const readFriendsList = createFriendsListReader(storage);
    const writeFriendsList = createFriendsListWriter(storage);
    elementCollection.add({
      friends: "#friends"
    });
    function readCollapsedState() {
      return storage.read(STORAGE_KEY_COLLAPSED_STATE, STORAGE_AREA_NAME_COLLAPSED_STATE);
    }
    async function writeCollapsedState(newValue) {
      await storage.write(STORAGE_KEY_COLLAPSED_STATE, newValue, STORAGE_AREA_NAME_COLLAPSED_STATE);
    }
    function getProfilePageUrl(userId) {
      return `${window.location.protocol}//fanfou.com/${userId}`;
    }
    const SortableList = sortableContainer(({items, instance}) => Object(compat_module["createElement"])("ul", {
      ref: instance.setListRef,
      className: "alist"
    }, items.map((item, index) => Object(compat_module["createElement"])(SortableItem, {
      key: "item-" + item.userId,
      index,
      item,
      instance
    }))));
    const SortableItem = sortableElement(({item, instance}) => Object(compat_module["createElement"])("li", {
      key: item.userId,
      className: CLASSNAME_ITEM
    }, Object(compat_module["createElement"])("a", {
      href: getProfilePageUrl(item.userId),
      title: item.nickname
    }, Object(compat_module["createElement"])(DragHandle, null), Object(compat_module["createElement"])("img", {
      src: item.avatarUrl,
      alt: `@${item.nickname} 的头像`,
      onClick: event => instance.onClickAvatar(event, item)
    }), Object(compat_module["createElement"])("span", null, item.nickname))));
    const DragHandle = sortableHandle(() => Object(compat_module["createElement"])("div", {
      className: "sf-drag-handle"
    }));
    class FavoriteFanfouers extends compat_module["Component"] {
      constructor(...args) {
        super(...args);
        this.setFriendsList = newValue => {
          this.setState({
            friendsData: newValue
          }, () => {
            writeFriendsList(newValue);
          });
        };
        this.onStorageChange = createStorageChangeHandler(() => {
          this.loadData();
        });
        this.onClickTitle = event => {
          event.stopImmediatePropagation();
          const newState = !this.state.isCollapsed;
          this.setState({
            isCollapsed: newState
          });
          writeCollapsedState(newState);
        };
        this.onRightClickTitle = async event => {
          event.preventDefault();
          if (!window.confirm(CONFIRMING_MESSAGE)) return;
          window.jQuery(this.list).slideUp();
          await p_sleep_default()(500);
          this.setFriendsList([]);
        };
        this.setListRef = element => {
          this.list = element;
        };
        this.getSortableHelperContainer = () => this.list;
        this.onSortEnd = ({oldIndex, newIndex}) => {
          const newValue = array_move_default()(this.state.friendsData, oldIndex, newIndex);
          this.setFriendsList(newValue);
        };
        this.onClickAvatar = async (event, item) => {
          if (!event.shiftKey) return;
          event.preventDefault();
          const li = event.path.find(element => element.matches("." + CLASSNAME_ITEM));
          const friendsData = [ ...this.state.friendsData ];
          await Object(fade["b"])(li, 400);
          Object(arrayRemove["a"])(friendsData, item);
          this.setFriendsList(friendsData);
        };
        this.openAll = async () => {
          for (const friendData of this.state.friendsData) {
            proxiedCreateTab.create({
              url: getProfilePageUrl(friendData.userId),
              openInBackgroundTab: true
            });
            await p_sleep_default()(1e3);
          }
        };
        this.state = {
          isReady: false,
          isCollapsed: false,
          friendsData: []
        };
        this.loadData();
      }
      async loadData() {
        this.setState({
          isReady: true,
          isCollapsed: await readCollapsedState(),
          friendsData: await readFriendsList()
        });
      }
      render() {
        const classNames = classnames_default()({
          colltab: true,
          "sf-is-ready": this.state.isReady
        });
        return Object(compat_module["createElement"])("div", {
          id: "sf-favorite-fanfouers-list",
          className: classNames
        }, this.renderToggle(), this.renderTitle(), this.renderFriendsList(), this.renderOpenAll(), this.renderEmpty());
      }
      renderToggle() {
        return Object(compat_module["createElement"])("b", {
          className: classnames_default()({
            collapse: this.state.isCollapsed
          })
        });
      }
      renderTitle() {
        return Object(compat_module["createElement"])("h2", {
          onClick: this.onClickTitle,
          onContextMenu: this.onRightClickTitle
        }, "有爱饭友");
      }
      renderFriendsList() {
        if (this.state.isCollapsed || !this.state.friendsData.length) return null;
        const sortableListProps = {
          instance: this,
          items: this.state.friendsData,
          axis: "xy",
          helperContainer: this.getSortableHelperContainer,
          helperClass: CLASSNAME_SORTABLE_HELPER,
          lockToContainerEdges: true,
          useDragHandle: true,
          transitionDuration: 200,
          onSortEnd: this.onSortEnd
        };
        return Object(compat_module["createElement"])(SortableList, sortableListProps);
      }
      renderOpenAll() {
        if (this.state.isCollapsed || !this.state.friendsData.length) return null;
        return Object(compat_module["createElement"])("div", null, Object(compat_module["createElement"])("a", {
          onClick: this.openAll
        }, "» 打开所有"), this.renderTip());
      }
      renderEmpty() {
        if (this.state.isCollapsed || this.state.friendsData.length) return null;
        return Object(compat_module["createElement"])("div", null, "还没有饭友被添加到列表。", this.renderTip());
      }
      renderTip() {
        const tooltipProps = {
          className: "sf-tip",
          tipContentClassName: "sf-favorite-fanfouers-tooltip",
          content: USER_GUIDE,
          direction: "down-end"
        };
        return Object(compat_module["createElement"])(TooltipWithDefaultProps, tooltipProps, "?");
      }
      componentDidMount() {
        registerBroadcastListener(this.onStorageChange);
      }
      componentWillUnmount() {
        unregisterBroadcastListener(this.onStorageChange);
      }
    }
    return {
      migrations: [ {
        migrationId: "favorite-fanfouers/ls-to-chrome-storage-api-and-rename-properties",
        storageAreaName: "sync",
        async executor() {
          const oldData = readJSONFromLocalStorage("fav_friends");
          if (!oldData) return;
          const newData = oldData.map(item => ({
            userId: item.userid,
            nickname: item.nickname,
            avatarUrl: item.avatar_url
          }));
          await writeFriendsList(newData);
        }
      } ],
      applyWhen: () => isHomePage(),
      waitReady: () => elementCollection.ready("friends"),
      onLoad() {
        const {friends} = elementCollection.getAll();
        unmount = preactRender(Object(compat_module["createElement"])(FavoriteFanfouers, null), rendered => {
          friends.before(rendered);
        });
      },
      onUnload() {
        unmount();
        unmount = null;
      }
    };
  };
  const FAVED_TIP = "从有爱饭友列表去除";
  const UNFAVED_TIP = "加入有爱饭友列表";
  var user_profile_page = context => {
    const {requireModules, registerBroadcastListener, unregisterBroadcastListener, elementCollection} = context;
    const {storage} = requireModules([ "storage" ]);
    let unmount;
    const readFriendsList = createFriendsListReader(storage);
    const writeFriendsList = createFriendsListWriter(storage);
    elementCollection.add({
      info: "#info"
    });
    function getUserId() {
      return decodeURIComponent(window.location.pathname.split("/")[1]);
    }
    function findByUserId(userId) {
      return friendData => friendData.userId === userId;
    }
    async function isFavorited() {
      const userId = getUserId();
      const friendsList = await readFriendsList();
      return friendsList.some(findByUserId(userId));
    }
    async function addToOrUpdateFriendsList() {
      const userId = getUserId();
      const friendsList = await readFriendsList();
      const existingIndex = friendsList.findIndex(findByUserId(userId));
      const friendData = {
        userId,
        nickname: Object(select_dom["a"])("#panel h1").textContent,
        avatarUrl: Object(select_dom["a"])("#avatar img").src.replace(/^https?:/, "")
      };
      if (-1 === existingIndex) friendsList.push(friendData); else friendsList[existingIndex] = friendData;
      await writeFriendsList(friendsList);
    }
    async function removeFromFriendsList() {
      const userId = getUserId();
      const friendsList = await readFriendsList();
      const index = friendsList.findIndex(findByUserId(userId));
      friendsList.splice(index, 1);
      await writeFriendsList(friendsList);
    }
    class FavoriteFriend extends preact_module["a"] {
      constructor(...args) {
        super(...args);
        this.onStorageChange = createStorageChangeHandler(() => {
          this.refreshState();
        });
        this.toggleFavoritedStatus = async () => {
          if (await isFavorited()) await removeFromFriendsList(); else await addToOrUpdateFriendsList();
          await this.refreshState();
        };
        this.state = {
          isFavorited: false
        };
        this.refreshState();
      }
      async refreshState() {
        this.setState({
          isFavorited: await isFavorited()
        });
      }
      renderFavoritedStatusIndicator() {
        const id = "sf-favorited-status-indicator";
        const className = classnames_default()({
          "sf-is-favorited": this.state.isFavorited
        });
        Object(preact_module["j"])(Object(preact_module["g"])("span", {
          id,
          className
        }), this.favoritedStatusIndicator.parentElement, this.favoritedStatusIndicator);
      }
      renderFavoritedStatusToggler() {
        const id = "sf-favorited-status-toggler";
        const title = this.state.isFavorited ? FAVED_TIP : UNFAVED_TIP;
        const className = classnames_default()({
          "sf-is-favorited": this.state.isFavorited
        });
        Object(preact_module["j"])(Object(preact_module["g"])("a", {
          id,
          className,
          title,
          onClick: this.toggleFavoritedStatus
        }), this.favoritedStatusToggler.parentElement, this.favoritedStatusToggler);
      }
      render() {
        this.renderFavoritedStatusIndicator();
        this.renderFavoritedStatusToggler();
        return null;
      }
      componentWillMount() {
        this.favoritedStatusIndicator = document.createElement("span");
        this.favoritedStatusToggler = document.createElement("a");
        Object(select_dom["a"])("#avatar").append(this.favoritedStatusIndicator);
        Object(select_dom["a"])("#panel h1").append(this.favoritedStatusToggler);
        registerBroadcastListener(this.onStorageChange);
      }
      componentWillUnmount() {
        this.favoritedStatusIndicator.remove();
        this.favoritedStatusToggler.remove();
        this.favoritedStatusIndicator = this.favoritedStatusToggler = null;
        unregisterBroadcastListener(this.onStorageChange);
      }
    }
    return {
      applyWhen: () => isUserProfilePage(),
      waitReady: () => elementCollection.ready("info"),
      async onLoad() {
        unmount = preactRender(Object(preact_module["g"])(FavoriteFriend, null));
        if (await isFavorited()) addToOrUpdateFriendsList();
      },
      onUnload() {
        unmount();
        unmount = null;
      }
    };
  };
  async function _page_onClick(event) {
    const img = event.target;
    const link = img.parentElement;
    if (img.naturalHeight / img.naturalWidth > 3) {
      const photoEntryUrl = window.location.origin + link.getAttribute("name");
      event.stopImmediatePropagation();
      event.preventDefault();
      window.open(photoEntryUrl);
    } else {
      const zoomImage = await element_ready_default()("#ZoomImage", {
        stopOnDomReady: false,
        timeout: 5e3
      });
      if (zoomImage) zoomImage.src = link.href;
    }
  }
  function _page_processStatus(li) {
    const photo = Object(select_dom["a"])(".photo.zoom img", li);
    if (photo) photo.addEventListener("click", _page_onClick);
  }
  function _page_mutationObserverCallback(mutationRecords) {
    for (const {addedNodes} of mutationRecords) for (const li of addedNodes) _page_processStatus(li);
  }
  var fix_photo_zoom_page = context => {
    const {requireModules} = context;
    const {timelineElementObserver} = requireModules([ "timelineElementObserver" ]);
    return {
      applyWhen: () => isTimelinePage(),
      onLoad() {
        timelineElementObserver.addCallback(_page_mutationObserverCallback);
      },
      onUnload() {
        timelineElementObserver.removeCallback(_page_mutationObserverCallback);
      }
    };
  };
  var floating_status_form_page = context => {
    const {requireModules, elementCollection} = context;
    const {statusFormIntersectionObserver} = requireModules([ "statusFormIntersectionObserver" ]);
    let updatePlaceholder;
    let isFloatingEnabled = false;
    elementCollection.add({
      update: "#phupdate",
      act: {
        parent: "update",
        selector: ".act"
      },
      textarea: {
        parent: "update",
        selector: "textarea"
      }
    });
    function enableFloating() {
      if (isFloatingEnabled) return;
      isFloatingEnabled = true;
      const update = elementCollection.get("update");
      updatePlaceholder.style.height = update.offsetHeight + "px";
      updatePlaceholder.style.margin = getComputedStyle(update).margin;
      updatePlaceholder.hidden = false;
      update.classList.add("sf-floating-status-form");
    }
    function disableFloating() {
      if (!isFloatingEnabled) return;
      isFloatingEnabled = false;
      updatePlaceholder.hidden = true;
      elementCollection.get("update").classList.remove("sf-floating-status-form");
    }
    function intersectionObserverCallback(isIntersected) {
      if (isIntersected) disableFloating(); else enableFloating();
    }
    function expandTextareaAndShowOperationButtons() {
      const {act, textarea} = elementCollection.getAll();
      act.style.display = "block";
      textarea.style.height = "4.6em";
      textarea.removeEventListener("click", expandTextareaAndShowOperationButtons);
      textarea.removeEventListener("input", expandTextareaAndShowOperationButtons);
    }
    return {
      applyWhen: () => Object(promiseEvery["a"])([ neg(isPrivateMessagePage()), elementCollection.ready("update") ]),
      onLoad() {
        const textarea = elementCollection.get("textarea");
        updatePlaceholder = document.createElement("div");
        updatePlaceholder.setAttribute("id", "sf-phupdate-placeholder");
        updatePlaceholder.hidden = true;
        elementCollection.get("update").before(updatePlaceholder);
        statusFormIntersectionObserver.addListener(intersectionObserverCallback);
        textarea.addEventListener("click", expandTextareaAndShowOperationButtons);
        textarea.addEventListener("input", expandTextareaAndShowOperationButtons);
      },
      onUnload() {
        disableFloating();
        updatePlaceholder.remove();
        updatePlaceholder = null;
        statusFormIntersectionObserver.removeListener(intersectionObserverCallback);
      }
    };
  };
  var arrayUniquePush = __webpack_require__(15);
  var replay_and_repost_page = context => {
    const {readOptionValue, elementCollection, registerDOMEventListener} = context;
    elementCollection.add({
      update: "#phupdate",
      form: {
        parent: "update",
        selector: "form"
      },
      textarea: {
        parent: "update",
        selector: "textarea"
      }
    });
    registerDOMEventListener("textarea", constants["POST_STATUS_SUCCESS_EVENT_TYPE"], onPostStatusSuccess);
    function onPostStatusSuccess(event) {
      const {textarea} = elementCollection.getAll();
      const {formDataJson} = event.detail;
      const statusContent = formDataJson.content || formDataJson.desc;
      if (readOptionValue("keepFocusAfterPosting")) textarea.focus();
      if (readOptionValue("keepAtNamesAfterPosting") && statusContent.startsWith("@")) {
        const userNicknames = [];
        extractUserNicknamesFromStatusContent(statusContent, userNicknames);
        textarea.value = userNicknames.join(" ") + " ";
        const selectionPos = textarea.value.length;
        textarea.setSelectionRange(selectionPos, selectionPos);
      }
    }
    function extractStatusId(li) {
      return Object(select_dom["a"])(".stamp .time", li).getAttribute("ffid");
    }
    function extractStatusContent(li) {
      const repostLink = Object(select_dom["a"])(":scope > .op > .repost", li);
      const queryString = repostLink.search.slice(1);
      const urlSearchParams = new URLSearchParams(queryString);
      const queryMap = Object.fromEntries(urlSearchParams.entries());
      const statusContent = queryMap.status;
      return statusContent;
    }
    function extractUserNicknamesFromStatusDOM(li, callback) {
      if (Array.isArray(callback)) {
        const userNicknames = [];
        callback = userNickname => Object(arrayUniquePush["a"])(userNicknames, userNickname);
      }
      for (const atUserElement of select_dom["a"].all(".content a.former", li)) {
        const userUrl = atUserElement.href;
        const userNickname = "@" + atUserElement.textContent;
        if (userUrl !== Object(getLoggedInUserProfilePageUrl["a"])()) callback(userNickname);
      }
    }
    function extractUserNicknamesFromStatusContent(statusContent, callback) {
      if (Array.isArray(callback)) {
        const userNicknames = [];
        callback = userNickname => Object(arrayUniquePush["a"])(userNicknames, userNickname);
      }
      for (const textPart of statusContent.split(/\s+/)) if ("@" === textPart.charAt(0)) callback(textPart);
    }
    const createHandler = type => event => {
      event.preventDefault();
      const {form, textarea} = elementCollection.getAll();
      const li = event.path.find(element => "li" === element.tagName.toLowerCase());
      const authorElement = Object(select_dom["a"])(".author", li);
      const targetStatusId = extractStatusId(li);
      const targetStatusAuthorNickname = "@" + authorElement.textContent;
      const targetStatusText = extractStatusContent(li);
      const oldStatusContent = textarea.value.trim();
      let inReplyToStatusId = "", repostStatusId = "";
      let newStatusContent = "";
      let selectionStartPos = -1, selectionEndPos = -1;
      if ("reply" === type) {
        const atUserNicknames = [ targetStatusAuthorNickname ];
        const oldStatusNickNames = [];
        extractUserNicknamesFromStatusContent(oldStatusContent, oldStatusNickNames);
        extractUserNicknamesFromStatusDOM(li, nickname => {
          if (!oldStatusNickNames.includes(nickname)) Object(arrayUniquePush["a"])(atUserNicknames, nickname);
        });
        newStatusContent = atUserNicknames.join(" ") + " " + oldStatusContent;
        selectionStartPos = targetStatusAuthorNickname.length + 1;
        selectionEndPos = newStatusContent.length;
        inReplyToStatusId = targetStatusId;
      } else if ("repost" === type) {
        newStatusContent = `${oldStatusContent}${targetStatusText}`;
        selectionStartPos = 0;
        selectionEndPos = oldStatusContent.length;
        repostStatusId = targetStatusId;
      }
      textarea.value = newStatusContent;
      textarea.focus();
      compat_trigger_event_default()(textarea, "change");
      textarea.setSelectionRange(selectionStartPos, selectionEndPos);
      form.elements.in_reply_to_status_id.value = inReplyToStatusId;
      form.elements.repost_status_id.value = repostStatusId;
    };
    const onClickReply = createHandler("reply");
    const onClickRepost = createHandler("repost");
    return {
      applyWhen: () => Object(promiseEvery["a"])([ neg(isPrivateMessagePage()), elementCollection.ready("update") ]),
      onLoad() {
        on("click", "#stream ol .op .reply", onClickReply);
        on("click", "#stream ol .op .repost", onClickRepost);
      },
      onUnload() {
        off("click", "#stream ol .op .reply", onClickReply);
        off("click", "#stream ol .op .repost", onClickRepost);
      }
    };
  };
  var modules_scrollManager = __webpack_require__(41);
  let isRunning = false;
  let afId = null;
  let prevY = -1;
  function animatedScrollTop_scroll() {
    const currY = modules_scrollManager["default"].getScrollTop();
    const next = Math.floor(currY / 1.15);
    if (0 === currY) return stop();
    if (-1 !== prevY && Math.abs(currY - prevY) > 1) return stop();
    window.scrollTo(0, next);
    prevY = next;
    afId = requestAnimationFrame(animatedScrollTop_scroll);
  }
  function animatedScrollTop_start() {
    if (isRunning) return;
    isRunning = true;
    animatedScrollTop_scroll();
  }
  function stop() {
    if (!isRunning) return;
    isRunning = false;
    cancelAnimationFrame(afId);
    afId = null;
    prevY = -1;
  }
  var animatedScrollTop = async () => {
    await modules_scrollManager["default"].ready();
    animatedScrollTop_start();
  };
  const MAIN_TOP = 66;
  const _page_SCROLL_DEBOUNCE_WAIT = 500;
  var go_top_button_page = context => {
    const {requireModules} = context;
    const {scrollManager} = requireModules([ "scrollManager" ]);
    let toTopButton;
    let isHidden = false;
    function createButton() {
      const existingButton = Object(select_dom["a"])("#pagination-totop");
      const container = Object(select_dom["a"])("#stream") && Object(select_dom["a"])("#stream").parentElement || Object(select_dom["a"])(".inner-content");
      toTopButton = Object(dom_chef["h"])("a", {
        id: "pagination-totop",
        onClick: clickHandler
      }, "返回顶部");
      if (existingButton) existingButton.remove();
      container.append(toTopButton);
      hideButton();
      return toTopButton;
    }
    function clickHandler(event) {
      event.preventDefault();
      hideButton();
      animatedScrollTop();
    }
    const debouncedScrollHandler = just_debounce_it_default()(() => {
      if (scrollManager.getScrollTop() > MAIN_TOP) showButton(); else hideButton();
    }, _page_SCROLL_DEBOUNCE_WAIT);
    function scrollHandler() {
      hideButton();
      debouncedScrollHandler();
    }
    function showButton() {
      if (!isHidden) return;
      isHidden = false;
      toTopButton.style.display = "";
      requestAnimationFrame(() => Object.assign(toTopButton.style, {
        opacity: .5,
        cursor: "pointer",
        transition: "opacity .4s ease-in-out"
      }));
    }
    function hideButton() {
      if (isHidden) return;
      isHidden = true;
      Object.assign(toTopButton.style, {
        display: "none",
        opacity: 0,
        transition: ""
      });
    }
    return {
      applyWhen: () => promiseAny([ element_ready_default()("#stream"), element_ready_default()(".inner-content") ]),
      onLoad() {
        toTopButton = createButton();
        scrollManager.addListener(scrollHandler);
      },
      onUnload() {
        toTopButton.remove();
        toTopButton = null;
        scrollManager.removeListener(scrollHandler);
      }
    };
  };
  var dom_element_is_natively_editable = function(element) {
    if (element.ownerDocument.designMode && "on" === element.ownerDocument.designMode.toLowerCase()) return true;
    switch (element.tagName.toLowerCase()) {
     case "input":
      return isEditableInput(element);

     case "textarea":
      return true;
    }
    if (isContentEditable(element)) return true;
    return false;
  };
  function isContentEditable(element) {
    if (element.contentEditable && "true" === element.contentEditable.toLowerCase()) return true;
    if (element.contentEditable && "inherit" === element.contentEditable.toLowerCase() && element.parentNode) return isContentEditable(element.parentNode);
    return false;
  }
  function isEditableInput(input) {
    switch (input.type) {
     case "text":
      return true;

     case "email":
      return true;

     case "password":
      return true;

     case "search":
      return true;

     case "tel":
      return true;

     case "url":
      return true;

     default:
      return false;
    }
  }
  var element_visible = __webpack_require__(54);
  var element_visible_default = __webpack_require__.n(element_visible);
  var defined = __webpack_require__(35);
  var defined_default = __webpack_require__.n(defined);
  var isHotkey = (event, opts) => {
    if (event.ctrlKey !== Boolean(opts.ctrl)) return false;
    if (event.altKey !== Boolean(defined_default()(opts.alt, opts.option))) return false;
    if (event.shiftKey !== Boolean(opts.shift)) return false;
    if (event.metaKey !== Boolean(defined_default()(opts.command, opts.win))) return false;
    if (event.key.toLowerCase() !== opts.key.toLowerCase()) return false;
    return true;
  };
  var findElementWithSpecifiedContentInArray = __webpack_require__(26);
  var keyboard_shortcuts_page = context => {
    const {registerDOMEventListener} = context;
    const hotkeyHandlers = [ [ {
      key: "ArrowLeft"
    }, goPrevPage ], [ {
      key: "ArrowRight"
    }, goNextPage ], [ {
      key: "t"
    }, animatedScrollTop ], [ {
      key: "Enter"
    }, focusTextarea ] ];
    registerDOMEventListener(document.documentElement, "keydown", keyboardEventHandler);
    function keyboardEventHandler(event) {
      if (dom_element_is_natively_editable(event.target)) return;
      for (const [hotkeyOpts, handler] of hotkeyHandlers) if (isHotkey(event, hotkeyOpts)) {
        handler(event);
        break;
      }
    }
    function goPrevPage(event) {
      const prevPageButton = getPagerButtonsByText("上一页") || getPhotoPagerButtonByText("上一张");
      if (prevPageButton) {
        event.preventDefault();
        prevPageButton.click();
      }
    }
    function goNextPage(event) {
      const nextPageButton = getPagerButtonsByText("下一页") || getPhotoPagerButtonByText("下一张");
      if (nextPageButton) {
        event.preventDefault();
        nextPageButton.click();
      }
    }
    function getPagerButtonsByText(text) {
      const allPageButtons = select_dom["a"].all(".paginator > li > a");
      const buttonWithSpecifiedText = Object(findElementWithSpecifiedContentInArray["a"])(allPageButtons, text);
      return buttonWithSpecifiedText;
    }
    function getPhotoPagerButtonByText(text) {
      if (isPhotoEntryPage()) {
        const allPageButtons = select_dom["a"].all('#crumb > ul > li > a[href^="/photo/"]');
        const buttonWithSpecifiedText = Object(findElementWithSpecifiedContentInArray["a"])(allPageButtons, text);
        return buttonWithSpecifiedText;
      }
    }
    function focusTextarea(event) {
      const form = Object(select_dom["a"])("#phupdate form");
      const textarea = Object(select_dom["a"])("#phupdate textarea");
      const isTriggeredOutsideTheForm = form && !form.contains(event.target);
      const isTextareaVisible = textarea && element_visible_default()(textarea);
      if (isTriggeredOutsideTheForm && isTextareaVisible) {
        event.preventDefault();
        textarea.focus();
      }
    }
  };
  var activity_detector = __webpack_require__(55);
  var activity_detector_default = __webpack_require__.n(activity_detector);
  var process_unread_statuses_page = context => {
    const {readOptionValue, requireModules, elementCollection, registerDOMEventListener} = context;
    const {scrollManager, statusFormIntersectionObserver, proxiedAudio} = requireModules([ "scrollManager", "statusFormIntersectionObserver", "proxiedAudio" ]);
    const activityDetector = activity_detector_default()({
      autoInit: false
    });
    let previousCount = 0;
    let isUserActive = true;
    let mutationObserver;
    let isStatusFormIntersected = 0 === scrollManager.getScrollTop();
    elementCollection.add({
      timelineNotification: "#timeline-notification",
      showUnreadStatusesButton: "#timeline-notification > a",
      timelineCount: "#timeline-count"
    });
    registerDOMEventListener("showUnreadStatusesButton", "click", onClickButton);
    activityDetector.on("active", () => isUserActive = true);
    activityDetector.on("idle", () => isUserActive = false);
    function getUnreadStatusesCounts() {
      const bufferedStatuses = select_dom["a"].all("#stream > ol > li.buffered");
      const myStatuses = bufferedStatuses.filter(element => {
        const author = Object(select_dom["a"])(".author", element);
        return author.href === Object(getLoggedInUserProfilePageUrl["a"])();
      });
      return {
        myStatusesCount: myStatuses.length,
        restStatusesCount: bufferedStatuses.length - myStatuses.length
      };
    }
    function showBufferedStatuses() {
      elementCollection.get("showUnreadStatusesButton").click();
    }
    function playSound() {
      if (!readOptionValue("playSound")) return;
      const audioUrl = __webpack_require__(105);
      proxiedAudio.play(audioUrl);
    }
    function processUnreadStatuses() {
      if (!is_visible_module(elementCollection.get("timelineNotification"))) return;
      const {myStatusesCount, restStatusesCount} = getUnreadStatusesCounts();
      if (isStatusFormIntersected && myStatusesCount && !restStatusesCount) showBufferedStatuses(); else if (restStatusesCount > previousCount) {
        if (!isUserActive || !isStatusFormIntersected) playSound();
        previousCount = restStatusesCount;
      }
    }
    function onClickButton() {
      previousCount = 0;
    }
    function intersectionObserverCallback(isIntersected) {
      isStatusFormIntersected = isIntersected;
      processUnreadStatuses();
    }
    return {
      applyWhen: () => elementCollection.ready("timelineNotification"),
      waitReady: () => element_ready_default()("#stream"),
      onLoad() {
        statusFormIntersectionObserver.addListener(intersectionObserverCallback);
        mutationObserver = new MutationObserver(() => processUnreadStatuses());
        mutationObserver.observe(elementCollection.get("timelineCount"), {
          childList: true
        });
        activityDetector.init();
        previousCount = getUnreadStatusesCounts().restStatusesCount;
      },
      unload() {
        statusFormIntersectionObserver.removeListener(intersectionObserverCallback);
        mutationObserver.disconnect();
        mutationObserver = null;
        activityDetector.stop();
      }
    };
  };
  var is_number = __webpack_require__(56);
  var is_number_default = __webpack_require__.n(is_number);
  const ERR_FN_HAS_PRESET = new Error("fn 已经预先设置，不允许覆盖");
  const ERR_WAIT_HAS_PRESET = new Error("wait 已经预先设置，不允许覆盖");
  class Timeout_Timeout {
    constructor({fn, wait}) {
      if (this._hasPresetFn = "function" === typeof fn) this._fn = fn;
      if (this._hasPresetWait = is_number_default()(wait)) this._wait = wait;
      this._timeout = null;
      this._wrappedFn = () => {
        this._timeout = null;
        this._fn();
      };
    }
    setFn(fn) {
      if (this._hasPresetFn) throw ERR_FN_HAS_PRESET;
      this._fn = fn;
    }
    setWait(wait) {
      if (this._hasPresetWait) throw ERR_WAIT_HAS_PRESET;
      this._wait = wait;
    }
    isActive() {
      return null != this._timeout;
    }
    setup() {
      if (this.isActive()) return;
      this._timeout = setTimeout(this._wrappedFn, this._wait);
    }
    cancel() {
      if (!this.isActive()) return;
      clearTimeout(this._timeout);
      this._timeout = null;
    }
  }
  const RELEASE_COUNT = 3;
  const TEST_HOTKEY = {
    ctrl: true,
    alt: true,
    shift: true,
    key: "p"
  };
  var scroll_to_show_page = context => {
    const {requireModules, elementCollection, registerDOMEventListener} = context;
    const {scrollManager} = requireModules([ "scrollManager" ]);
    let scrollCount = 0;
    const waiting = new Timeout_Timeout({
      fn: noop["a"],
      wait: 96
    });
    const timeout = new Timeout_Timeout({
      fn: goBackward,
      wait: 500
    });
    elementCollection.add({
      timelineNotification: "#timeline-notification",
      button: {
        parent: "timelineNotification",
        selector: "a"
      },
      timelineCount: "#timeline-count"
    });
    registerDOMEventListener(window, "mousewheel", onMouseWheel);
    registerDOMEventListener(window, "keyup", onKeyUpTest);
    function setCount(next) {
      scrollCount = next;
      elementCollection.get("button").dataset.scrollCount = scrollCount;
      elementCollection.get("timelineNotification").classList.toggle("sf-is-scrolling", scrollCount > 0);
    }
    function goForward() {
      setCount(scrollCount + 1);
    }
    function goBackward() {
      setCount(scrollCount - 1);
      if (scrollCount > 0) timeout.setup();
    }
    function reset() {
      setCount(0);
    }
    function hasNewStatuses() {
      return is_visible_module(elementCollection.get("timelineNotification")) && parseInt(elementCollection.get("timelineCount").textContent, 10) > 0;
    }
    function showNewStatuses() {
      elementCollection.get("timelineNotification").click();
    }
    function onMouseWheel(event) {
      if (waiting.isActive()) return;
      if (event.wheelDeltaY <= 0) return;
      if (scrollManager.getScrollTop()) return;
      if ("TEXTAREA" === event.target.tagName) return;
      if (!hasNewStatuses()) return;
      timeout.cancel();
      goForward();
      if (scrollCount === RELEASE_COUNT) {
        showNewStatuses();
        reset();
      } else {
        waiting.setup();
        timeout.setup();
      }
    }
    function onKeyUpTest(event) {
      if (true) return;
      if (!isHotkey(event, TEST_HOTKEY)) return;
      elementCollection.get("timelineNotification").style.display = "";
      elementCollection.get("timelineCount").textContent = 3;
    }
    return {
      applyWhen: () => elementCollection.ready("timelineNotification")
    };
  };
  var photo_album_page = context => {
    const {elementCollection} = context;
    elementCollection.add({
      album: "#album",
      images: {
        selector: ".photo>img",
        parent: "album",
        getAll: true
      }
    });
    return {
      applyWhen: () => isPhotoAlbumPage(),
      waitReady: () => elementCollection.ready("album"),
      onLoad() {
        for (const photo of elementCollection.get("images")) {
          photo.src = photo.src.replace(/@120w_120h_1l\.jpg$/, "@240w_240h_1l.jpg");
          photo.style.maxWidth = photo.style.maxHeight = "120px";
          photo.style.boxSizing = "content-box";
        }
      },
      onUnload() {}
    };
  };
  var photo_entry_page = context => {
    const {elementCollection} = context;
    elementCollection.add({
      photo: "#photo img"
    });
    return {
      applyWhen: () => Object(promiseEvery["a"])([ isPhotoEntryPage(), elementCollection.ready("photo") ]),
      onLoad() {
        const photo = elementCollection.get("photo");
        photo.src = photo.src.replace(/@596w_1l\.jpg$/, "");
        photo.style.maxWidth = "596px";
      },
      onUnload() {}
    };
  };
  function shared_processStatus(li) {
    const photoLink = Object(select_dom["a"])("a.photo.zoom", li);
    const photo = photoLink && Object(select_dom["a"])("img", photoLink);
    if (photoLink && photo) {
      photoLink.href = photoLink.href.replace(/@596w_1l\.jpg$/, "");
      photo.src = photo.src.replace(/@100w_100h_1l\.jpg$/, "@200w_200h_1l.jpg");
      photo.style.maxHeight = "100px";
    }
  }
  var status_page = context => {
    const {elementCollection} = context;
    elementCollection.add({
      status: ".msg"
    });
    return {
      applyWhen: () => Object(promiseEvery["a"])([ isStatusPage(), elementCollection.ready("status") ]),
      onLoad() {
        shared_processStatus(elementCollection.get("status"));
      },
      onUnload() {}
    };
  };
  function timeline_page_mutationObserverCallback(mutationRecords) {
    for (const {addedNodes} of mutationRecords) for (const li of addedNodes) shared_processStatus(li);
  }
  var timeline_page = context => {
    const {requireModules} = context;
    const {timelineElementObserver} = requireModules([ "timelineElementObserver" ]);
    return {
      applyWhen: () => isTimelinePage(),
      onLoad() {
        timelineElementObserver.addCallback(timeline_page_mutationObserverCallback);
      },
      onUnload() {
        timelineElementObserver.removeCallback(timeline_page_mutationObserverCallback);
      }
    };
  };
  var blobToBase64 = blob => new Promise((resolve, reject) => {
    const fr = new FileReader;
    fr.onload = () => resolve(fr.result);
    fr.onerror = () => reject(fr.error);
    fr.readAsDataURL(blob);
  });
  const _page_STORAGE_KEY = "new-avatar-base64-temp";
  const _page_STORAGE_AREA_NAME = "session";
  const share_new_avatar_page_MESSAGE_CONFIRMING = "是否发表消息向大家分享你的新头像？";
  const MESSAGE_POSTING = "正在发布消息……";
  const MESSAGE_SUCCESS = "分享成功！";
  const MESSAGE_FAILURE = "发送失败";
  var share_new_avatar_page = context => {
    const {requireModules, elementCollection, registerDOMEventListener} = context;
    const {storage, notification} = requireModules([ "storage", "notification" ]);
    elementCollection.add({
      form: "#setpicture",
      fileControl: "#pro_bas_picture"
    });
    registerDOMEventListener("form", "submit", onFormSubmit);
    async function onFormSubmit() {
      const file = elementCollection.get("fileControl").files[0];
      const avatarBase64Temp = file && await blobToBase64(file);
      if (avatarBase64Temp) await storage.write(_page_STORAGE_KEY, avatarBase64Temp, _page_STORAGE_AREA_NAME);
    }
    async function uploadCachedAvatar() {
      const cachedAvatarBase64 = await storage.read(_page_STORAGE_KEY, _page_STORAGE_AREA_NAME);
      if (!cachedAvatarBase64) return;
      if (window.confirm(share_new_avatar_page_MESSAGE_CONFIRMING)) {
        notification.create(notification.INFO, MESSAGE_POSTING);
        const data = {
          ajax: "yes",
          action: "photo.upload",
          token: elementCollection.get("form").token.value,
          desc: "我刚刚上传了新头像",
          photo_base64: cachedAvatarBase64
        };
        let ajaxError;
        try {
          await Object(dist["a"])("/home/upload").formData(data).post();
        } catch (error) {
          ajaxError = error;
        }
        if (ajaxError) notification.create(notification.INFO, MESSAGE_FAILURE); else notification.create(notification.INFO, MESSAGE_SUCCESS);
      }
      await storage.delete(_page_STORAGE_KEY, _page_STORAGE_AREA_NAME);
    }
    return {
      applyWhen: () => "/settings" === window.location.pathname,
      waitReady: () => elementCollection.ready("form"),
      onLoad() {
        uploadCachedAvatar();
      }
    };
  };
  var array_last = __webpack_require__(57);
  var array_last_default = __webpack_require__.n(array_last);
  const CLASSNAME_CONTAINER = "sf-contextual-statuses-container";
  var indexOf = (string, matcher, starting = 0) => {
    let index = -1;
    let length = 0;
    if ("string" === typeof matcher) {
      index = string.indexOf(matcher, starting);
      length = matcher.length;
    } else {
      string = string.slice(starting);
      const matched = string.match(matcher);
      if (matched) {
        index = starting + matched.index;
        length = matched[0].length;
      }
    }
    return {
      index,
      length
    };
  };
  var extractText = (text, opts) => {
    let currentIndex = 0;
    const ret = {};
    for (const {key, opening, closing} of opts) {
      const matchedOpening = indexOf(text, opening, currentIndex);
      if (-1 === matchedOpening.index) break;
      currentIndex = matchedOpening.index + matchedOpening.length;
      const matchedClosing = indexOf(text, closing, currentIndex);
      if (-1 === matchedClosing.index) break;
      currentIndex = matchedClosing.index + matchedClosing.length;
      ret[key] = text.slice(matchedOpening.index + matchedOpening.length, matchedClosing.index);
    }
    return ret;
  };
  function _page_extends() {
    return _page_extends = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _page_extends.apply(null, arguments);
  }
  const ATTRIBUTE_CACHE_ID = "sf-contextual-statuses";
  var show_contextual_statuses_page = context => {
    const {readOptionValue, requireModules, elementCollection} = context;
    const {timelineElementObserver} = requireModules([ "timelineElementObserver" ]);
    const cacheMap = new Map;
    let cacheIdGen = 0;
    elementCollection.add({
      stream: "#stream"
    });
    class ContextualStatus extends preact_module["a"] {
      render() {
        const {isLast} = this.props;
        return Object(preact_module["g"])("li", {
          className: classnames_default()("unlight", {
            "sf-last": isLast
          })
        });
      }
      componentDidMount() {
        const li = this.base;
        li.innerHTML = this.props.html;
        window.FF.app.Stream.attach(li);
        if (this.props.hasPhoto) window.FF.app.Zoom.init(li);
      }
    }
    class ContextualStatuses extends preact_module["a"] {
      constructor(props) {
        super(props);
        this.fetchNextNStatusesPerConfig = () => {
          this.fetchNextNStatuses(readOptionValue("fetchStatusNumberPerClick"));
        };
        this.resetState = () => {
          this.setState(this.initialState);
        };
        this.fetchNextStatus = async () => {
          this.setState({
            isWaiting: true
          });
          const statusPageHtml = await fetchStatusPageHtml(this.state.nextStatusId);
          const {statusHtml, unavailableReason, nextStatusId, hasPhoto} = processStatusPageHtml(statusPageHtml);
          if (unavailableReason) this.setState({
            hasMore: false,
            unavailableReason
          }); else this.setState(state => ({
            hasMore: !!nextStatusId,
            nextStatusId,
            statuses: [ ...state.statuses, {
              isLast: !nextStatusId,
              html: statusHtml,
              hasPhoto
            } ]
          }));
          this.setState({
            isWaiting: false
          });
        };
        this.initialState = {
          hasMore: true,
          pendingNumber: 0,
          nextStatusId: props.initialStatusId,
          unavailableReason: "",
          isWaiting: false,
          statuses: []
        };
        this.state = {
          ...this.initialState
        };
      }
      async fetchNextNStatuses(pendingNumber) {
        this.setState(() => ({
          pendingNumber
        }));
        if (pendingNumber > 0 && this.state.hasMore) {
          await this.fetchNextStatus();
          await p_sleep_default()(400);
          this.fetchNextNStatuses(pendingNumber - 1);
        }
      }
      renderToggle() {
        if (!this.state.hasMore && !this.state.statuses.length) return null;
        if (this.state.isWaiting && !this.state.statuses.length) return null;
        if (this.state.statuses.length) return Object(preact_module["g"])("button", {
          className: "sf-toggle sf-animation-off",
          onClick: this.resetState
        }, "隐藏原文");
        const text = "repost" === this.props.type ? "转自" : "展开";
        return Object(preact_module["g"])("button", {
          className: "sf-toggle sf-" + this.props.type,
          onClick: this.fetchNextNStatusesPerConfig
        }, text);
      }
      renderStatuses() {
        return Object(preact_module["g"])("div", {
          className: "sf-contextual-statuses"
        }, this.state.statuses.map((props, i) => Object(preact_module["g"])(ContextualStatus, _page_extends({
          key: i
        }, props))));
      }
      renderIndicator() {
        if (this.state.isWaiting && this.state.pendingNumber > 0) return Object(preact_module["g"])("button", {
          className: "sf-indicator sf-waiting sf-animation-off"
        });
        if (!this.state.hasMore && this.state.unavailableReason) return Object(preact_module["g"])("button", {
          className: "sf-indicator sf-not-available"
        }, this.state.unavailableReason);
        if (this.state.hasMore && this.state.statuses.length) return Object(preact_module["g"])("button", {
          className: "sf-indicator",
          onClick: this.fetchNextNStatusesPerConfig
        }, "继续展开");
      }
      render() {
        return Object(preact_module["g"])("div", {
          className: CLASSNAME_CONTAINER
        }, this.renderToggle(), this.renderStatuses(), this.renderIndicator());
      }
      componentDidMount() {
        if (readOptionValue("autoFetch")) this.fetchNextStatus();
      }
    }
    function fetchStatusPageHtml(statusId) {
      return Object(dist["a"])("/statuses/" + statusId).get().text();
    }
    function processStatusPageHtml(statusPageHtml) {
      const {avatar, author, other} = extractText(statusPageHtml, [ {
        key: "avatar",
        opening: '<div id="avatar">',
        closing: "</div>"
      }, {
        key: "author",
        opening: "<h1>",
        closing: "</h1>"
      }, {
        key: "other",
        opening: /<h2( class="deleted")?>/,
        closing: "</h2>"
      } ]);
      const statusHtml = avatar.replace("<a", '<a class="avatar"') + author.replace("<a", '<a class="author"') + other.replace(' redirect="/home"', "");
      let unavailableReason;
      let nextStatusId;
      let hasPhoto = false;
      if (other.includes("我只向关注我的人公开我的消息")) unavailableReason = "未公开"; else if (other.includes("此消息已被删除")) unavailableReason = "已删除"; else {
        var _other$match;
        nextStatusId = null === (_other$match = other.match(/<span class="reply"><a href="\/statuses\/(.+?)">.+<\/a><\/span>/)) || void 0 === _other$match ? void 0 : _other$match[1];
        hasPhoto = other.includes("<img ");
      }
      return {
        statusHtml,
        unavailableReason,
        nextStatusId,
        hasPhoto
      };
    }
    function getCacheId(li) {
      let cacheId;
      if (li.hasAttribute(ATTRIBUTE_CACHE_ID)) cacheId = parseInt(li.getAttribute(ATTRIBUTE_CACHE_ID), 10); else {
        cacheId = cacheIdGen++;
        li.setAttribute(ATTRIBUTE_CACHE_ID, cacheId);
      }
      return cacheId;
    }
    function hasContextualStatuses(li) {
      return select_dom["a"].exists(".stamp .reply a", li);
    }
    function onStatusAdded(li) {
      if (!isStatusElement(li)) return;
      if (!hasContextualStatuses(li)) return;
      const cacheId = getCacheId(li);
      if (cacheMap.has(cacheId)) {
        const aliveInstance = cacheMap.get(cacheId);
        const maybeDeadInstance = li.nextElementSibling;
        if (null !== maybeDeadInstance && void 0 !== maybeDeadInstance && maybeDeadInstance.matches("." + CLASSNAME_CONTAINER)) maybeDeadInstance.replaceWith(aliveInstance);
        return;
      }
      const replyLink = Object(select_dom["a"])(".stamp .reply a", li);
      const props = {
        type: replyLink.textContent.startsWith("转自") ? "repost" : "reply",
        initialStatusId: array_last_default()(replyLink.href.split("/"))
      };
      preactRender(Object(preact_module["g"])(ContextualStatuses, props), instance => {
        li.after(instance);
        cacheMap.set(cacheId, instance);
      });
    }
    async function onStatusRemoved(li) {
      if (!isStatusElement(li)) return;
      if (!hasContextualStatuses(li)) return;
      const {stream} = elementCollection.getAll();
      const cacheId = getCacheId(li);
      if (select_dom["a"].exists(`[${ATTRIBUTE_CACHE_ID}="${cacheId}"]`, stream)) return;
      if (cacheMap.has(cacheId)) {
        const instance = cacheMap.get(cacheId);
        const elements = select_dom["a"].all("button, li", instance);
        if (isElementInDocument(instance)) {
          while (elements.length) {
            const element = elements.shift();
            await Object(fade["b"])(element, 400);
            element.remove();
          }
          instance.remove();
        }
        cacheMap.delete(cacheId);
      }
    }
    function mutationObserverCallback(mutationRecords) {
      for (const {addedNodes, removedNodes} of mutationRecords) {
        for (const addedNode of addedNodes) onStatusAdded(addedNode);
        for (const removedNode of removedNodes) onStatusRemoved(removedNode);
      }
    }
    return {
      applyWhen: () => isTimelinePage(),
      waitReady: () => Object(promiseEvery["a"])([ Object(requireFanfouLib["a"])("jQuery"), Object(requireFanfouLib["a"])("FF.app.Stream"), Object(requireFanfouLib["a"])("FF.app.Zoom") ]),
      onLoad() {
        timelineElementObserver.addCallback(mutationObserverCallback);
      },
      onUnload() {
        timelineElementObserver.removeCallback(mutationObserverCallback);
        cacheMap.clear();
        for (const li of select_dom["a"].all(`[${ATTRIBUTE_CACHE_ID}]`)) li.removeAttribute(ATTRIBUTE_CACHE_ID);
        for (const container of select_dom["a"].all("." + CLASSNAME_CONTAINER)) container.remove();
      }
    };
  };
  var fix_reply_and_repost_page = () => {
    const createHandler = proxiedSelector => event => {
      const {handler} = window.jQuery._data(document, "events").click.find(({selector}) => selector === proxiedSelector);
      handler.call(event.target, event);
    };
    const onClickReply = createHandler(".message ol >li .op>a.reply");
    const onClickRepost = createHandler("#stream ol >li >span.op>a.repost");
    return {
      applyWhen: () => isTimelinePage(),
      onLoad() {
        on("click", `.${CLASSNAME_CONTAINER} .op .reply`, onClickReply);
        on("click", `.${CLASSNAME_CONTAINER} .op .repost`, onClickRepost);
      },
      onUnload() {
        off("click", `.${CLASSNAME_CONTAINER} .op .reply`, onClickReply);
        off("click", `.${CLASSNAME_CONTAINER} .op .repost`, onClickRepost);
      }
    };
  };
  var numberClamp = clamp;
  function clamp(b1, n, b2) {
    if ("number" != typeof b1 || "number" != typeof n || "number" != typeof b2) throw new Error("arguments must be numbers");
    if (isNaN(b1) || isNaN(n) || isNaN(b2)) return NaN;
    if (b1 == b2) return b1;
    var lower, higher;
    b1 < b2 ? (lower = b1, higher = b2) : (higher = b1, lower = b2);
    if (n < lower) return lower;
    if (n > higher) return higher;
    return n;
  }
  var p_retry = __webpack_require__(58);
  var p_retry_default = __webpack_require__.n(p_retry);
  var lib = __webpack_require__(59);
  var lib_default = __webpack_require__.n(lib);
  var loadAsset = __webpack_require__(36);
  var Deferred = __webpack_require__(28);
  let jsonp_count = 0;
  const prefix = "spacefanfou$$jsonp";
  const ERR_TIMEOUT = new Error("JSONP timeout");
  var jsonp = (url, opts = {}) => {
    const id = `${prefix}${jsonp_count++}`;
    const params = opts.params || {};
    const callbackField = opts.callbackField || "callback";
    const timeout = null != opts.timeout ? opts.timeout : 6e4;
    const cache = true === opts.cache;
    const d = new Deferred["a"];
    let timer;
    let script;
    if (timeout) timer = setTimeout(() => {
      d.reject(ERR_TIMEOUT);
      cleanup();
    }, timeout);
    function cleanup() {
      delete window[id];
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      if (script) {
        script.remove();
        script = null;
      }
    }
    function wrappedCallback(response) {
      d.resolve(response);
      cleanup();
    }
    window[id] = wrappedCallback;
    const finalParams = {
      ...params,
      [callbackField]: id
    };
    if (!cache) finalParams._ = Date.now();
    const finalUrl = lib_default()(url, finalParams);
    script = Object(loadAsset["a"])({
      type: "script",
      url: finalUrl,
      mount: loadAsset["b"]
    });
    return d.promise;
  };
  var RGX = /([^{]*?)\w(?=\})/g;
  var MAP = {
    YYYY: "getFullYear",
    YY: "getYear",
    MM: function(d) {
      return d.getMonth() + 1;
    },
    DD: "getDate",
    HH: "getHours",
    mm: "getMinutes",
    ss: "getSeconds",
    fff: "getMilliseconds"
  };
  var tinydate = function(str, custom) {
    var parts = [], offset = 0;
    str.replace(RGX, (function(key, _, idx) {
      parts.push(str.substring(offset, idx - 1));
      offset = idx += key.length + 1;
      parts.push(custom && custom[key] || function(d) {
        return ("00" + ("string" === typeof MAP[key] ? d[MAP[key]]() : MAP[key](d))).slice(-key.length);
      });
    }));
    if (offset !== str.length) parts.push(str.substring(offset));
    return function(arg) {
      var out = "", i = 0, d = arg || new Date;
      for (;i < parts.length; i++) out += "string" === typeof parts[i] ? parts[i] : parts[i](d);
      return out;
    };
  };
  var formatDate = tinydate("{YYYY}-{MM}-{DD}");
  class _page_SidebarStatistics extends preact_module["a"] {
    constructor(...args) {
      super(...args);
      this.state = {
        isProtected: false,
        registerDateText: "……",
        registerDurationText: "……",
        registerDurationProgress: 0,
        statusFrequencyText: "……",
        statusFrequencyProgress: 0,
        influenceIndexText: "……",
        influenceIndexProgress: 0,
        backgroundImageUrl: null
      };
    }
    async componentWillMount() {
      const userProfile = await this.fetchUserProfileData();
      this.processData(userProfile);
    }
    getUserId() {
      const metaContent = Object(select_dom["a"])("meta[name=author]").content;
      const userId = metaContent.match(/\((.+)\)/)[1];
      return userId;
    }
    async fetchUserProfileData() {
      const apiUrl = "//api.fanfou.com/users/show.json";
      const params = {
        id: this.getUserId()
      };
      const fetch = () => jsonp(apiUrl, {
        params
      });
      const userProfileData = await p_retry_default()(fetch, {
        retries: 3,
        minTimeout: 250
      });
      return userProfileData;
    }
    processData(userProfile) {
      const isProtected = userProfile.protected;
      const registerDate = new Date(userProfile.created_at);
      const registerDateText = formatDate(registerDate);
      const registerDays = Math.floor((new Date - registerDate) / 864e5);
      const registerYears = Math.floor(registerDays / 365.2425);
      const registerMonths = Math.floor((registerDays - 365.2425 * registerYears) / 30.4369);
      const registerDuration = (registerYears > 0 || registerMonths > 0 ? "约 " : "") + (registerYears > 0 ? registerYears + " 年" + (registerMonths > 0 ? "零 " + registerMonths + " 个月" : "") : registerMonths > 0 ? registerMonths + " 个月" : registerDays >= 7 ? "不足一个月" : registerDays > 0 ? "不足一周" : "刚来不到一天");
      const registerDurationText = `${registerDuration}（${registerDays} 天）`;
      const actualRegisterDays = registerDate < new Date(2009, 6, 8) ? registerDays - 505 : registerDays;
      const daysSinceFanfouStart = Math.round((new Date - new Date(2007, 4, 12)) / 864e5);
      const registerDurationProgress = registerDays / daysSinceFanfouStart;
      const statusFrequency = actualRegisterDays < 1 ? userProfile.statuses_count : (userProfile.statuses_count / actualRegisterDays).toFixed(2);
      const statusFrequencyText = `平均 ${statusFrequency} 条消息 / 天`;
      const statusFrequencyProgress = statusFrequency / 50;
      let actionIndex = (40 * statusFrequency - statusFrequency ** 2) / 400;
      if (statusFrequency > 20) actionIndex = 1;
      if (isProtected) actionIndex *= .75;
      const influenceIndex = (10 * Math.sqrt(userProfile.followers_count) / Math.log(registerDays + 100) + (userProfile.followers_count / 100 + registerDays / 100) * actionIndex).toFixed(0);
      const influenceIndexText = influenceIndex + " 公里";
      const influenceIndexProgress = influenceIndex / 100;
      const backgroundImageUrl = userProfile.profile_background_image_url;
      const isBackgroundImageDisabled = "none" === getComputedStyle(document.body).backgroundImage;
      this.setState({
        isProtected,
        registerDateText,
        registerDurationText,
        registerDurationProgress,
        statusFrequencyText,
        statusFrequencyProgress,
        influenceIndexText,
        influenceIndexProgress,
        backgroundImageUrl: isBackgroundImageDisabled ? null : backgroundImageUrl
      });
    }
    render() {
      const {isProtected, registerDateText, registerDurationText, registerDurationProgress, statusFrequencyText, statusFrequencyProgress, influenceIndexText, influenceIndexProgress, backgroundImageUrl} = this.state;
      return Object(preact_module["g"])("div", {
        class: "stabs sf-sidebar-statistics"
      }, Object(preact_module["g"])("h2", null, "统计信息"), Object(preact_module["g"])("ul", null, Object(preact_module["g"])(_page_StatisticItem, {
        extraClassNames: classnames_default()({
          "sf-is-protected": isProtected
        }),
        text: "注册于 " + registerDateText
      }), Object(preact_module["g"])(_page_StatisticItem, {
        text: "饭龄：" + registerDurationText,
        tip: "注册时长",
        enableProgressBar: true,
        progress: registerDurationProgress,
        progressBarColor: "red"
      }), Object(preact_module["g"])(_page_StatisticItem, {
        text: "饭量：" + statusFrequencyText,
        tip: "消息频率",
        enableProgressBar: true,
        progress: statusFrequencyProgress,
        progressBarColor: "green"
      }), Object(preact_module["g"])(_page_StatisticItem, {
        text: "饭香：" + influenceIndexText,
        tip: "影响力",
        enableProgressBar: true,
        progress: influenceIndexProgress,
        progressBarColor: "blue"
      }), backgroundImageUrl && Object(preact_module["g"])(_page_StatisticItem, {
        text: "» 查看背景图片",
        url: backgroundImageUrl
      })));
    }
  }
  class _page_StatisticItem extends preact_module["a"] {
    render() {
      const {text, url, extraClassNames} = this.props;
      const classnames = classnames_default()("sf-sidebar-statistics-item", extraClassNames);
      return Object(preact_module["g"])("li", {
        className: classnames
      }, url ? Object(preact_module["g"])("a", {
        href: url
      }, text) : text, this.renderTip(), this.renderProgressBar());
    }
    renderTip() {
      const {tip} = this.props;
      const tooltipProps = {
        className: "sf-tip",
        content: tip,
        distance: 0
      };
      return tip && Object(preact_module["g"])(TooltipWithDefaultProps, tooltipProps, "?");
    }
    renderProgressBar() {
      const {enableProgressBar, progressBarColor, progress} = this.props;
      if (enableProgressBar) return Object(preact_module["g"])("div", {
        className: "sf-sidebar-statistics-progressbar sf-" + progressBarColor
      }, Object(preact_module["g"])("span", {
        style: {
          width: 100 * numberClamp(0, progress, 1) + "%"
        }
      }));
    }
  }
  var sidebar_statistics_page = context => {
    const {elementCollection} = context;
    let unmount;
    elementCollection.add({
      stabs: ".stabs"
    });
    return {
      applyWhen: () => isUserProfilePage(),
      waitReady: () => elementCollection.ready("stabs"),
      onLoad() {
        unmount = preactRender(Object(preact_module["g"])(_page_SidebarStatistics, null), rendered => {
          elementCollection.get("stabs").after(rendered);
        });
      },
      onUnload() {
        unmount();
      }
    };
  };
  function dist_n(e) {
    return (dist_n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n) {
      return typeof n;
    } : function(n) {
      return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
    })(e);
  }
  var dist_e = function(n) {
    return void 0 === n;
  }, dist_t = function(n) {
    return Array.isArray(n);
  }, dist_o = function(n) {
    return n && "number" == typeof n.size && "string" == typeof n.type && "function" == typeof n.slice;
  };
  function dist_r(i, s, f, u) {
    if ((s = s || {}).indices = !dist_e(s.indices) && s.indices, s.booleansAsIntegers = !dist_e(s.booleansAsIntegers) && s.booleansAsIntegers, 
    s.nullsAsUndefineds = !dist_e(s.nullsAsUndefineds) && s.nullsAsUndefineds, f = f || new FormData, 
    dist_e(i)) return f;
    if (null === i) s.nullsAsUndefineds || f.append(u, ""); else if (dist_t(i)) if (i.length) i.forEach((function(n, e) {
      var t = u + "[" + (s.indices ? e : "") + "]";
      dist_r(n, s, f, t);
    })); else {
      var l = u + "[]";
      f.append(l, "");
    } else !function(n) {
      return n instanceof Date;
    }(i) ? !function(n) {
      return "boolean" == typeof n;
    }(i) ? !function(n) {
      return n === Object(n);
    }(i) || function(e) {
      return dist_o(e) && "string" == typeof e.name && ("object" === dist_n(e.lastModifiedDate) || "number" == typeof e.lastModified);
    }(i) || dist_o(i) ? f.append(u, i) : Object.keys(i).forEach((function(n) {
      var e = i[n];
      if (dist_t(e)) for (;n.length > 2 && n.lastIndexOf("[]") === n.length - 2; ) n = n.substring(0, n.length - 2);
      dist_r(e, s, f, u ? u + "[" + n + "]" : n);
    })) : s.booleansAsIntegers ? f.append(u, i ? 1 : 0) : f.append(u, i) : f.append(u, i.toISOString());
    return f;
  }
  var safe_json_parse_callback = __webpack_require__(60);
  var callback_default = __webpack_require__.n(safe_json_parse_callback);
  var collectionFlush = flush;
  function flush(collection) {
    var result, len, i;
    if (!collection) return;
    if (Array.isArray(collection)) {
      result = [];
      len = collection.length;
      for (i = 0; i < len; i++) {
        var elem = collection[i];
        if (null != elem) result.push(elem);
      }
      return result;
    }
    if ("object" == typeof collection) {
      result = {};
      var keys = Object.keys(collection);
      len = keys.length;
      for (i = 0; i < len; i++) {
        var key = keys[i];
        var value = collection[key];
        if (null != value) result[key] = value;
      }
      return result;
    }
    return;
  }
  const API_URL_PLAIN_MESSAGE = "/home";
  const API_URL_UPLOAD_IMAGE = "/home/upload";
  const API_ACTION_PLAIN_MESSAGE = "msg.post";
  const API_ACTION_UPLOAD_IMAGE = "photo.upload";
  const URL_FANFOU_M_HOME = window.location.protocol + "//m.fanfou.com/home";
  const ERROR_FAILED_REFRESHING_TOKEN = new Error("刷新 token 失败");
  var ajax_form_page = context => {
    const {requireModules, registerDOMEventListener, elementCollection} = context;
    const {notification, scrollManager, checkMyNewStatus, proxiedFetch} = requireModules([ "notification", "scrollManager", "checkMyNewStatus", "proxiedFetch" ]);
    let isSubmitting = false;
    elementCollection.add({
      form: "#phupdate form",
      loading: "#phupdate .loading",
      textarea: "#phupdate textarea",
      uploadCloseHandle: "#phupdate .upload-close-handle",
      submitButton: '#phupdate input[type="submit"]',
      popupBox: "#PopupBox"
    });
    registerDOMEventListener("form", "submit", onFormSubmit);
    registerDOMEventListener("textarea", "input", onTextareaChange);
    registerDOMEventListener("textarea", "change", onTextareaChange);
    registerDOMEventListener("textarea", "keyup", onTextareaKeyup);
    function toggleState(state) {
      const {loading, textarea, submitButton} = elementCollection.getAll();
      if (isSubmitting = state) {
        loading.style.visibility = "visible";
        textarea.disabled = true;
        submitButton.disabled = true;
      } else {
        loading.style.visibility = "hidden";
        textarea.disabled = false;
        submitButton.disabled = false;
      }
    }
    function resetReplyAndRepost() {
      const {form, popupBox} = elementCollection.getAll();
      form.elements.in_reply_to_status_id.value = "";
      form.elements.repost_status_id.value = "";
      popupBox.style.display = "none";
    }
    function resetForm() {
      const {textarea, uploadCloseHandle, submitButton} = elementCollection.getAll();
      textarea.value = "";
      compat_trigger_event_default()(textarea, "change");
      uploadCloseHandle.click();
      submitButton.value = "发送";
    }
    async function refreshToken() {
      var _select;
      const {error: ajaxError, responseText: html} = await proxiedFetch.get({
        url: URL_FANFOU_M_HOME
      });
      if (ajaxError) throw ERROR_FAILED_REFRESHING_TOKEN;
      const document = Object(parseHTML["a"])(html);
      const token = null === (_select = Object(select_dom["a"])('input[name="token"]', document)) || void 0 === _select ? void 0 : _select.value;
      if (!token) throw ERROR_FAILED_REFRESHING_TOKEN;
      elementCollection.get("form").elements.token.value = token;
    }
    function extractFormData() {
      var _form$elements$conten, _form$elements$desc, _form$elements$locati;
      const form = elementCollection.get("form");
      let formDataJson = {
        ajax: "yes",
        token: form.elements.token.value,
        action: form.elements.action.value,
        content: null === (_form$elements$conten = form.elements.content) || void 0 === _form$elements$conten ? void 0 : _form$elements$conten.value,
        desc: null === (_form$elements$desc = form.elements.desc) || void 0 === _form$elements$desc ? void 0 : _form$elements$desc.value,
        photo_base64: form.elements.photo_base64.value,
        picture: form.elements.picture.files[0],
        in_reply_to_status_id: form.elements.in_reply_to_status_id.value,
        repost_status_id: form.elements.repost_status_id.value,
        location: null === (_form$elements$locati = form.elements.location) || void 0 === _form$elements$locati ? void 0 : _form$elements$locati.value
      };
      const isImageAttached = !!(formDataJson.photo_base64 || formDataJson.picture);
      if (!isImageAttached && formDataJson.action === API_ACTION_UPLOAD_IMAGE) {
        formDataJson.action = API_ACTION_PLAIN_MESSAGE;
        formDataJson.content = formDataJson.desc;
      }
      if (isImageAttached) delete formDataJson.content; else {
        delete formDataJson.desc;
        delete formDataJson.photo_base64;
        delete formDataJson.picture;
      }
      formDataJson = collectionFlush(formDataJson);
      return {
        isImageAttached,
        formDataJson
      };
    }
    function performAjaxRequest(url, formDataJson, isImageAttached, onUploadProgress) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest;
        const formData = dist_r(formDataJson);
        xhr.open("POST", url, true);
        xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        xhr.onload = () => callback_default()(xhr.responseText, (error, json) => {
          if (error) reject(); else resolve(json);
        });
        xhr.onerror = () => reject();
        isImageAttached && (xhr.upload.onprogress = onUploadProgress);
        xhr.send(formData);
      });
    }
    function triggerSuccessEvent(formDataJson) {
      const event = new CustomEvent(constants["POST_STATUS_SUCCESS_EVENT_TYPE"], {
        detail: {
          formDataJson
        }
      });
      elementCollection.get("textarea").dispatchEvent(event);
    }
    async function postMessage() {
      if (isSubmitting) return;
      toggleState(true);
      await refreshToken();
      const {isImageAttached, formDataJson} = extractFormData();
      const url = isImageAttached ? API_URL_UPLOAD_IMAGE : API_URL_PLAIN_MESSAGE;
      const startTime = Date.now();
      let response;
      let isSuccess;
      try {
        var _response;
        response = await performAjaxRequest(url, formDataJson, isImageAttached, event => {
          if (!event.lengthComputable) return;
          if (event.total < 51200) return;
          const progress = event.loaded / event.total;
          const percent = Math.round(100 * progress) + "%";
          elementCollection.get("submitButton").value = percent;
        });
        isSuccess = !!(null !== (_response = response) && void 0 !== _response && _response.status);
      } catch (error) {
        isSuccess = false;
      }
      toggleState(false);
      if (isSuccess) {
        var _response2;
        notification.create(notification.INFO, (null === (_response2 = response) || void 0 === _response2 ? void 0 : _response2.msg) || (isImageAttached ? "图片上传成功！" : "发送成功！"));
        resetForm();
        triggerSuccessEvent(formDataJson);
      } else {
        var _response3;
        notification.create(notification.ERROR, (null === (_response3 = response) || void 0 === _response3 ? void 0 : _response3.msg) || (isImageAttached ? "图片上传失败" : "发送失败"));
      }
      if (!isSuccess || !scrollManager.getScrollTop()) elementCollection.get("textarea").focus();
      if (isSuccess && isHomePage()) checkMyNewStatus.check(startTime);
    }
    function onFormSubmit(event) {
      event.preventDefault();
      postMessage();
    }
    function onTextareaChange() {
      if ("" === elementCollection.get("textarea").value) resetReplyAndRepost();
    }
    function onTextareaKeyup(event) {
      if (isHotkey(event, {
        ctrl: true,
        key: "Enter"
      })) {
        event.preventDefault();
        postMessage();
      }
    }
    return {
      applyWhen: () => elementCollection.ready("form")
    };
  };
  var autofocus_textarea_page = context => {
    const {requireModules, elementCollection} = context;
    const {statusFormIntersectionObserver} = requireModules([ "statusFormIntersectionObserver" ]);
    elementCollection.add({
      textarea: "#phupdate textarea"
    });
    function intersectionObserverCallback(isIntersected) {
      if (isIntersected) elementCollection.get("textarea").focus(); else if (isEmpty()) elementCollection.get("textarea").blur();
    }
    function isEmpty() {
      return "" === elementCollection.get("textarea").value;
    }
    return {
      applyWhen: () => elementCollection.ready("textarea"),
      onLoad() {
        statusFormIntersectionObserver.addListener(intersectionObserverCallback);
      },
      onUnload() {
        statusFormIntersectionObserver.removeListener(intersectionObserverCallback);
      }
    };
  };
  var download = "<EXTENSION_ORIGIN_PLACEHOLDER>/assets/images/download.svg";
  const CLASSNAME_SHOW_TIP = "sf-show-dnd-upload-tip";
  var fix_dnd_upload_page = context => {
    const {registerDOMEventListener, elementCollection} = context;
    let tip;
    let n = 0;
    elementCollection.add({
      update: "#phupdate",
      message: "#message",
      textareaWrapper: {
        parent: "update",
        selector: ".textarea-wrapper"
      },
      action: {
        parent: "update",
        selector: "input[name=action]"
      },
      textarea: {
        parent: "update",
        selector: "textarea"
      },
      uploadFilename: "#upload-filename",
      uploadWrapper: "#upload-wrapper",
      updateBase64: "#upload-base64",
      act: {
        parent: "update",
        selector: ".act"
      }
    });
    registerDOMEventListener(window, "dragenter", onDragEnter);
    registerDOMEventListener(window, "dragover", onDragOver);
    registerDOMEventListener(window, "dragleave", onDragLeave);
    registerDOMEventListener(window, "drop", onDrop);
    function createTip() {
      tip = Object(dom_chef["h"])("div", {
        id: "sf-dnd-upload-tip"
      }, Object(dom_chef["h"])("img", {
        src: replaceExtensionOrigin(download)
      }), "拖放图片到这里");
      elementCollection.get("textareaWrapper").append(tip);
    }
    function removeTip() {
      tip.remove();
      tip = null;
    }
    const expandTextarea = Object(index_esm["a"])(() => {
      const {act, textarea} = elementCollection.getAll();
      act.style.display = "block";
      textarea.style.height = "4.6em";
    });
    function isDraggingFiles(event) {
      return Array.from(event.dataTransfer.items).some(item => "file" === item.kind);
    }
    function isDraggingImages(event) {
      return Array.from(event.dataTransfer.items).some(item => item.type.startsWith("image/"));
    }
    function setDropEffect(event) {
      event.dataTransfer.dropEffect = isDraggingImages(event) ? "copy" : "none";
    }
    function onDragEnter(event) {
      if (!isDraggingFiles(event)) return;
      event.preventDefault();
      setDropEffect(event);
      if (isDraggingImages(event) && 0 === n++) {
        expandTextarea();
        document.body.classList.add(CLASSNAME_SHOW_TIP);
        elementCollection.get("textarea").blur();
      }
    }
    function onDragOver(event) {
      if (isDraggingFiles(event)) {
        event.preventDefault();
        setDropEffect(event);
      }
    }
    function onDragLeave(event) {
      if (isDraggingImages(event) && 0 === --n) document.body.classList.remove(CLASSNAME_SHOW_TIP);
    }
    function onDrop(event) {
      if (!isDraggingImages(event)) return;
      event.preventDefault();
      document.body.classList.remove(CLASSNAME_SHOW_TIP);
      n = 0;
      const {update} = elementCollection.getAll();
      if (update.contains(event.target)) {
        const file = event.dataTransfer.files[0];
        processForm(file);
      }
    }
    async function processForm(file) {
      const {message, action, textarea, uploadFilename, updateBase64} = elementCollection.getAll();
      message.setAttribute("action", "/home/upload");
      message.setAttribute("enctype", "multipart/form-data");
      action.value = "photo.upload";
      textarea.setAttribute("name", "desc");
      textarea.focus();
      uploadFilename.textContent = file.name;
      updateBase64.value = await blobToBase64(file);
    }
    return {
      applyWhen: () => elementCollection.ready("uploadWrapper"),
      onLoad() {
        createTip();
      },
      onUnload() {
        removeTip();
      }
    };
  };
  var string_width = __webpack_require__(45);
  var string_width_default = __webpack_require__.n(string_width);
  var parseFilename = filename => {
    const index = filename.lastIndexOf(".");
    let basename, extname;
    if (-1 === index) {
      basename = filename;
      extname = "";
    } else {
      basename = filename.slice(0, index);
      extname = filename.slice(index);
    }
    return {
      basename,
      extname
    };
  };
  const FILENAME_ELLIPSIS = "...";
  var truncateFilename = (filename, toWidth) => {
    const originalWidth = string_width_default()(filename);
    if (originalWidth <= toWidth) return filename;
    const {basename, extname} = parseFilename(filename);
    const splitBasename = basename.split("");
    let head = "", tail = extname;
    let ticktock = 1;
    while (string_width_default()(head + FILENAME_ELLIPSIS + tail) < toWidth) {
      if (ticktock) head += splitBasename.shift(); else tail = splitBasename.pop() + tail;
      ticktock = (ticktock + 1) % 2;
    }
    return head + FILENAME_ELLIPSIS + tail;
  };
  const CLASSNAME_IMAGE_ATTACHED = "sf-image-attached";
  var fix_upload_images_page = context => {
    const {registerDOMEventListener, elementCollection} = context;
    let base64MutationObserver;
    let filenameMutationObserver;
    elementCollection.add({
      uploadWrapper: "#upload-wrapper",
      uploadButton: "#upload-button",
      uploadFile: "#upload-file",
      uploadBase64: "#upload-base64",
      uploadFilename: "#upload-filename",
      closeHandle: ".upload-close-handle"
    });
    registerDOMEventListener("uploadFile", "change", onFileChange);
    registerDOMEventListener("closeHandle", "click", onClickClose);
    function base64MutationObserverCallback() {
      const isImageAttached = elementCollection.get("uploadBase64").value.length > 0;
      toggleImageAttachedState(isImageAttached);
    }
    function filenameMutationObserverCallback() {
      const {uploadFilename} = elementCollection.getAll();
      uploadFilename.textContent = truncateFilename(uploadFilename.textContent, 28);
    }
    function onFileChange() {
      const isImageAttached = elementCollection.get("uploadFile").files.length > 0;
      toggleImageAttachedState(isImageAttached);
    }
    function onClickClose() {
      toggleImageAttachedState(false);
    }
    function toggleImageAttachedState(isImageAttached) {
      const {uploadButton, uploadFilename, closeHandle} = elementCollection.getAll();
      uploadButton.classList.toggle(CLASSNAME_IMAGE_ATTACHED, isImageAttached);
      uploadFilename.style.display = isImageAttached ? "inline" : "none";
      closeHandle.style.display = isImageAttached ? "inline" : "none";
    }
    return {
      applyWhen: () => elementCollection.ready("uploadWrapper"),
      onLoad() {
        base64MutationObserver = new MutationObserver(base64MutationObserverCallback);
        base64MutationObserver.observe(elementCollection.get("uploadBase64"), {
          attributes: true,
          attributeFilter: [ "value" ]
        });
        filenameMutationObserver = new MutationObserver(filenameMutationObserverCallback);
        filenameMutationObserver.observe(elementCollection.get("uploadFilename"), {
          childList: true
        });
      },
      onUnload() {
        base64MutationObserver.disconnect();
        base64MutationObserver = null;
        filenameMutationObserver.disconnect();
        filenameMutationObserver = null;
      }
    };
  };
  const elementDisplay = {};
  function getDefaultDisplay(nodeName) {
    if (!elementDisplay[nodeName]) {
      const element = document.createElement(nodeName);
      document.body.append(element);
      let display = getComputedStyle(element, "").getPropertyValue("display");
      element.remove();
      if ("none" === display) display = "block";
      elementDisplay[nodeName] = display;
    }
    return elementDisplay[nodeName];
  }
  function showElement(element) {
    if ("none" === element.style.display) element.style.display = "";
    if ("none" === getComputedStyle(element, "").getPropertyValue("display")) element.style.display = getDefaultDisplay(element.nodeName);
  }
  function isImage(type) {
    return /^image\/(jpe?g|png|gif|bmp)$/.test(type);
  }
  async function onPaste(event) {
    const items = Array.from(event.clipboardData.items);
    const files = items.map(item => item.getAsFile()).filter(x => x instanceof Blob);
    const imageBlob = files.find(file => isImage(file.type));
    if (!imageBlob) return;
    const imageType = imageBlob.type.replace("image/", "");
    const uploadFilename = Object(select_dom["a"])("#upload-filename");
    uploadFilename.textContent = "image-from-clipboard." + imageType;
    showElement(uploadFilename);
    const close = Object(select_dom["a"])("#ul_close");
    showElement(close);
    const message = Object(select_dom["a"])("#message");
    message.setAttribute("action", "/home/upload");
    message.setAttribute("enctype", "multipart/form-data");
    const actionField = Object(select_dom["a"])('#phupdate input[name="action"]');
    actionField.value = "photo.upload";
    const textarea = Object(select_dom["a"])("#phupdate textarea");
    textarea.setAttribute("name", "desc");
    const base64 = Object(select_dom["a"])("#upload-base64");
    base64.value = await blobToBase64(imageBlob);
    const uploadWrapper = Object(select_dom["a"])("#upload-wrapper");
    showElement(uploadWrapper);
  }
  var paste_image_from_clipboard_page = context => {
    const {elementCollection, registerDOMEventListener} = context;
    elementCollection.add({
      textarea: "#phupdate textarea"
    });
    registerDOMEventListener(window, "paste", onPaste);
    return {
      applyWhen: () => elementCollection.ready("textarea")
    };
  };
  var index_esm_arrayRemove = remove;
  function remove(arr1, arr2) {
    if (!Array.isArray(arr1) || !Array.isArray(arr2)) throw new Error("expected both arguments to be arrays");
    var result = [];
    var len = arr1.length;
    for (var i = 0; i < len; i++) {
      var elem = arr1[i];
      if (-1 == arr2.indexOf(elem)) result.push(elem);
    }
    return result;
  }
  const ATTRIBUTE_INTERNAL_ID = "sf-internal-id";
  var refresh_status_count_page = context => {
    const {requireModules, elementCollection} = context;
    const {timelineElementObserver, proxiedFetch} = requireModules([ "timelineElementObserver", "proxiedFetch" ]);
    let isInit;
    let internalIdGen = 0;
    elementCollection.add({
      count: "#user_stats li:nth-of-type(3) .count"
    });
    function getStatusInternalId(li) {
      return li.getAttribute(ATTRIBUTE_INTERNAL_ID) || function() {
        const internalId = String(internalIdGen++);
        li.setAttribute(ATTRIBUTE_INTERNAL_ID, internalId);
        return internalId;
      }();
    }
    function getStatusByInternalId(statusElements) {
      return internalId => statusElements.find(li => getStatusInternalId(li) === internalId);
    }
    function getStatusAuthorId(li) {
      return Object(select_dom["a"])(".author", li).pathname.slice(1);
    }
    function isLoggedInUserId(userId) {
      return userId === getLoggedInUserId();
    }
    function mutationObserverCallback(mutationRecords) {
      for (const {addedNodes, removedNodes} of mutationRecords) {
        const removed = removedNodes.filter(isStatusElement).map(getStatusInternalId);
        const added = addedNodes.filter(isStatusElement).map(getStatusInternalId);
        const diff = [ ...index_esm_arrayRemove(added, removed).map(getStatusByInternalId(addedNodes)), ...index_esm_arrayRemove(removed, added).map(getStatusByInternalId(removedNodes)) ];
        const loggedInUserStatuses = diff.map(getStatusAuthorId).filter(isLoggedInUserId);
        if (isInit) {
          isInit = false;
          return;
        }
        if (loggedInUserStatuses.length) refreshStatusCount();
      }
    }
    async function refreshStatusCount() {
      const userId = getLoggedInUserId();
      const url = "https://m.fanfou.com/" + userId;
      const {error: ajaxError, responseText: html} = await proxiedFetch.get({
        url
      });
      if (ajaxError) return;
      const document = Object(parseHTML["a"])(html);
      const p = Object(select_dom["a"])("#nav", document).previousElementSibling;
      const re = /^消息\((\d+)\)$/;
      const link = Object(findElementWithSpecifiedContentInArray["a"])(select_dom["a"].all("a", p), re);
      const newCountNumber = link.textContent.match(re)[1];
      elementCollection.get("count").textContent = newCountNumber;
    }
    return {
      applyWhen: () => isHomePage(),
      onLoad() {
        isInit = true;
        timelineElementObserver.addCallback(mutationObserverCallback);
      },
      onUnload() {
        timelineElementObserver.removeCallback(mutationObserverCallback);
      }
    };
  };
  var revoke_event_listeners_page = context => {
    const {elementCollection} = context;
    let eventsBackup;
    elementCollection.add({
      form: {
        selector: "#phupdate form"
      },
      textarea: {
        selector: "#phupdate textarea"
      }
    });
    function backupEventListeners() {
      const {Event} = window.YAHOO.util;
      let formSubmit, textareaKeyup;
      Object(keepRetry["a"])({
        checker() {
          formSubmit = Event.getListeners(elementCollection.get("form"), "submit");
          textareaKeyup = Event.getListeners(elementCollection.get("textarea"), "keyup");
          return formSubmit && textareaKeyup;
        },
        executor() {
          eventsBackup = {
            formSubmit: formSubmit[0].fn,
            textareaKeyup: textareaKeyup[0].fn
          };
          Event.removeListener(elementCollection.get("form"), "submit", eventsBackup.formSubmit);
          Event.removeListener(elementCollection.get("textarea"), "keyup", eventsBackup.textareaKeyup);
        }
      });
    }
    function restoreEventListeners() {
      const {Event} = window.YAHOO.util;
      Event.addListener(elementCollection.get("form"), "submit", eventsBackup.formSubmit);
      Event.addListener(elementCollection.get("textarea"), "keyup", eventsBackup.textareaKeyup);
      eventsBackup = null;
    }
    return {
      applyWhen: () => Object(promiseEvery["a"])([ neg(isPrivateMessagePage()), elementCollection.ready("textarea") ]),
      waitReady: () => Object(requireFanfouLib["a"])("YAHOO"),
      onLoad() {
        backupEventListeners();
      },
      onUnload() {
        restoreEventListeners();
      }
    };
  };
  const MAX_STATUS_LENGTH = 140;
  const WARN_WHEN_LESS_THAN = 20;
  const CLASSNAME_STATUS_TEXTAREA_EMPTY = "sf-status-form-textarea-empty";
  const CLASSNAME_STATUS_TEXTAREA_FOCUSED = "sf-status-form-textarea-focused";
  const CLASSNAME_WARNING = "sf-warning";
  const CLASSNAME_EXCEEDED = "sf-exceeded";
  var textarea_state_page = context => {
    const {registerDOMEventListener, elementCollection} = context;
    let counter;
    elementCollection.add({
      update: "#phupdate",
      textarea: {
        parent: "update",
        selector: "textarea"
      },
      loading: {
        parent: "update",
        selector: ".act .actpost .loading"
      }
    });
    registerDOMEventListener("textarea", "focus", onFocusedStateChanged);
    registerDOMEventListener("textarea", "change", onChange);
    registerDOMEventListener("textarea", "input", onChange);
    registerDOMEventListener("textarea", "keydown", onKeyDown);
    registerDOMEventListener("textarea", "blur", onFocusedStateChanged);
    function onFocusedStateChanged() {
      const {update, textarea} = elementCollection.getAll();
      const isFocused = document.activeElement === textarea;
      update.classList.toggle(CLASSNAME_STATUS_TEXTAREA_FOCUSED, isFocused);
    }
    function onChange() {
      const {update, textarea} = elementCollection.getAll();
      const statusLength = textarea.value.length;
      const isEmpty = 0 === statusLength;
      const remaining = MAX_STATUS_LENGTH - statusLength;
      const hasExceeded = remaining < 0;
      const isDangerous = remaining <= WARN_WHEN_LESS_THAN && !hasExceeded;
      update.classList.toggle(CLASSNAME_STATUS_TEXTAREA_EMPTY, isEmpty);
      counter.textContent = MAX_STATUS_LENGTH - statusLength;
      counter.classList.toggle(CLASSNAME_WARNING, isDangerous);
      counter.classList.toggle(CLASSNAME_EXCEEDED, hasExceeded);
    }
    function onKeyDown(event) {
      const {textarea} = elementCollection.getAll();
      if (document.activeElement !== textarea) return;
      if (!isHotkey(event, {
        key: "Escape"
      })) return;
      textarea.blur();
    }
    function createCounter() {
      counter = document.createElement("span");
      counter.setAttribute("id", "sf-counter");
      elementCollection.get("loading").after(counter);
    }
    return {
      applyWhen: () => elementCollection.ready("update"),
      onLoad() {
        createCounter();
        onChange();
      },
      onUnload() {
        const update = elementCollection.get("update");
        update.classList.remove(CLASSNAME_STATUS_TEXTAREA_EMPTY);
        update.classList.remove(CLASSNAME_STATUS_TEXTAREA_FOCUSED);
        counter.remove();
        counter = null;
      }
    };
  };
  const INTERVAL_DURATION = 15e3;
  var update_timestamps_page = () => {
    let intervalId;
    function updateTimestamps() {
      const timeElements = select_dom["a"].all("#stream > ol > li > .stamp > .time");
      for (const element of timeElements) {
        const time = window.FF.util.parseDate(element.getAttribute("stime")) + window.FF.app.Timeline.srv_clk_minus_client;
        element.textContent = window.FF.util.getRelativeTime(time);
      }
    }
    return {
      applyWhen: () => element_ready_default()("#stream"),
      waitReady: () => Object(promiseEvery["a"])([ Object(requireFanfouLib["a"])("FF.util.parseDate"), Object(requireFanfouLib["a"])("FF.util.getRelativeTime"), Object(requireFanfouLib["a"])("FF.app.Timeline") ]),
      onLoad() {
        intervalId = setInterval(updateTimestamps, INTERVAL_DURATION);
        updateTimestamps();
      },
      onUnload() {
        clearInterval(intervalId);
        intervalId = null;
      }
    };
  };
  var login_form_page = context => {
    const {elementCollection} = context;
    let originalAutoLoginLabel;
    elementCollection.add({
      login: "#login",
      al: "#autologin"
    });
    return {
      applyWhen: () => isLoginPage(),
      waitReady: () => elementCollection.ready("login"),
      onLoad() {
        elementCollection.get("al").checked = true;
        originalAutoLoginLabel = elementCollection.get("al").nextSibling.textContent;
        elementCollection.get("al").nextSibling.textContent = " 保存到「多账户切换列表」";
      },
      onUnload() {
        elementCollection.get("al").nextSibling.textContent = originalAutoLoginLabel;
        originalAutoLoginLabel = null;
      }
    };
  };
  var omitBy = (object, predicate) => {
    const ret = {};
    for (const [k, v] of Object.entries(object)) if (!predicate(v, k)) ret[k] = v;
    return ret;
  };
  const user_switcher_page_STORAGE_KEY = "user-switcher/allUserData";
  const user_switcher_page_STORAGE_AREA_NAME = "local";
  const CLASSNAME_IS_READY = "sf-is-ready";
  var user_switcher_page = context => {
    const {requireModules, elementCollection} = context;
    const {storage} = requireModules([ "storage" ]);
    let unmountUserSwitcher;
    elementCollection.add({
      usertop: "#user_top"
    });
    class UserSwitcher extends preact_module["a"] {
      constructor(...args) {
        super(...args);
        this.loadData = async () => {
          this.setState({
            allUserData: await readAllUserData()
          });
          elementCollection.get("usertop").classList.add(CLASSNAME_IS_READY);
        };
        this.state = {
          allUserData: []
        };
        this.loadData();
      }
      componentWillUnmount() {
        elementCollection.get("usertop").classList.remove(CLASSNAME_IS_READY);
      }
      async switchToUser(userId) {
        await writeUserCookies(userId);
        redirectToHomePage();
      }
      async removeUser(userId) {
        const userData = await getUserData(userId);
        const tip = `确定要从用户列表中删除 @${userData.nickname}（${userId}）吗？`;
        if (window.confirm(tip)) {
          await removeUser(userId);
          await this.loadData();
        }
      }
      renderItem(userData) {
        const currentUserId = getLoggedInUserId();
        const {userId, avatarUrl, nickname} = userData;
        if (userId === currentUserId) return null;
        return Object(preact_module["g"])("li", {
          key: "user-" + userId,
          className: "sf-user-item"
        }, Object(preact_module["g"])("a", {
          class: "sf-user-info",
          onClick: () => this.switchToUser(userId)
        }, Object(preact_module["g"])("img", {
          src: avatarUrl,
          alt: nickname
        }), nickname), Object(preact_module["g"])("span", {
          class: "sf-del-icon",
          onClick: () => this.removeUser(userId)
        }, "×"));
      }
      renderAddNew() {
        return Object(preact_module["g"])("li", {
          key: "add-new",
          class: "sf-add-new-user"
        }, Object(preact_module["g"])("input", {
          type: "button",
          className: "formbutton",
          onClick: addNewUser,
          value: "登入另一个……"
        }));
      }
      render() {
        const {allUserData} = this.state;
        return Object(preact_module["g"])("ul", {
          id: "sf-user-switcher"
        }, allUserData.map(this.renderItem, this), this.renderAddNew());
      }
    }
    async function readAllUserData() {
      return await storage.read(user_switcher_page_STORAGE_KEY, user_switcher_page_STORAGE_AREA_NAME) || [];
    }
    async function writeAllUserData(data) {
      await storage.write(user_switcher_page_STORAGE_KEY, data, user_switcher_page_STORAGE_AREA_NAME);
    }
    async function getUserData(userId, allUserData_) {
      const allUserData = allUserData_ || await readAllUserData();
      const userData = allUserData.find(item => item.userId === userId);
      return userData;
    }
    async function writeUserCookies(userId) {
      const userData = await getUserData(userId);
      for (const [key, value] of Object.entries(userData.cookies)) js_cookie_default.a.set(key, value, {
        domain: ".fanfou.com",
        expires: 30
      });
    }
    async function addOrUpdateCurrentUser() {
      const loggedInUserId = getLoggedInUserId();
      const allCookies = js_cookie_default.a.get();
      const userData = {
        userId: loggedInUserId,
        nickname: Object(select_dom["a"])("#user_top h3").textContent,
        avatarUrl: Object(select_dom["a"])("#user_top img").src,
        cookies: omitBy(allCookies, (_, key) => key.startsWith("_") || "uuid" === key)
      };
      await updateUserData(loggedInUserId, userData);
    }
    async function removeUser(userId) {
      await updateUserData(userId, null);
    }
    async function removeCurrentUser() {
      await removeUser(getLoggedInUserId());
    }
    async function updateUserData(userId, userData) {
      const allUserData = await readAllUserData();
      const oldUserData = await getUserData(userId, allUserData);
      if (oldUserData) Object(arrayRemove["a"])(allUserData, oldUserData);
      if (userData) allUserData.unshift(userData);
      await writeAllUserData(allUserData);
    }
    function addNewUser() {
      removeSessionCookies();
      redirectToLoginPage();
    }
    function removeSessionCookies() {
      [ "u", "m", "al", "PHPSESSID" ].forEach(key => {
        js_cookie_default.a.remove(key, {
          domain: ".fanfou.com"
        });
      });
    }
    function redirectToLoginPage() {
      window.location.href = "/login";
    }
    function redirectToHomePage() {
      window.location.href = "/home";
    }
    function renderUserSwitcher() {
      unmountUserSwitcher = preactRender(Object(preact_module["g"])(UserSwitcher, null), rendered => {
        elementCollection.get("usertop").append(rendered);
      });
    }
    function getLogoutLink() {
      const navigationLinks = select_dom["a"].all("#navigation a");
      const logoutLink = Object(findElementWithSpecifiedContentInArray["a"])(navigationLinks, "退出");
      return logoutLink;
    }
    async function onLogoutClick() {
      const currentUserId = getLoggedInUserId();
      await removeUser(currentUserId);
    }
    function listenOnLogout() {
      const logoutLink = getLogoutLink();
      logoutLink.addEventListener("click", onLogoutClick);
    }
    function unlistenOnLogout() {
      const logoutLink = getLogoutLink();
      logoutLink.removeEventListener("click", onLogoutClick);
    }
    return {
      migrations: [ {
        migrationId: "user-switcher/ls-to-chrome-storage-api-and-object-to-array",
        storageAreaName: "local",
        async executor() {
          const oldData = readJSONFromLocalStorage("switcher");
          if (!oldData) return;
          const newData = [];
          for (const [userId, userData] of Object.entries(oldData)) newData.push({
            userId,
            avatarUrl: userData.image,
            ...just_pick_default()(userData, [ "nickname", "cookies" ])
          });
          await writeAllUserData(newData);
        }
      } ],
      applyWhen: () => elementCollection.ready("usertop"),
      async onLoad() {
        if (js_cookie_default.a.get("al")) await addOrUpdateCurrentUser(); else await removeCurrentUser();
        renderUserSwitcher();
        listenOnLogout();
      },
      onUnload() {
        unmountUserSwitcher();
        unlistenOnLogout();
      }
    };
  };
  var batch_manage_relationships_friend_requests_page = __webpack_require__(61);
  var batch_manage_relationships_friends_and_followers_page = __webpack_require__(62);
  var features_batch_remove_private_messages_page = __webpack_require__(63);
  var features_batch_remove_statuses_page = __webpack_require__(64);
  var better_at_autocomplete_enable_new_one_page = __webpack_require__(65);
  var check_saved_searches_sidebar_indicators_page = __webpack_require__(66);
  var features_enrich_statuses_page = __webpack_require__(67);
  var favorite_fanfouers_home_page = __webpack_require__(68);
  var favorite_fanfouers_user_profile_page = __webpack_require__(69);
  var floating_status_form_floating_status_form_page = __webpack_require__(70);
  var floating_status_form_replay_and_repost_page = __webpack_require__(71);
  var features_go_top_button_page = __webpack_require__(72);
  var process_unread_statuses_scroll_to_show_page = __webpack_require__(73);
  var features_show_contextual_statuses_page = __webpack_require__(74);
  var features_sidebar_statistics_page = __webpack_require__(75);
  var status_form_enhancements_fix_dnd_upload_page = __webpack_require__(76);
  var misc_page = __webpack_require__(77);
  var user_switcher_user_switcher_page = __webpack_require__(78);
  const metadata_options = {
    _: {
      defaultValue: true,
      label: "随页面向下滚动自动加载更多消息"
    }
  };
  const batch_manage_relationships_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理关注的人"
    }
  };
  const batch_remove_private_messages_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理私信"
    }
  };
  const batch_remove_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "批量管理消息",
      comment: "按住 Shift 键可以批量选择"
    }
  };
  const metadata_isSoldered = true;
  const box_shadows_metadata_options = {
    _: {
      defaultValue: false,
      label: "在导航栏、主窗体等框架下显示阴影"
    }
  };
  const check_friendship_metadata_options = {
    _: {
      defaultValue: false,
      label: "在用户页面显示好友关系检查工具"
    }
  };
  const check_saved_searches_metadata_options = {
    _: {
      defaultValue: true,
      label: "自动检查关注的话题是否有新消息"
    },
    enableNotifications: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有新消息时显示桌面通知"
    }
  };
  const enrich_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "消息内容增强",
      comment: "自动展开短链接，为图片链接添加预览图等"
    }
  };
  const favorite_fanfouers_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许添加有爱饭友，并显示在首页侧栏上"
    }
  };
  const fix_photo_zoom_metadata_isSoldered = true;
  const floating_status_form_metadata_options = {
    _: {
      defaultValue: false,
      label: "使用跟随页面滚动的浮动输入框"
    },
    keepFocusAfterPosting: {
      defaultValue: false,
      label: "消息发出后将焦点保留在输入框"
    },
    keepAtNamesAfterPosting: {
      defaultValue: false,
      label: "消息发出后在输入框中保留所 @ 的人"
    }
  };
  const go_top_button_metadata_isSoldered = true;
  const google_analytics_metadata_isSoldered = true;
  const keyboard_shortcuts_metadata_isSoldered = true;
  const notifications_metadata_options = {
    _: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "启用 Chrome 桌面通知"
    },
    notifyUnreadMentions: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新 @ 提到我的通知"
    },
    notifyUnreadPrivateMessages: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新私信通知"
    },
    notifyNewFollowers: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示新关注者通知"
    },
    doNotDisturbWhenVisitingFanfou: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "当我浏览饭否页面时不要显示通知"
    },
    notifyUpdateDetails: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "太空饭否更新后通知显示更新内容"
    },
    playSound: {
      defaultValue: true,
      disableCloudSyncing: true,
      label: "显示通知时播放提示音"
    }
  };
  const process_unread_statuses_metadata_options = {
    _: {
      isSoldered: true,
      label: "时间线上出现新消息时进行处理"
    },
    playSound: {
      defaultValue: false,
      disableCloudSyncing: true,
      label: "有未读消息时播放提示音",
      comment: "饭否页面打开状态下"
    }
  };
  const remove_app_recommendations_metadata_options = {
    _: {
      defaultValue: false,
      label: "屏蔽「饭否应用」广告区和「随机应用推荐」"
    }
  };
  const remove_brackets_metadata_isSoldered = true;
  const remove_logo_beta_metadata_options = {
    _: {
      defaultValue: true,
      label: "去除 logo 的「测试版」字样"
    }
  };
  const remove_personalized_theme_metadata_options = {
    _: {
      defaultValue: false,
      label: "允许关闭用户的自定义模板",
      comment: "恢复到饭否初始样式"
    }
  };
  const retinafy_photos_metadata_isSoldered = true;
  const share_new_avatar_metadata_isSoldered = true;
  const share_to_fanfou_metadata_options = {
    _: {
      defaultValue: false,
      label: "添加「分享到饭否」到网页右键菜单"
    }
  };
  const show_contextual_statuses_metadata_options = {
    _: {
      defaultValue: true,
      label: "允许展开回复和转发的消息"
    },
    fetchStatusNumberPerClick: {
      defaultValue: 3,
      label: `每次展开 ${constants["CONTROL_PLACEHOLDER"]} 条消息`,
      controlOptions: {
        step: 1,
        min: 1,
        max: 7
      }
    },
    autoFetch: {
      defaultValue: false,
      label: "消息载入后自动展开 1 条消息"
    }
  };
  const sidebar_statistics_metadata_isSoldered = true;
  const status_form_enhancements_metadata_isSoldered = true;
  const translucent_sidebar_metadata_options = {
    _: {
      defaultValue: true,
      label: "半透明的侧栏"
    }
  };
  const update_timestamps_metadata_isSoldered = true;
  const user_switcher_metadata_isSoldered = true;
  var dot_prop = __webpack_require__(39);
  var dot_prop_default = __webpack_require__.n(dot_prop);
  function loadComponent(path, module) {
    const [, featureName, filename] = path.split("/");
    if ("metadata.js" === filename) return {
      featureName,
      type: "metadata",
      module
    };
    const {basename, extname} = parseFilename(filename);
    const atPos = basename.lastIndexOf("@");
    const subfeatureName = 0 === atPos ? "default" : basename.slice(0, atPos);
    if ([ ".less", ".css" ].includes(extname)) return {
      featureName,
      subfeatureName,
      type: "style",
      module: replaceExtensionOrigin(module)
    };
    if (".js" === extname) return {
      featureName,
      subfeatureName,
      type: "script",
      module: module.default
    };
  }
  function loadComponents() {
    const modules = {
      "./auto-pager/metadata.js": metadata_namespaceObject,
      "./batch-manage-relationships/metadata.js": batch_manage_relationships_metadata_namespaceObject,
      "./batch-remove-private-messages/metadata.js": batch_remove_private_messages_metadata_namespaceObject,
      "./batch-remove-statuses/metadata.js": batch_remove_statuses_metadata_namespaceObject,
      "./better-at-autocomplete/metadata.js": better_at_autocomplete_metadata_namespaceObject,
      "./box-shadows/metadata.js": box_shadows_metadata_namespaceObject,
      "./check-friendship/metadata.js": check_friendship_metadata_namespaceObject,
      "./check-saved-searches/metadata.js": check_saved_searches_metadata_namespaceObject,
      "./enrich-statuses/metadata.js": enrich_statuses_metadata_namespaceObject,
      "./favorite-fanfouers/metadata.js": favorite_fanfouers_metadata_namespaceObject,
      "./fix-photo-zoom/metadata.js": fix_photo_zoom_metadata_namespaceObject,
      "./floating-status-form/metadata.js": floating_status_form_metadata_namespaceObject,
      "./go-top-button/metadata.js": go_top_button_metadata_namespaceObject,
      "./google-analytics/metadata.js": google_analytics_metadata_namespaceObject,
      "./keyboard-shortcuts/metadata.js": keyboard_shortcuts_metadata_namespaceObject,
      "./notifications/metadata.js": notifications_metadata_namespaceObject,
      "./process-unread-statuses/metadata.js": process_unread_statuses_metadata_namespaceObject,
      "./remove-app-recommendations/metadata.js": remove_app_recommendations_metadata_namespaceObject,
      "./remove-brackets/metadata.js": remove_brackets_metadata_namespaceObject,
      "./remove-logo-beta/metadata.js": remove_logo_beta_metadata_namespaceObject,
      "./remove-personalized-theme/metadata.js": remove_personalized_theme_metadata_namespaceObject,
      "./retinafy-photos/metadata.js": retinafy_photos_metadata_namespaceObject,
      "./share-new-avatar/metadata.js": share_new_avatar_metadata_namespaceObject,
      "./share-to-fanfou/metadata.js": share_to_fanfou_metadata_namespaceObject,
      "./show-contextual-statuses/metadata.js": show_contextual_statuses_metadata_namespaceObject,
      "./sidebar-statistics/metadata.js": sidebar_statistics_metadata_namespaceObject,
      "./status-form-enhancements/metadata.js": status_form_enhancements_metadata_namespaceObject,
      "./translucent-sidebar/metadata.js": translucent_sidebar_metadata_namespaceObject,
      "./update-timestamps/metadata.js": update_timestamps_metadata_namespaceObject,
      "./user-switcher/metadata.js": user_switcher_metadata_namespaceObject,
      "./batch-manage-relationships/friend-requests@page.less": batch_manage_relationships_friend_requests_page,
      "./batch-manage-relationships/friends-and-followers@page.less": batch_manage_relationships_friends_and_followers_page,
      "./batch-remove-private-messages/@page.less": features_batch_remove_private_messages_page,
      "./batch-remove-statuses/@page.less": features_batch_remove_statuses_page,
      "./better-at-autocomplete/enable-new-one@page.less": better_at_autocomplete_enable_new_one_page,
      "./check-saved-searches/sidebar-indicators@page.less": check_saved_searches_sidebar_indicators_page,
      "./enrich-statuses/@page.less": features_enrich_statuses_page,
      "./favorite-fanfouers/home@page.less": favorite_fanfouers_home_page,
      "./favorite-fanfouers/user-profile@page.less": favorite_fanfouers_user_profile_page,
      "./floating-status-form/floating-status-form@page.less": floating_status_form_floating_status_form_page,
      "./floating-status-form/replay-and-repost@page.less": floating_status_form_replay_and_repost_page,
      "./go-top-button/@page.less": features_go_top_button_page,
      "./process-unread-statuses/scroll-to-show@page.less": process_unread_statuses_scroll_to_show_page,
      "./show-contextual-statuses/@page.less": features_show_contextual_statuses_page,
      "./sidebar-statistics/@page.less": features_sidebar_statistics_page,
      "./status-form-enhancements/fix-dnd-upload@page.less": status_form_enhancements_fix_dnd_upload_page,
      "./status-form-enhancements/misc@page.less": misc_page,
      "./user-switcher/user-switcher@page.less": user_switcher_user_switcher_page,
      "./auto-pager/@page.js": _page_namespaceObject,
      "./batch-manage-relationships/friend-requests@page.js": friend_requests_page_namespaceObject,
      "./batch-manage-relationships/friends-and-followers@page.js": friends_and_followers_page_namespaceObject,
      "./batch-remove-private-messages/@page.js": batch_remove_private_messages_page_namespaceObject,
      "./batch-remove-statuses/@page.js": batch_remove_statuses_page_namespaceObject,
      "./better-at-autocomplete/disable-old-one@page.js": disable_old_one_page_namespaceObject,
      "./better-at-autocomplete/enable-new-one@page.js": enable_new_one_page_namespaceObject,
      "./check-friendship/@page.js": check_friendship_page_namespaceObject,
      "./check-saved-searches/sidebar-indicators@page.js": sidebar_indicators_page_namespaceObject,
      "./enrich-statuses/@page.js": enrich_statuses_page_namespaceObject,
      "./favorite-fanfouers/home@page.js": home_page_namespaceObject,
      "./favorite-fanfouers/user-profile@page.js": user_profile_page_namespaceObject,
      "./fix-photo-zoom/@page.js": fix_photo_zoom_page_namespaceObject,
      "./floating-status-form/floating-status-form@page.js": floating_status_form_page_namespaceObject,
      "./floating-status-form/replay-and-repost@page.js": replay_and_repost_page_namespaceObject,
      "./go-top-button/@page.js": go_top_button_page_namespaceObject,
      "./keyboard-shortcuts/@page.js": keyboard_shortcuts_page_namespaceObject,
      "./process-unread-statuses/process-unread-statuses@page.js": process_unread_statuses_page_namespaceObject,
      "./process-unread-statuses/scroll-to-show@page.js": scroll_to_show_page_namespaceObject,
      "./retinafy-photos/photo-album@page.js": photo_album_page_namespaceObject,
      "./retinafy-photos/photo-entry@page.js": photo_entry_page_namespaceObject,
      "./retinafy-photos/status@page.js": status_page_namespaceObject,
      "./retinafy-photos/timeline@page.js": timeline_page_namespaceObject,
      "./share-new-avatar/@page.js": share_new_avatar_page_namespaceObject,
      "./show-contextual-statuses/@page.js": show_contextual_statuses_page_namespaceObject,
      "./show-contextual-statuses/fix-reply-and-repost@page.js": fix_reply_and_repost_page_namespaceObject,
      "./sidebar-statistics/@page.js": sidebar_statistics_page_namespaceObject,
      "./status-form-enhancements/ajax-form@page.js": ajax_form_page_namespaceObject,
      "./status-form-enhancements/autofocus-textarea@page.js": autofocus_textarea_page_namespaceObject,
      "./status-form-enhancements/fix-dnd-upload@page.js": fix_dnd_upload_page_namespaceObject,
      "./status-form-enhancements/fix-upload-images@page.js": fix_upload_images_page_namespaceObject,
      "./status-form-enhancements/paste-image-from-clipboard@page.js": paste_image_from_clipboard_page_namespaceObject,
      "./status-form-enhancements/refresh-status-count@page.js": refresh_status_count_page_namespaceObject,
      "./status-form-enhancements/revoke-event-listeners@page.js": revoke_event_listeners_page_namespaceObject,
      "./status-form-enhancements/textarea-state@page.js": textarea_state_page_namespaceObject,
      "./update-timestamps/@page.js": update_timestamps_page_namespaceObject,
      "./user-switcher/login-form@page.js": login_form_page_namespaceObject,
      "./user-switcher/user-switcher@page.js": user_switcher_page_namespaceObject
    };
    const components = Object.entries(modules).map(([path, module]) => loadComponent(path, module));
    return components;
  }
  function processOptionDef(featureName, optionName, rawOptionDef, isSubOption) {
    const {isSoldered = false, defaultValue, disableCloudSyncing = false} = rawOptionDef;
    const optionDef = {
      key: optionName,
      isSoldered,
      isSubOption,
      disableCloudSyncing,
      type: function() {
        if (isSoldered || "boolean" === typeof defaultValue) return "checkbox"; else if ("number" === typeof defaultValue) return "number"; else throw new Error("无法判断选项的类型，因为没有指定 `isSoldered` 或 `defaultValue`");
      }(),
      ...just_pick_default()(rawOptionDef, [ "label", "comment", "controlOptions" ])
    };
    if (isSubOption) optionDef.parentKey = featureName;
    return optionDef;
  }
  function processMetadata(featureName, metadata) {
    const isSoldered = !!metadata.isSoldered;
    const optionNames = [];
    const optionDefs = [];
    const defaultValues = {};
    const optionStorageAreaMap = {};
    if (!isSoldered) for (const [k, v] of Object.entries(metadata.options)) {
      const isSubOption = "_" !== k;
      const optionName = isSubOption ? `${featureName}/${k}` : featureName;
      const optionDef = processOptionDef(featureName, optionName, v, isSubOption);
      optionNames.push(optionName);
      optionDefs.push(optionDef);
      defaultValues[optionName] = v.isSoldered || v.defaultValue;
      optionStorageAreaMap[optionName] = v.disableCloudSyncing ? "local" : "sync";
    }
    return {
      isSoldered,
      optionNames,
      optionDefs,
      defaultValues,
      optionStorageAreaMap
    };
  }
  function loadFeatures() {
    const features = {};
    for (const {featureName, subfeatureName, type, module} of loadComponents()) if ("metadata" === type) dot_prop_default.a.set(features, featureName + ".metadata", processMetadata(featureName, module)); else dot_prop_default.a.set(features, `${featureName}.subfeatures.${subfeatureName}.${type}`, module);
    return features;
  }
  var src_features = loadFeatures();
  async function init({createEnvironment, modules, createFeatureClass, createSubfeatureClass}) {
    const environment = await createEnvironment();
    const Feature = createFeatureClass({
      ...environment,
      modules
    });
    const Subfeature = createSubfeatureClass({
      ...environment,
      modules
    });
    for (const [featureName, {metadata, subfeatures}] of Object.entries(src_features)) {
      if (!subfeatures) continue;
      const feature = new Feature({
        featureName,
        metadata
      });
      for (const [subfeatureName, {style, script}] of Object.entries(subfeatures)) {
        const subfeature = new Subfeature({
          featureName,
          subfeatureName,
          style,
          script,
          parent: feature
        });
        feature.addSubfeature(subfeature);
      }
      Object(safelyInvokeFn["a"])(feature.init.bind(feature));
    }
  }
  init(__webpack_require__(158));
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "createEnvironment", (function() {
    return createPageEnvironment;
  }));
  __webpack_require__.d(__webpack_exports__, "createFeatureClass", (function() {
    return createFeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "createSubfeatureClass", (function() {
    return createSubfeatureClass;
  }));
  __webpack_require__.d(__webpack_exports__, "modules", (function() {
    return page_modules["default"];
  }));
  var environment_bridge = __webpack_require__(9);
  var wrapper = __webpack_require__(8);
  var constants = __webpack_require__(3);
  const settings_settings = Object(wrapper["a"])({
    async install() {
      await environment_bridge["a"].ready();
    },
    readAll() {
      return environment_bridge["a"].postMessage({
        action: constants["SETTINGS_READ_ALL"]
      });
    }
  });
  var environment_settings = settings_settings;
  async function createPageEnvironment() {
    await environment_settings.ready();
    return {
      bridge: environment_bridge["a"],
      settings: environment_settings
    };
  }
  var just_pick = __webpack_require__(18);
  var just_pick_default = __webpack_require__.n(just_pick);
  var fast_deep_equal = __webpack_require__(79);
  var fast_deep_equal_default = __webpack_require__.n(fast_deep_equal);
  var safelyInvokeFn = __webpack_require__(20);
  var promise_queue = __webpack_require__(80);
  var promise_queue_default = __webpack_require__.n(promise_queue);
  __webpack_require__(37);
  var log = __webpack_require__(16);
  const STORAGE_KEY = "migrated";
  const MAX_CONCURRENT = 1;
  const MAX_QUEUE = 1 / 0;
  const queue = new promise_queue_default.a(MAX_CONCURRENT, MAX_QUEUE);
  var migrate = opts => queue.add(async () => {
    const {storage, storageAreaName, migrationId, executor} = opts;
    const migrated = await storage.read(STORAGE_KEY, storageAreaName) || [];
    if ("string" !== typeof storageAreaName) throw new TypeError("必须指定 storageAreaName");
    if ("string" !== typeof migrationId) throw new TypeError("必须指定 migrationId");
    if ("function" !== typeof executor) throw new TypeError("必须指定 executor");
    if (false) ;
    if (!migrated.includes(migrationId)) {
      try {
        await executor();
      } catch (error) {
        log["a"].error(error);
      }
      await storage.write(STORAGE_KEY, [ ...migrated, migrationId ], storageAreaName);
    }
  });
  var extensionUnloaded = __webpack_require__(30);
  var createFeatureClass = ({messaging, bridge, settings, modules}) => class {
    constructor({featureName, metadata}) {
      this.featureName = featureName;
      this.metadata = metadata;
      this.subfeatures = [];
      this.optionValuesCache = {};
      this.isLoaded = false;
    }
    get transport() {
      return messaging || bridge;
    }
    addSubfeature(subfeature) {
      this.subfeatures.push(subfeature);
    }
    async init() {
      await this.loadOptionValues();
      await this.migrate();
      if (this.metadata.isSoldered || await this.checkIfEnabled()) await this.load();
      this.listenOnSettingsChange();
      this.listenOnExtensionUnload();
    }
    async loadOptionValues() {
      const optionValues = await settings.readAll();
      this.optionValuesCache = just_pick_default()(optionValues, this.metadata.optionNames);
    }
    async migrate() {
      const {storage} = modules;
      for (const subfeature of this.subfeatures) {
        const {migrations = []} = subfeature;
        for (const migration of migrations) await migrate({
          storage,
          ...migration
        });
      }
    }
    checkIfEnabled() {
      return this.optionValuesCache[this.featureName];
    }
    load() {
      if (this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.load.bind(subfeature));
      this.isLoaded = true;
    }
    unload() {
      if (!this.isLoaded) return;
      for (const subfeature of this.subfeatures) Object(safelyInvokeFn["a"])(subfeature.unload.bind(subfeature));
      this.isLoaded = false;
    }
    listenOnSettingsChange() {
      this.transport.registerBroadcastListener(message => {
        if (message.action === constants["SETTINGS_CHANGED"]) this.handleSettingsChange();
      });
    }
    async handleSettingsChange() {
      const previousOptionValues = this.optionValuesCache;
      await this.loadOptionValues();
      const currentOptionValues = this.optionValuesCache;
      const previousEnabled = previousOptionValues[this.featureName];
      const currentEnabled = currentOptionValues[this.featureName];
      if (currentEnabled === previousEnabled) {
        if (!currentEnabled) return;
        if (fast_deep_equal_default()(previousOptionValues, currentOptionValues)) return;
        for (const subfeature of this.subfeatures) subfeature.handleSettingsChange();
      } else if (this.isLoaded) this.unload(); else this.load();
    }
    listenOnExtensionUnload() {
      extensionUnloaded["a"].addListener(this.handleExtensionUnload.bind(this));
    }
    handleExtensionUnload() {
      this.unload();
    }
  };
  var index_esm = __webpack_require__(10);
  var keepRetry = __webpack_require__(22);
  var waitForHead = Object(index_esm["a"])(() => Object(keepRetry["a"])({
    checker: () => document.head,
    delay: 0
  }));
  var loadAsset = __webpack_require__(36);
  var select_dom = __webpack_require__(0);
  var element_ready = __webpack_require__(6);
  var element_ready_default = __webpack_require__.n(element_ready);
  class ElementCollection_ElementCollection {
    constructor() {
      this._collection = {};
    }
    add(elements) {
      for (const [alias, elementOpts] of Object.entries(elements)) {
        let selector, parent, getAll;
        if ("string" === typeof elementOpts) {
          selector = elementOpts;
          getAll = false;
        } else {
          selector = elementOpts.selector;
          parent = elementOpts.parent;
          getAll = elementOpts.getAll;
        }
        if ("string" !== typeof selector) throw new TypeError("selector 未指定");
        this._collection[alias] = {
          selector,
          parent,
          getAll,
          element: null,
          promise: null
        };
      }
    }
    has(alias) {
      return {}.hasOwnProperty.call(this._collection, alias);
    }
    get(alias) {
      if (Array.isArray(alias)) {
        const ret = {};
        for (const item of alias) ret[item] = this.get(item);
        return ret;
      }
      const entry = this._collection[alias];
      if (!entry.element || entry.getAll && !entry.element.length) {
        const fn = entry.getAll ? select_dom["a"].all : select_dom["a"];
        const parent = entry.parent ? this.get(entry.parent) : document;
        entry.element = fn(entry.selector, parent);
      }
      return entry.element;
    }
    getAll() {
      const allAliases = Object.keys(this._collection);
      return this.get(allAliases);
    }
    getToken(alias) {
      return {
        isElementCollectionToken: true,
        collection: this,
        alias
      };
    }
    ready(alias) {
      const entry = this._collection[alias];
      if (entry.parent) throw new Error("不能设定 parent");
      if (!entry.promise) entry.promise = element_ready_default()(entry.selector);
      return entry.promise;
    }
    free() {
      for (const entry of Object.values(this._collection)) entry.element = entry.promise = null;
    }
  }
  var promiseEvery = __webpack_require__(7);
  var createSubfeatureClass = ({messaging, bridge, modules}) => class {
    constructor({featureName, subfeatureName, style, script, parent}) {
      var _this$script;
      this.requireModules = moduleNames => {
        const requiredModules = {};
        for (const moduleName of moduleNames) {
          const module = modules[moduleName];
          if (!module) throw new Error("未知 module：" + moduleName);
          this.waitReadyFns.push(module.ready);
          requiredModules[moduleName] = module;
        }
        return requiredModules;
      };
      this.registerDOMEventListener = (element, eventType, listener, opts = false) => {
        if (!element) log["a"].error("element 不存在"); else if ("string" === typeof element && !this.elementCollection.has(element)) log["a"].error("如果使用选择器，请通过 ElementCollection 注册：", element); else if ("string" !== typeof element && !element.addEventListener) log["a"].error("element 不存在或类型非法", element);
        this.domEventListeners = [ ...this.domEventListeners, {
          element,
          eventType,
          listener,
          opts
        } ];
      };
      this.readOptionValue = key => {
        const optionName = `${this.featureName}/${key}`;
        const optionValue = this.parent.optionValuesCache[optionName];
        return optionValue;
      };
      this.featureName = featureName;
      this.subfeatureName = subfeatureName;
      this.parent = parent;
      this.initContext();
      if (style) this.style = {
        element: null,
        code: style
      };
      if (script) {
        const featureScriptObj = script(this.context) || {};
        if (featureScriptObj.waitReady) this.waitReadyFns.push(featureScriptObj.waitReady);
        this.migrations = featureScriptObj.migrations;
        this.script = just_pick_default()(featureScriptObj, [ "applyWhen", "onLoad", "onSettingsChange", "onUnload" ]);
      }
      this.isApplicable = Object(index_esm["a"])((null === (_this$script = this.script) || void 0 === _this$script ? void 0 : _this$script.applyWhen) || (() => Promise.resolve(true)));
    }
    get transport() {
      return messaging || bridge;
    }
    initContext() {
      this.waitReadyFns = [];
      this.domEventListeners = [];
      this.elementCollection = new ElementCollection_ElementCollection;
      this.context = {
        ...just_pick_default()(this, [ "requireModules", "registerDOMEventListener", "elementCollection", "readOptionValue" ]),
        ...just_pick_default()(this.transport, [ "registerBroadcastListener", "unregisterBroadcastListener" ])
      };
    }
    async load() {
      if (!await this.isApplicable()) return;
      await this.loadStyle();
      await this.loadScript();
    }
    async unload() {
      if (!await this.isApplicable()) return;
      this.unloadStyle();
      this.unloadScript();
    }
    async loadStyle() {
      if (!this.style) return;
      await waitForHead();
      this.style.element = Object(loadAsset["a"])({
        type: "style",
        code: this.style.code,
        dataset: just_pick_default()(this, [ "featureName", "subfeatureName" ]),
        mount: loadAsset["c"]
      });
    }
    unloadStyle() {
      if (!this.style) return;
      this.style.element.remove();
      this.style.element = null;
    }
    async loadScript() {
      if (!this.script) return;
      if (await Object(promiseEvery["a"])(this.waitReadyFns.map(fn => fn()))) {
        var _this$script$onLoad, _this$script2;
        this.bindDOMEventListeners();
        await (null === (_this$script$onLoad = (_this$script2 = this.script).onLoad) || void 0 === _this$script$onLoad ? void 0 : _this$script$onLoad.call(_this$script2));
      } else log["a"].debug(`${this.featureName}[${this.subfeatureName}] 没有加载，因为 waitReady 检查未通过`);
    }
    async unloadScript() {
      var _this$script$onUnload, _this$script3;
      if (!this.script) return;
      this.unbindDOMEventListeners();
      await (null === (_this$script$onUnload = (_this$script3 = this.script).onUnload) || void 0 === _this$script$onUnload ? void 0 : _this$script$onUnload.call(_this$script3));
      this.elementCollection.free();
    }
    bindDOMEventListeners() {
      this.processDOMEventListeners("addEventListener");
    }
    unbindDOMEventListeners() {
      this.processDOMEventListeners("removeEventListener");
    }
    processDOMEventListeners(methodName) {
      for (const entry of this.domEventListeners) {
        const {element, eventType, listener, opts} = entry;
        if (!element) {
          log["a"].error("DOM 元素不存在", entry);
          continue;
        }
        const actualElement = "string" === typeof element ? this.elementCollection.get(element) : element;
        const actualElementArray = Array.isArray(actualElement) ? actualElement : [ actualElement ];
        for (const actualElement_ of actualElementArray) actualElement_[methodName](eventType, listener, opts);
      }
    }
    handleSettingsChange() {
      var _this$script$onSettin, _this$script4;
      null === (_this$script$onSettin = (_this$script4 = this.script).onSettingsChange) || void 0 === _this$script$onSettin ? void 0 : _this$script$onSettin.call(_this$script4);
    }
  };
  var page_modules = __webpack_require__(43);
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var select_dom = __webpack_require__(0);
  var dist = __webpack_require__(14);
  var requireFanfouLib = __webpack_require__(17);
  var keepRetry = __webpack_require__(22);
  var parseHTML = __webpack_require__(29);
  var asyncSingleton = fn => {
    let promise;
    return (...args) => {
      if (!promise) promise = fn(...args).finally(() => {
        promise = null;
      });
      return promise;
    };
  };
  var getLoggedInUserProfilePageUrl = __webpack_require__(25);
  const TIMEOUT_MS = 5e3;
  let timeDifference = 0;
  function processHtml(html) {
    const document = Object(parseHTML["a"])(html);
    const statusElements = Array.from(document.body.children);
    return statusElements;
  }
  async function fetchNewStatuses() {
    const {currentSinceId} = window.FF.app.Timeline;
    const json = await Object(dist["a"])("/hc?since_id=" + currentSinceId).get().json();
    const statusElements = processHtml(json.data.timeline || "");
    const serverTime = Date.parse(json.srv_clk);
    const clientTime = Date.now();
    timeDifference = serverTime ? clientTime - serverTime : 0;
    return statusElements;
  }
  function findTheStatusJustPosted(startTime, statusElements) {
    return statusElements.some(li => {
      const authorUrl = Object(select_dom["a"])(".author", li).href;
      if (authorUrl !== Object(getLoggedInUserProfilePageUrl["a"])()) return false;
      const statusTime = Date.parse(Object(select_dom["a"])(".time", li).getAttribute("stime")) + timeDifference;
      if (startTime > statusTime) return false;
      return true;
    });
  }
  const check = asyncSingleton((startTime = Date.now()) => Object(keepRetry["a"])({
    async checker() {
      const newStatuses = await fetchNewStatuses();
      const hasFoundMyStatuses = findTheStatusJustPosted(startTime, newStatuses);
      return hasFoundMyStatuses;
    },
    executor() {
      window.FF.app.Timeline.checkNew();
    },
    until() {
      const now = Date.now();
      const shouldCancel = now - startTime > TIMEOUT_MS;
      return shouldCancel;
    }
  }));
  __webpack_exports__["default"] = {
    ready: () => Object(requireFanfouLib["a"])("FF.app.Timeline"),
    check
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var wrapper = __webpack_require__(8);
  var Deferred = __webpack_require__(28);
  var safelyInvokeFns = __webpack_require__(23);
  var extensionUnloaded = __webpack_require__(30);
  var arrayUniquePush = __webpack_require__(15);
  var arrayRemove = __webpack_require__(13);
  var constants = __webpack_require__(3);
  let port;
  let id = 0;
  const deferreds = {};
  const broadcastListeners = [];
  function onMessage({type, senderId, message}) {
    if (type === constants["BROADCASTING_MESSAGE"]) messaging.broadcast(message); else if (null != senderId) {
      const d = deferreds[senderId];
      d.resolve(message);
      delete deferreds[senderId];
    }
  }
  function onDisconnect() {
    extensionUnloaded["a"].trigger();
  }
  const messaging = Object(wrapper["a"])({
    install() {
      port = chrome.runtime.connect();
      port.onMessage.addListener(onMessage);
      port.onDisconnect.addListener(onDisconnect);
    },
    uninstall() {
      port = null;
      broadcastListeners.length = 0;
    },
    registerBroadcastListener(fn) {
      Object(arrayUniquePush["a"])(broadcastListeners, fn);
    },
    unregisterBroadcastListener(fn) {
      Object(arrayRemove["a"])(broadcastListeners, fn);
    },
    broadcast(message) {
      Object(safelyInvokeFns["a"])({
        fns: broadcastListeners,
        args: [ message ]
      });
    },
    postMessage(message) {
      const senderId = id++;
      const d = deferreds[senderId] = new Deferred["a"];
      port.postMessage({
        senderId,
        message
      });
      return d.promise;
    }
  });
  var environment_messaging = messaging;
  __webpack_exports__["default"] = Object(wrapper["a"])({
    install() {
      return environment_messaging.ready();
    },
    async read(key, storageAreaName) {
      const {value} = await environment_messaging.postMessage({
        action: constants["STORAGE_READ"],
        payload: {
          storageAreaName,
          key
        }
      });
      return value;
    },
    async write(key, value, storageAreaName) {
      await environment_messaging.postMessage({
        action: constants["STORAGE_WRITE"],
        payload: {
          storageAreaName,
          key,
          value
        }
      });
    },
    async delete(key, storageAreaName) {
      await environment_messaging.postMessage({
        action: constants["STORAGE_DELETE"],
        payload: {
          storageAreaName,
          key
        }
      });
    }
  });
} ]);