(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ("undefined" !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: "Module"
    });
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && "object" === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value
    });
    if (2 & mode && "string" != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function() {
      return module["default"];
    } : function() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 27);
})([ function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return x;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return k;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return K;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return Q;
  }));
  __webpack_require__.d(__webpack_exports__, "e", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "f", (function() {
    return b;
  }));
  __webpack_require__.d(__webpack_exports__, "g", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "h", (function() {
    return J;
  }));
  __webpack_require__.d(__webpack_exports__, "i", (function() {
    return l;
  }));
  __webpack_require__.d(__webpack_exports__, "j", (function() {
    return G;
  }));
  __webpack_require__.d(__webpack_exports__, "k", (function() {
    return H;
  }));
  var n, l, u, i, r, o, e, f, c, s, a, h, p = {}, v = [], y = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, w = Array.isArray;
  function d(n, l) {
    for (var u in l) n[u] = l[u];
    return n;
  }
  function g(n) {
    n && n.parentNode && n.parentNode.removeChild(n);
  }
  function _(l, u, t) {
    var i, r, o, e = {};
    for (o in u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : e[o] = u[o];
    if (arguments.length > 2 && (e.children = arguments.length > 3 ? n.call(arguments, 2) : t), 
    "function" == typeof l && null != l.defaultProps) for (o in l.defaultProps) void 0 === e[o] && (e[o] = l.defaultProps[o]);
    return m(l, e, i, r, null);
  }
  function m(n, t, i, r, o) {
    var e = {
      type: n,
      props: t,
      key: i,
      ref: r,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __c: null,
      constructor: void 0,
      __v: null == o ? ++u : o,
      __i: -1,
      __u: 0
    };
    return null == o && null != l.vnode && l.vnode(e), e;
  }
  function b() {
    return {
      current: null
    };
  }
  function k(n) {
    return n.children;
  }
  function x(n, l) {
    this.props = n, this.context = l;
  }
  function S(n, l) {
    if (null == l) return n.__ ? S(n.__, n.__i + 1) : null;
    for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? S(n) : null;
  }
  function C(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
      for (n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) {
        n.__e = n.__c.base = u.__e;
        break;
      }
      return C(n);
    }
  }
  function M(n) {
    (!n.__d && (n.__d = !0) && i.push(n) && !$.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)($);
  }
  function $() {
    for (var n, u, t, r, o, f, c, s = 1; i.length; ) i.length > s && i.sort(e), n = i.shift(), 
    s = i.length, n.__d && (t = void 0, r = void 0, o = (r = (u = n).__v).__e, f = [], 
    c = [], u.__P && ((t = d({}, r)).__v = r.__v + 1, l.vnode && l.vnode(t), O(u.__P, t, r, u.__n, u.__P.namespaceURI, 32 & r.__u ? [ o ] : null, f, null == o ? S(r) : o, !!(32 & r.__u), c), 
    t.__v = r.__v, t.__.__k[t.__i] = t, N(f, t, c), r.__e = r.__ = null, t.__e != o && C(t)));
    $.__r = 0;
  }
  function I(n, l, u, t, i, r, o, e, f, c, s) {
    var a, h, y, w, d, g, _, m = t && t.__k || v, b = l.length;
    for (f = P(u, l, m, f, b), a = 0; a < b; a++) null != (y = u.__k[a]) && (h = -1 == y.__i ? p : m[y.__i] || p, 
    y.__i = a, g = O(n, y, h, i, r, o, e, f, c, s), w = y.__e, y.ref && h.ref != y.ref && (h.ref && B(h.ref, null, y), 
    s.push(y.ref, y.__c || w, y)), null == d && null != w && (d = w), (_ = !!(4 & y.__u)) || h.__k === y.__k ? f = A(y, f, n, _) : "function" == typeof y.type && void 0 !== g ? f = g : w && (f = w.nextSibling), 
    y.__u &= -7);
    return u.__e = d, f;
  }
  function P(n, l, u, t, i) {
    var r, o, e, f, c, s = u.length, a = s, h = 0;
    for (n.__k = new Array(i), r = 0; r < i; r++) null != (o = l[r]) && "boolean" != typeof o && "function" != typeof o ? (f = r + h, 
    (o = n.__k[r] = "string" == typeof o || "number" == typeof o || "bigint" == typeof o || o.constructor == String ? m(null, o, null, null, null) : w(o) ? m(k, {
      children: o
    }, null, null, null) : null == o.constructor && o.__b > 0 ? m(o.type, o.props, o.key, o.ref ? o.ref : null, o.__v) : o).__ = n, 
    o.__b = n.__b + 1, e = null, -1 != (c = o.__i = L(o, u, f, a)) && (a--, (e = u[c]) && (e.__u |= 2)), 
    null == e || null == e.__v ? (-1 == c && (i > s ? h-- : i < s && h++), "function" != typeof o.type && (o.__u |= 4)) : c != f && (c == f - 1 ? h-- : c == f + 1 ? h++ : (c > f ? h-- : h++, 
    o.__u |= 4))) : n.__k[r] = null;
    if (a) for (r = 0; r < s; r++) null != (e = u[r]) && 0 == (2 & e.__u) && (e.__e == t && (t = S(e)), 
    D(e, e));
    return t;
  }
  function A(n, l, u, t) {
    var i, r;
    if ("function" == typeof n.type) {
      for (i = n.__k, r = 0; i && r < i.length; r++) i[r] && (i[r].__ = n, l = A(i[r], l, u, t));
      return l;
    }
    n.__e != l && (t && (l && n.type && !l.parentNode && (l = S(n)), u.insertBefore(n.__e, l || null)), 
    l = n.__e);
    do {
      l = l && l.nextSibling;
    } while (null != l && 8 == l.nodeType);
    return l;
  }
  function H(n, l) {
    return l = l || [], null == n || "boolean" == typeof n || (w(n) ? n.some((function(n) {
      H(n, l);
    })) : l.push(n)), l;
  }
  function L(n, l, u, t) {
    var i, r, o, e = n.key, f = n.type, c = l[u], s = null != c && 0 == (2 & c.__u);
    if (null === c && null == n.key || s && e == c.key && f == c.type) return u;
    if (t > (s ? 1 : 0)) for (i = u - 1, r = u + 1; i >= 0 || r < l.length; ) if (null != (c = l[o = i >= 0 ? i-- : r++]) && 0 == (2 & c.__u) && e == c.key && f == c.type) return o;
    return -1;
  }
  function T(n, l, u) {
    "-" == l[0] ? n.setProperty(l, null == u ? "" : u) : n[l] = null == u ? "" : "number" != typeof u || y.test(l) ? u : u + "px";
  }
  function j(n, l, u, t, i) {
    var r, o;
    n: if ("style" == l) if ("string" == typeof u) n.style.cssText = u; else {
      if ("string" == typeof t && (n.style.cssText = t = ""), t) for (l in t) u && l in u || T(n.style, l, "");
      if (u) for (l in u) t && u[l] == t[l] || T(n.style, l, u[l]);
    } else if ("o" == l[0] && "n" == l[1]) r = l != (l = l.replace(f, "$1")), o = l.toLowerCase(), 
    l = o in n || "onFocusOut" == l || "onFocusIn" == l ? o.slice(2) : l.slice(2), n.l || (n.l = {}), 
    n.l[l + r] = u, u ? t ? u.u = t.u : (u.u = c, n.addEventListener(l, r ? a : s, r)) : n.removeEventListener(l, r ? a : s, r); else {
      if ("http://www.w3.org/2000/svg" == i) l = l.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s"); else if ("width" != l && "height" != l && "href" != l && "list" != l && "form" != l && "tabIndex" != l && "download" != l && "rowSpan" != l && "colSpan" != l && "role" != l && "popover" != l && l in n) try {
        n[l] = null == u ? "" : u;
        break n;
      } catch (n) {}
      "function" == typeof u || (null == u || !1 === u && "-" != l[4] ? n.removeAttribute(l) : n.setAttribute(l, "popover" == l && 1 == u ? "" : u));
    }
  }
  function F(n) {
    return function(u) {
      if (this.l) {
        var t = this.l[u.type + n];
        if (null == u.t) u.t = c++; else if (u.t < t.u) return;
        return t(l.event ? l.event(u) : u);
      }
    };
  }
  function O(n, u, t, i, r, o, e, f, c, s) {
    var a, h, p, v, y, _, m, b, S, C, M, $, P, A, H, L, T, j = u.type;
    if (null != u.constructor) return null;
    128 & t.__u && (c = !!(32 & t.__u), o = [ f = u.__e = t.__e ]), (a = l.__b) && a(u);
    n: if ("function" == typeof j) try {
      if (b = u.props, S = "prototype" in j && j.prototype.render, C = (a = j.contextType) && i[a.__c], 
      M = a ? C ? C.props.value : a.__ : i, t.__c ? m = (h = u.__c = t.__c).__ = h.__E : (S ? u.__c = h = new j(b, M) : (u.__c = h = new x(b, M), 
      h.constructor = j, h.render = E), C && C.sub(h), h.props = b, h.state || (h.state = {}), 
      h.context = M, h.__n = i, p = h.__d = !0, h.__h = [], h._sb = []), S && null == h.__s && (h.__s = h.state), 
      S && null != j.getDerivedStateFromProps && (h.__s == h.state && (h.__s = d({}, h.__s)), 
      d(h.__s, j.getDerivedStateFromProps(b, h.__s))), v = h.props, y = h.state, h.__v = u, 
      p) S && null == j.getDerivedStateFromProps && null != h.componentWillMount && h.componentWillMount(), 
      S && null != h.componentDidMount && h.__h.push(h.componentDidMount); else {
        if (S && null == j.getDerivedStateFromProps && b !== v && null != h.componentWillReceiveProps && h.componentWillReceiveProps(b, M), 
        !h.__e && null != h.shouldComponentUpdate && !1 === h.shouldComponentUpdate(b, h.__s, M) || u.__v == t.__v) {
          for (u.__v != t.__v && (h.props = b, h.state = h.__s, h.__d = !1), u.__e = t.__e, 
          u.__k = t.__k, u.__k.some((function(n) {
            n && (n.__ = u);
          })), $ = 0; $ < h._sb.length; $++) h.__h.push(h._sb[$]);
          h._sb = [], h.__h.length && e.push(h);
          break n;
        }
        null != h.componentWillUpdate && h.componentWillUpdate(b, h.__s, M), S && null != h.componentDidUpdate && h.__h.push((function() {
          h.componentDidUpdate(v, y, _);
        }));
      }
      if (h.context = M, h.props = b, h.__P = n, h.__e = !1, P = l.__r, A = 0, S) {
        for (h.state = h.__s, h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), 
        H = 0; H < h._sb.length; H++) h.__h.push(h._sb[H]);
        h._sb = [];
      } else do {
        h.__d = !1, P && P(u), a = h.render(h.props, h.state, h.context), h.state = h.__s;
      } while (h.__d && ++A < 25);
      h.state = h.__s, null != h.getChildContext && (i = d(d({}, i), h.getChildContext())), 
      S && !p && null != h.getSnapshotBeforeUpdate && (_ = h.getSnapshotBeforeUpdate(v, y)), 
      L = a, null != a && a.type === k && null == a.key && (L = V(a.props.children)), 
      f = I(n, w(L) ? L : [ L ], u, t, i, r, o, e, f, c, s), h.base = u.__e, u.__u &= -161, 
      h.__h.length && e.push(h), m && (h.__E = h.__ = null);
    } catch (n) {
      if (u.__v = null, c || null != o) if (n.then) {
        for (u.__u |= c ? 160 : 128; f && 8 == f.nodeType && f.nextSibling; ) f = f.nextSibling;
        o[o.indexOf(f)] = null, u.__e = f;
      } else {
        for (T = o.length; T--; ) g(o[T]);
        z(u);
      } else u.__e = t.__e, u.__k = t.__k, n.then || z(u);
      l.__e(n, u, t);
    } else null == o && u.__v == t.__v ? (u.__k = t.__k, u.__e = t.__e) : f = u.__e = q(t.__e, u, t, i, r, o, e, c, s);
    return (a = l.diffed) && a(u), 128 & u.__u ? void 0 : f;
  }
  function z(n) {
    n && n.__c && (n.__c.__e = !0), n && n.__k && n.__k.forEach(z);
  }
  function N(n, u, t) {
    for (var i = 0; i < t.length; i++) B(t[i], t[++i], t[++i]);
    l.__c && l.__c(u, n), n.some((function(u) {
      try {
        n = u.__h, u.__h = [], n.some((function(n) {
          n.call(u);
        }));
      } catch (n) {
        l.__e(n, u.__v);
      }
    }));
  }
  function V(n) {
    return "object" != typeof n || null == n || n.__b && n.__b > 0 ? n : w(n) ? n.map(V) : d({}, n);
  }
  function q(u, t, i, r, o, e, f, c, s) {
    var a, h, v, y, d, _, m, b = i.props, k = t.props, x = t.type;
    if ("svg" == x ? o = "http://www.w3.org/2000/svg" : "math" == x ? o = "http://www.w3.org/1998/Math/MathML" : o || (o = "http://www.w3.org/1999/xhtml"), 
    null != e) for (a = 0; a < e.length; a++) if ((d = e[a]) && "setAttribute" in d == !!x && (x ? d.localName == x : 3 == d.nodeType)) {
      u = d, e[a] = null;
      break;
    }
    if (null == u) {
      if (null == x) return document.createTextNode(k);
      u = document.createElementNS(o, x, k.is && k), c && (l.__m && l.__m(t, e), c = !1), 
      e = null;
    }
    if (null == x) b === k || c && u.data == k || (u.data = k); else {
      if (e = e && n.call(u.childNodes), b = i.props || p, !c && null != e) for (b = {}, 
      a = 0; a < u.attributes.length; a++) b[(d = u.attributes[a]).name] = d.value;
      for (a in b) if (d = b[a], "children" == a) ; else if ("dangerouslySetInnerHTML" == a) v = d; else if (!(a in k)) {
        if ("value" == a && "defaultValue" in k || "checked" == a && "defaultChecked" in k) continue;
        j(u, a, null, d, o);
      }
      for (a in k) d = k[a], "children" == a ? y = d : "dangerouslySetInnerHTML" == a ? h = d : "value" == a ? _ = d : "checked" == a ? m = d : c && "function" != typeof d || b[a] === d || j(u, a, d, b[a], o);
      if (h) c || v && (h.__html == v.__html || h.__html == u.innerHTML) || (u.innerHTML = h.__html), 
      t.__k = []; else if (v && (u.innerHTML = ""), I("template" == t.type ? u.content : u, w(y) ? y : [ y ], t, i, r, "foreignObject" == x ? "http://www.w3.org/1999/xhtml" : o, e, f, e ? e[0] : i.__k && S(i, 0), c, s), 
      null != e) for (a = e.length; a--; ) g(e[a]);
      c || (a = "value", "progress" == x && null == _ ? u.removeAttribute("value") : null != _ && (_ !== u[a] || "progress" == x && !_ || "option" == x && _ != b[a]) && j(u, a, _, b[a], o), 
      a = "checked", null != m && m != u[a] && j(u, a, m, b[a], o));
    }
    return u;
  }
  function B(n, u, t) {
    try {
      if ("function" == typeof n) {
        var i = "function" == typeof n.__u;
        i && n.__u(), i && null == u || (n.__u = n(u));
      } else n.current = u;
    } catch (n) {
      l.__e(n, t);
    }
  }
  function D(n, u, t) {
    var i, r;
    if (l.unmount && l.unmount(n), (i = n.ref) && (i.current && i.current != n.__e || B(i, null, u)), 
    null != (i = n.__c)) {
      if (i.componentWillUnmount) try {
        i.componentWillUnmount();
      } catch (n) {
        l.__e(n, u);
      }
      i.base = i.__P = null;
    }
    if (i = n.__k) for (r = 0; r < i.length; r++) i[r] && D(i[r], u, t || "function" != typeof n.type);
    t || g(n.__e), n.__c = n.__ = n.__e = void 0;
  }
  function E(n, l, u) {
    return this.constructor(n, u);
  }
  function G(u, t, i) {
    var r, o, e, f;
    t == document && (t = document.documentElement), l.__ && l.__(u, t), o = (r = "function" == typeof i) ? null : i && i.__k || t.__k, 
    e = [], f = [], O(t, u = (!r && i || t).__k = _(k, null, [ u ]), o || p, p, t.namespaceURI, !r && i ? [ i ] : o ? null : t.firstChild ? n.call(t.childNodes) : null, e, !r && i ? i : o ? o.__e : t.firstChild, r, f), 
    N(e, u, f);
  }
  function J(n, l) {
    G(n, l, J);
  }
  function K(l, u, t) {
    var i, r, o, e, f = d({}, l.props);
    for (o in l.type && l.type.defaultProps && (e = l.type.defaultProps), u) "key" == o ? i = u[o] : "ref" == o ? r = u[o] : f[o] = void 0 === u[o] && null != e ? e[o] : u[o];
    return arguments.length > 2 && (f.children = arguments.length > 3 ? n.call(arguments, 2) : t), 
    m(l.type, f, i || l.key, r || l.ref, null);
  }
  function Q(n) {
    function l(n) {
      var u, t;
      return this.getChildContext || (u = new Set, (t = {})[l.__c] = this, this.getChildContext = function() {
        return t;
      }, this.componentWillUnmount = function() {
        u = null;
      }, this.shouldComponentUpdate = function(n) {
        this.props.value != n.value && u.forEach((function(n) {
          n.__e = !0, M(n);
        }));
      }, this.sub = function(n) {
        u.add(n);
        var l = n.componentWillUnmount;
        n.componentWillUnmount = function() {
          u && u.delete(n), l && l.call(n);
        };
      }), n.children;
    }
    return l.__c = "__cC" + h++, l.__ = n, l.Provider = l.__l = (l.Consumer = function(n, l) {
      return n.children(l);
    }).contextType = l, l;
  }
  n = v.slice, l = {
    __e: function(n, l, u, t) {
      for (var i, r, o; l = l.__; ) if ((i = l.__c) && !i.__) try {
        if ((r = i.constructor) && null != r.getDerivedStateFromError && (i.setState(r.getDerivedStateFromError(n)), 
        o = i.__d), null != i.componentDidCatch && (i.componentDidCatch(n, t || {}), o = i.__d), 
        o) return i.__E = i;
      } catch (l) {
        n = l;
      }
      throw n;
    }
  }, u = 0, function(n) {
    return null != n && null == n.constructor;
  }, x.prototype.setState = function(n, l) {
    var u;
    u = null != this.__s && this.__s != this.state ? this.__s : this.__s = d({}, this.state), 
    "function" == typeof n && (n = n(d({}, u), this.props)), n && d(u, n), null != n && this.__v && (l && this._sb.push(l), 
    M(this));
  }, x.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), M(this));
  }, x.prototype.render = k, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, 
  e = function(n, l) {
    return n.__v.__b - l.__v.__b;
  }, $.__r = 0, f = /(PointerCapture)$|Capture$/i, c = 0, s = F(!1), a = F(!0), h = 0;
}, function(module, exports, __webpack_require__) {
  (function(__filename) {
    function loadConstants() {
      const context = __webpack_require__(12);
      return context.keys().reduce((constants, key) => key.endsWith(__filename) ? constants : Object.assign(constants, context(key)), {});
    }
    module.exports = Object.assign(exports, loadConstants());
  }).call(this, "/index.js");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "Component", (function() {
    return preact_module["a"];
  }));
  __webpack_require__.d(__webpack_exports__, "Fragment", (function() {
    return preact_module["b"];
  }));
  __webpack_require__.d(__webpack_exports__, "createContext", (function() {
    return preact_module["d"];
  }));
  __webpack_require__.d(__webpack_exports__, "createElement", (function() {
    return preact_module["e"];
  }));
  __webpack_require__.d(__webpack_exports__, "createRef", (function() {
    return preact_module["f"];
  }));
  __webpack_require__.d(__webpack_exports__, "useCallback", (function() {
    return q;
  }));
  __webpack_require__.d(__webpack_exports__, "useContext", (function() {
    return x;
  }));
  __webpack_require__.d(__webpack_exports__, "useDebugValue", (function() {
    return P;
  }));
  __webpack_require__.d(__webpack_exports__, "useEffect", (function() {
    return y;
  }));
  __webpack_require__.d(__webpack_exports__, "useErrorBoundary", (function() {
    return b;
  }));
  __webpack_require__.d(__webpack_exports__, "useId", (function() {
    return g;
  }));
  __webpack_require__.d(__webpack_exports__, "useImperativeHandle", (function() {
    return F;
  }));
  __webpack_require__.d(__webpack_exports__, "useLayoutEffect", (function() {
    return _;
  }));
  __webpack_require__.d(__webpack_exports__, "useMemo", (function() {
    return T;
  }));
  __webpack_require__.d(__webpack_exports__, "useReducer", (function() {
    return h;
  }));
  __webpack_require__.d(__webpack_exports__, "useRef", (function() {
    return A;
  }));
  __webpack_require__.d(__webpack_exports__, "useState", (function() {
    return d;
  }));
  __webpack_require__.d(__webpack_exports__, "Children", (function() {
    return O;
  }));
  __webpack_require__.d(__webpack_exports__, "PureComponent", (function() {
    return N;
  }));
  __webpack_require__.d(__webpack_exports__, "StrictMode", (function() {
    return Cn;
  }));
  __webpack_require__.d(__webpack_exports__, "Suspense", (function() {
    return compat_module_P;
  }));
  __webpack_require__.d(__webpack_exports__, "SuspenseList", (function() {
    return compat_module_B;
  }));
  __webpack_require__.d(__webpack_exports__, "__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED", (function() {
    return hn;
  }));
  __webpack_require__.d(__webpack_exports__, "cloneElement", (function() {
    return _n;
  }));
  __webpack_require__.d(__webpack_exports__, "createFactory", (function() {
    return dn;
  }));
  __webpack_require__.d(__webpack_exports__, "createPortal", (function() {
    return $;
  }));
  __webpack_require__.d(__webpack_exports__, "default", (function() {
    return Rn;
  }));
  __webpack_require__.d(__webpack_exports__, "findDOMNode", (function() {
    return Sn;
  }));
  __webpack_require__.d(__webpack_exports__, "flushSync", (function() {
    return En;
  }));
  __webpack_require__.d(__webpack_exports__, "forwardRef", (function() {
    return compat_module_D;
  }));
  __webpack_require__.d(__webpack_exports__, "hydrate", (function() {
    return tn;
  }));
  __webpack_require__.d(__webpack_exports__, "isElement", (function() {
    return xn;
  }));
  __webpack_require__.d(__webpack_exports__, "isFragment", (function() {
    return pn;
  }));
  __webpack_require__.d(__webpack_exports__, "isMemo", (function() {
    return yn;
  }));
  __webpack_require__.d(__webpack_exports__, "isValidElement", (function() {
    return mn;
  }));
  __webpack_require__.d(__webpack_exports__, "lazy", (function() {
    return compat_module_z;
  }));
  __webpack_require__.d(__webpack_exports__, "memo", (function() {
    return M;
  }));
  __webpack_require__.d(__webpack_exports__, "render", (function() {
    return nn;
  }));
  __webpack_require__.d(__webpack_exports__, "startTransition", (function() {
    return R;
  }));
  __webpack_require__.d(__webpack_exports__, "unmountComponentAtNode", (function() {
    return bn;
  }));
  __webpack_require__.d(__webpack_exports__, "unstable_batchedUpdates", (function() {
    return gn;
  }));
  __webpack_require__.d(__webpack_exports__, "useDeferredValue", (function() {
    return compat_module_w;
  }));
  __webpack_require__.d(__webpack_exports__, "useInsertionEffect", (function() {
    return I;
  }));
  __webpack_require__.d(__webpack_exports__, "useSyncExternalStore", (function() {
    return compat_module_C;
  }));
  __webpack_require__.d(__webpack_exports__, "useTransition", (function() {
    return compat_module_k;
  }));
  __webpack_require__.d(__webpack_exports__, "version", (function() {
    return vn;
  }));
  var preact_module = __webpack_require__(0);
  var hooks_module_t, hooks_module_r, hooks_module_u, hooks_module_i, hooks_module_o = 0, f = [], hooks_module_c = preact_module["i"], hooks_module_e = hooks_module_c.__b, a = hooks_module_c.__r, v = hooks_module_c.diffed, hooks_module_l = hooks_module_c.__c, m = hooks_module_c.unmount, s = hooks_module_c.__;
  function p(n, t) {
    hooks_module_c.__h && hooks_module_c.__h(hooks_module_r, n, hooks_module_o || t), 
    hooks_module_o = 0;
    var u = hooks_module_r.__H || (hooks_module_r.__H = {
      __: [],
      __h: []
    });
    return n >= u.__.length && u.__.push({}), u.__[n];
  }
  function d(n) {
    return hooks_module_o = 1, h(D, n);
  }
  function h(n, u, i) {
    var o = p(hooks_module_t++, 2);
    if (o.t = n, !o.__c && (o.__ = [ i ? i(u) : D(void 0, u), function(n) {
      var t = o.__N ? o.__N[0] : o.__[0], r = o.t(t, n);
      t !== r && (o.__N = [ r, o.__[1] ], o.__c.setState({}));
    } ], o.__c = hooks_module_r, !hooks_module_r.__f)) {
      var f = function(n, t, r) {
        if (!o.__c.__H) return !0;
        var u = o.__c.__H.__.filter((function(n) {
          return !!n.__c;
        }));
        if (u.every((function(n) {
          return !n.__N;
        }))) return !c || c.call(this, n, t, r);
        var i = o.__c.props !== n;
        return u.forEach((function(n) {
          if (n.__N) {
            var t = n.__[0];
            n.__ = n.__N, n.__N = void 0, t !== n.__[0] && (i = !0);
          }
        })), c && c.call(this, n, t, r) || i;
      };
      hooks_module_r.__f = !0;
      var c = hooks_module_r.shouldComponentUpdate, e = hooks_module_r.componentWillUpdate;
      hooks_module_r.componentWillUpdate = function(n, t, r) {
        if (this.__e) {
          var u = c;
          c = void 0, f(n, t, r), c = u;
        }
        e && e.call(this, n, t, r);
      }, hooks_module_r.shouldComponentUpdate = f;
    }
    return o.__N || o.__;
  }
  function y(n, u) {
    var i = p(hooks_module_t++, 3);
    !hooks_module_c.__s && C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__H.__h.push(i));
  }
  function _(n, u) {
    var i = p(hooks_module_t++, 4);
    !hooks_module_c.__s && C(i.__H, u) && (i.__ = n, i.u = u, hooks_module_r.__h.push(i));
  }
  function A(n) {
    return hooks_module_o = 5, T((function() {
      return {
        current: n
      };
    }), []);
  }
  function F(n, t, r) {
    hooks_module_o = 6, _((function() {
      if ("function" == typeof n) {
        var r = n(t());
        return function() {
          n(null), r && "function" == typeof r && r();
        };
      }
      if (n) return n.current = t(), function() {
        return n.current = null;
      };
    }), null == r ? r : r.concat(n));
  }
  function T(n, r) {
    var u = p(hooks_module_t++, 7);
    return C(u.__H, r) && (u.__ = n(), u.__H = r, u.__h = n), u.__;
  }
  function q(n, t) {
    return hooks_module_o = 8, T((function() {
      return n;
    }), t);
  }
  function x(n) {
    var u = hooks_module_r.context[n.__c], i = p(hooks_module_t++, 9);
    return i.c = n, u ? (null == i.__ && (i.__ = !0, u.sub(hooks_module_r)), u.props.value) : n.__;
  }
  function P(n, t) {
    hooks_module_c.useDebugValue && hooks_module_c.useDebugValue(t ? t(n) : n);
  }
  function b(n) {
    var u = p(hooks_module_t++, 10), i = d();
    return u.__ = n, hooks_module_r.componentDidCatch || (hooks_module_r.componentDidCatch = function(n, t) {
      u.__ && u.__(n, t), i[1](n);
    }), [ i[0], function() {
      i[1](void 0);
    } ];
  }
  function g() {
    var n = p(hooks_module_t++, 11);
    if (!n.__) {
      for (var u = hooks_module_r.__v; null !== u && !u.__m && null !== u.__; ) u = u.__;
      var i = u.__m || (u.__m = [ 0, 0 ]);
      n.__ = "P" + i[0] + "-" + i[1]++;
    }
    return n.__;
  }
  function j() {
    for (var n; n = f.shift(); ) if (n.__P && n.__H) try {
      n.__H.__h.forEach(z), n.__H.__h.forEach(B), n.__H.__h = [];
    } catch (t) {
      n.__H.__h = [], hooks_module_c.__e(t, n.__v);
    }
  }
  hooks_module_c.__b = function(n) {
    hooks_module_r = null, hooks_module_e && hooks_module_e(n);
  }, hooks_module_c.__ = function(n, t) {
    n && t.__k && t.__k.__m && (n.__m = t.__k.__m), s && s(n, t);
  }, hooks_module_c.__r = function(n) {
    a && a(n), hooks_module_t = 0;
    var i = (hooks_module_r = n.__c).__H;
    i && (hooks_module_u === hooks_module_r ? (i.__h = [], hooks_module_r.__h = [], 
    i.__.forEach((function(n) {
      n.__N && (n.__ = n.__N), n.u = n.__N = void 0;
    }))) : (i.__h.forEach(z), i.__h.forEach(B), i.__h = [], hooks_module_t = 0)), hooks_module_u = hooks_module_r;
  }, hooks_module_c.diffed = function(n) {
    v && v(n);
    var t = n.__c;
    t && t.__H && (t.__H.__h.length && (1 !== f.push(t) && hooks_module_i === hooks_module_c.requestAnimationFrame || ((hooks_module_i = hooks_module_c.requestAnimationFrame) || w)(j)), 
    t.__H.__.forEach((function(n) {
      n.u && (n.__H = n.u), n.u = void 0;
    }))), hooks_module_u = hooks_module_r = null;
  }, hooks_module_c.__c = function(n, t) {
    t.some((function(n) {
      try {
        n.__h.forEach(z), n.__h = n.__h.filter((function(n) {
          return !n.__ || B(n);
        }));
      } catch (r) {
        t.some((function(n) {
          n.__h && (n.__h = []);
        })), t = [], hooks_module_c.__e(r, n.__v);
      }
    })), hooks_module_l && hooks_module_l(n, t);
  }, hooks_module_c.unmount = function(n) {
    m && m(n);
    var t, r = n.__c;
    r && r.__H && (r.__H.__.forEach((function(n) {
      try {
        z(n);
      } catch (n) {
        t = n;
      }
    })), r.__H = void 0, t && hooks_module_c.__e(t, r.__v));
  };
  var k = "function" == typeof requestAnimationFrame;
  function w(n) {
    var t, r = function() {
      clearTimeout(u), k && cancelAnimationFrame(t), setTimeout(n);
    }, u = setTimeout(r, 35);
    k && (t = requestAnimationFrame(r));
  }
  function z(n) {
    var t = hooks_module_r, u = n.__c;
    "function" == typeof u && (n.__c = void 0, u()), hooks_module_r = t;
  }
  function B(n) {
    var t = hooks_module_r;
    n.__c = n.__(), hooks_module_r = t;
  }
  function C(n, t) {
    return !n || n.length !== t.length || t.some((function(t, r) {
      return t !== n[r];
    }));
  }
  function D(n, t) {
    return "function" == typeof t ? t(n) : t;
  }
  function compat_module_g(n, t) {
    for (var e in t) n[e] = t[e];
    return n;
  }
  function E(n, t) {
    for (var e in n) if ("__source" !== e && !(e in t)) return !0;
    for (var r in t) if ("__source" !== r && n[r] !== t[r]) return !0;
    return !1;
  }
  function compat_module_C(n, t) {
    var e = t(), r = d({
      t: {
        __: e,
        u: t
      }
    }), u = r[0].t, o = r[1];
    return _((function() {
      u.__ = e, u.u = t, compat_module_x(u) && o({
        t: u
      });
    }), [ n, e, t ]), y((function() {
      return compat_module_x(u) && o({
        t: u
      }), n((function() {
        compat_module_x(u) && o({
          t: u
        });
      }));
    }), [ n ]), e;
  }
  function compat_module_x(n) {
    var t, e, r = n.u, u = n.__;
    try {
      var o = r();
      return !((t = u) === (e = o) && (0 !== t || 1 / t == 1 / e) || t != t && e != e);
    } catch (n) {
      return !0;
    }
  }
  function R(n) {
    n();
  }
  function compat_module_w(n) {
    return n;
  }
  function compat_module_k() {
    return [ !1, R ];
  }
  var I = _;
  function N(n, t) {
    this.props = n, this.context = t;
  }
  function M(n, e) {
    function r(n) {
      var t = this.props.ref, r = t == n.ref;
      return !r && t && (t.call ? t(null) : t.current = null), e ? !e(this.props, n) || !r : E(this.props, n);
    }
    function u(e) {
      return this.shouldComponentUpdate = r, Object(preact_module["e"])(n, e);
    }
    return u.displayName = "Memo(" + (n.displayName || n.name) + ")", u.prototype.isReactComponent = !0, 
    u.__f = !0, u.type = n, u;
  }
  (N.prototype = new preact_module["a"]).isPureReactComponent = !0, N.prototype.shouldComponentUpdate = function(n, t) {
    return E(this.props, n) || E(this.state, t);
  };
  var compat_module_T = preact_module["i"].__b;
  preact_module["i"].__b = function(n) {
    n.type && n.type.__f && n.ref && (n.props.ref = n.ref, n.ref = null), compat_module_T && compat_module_T(n);
  };
  var compat_module_A = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
  function compat_module_D(n) {
    function t(t) {
      var e = compat_module_g({}, t);
      return delete e.ref, n(e, t.ref || null);
    }
    return t.$$typeof = compat_module_A, t.render = n, t.prototype.isReactComponent = t.__f = !0, 
    t.displayName = "ForwardRef(" + (n.displayName || n.name) + ")", t;
  }
  var L = function(n, t) {
    return null == n ? null : Object(preact_module["k"])(Object(preact_module["k"])(n).map(t));
  }, O = {
    map: L,
    forEach: L,
    count: function(n) {
      return n ? Object(preact_module["k"])(n).length : 0;
    },
    only: function(n) {
      var t = Object(preact_module["k"])(n);
      if (1 !== t.length) throw "Children.only";
      return t[0];
    },
    toArray: preact_module["k"]
  }, compat_module_F = preact_module["i"].__e;
  preact_module["i"].__e = function(n, t, e, r) {
    if (n.then) for (var u, o = t; o = o.__; ) if ((u = o.__c) && u.__c) return null == t.__e && (t.__e = e.__e, 
    t.__k = e.__k), u.__c(n, t);
    compat_module_F(n, t, e, r);
  };
  var U = preact_module["i"].unmount;
  function V(n, t, e) {
    return n && (n.__c && n.__c.__H && (n.__c.__H.__.forEach((function(n) {
      "function" == typeof n.__c && n.__c();
    })), n.__c.__H = null), null != (n = compat_module_g({}, n)).__c && (n.__c.__P === e && (n.__c.__P = t), 
    n.__c.__e = !0, n.__c = null), n.__k = n.__k && n.__k.map((function(n) {
      return V(n, t, e);
    }))), n;
  }
  function W(n, t, e) {
    return n && e && (n.__v = null, n.__k = n.__k && n.__k.map((function(n) {
      return W(n, t, e);
    })), n.__c && n.__c.__P === t && (n.__e && e.appendChild(n.__e), n.__c.__e = !0, 
    n.__c.__P = e)), n;
  }
  function compat_module_P() {
    this.__u = 0, this.o = null, this.__b = null;
  }
  function compat_module_j(n) {
    var t = n.__.__c;
    return t && t.__a && t.__a(n);
  }
  function compat_module_z(n) {
    var e, r, u;
    function o(o) {
      if (e || (e = n()).then((function(n) {
        r = n.default || n;
      }), (function(n) {
        u = n;
      })), u) throw u;
      if (!r) throw e;
      return Object(preact_module["e"])(r, o);
    }
    return o.displayName = "Lazy", o.__f = !0, o;
  }
  function compat_module_B() {
    this.i = null, this.l = null;
  }
  preact_module["i"].unmount = function(n) {
    var t = n.__c;
    t && t.__R && t.__R(), t && 32 & n.__u && (n.type = null), U && U(n);
  }, (compat_module_P.prototype = new preact_module["a"]).__c = function(n, t) {
    var e = t.__c, r = this;
    null == r.o && (r.o = []), r.o.push(e);
    var u = compat_module_j(r.__v), o = !1, i = function() {
      o || (o = !0, e.__R = null, u ? u(l) : l());
    };
    e.__R = i;
    var l = function() {
      if (!--r.__u) {
        if (r.state.__a) {
          var n = r.state.__a;
          r.__v.__k[0] = W(n, n.__c.__P, n.__c.__O);
        }
        var t;
        for (r.setState({
          __a: r.__b = null
        }); t = r.o.pop(); ) t.forceUpdate();
      }
    };
    r.__u++ || 32 & t.__u || r.setState({
      __a: r.__b = r.__v.__k[0]
    }), n.then(i, i);
  }, compat_module_P.prototype.componentWillUnmount = function() {
    this.o = [];
  }, compat_module_P.prototype.render = function(n, e) {
    if (this.__b) {
      if (this.__v.__k) {
        var r = document.createElement("div"), o = this.__v.__k[0].__c;
        this.__v.__k[0] = V(this.__b, r, o.__O = o.__P);
      }
      this.__b = null;
    }
    var i = e.__a && Object(preact_module["e"])(preact_module["b"], null, n.fallback);
    return i && (i.__u &= -33), [ Object(preact_module["e"])(preact_module["b"], null, e.__a ? null : n.children), i ];
  };
  var H = function(n, t, e) {
    if (++e[1] === e[0] && n.l.delete(t), n.props.revealOrder && ("t" !== n.props.revealOrder[0] || !n.l.size)) for (e = n.i; e; ) {
      for (;e.length > 3; ) e.pop()();
      if (e[1] < e[0]) break;
      n.i = e = e[2];
    }
  };
  function Z(n) {
    return this.getChildContext = function() {
      return n.context;
    }, n.children;
  }
  function Y(n) {
    var e = this, r = n.h;
    if (e.componentWillUnmount = function() {
      Object(preact_module["j"])(null, e.v), e.v = null, e.h = null;
    }, e.h && e.h !== r && e.componentWillUnmount(), !e.v) {
      for (var u = e.__v; null !== u && !u.__m && null !== u.__; ) u = u.__;
      e.h = r, e.v = {
        nodeType: 1,
        parentNode: r,
        childNodes: [],
        __k: {
          __m: u.__m
        },
        contains: function() {
          return !0;
        },
        insertBefore: function(n, t) {
          this.childNodes.push(n), e.h.insertBefore(n, t);
        },
        removeChild: function(n) {
          this.childNodes.splice(this.childNodes.indexOf(n) >>> 1, 1), e.h.removeChild(n);
        }
      };
    }
    Object(preact_module["j"])(Object(preact_module["e"])(Z, {
      context: e.context
    }, n.__v), e.v);
  }
  function $(n, e) {
    var r = Object(preact_module["e"])(Y, {
      __v: n,
      h: e
    });
    return r.containerInfo = e, r;
  }
  (compat_module_B.prototype = new preact_module["a"]).__a = function(n) {
    var t = this, e = compat_module_j(t.__v), r = t.l.get(n);
    return r[0]++, function(u) {
      var o = function() {
        t.props.revealOrder ? (r.push(u), H(t, n, r)) : u();
      };
      e ? e(o) : o();
    };
  }, compat_module_B.prototype.render = function(n) {
    this.i = null, this.l = new Map;
    var t = Object(preact_module["k"])(n.children);
    n.revealOrder && "b" === n.revealOrder[0] && t.reverse();
    for (var e = t.length; e--; ) this.l.set(t[e], this.i = [ 1, 0, this.i ]);
    return n.children;
  }, compat_module_B.prototype.componentDidUpdate = compat_module_B.prototype.componentDidMount = function() {
    var n = this;
    this.l.forEach((function(t, e) {
      H(n, e, t);
    }));
  };
  var compat_module_q = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103, G = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, J = /^on(Ani|Tra|Tou|BeforeInp|Compo)/, K = /[A-Z0-9]/g, Q = "undefined" != typeof document, X = function(n) {
    return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(n);
  };
  function nn(n, t, e) {
    return null == t.__k && (t.textContent = ""), Object(preact_module["j"])(n, t), 
    "function" == typeof e && e(), n ? n.__c : null;
  }
  function tn(n, t, e) {
    return Object(preact_module["h"])(n, t), "function" == typeof e && e(), n ? n.__c : null;
  }
  preact_module["a"].prototype.isReactComponent = {}, [ "componentWillMount", "componentWillReceiveProps", "componentWillUpdate" ].forEach((function(t) {
    Object.defineProperty(preact_module["a"].prototype, t, {
      configurable: !0,
      get: function() {
        return this["UNSAFE_" + t];
      },
      set: function(n) {
        Object.defineProperty(this, t, {
          configurable: !0,
          writable: !0,
          value: n
        });
      }
    });
  }));
  var en = preact_module["i"].event;
  function rn() {}
  function un() {
    return this.cancelBubble;
  }
  function on() {
    return this.defaultPrevented;
  }
  preact_module["i"].event = function(n) {
    return en && (n = en(n)), n.persist = rn, n.isPropagationStopped = un, n.isDefaultPrevented = on, 
    n.nativeEvent = n;
  };
  var ln, cn = {
    enumerable: !1,
    configurable: !0,
    get: function() {
      return this.class;
    }
  }, fn = preact_module["i"].vnode;
  preact_module["i"].vnode = function(n) {
    "string" == typeof n.type && function(n) {
      var t = n.props, e = n.type, u = {}, o = -1 === e.indexOf("-");
      for (var i in t) {
        var l = t[i];
        if (!("value" === i && "defaultValue" in t && null == l || Q && "children" === i && "noscript" === e || "class" === i || "className" === i)) {
          var c = i.toLowerCase();
          "defaultValue" === i && "value" in t && null == t.value ? i = "value" : "download" === i && !0 === l ? l = "" : "translate" === c && "no" === l ? l = !1 : "o" === c[0] && "n" === c[1] ? "ondoubleclick" === c ? i = "ondblclick" : "onchange" !== c || "input" !== e && "textarea" !== e || X(t.type) ? "onfocus" === c ? i = "onfocusin" : "onblur" === c ? i = "onfocusout" : J.test(i) && (i = c) : c = i = "oninput" : o && G.test(i) ? i = i.replace(K, "-$&").toLowerCase() : null === l && (l = void 0), 
          "oninput" === c && u[i = c] && (i = "oninputCapture"), u[i] = l;
        }
      }
      "select" == e && u.multiple && Array.isArray(u.value) && (u.value = Object(preact_module["k"])(t.children).forEach((function(n) {
        n.props.selected = -1 != u.value.indexOf(n.props.value);
      }))), "select" == e && null != u.defaultValue && (u.value = Object(preact_module["k"])(t.children).forEach((function(n) {
        n.props.selected = u.multiple ? -1 != u.defaultValue.indexOf(n.props.value) : u.defaultValue == n.props.value;
      }))), t.class && !t.className ? (u.class = t.class, Object.defineProperty(u, "className", cn)) : (t.className && !t.class || t.class && t.className) && (u.class = u.className = t.className), 
      n.props = u;
    }(n), n.$$typeof = compat_module_q, fn && fn(n);
  };
  var an = preact_module["i"].__r;
  preact_module["i"].__r = function(n) {
    an && an(n), ln = n.__c;
  };
  var sn = preact_module["i"].diffed;
  preact_module["i"].diffed = function(n) {
    sn && sn(n);
    var t = n.props, e = n.__e;
    null != e && "textarea" === n.type && "value" in t && t.value !== e.value && (e.value = null == t.value ? "" : t.value), 
    ln = null;
  };
  var hn = {
    ReactCurrentDispatcher: {
      current: {
        readContext: function(n) {
          return ln.__n[n.__c].props.value;
        },
        useCallback: q,
        useContext: x,
        useDebugValue: P,
        useDeferredValue: compat_module_w,
        useEffect: y,
        useId: g,
        useImperativeHandle: F,
        useInsertionEffect: I,
        useLayoutEffect: _,
        useMemo: T,
        useReducer: h,
        useRef: A,
        useState: d,
        useSyncExternalStore: compat_module_C,
        useTransition: compat_module_k
      }
    }
  }, vn = "18.3.1";
  function dn(n) {
    return preact_module["e"].bind(null, n);
  }
  function mn(n) {
    return !!n && n.$$typeof === compat_module_q;
  }
  function pn(n) {
    return mn(n) && n.type === preact_module["b"];
  }
  function yn(n) {
    return !!n && !!n.displayName && ("string" == typeof n.displayName || n.displayName instanceof String) && n.displayName.startsWith("Memo(");
  }
  function _n(n) {
    return mn(n) ? preact_module["c"].apply(null, arguments) : n;
  }
  function bn(n) {
    return !!n.__k && (Object(preact_module["j"])(null, n), !0);
  }
  function Sn(n) {
    return n && (n.base || 1 === n.nodeType && n) || null;
  }
  var gn = function(n, t) {
    return n(t);
  }, En = function(n, t) {
    return n(t);
  }, Cn = preact_module["b"], xn = mn, Rn = {
    useState: d,
    useId: g,
    useReducer: h,
    useEffect: y,
    useLayoutEffect: _,
    useInsertionEffect: I,
    useTransition: compat_module_k,
    useDeferredValue: compat_module_w,
    useSyncExternalStore: compat_module_C,
    startTransition: R,
    useRef: A,
    useImperativeHandle: F,
    useMemo: T,
    useCallback: q,
    useContext: x,
    useDebugValue: P,
    version: "18.3.1",
    Children: O,
    render: nn,
    hydrate: tn,
    unmountComponentAtNode: bn,
    createPortal: $,
    createElement: preact_module["e"],
    createContext: preact_module["d"],
    createFactory: dn,
    cloneElement: _n,
    createRef: preact_module["f"],
    Fragment: preact_module["b"],
    isValidElement: mn,
    isElement: xn,
    isFragment: pn,
    isMemo: yn,
    findDOMNode: Sn,
    Component: preact_module["a"],
    PureComponent: N,
    memo: M,
    forwardRef: compat_module_D,
    flushSync: En,
    unstable_batchedUpdates: gn,
    StrictMode: Cn,
    Suspense: compat_module_P,
    SuspenseList: compat_module_B,
    lazy: compat_module_z,
    __SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED: hn
  };
}, function(module, exports, __webpack_require__) {
  var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
  /*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/  (function() {
    "use strict";
    var hasOwn = {}.hasOwnProperty;
    function classNames() {
      var classes = "";
      for (var i = 0; i < arguments.length; i++) {
        var arg = arguments[i];
        if (arg) classes = appendClass(classes, parseValue(arg));
      }
      return classes;
    }
    function parseValue(arg) {
      if ("string" === typeof arg || "number" === typeof arg) return arg;
      if ("object" !== typeof arg) return "";
      if (Array.isArray(arg)) return classNames.apply(null, arg);
      if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes("[native code]")) return arg.toString();
      var classes = "";
      for (var key in arg) if (hasOwn.call(arg, key) && arg[key]) classes = appendClass(classes, key);
      return classes;
    }
    function appendClass(value, newClass) {
      if (!newClass) return value;
      if (value) return value + " " + newClass;
      return value + newClass;
    }
    if (true, module.exports) {
      classNames.default = classNames;
      module.exports = classNames;
    } else if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function() {
      return classNames;
    }.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), void 0 !== __WEBPACK_AMD_DEFINE_RESULT__ && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  })();
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.getScrollTop = getScrollTop;
  exports.getScrollLeft = getScrollLeft;
  exports.getArrowSpacing = getArrowSpacing;
  exports.getScrollParent = getScrollParent;
  exports.noArrowDistance = exports.bodyPadding = exports.minArrowPadding = void 0;
  var minArrowPadding = 5;
  exports.minArrowPadding = minArrowPadding;
  var bodyPadding = 10;
  exports.bodyPadding = bodyPadding;
  var noArrowDistance = 3;
  exports.noArrowDistance = noArrowDistance;
  function getScrollTop() {
    return window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  }
  function getScrollLeft() {
    return window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0;
  }
  function getArrowSpacing(props) {
    var defaultArrowSpacing = props.arrow ? props.arrowSize : noArrowDistance;
    return "number" === typeof props.distance ? props.distance : defaultArrowSpacing;
  }
  function getScrollParent(element) {
    var style = getComputedStyle(element);
    var scrollParent = window;
    if ("fixed" !== style.position) {
      var parent = element.parentElement;
      while (parent) {
        var parentStyle = getComputedStyle(parent);
        if (/(auto|scroll)/.test(parentStyle.overflow + parentStyle.overflowY + parentStyle.overflowX)) {
          scrollParent = parent;
          parent = void 0;
        } else parent = parent.parentElement;
      }
    }
    return scrollParent;
  }
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    for (var i = 0; i < arguments.length; i++) if ("undefined" !== typeof arguments[i]) return arguments[i];
  };
}, function(module, exports, __webpack_require__) {
  if (false) ; else module.exports = __webpack_require__(23)();
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = positions;
  var _getDirection = _interopRequireDefault(__webpack_require__(26));
  var _functions = __webpack_require__(4);
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = null != arguments[i] ? arguments[i] : {};
      var ownKeys = Object.keys(source);
      if ("function" === typeof Object.getOwnPropertySymbols) ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter((function(sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      })));
      ownKeys.forEach((function(key) {
        _defineProperty(target, key, source[key]);
      }));
    }
    return target;
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    }); else obj[key] = value;
    return obj;
  }
  function getTipMaxWidth() {
    return "undefined" !== typeof document ? document.documentElement.clientWidth - 2 * _functions.bodyPadding : 1e3;
  }
  function parseAlignMode(direction) {
    var directionArray = direction.split("-");
    if (directionArray.length > 1) return directionArray[1];
    return "middle";
  }
  function getUpDownPosition(tip, target, state, direction, alignMode, props) {
    var left = -1e7;
    var top;
    var transform = state.showTip ? void 0 : "translateX(-10000000px)";
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    if (tip) {
      var scrollLeft = (0, _functions.getScrollLeft)();
      var targetRect = target.getBoundingClientRect();
      var targetLeft = targetRect.left + scrollLeft;
      var halfTargetWidth = Math.round(target.offsetWidth / 2);
      var tipWidth = Math.min(getTipMaxWidth(), tip.offsetWidth);
      var arrowCenter = targetLeft + halfTargetWidth;
      var arrowLeft = arrowCenter - props.arrowSize;
      var arrowRight = arrowCenter + props.arrowSize;
      if ("start" === alignMode) left = props.arrow ? Math.min(arrowLeft, targetLeft) : targetLeft; else if ("end" === alignMode) {
        var rightWithArrow = Math.max(arrowRight, targetLeft + target.offsetWidth);
        var rightEdge = props.arrow ? rightWithArrow : targetLeft + target.offsetWidth;
        left = Math.max(rightEdge - tipWidth, _functions.bodyPadding + scrollLeft);
      } else {
        var centeredLeft = targetLeft + halfTargetWidth - Math.round(tipWidth / 2);
        var availableSpaceOnLeft = _functions.bodyPadding + scrollLeft;
        left = Math.max(centeredLeft, availableSpaceOnLeft);
      }
      var rightOfTip = left + tipWidth;
      var rightOfScreen = scrollLeft + document.documentElement.clientWidth - _functions.bodyPadding;
      var rightOverhang = rightOfTip - rightOfScreen;
      if (rightOverhang > 0) left -= rightOverhang;
      if ("up" === direction) top = targetRect.top + (0, _functions.getScrollTop)() - (tip.offsetHeight + arrowSpacing); else top = targetRect.bottom + (0, 
      _functions.getScrollTop)() + arrowSpacing;
    }
    return {
      left,
      top,
      transform
    };
  }
  function getLeftRightPosition(tip, target, state, direction, alignMode, props) {
    var left = -1e7;
    var top = 0;
    var transform = state.showTip ? void 0 : "translateX(-10000000px)";
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var arrowPadding = props.arrow ? _functions.minArrowPadding : 0;
    if (tip) {
      var scrollTop = (0, _functions.getScrollTop)();
      var scrollLeft = (0, _functions.getScrollLeft)();
      var targetRect = target.getBoundingClientRect();
      var targetTop = targetRect.top + scrollTop;
      var halfTargetHeight = Math.round(target.offsetHeight / 2);
      var arrowTop = targetTop + halfTargetHeight - props.arrowSize;
      var arrowBottom = targetRect.top + scrollTop + halfTargetHeight + props.arrowSize;
      if ("start" === alignMode) top = props.arrow ? Math.min(targetTop, arrowTop) : targetTop; else if ("end" === alignMode) {
        var topForBottomAlign = targetRect.bottom + scrollTop - tip.offsetHeight;
        top = props.arrow ? Math.max(topForBottomAlign, arrowBottom - tip.offsetHeight) : topForBottomAlign;
      } else {
        var centeredTop = Math.max(targetTop + halfTargetHeight - Math.round(tip.offsetHeight / 2), _functions.bodyPadding + scrollTop);
        top = Math.min(centeredTop, arrowTop - arrowPadding);
      }
      var bottomOverhang = top - scrollTop + tip.offsetHeight + _functions.bodyPadding - window.innerHeight;
      if (bottomOverhang > 0) top = Math.max(top - bottomOverhang, arrowBottom + arrowPadding - tip.offsetHeight);
      if ("right" === direction) left = targetRect.right + arrowSpacing + scrollLeft; else left = targetRect.left - arrowSpacing - tip.offsetWidth + scrollLeft;
    }
    return {
      left,
      top,
      transform
    };
  }
  function getArrowStyles(target, tip, direction, state, props) {
    if (!target || !props.arrow) return {
      positionStyles: {
        top: "0",
        left: "-10000000px"
      }
    };
    var targetRect = target.getBoundingClientRect();
    var halfTargetHeight = Math.round(target.offsetHeight / 2);
    var halfTargetWidth = Math.round(target.offsetWidth / 2);
    var scrollTop = (0, _functions.getScrollTop)();
    var scrollLeft = (0, _functions.getScrollLeft)();
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var borderStyles = {};
    var positionStyles = {};
    switch (direction) {
     case "right":
      borderStyles.borderTop = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderBottom = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderRight = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderRightWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderRightStyle = "solid";
      }
      positionStyles.top = state.showTip && tip ? targetRect.top + scrollTop + halfTargetHeight - props.arrowSize : "-10000000px";
      positionStyles.left = targetRect.right + scrollLeft + arrowSpacing - props.arrowSize;
      break;

     case "left":
      borderStyles.borderTop = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderBottom = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderLeft = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderLeftWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderLeftStyle = "solid";
      }
      positionStyles.top = state.showTip && tip ? targetRect.top + scrollTop + halfTargetHeight - props.arrowSize : "-10000000px";
      positionStyles.left = targetRect.left + scrollLeft - arrowSpacing - 1;
      break;

     case "up":
      borderStyles.borderLeft = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderRight = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderTop = "".concat(props.arrowSize, "px solid ").concat(props.background); else {
        borderStyles.borderTopWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderTopStyle = "solid";
      }
      positionStyles.left = state.showTip && tip ? targetRect.left + scrollLeft + halfTargetWidth - props.arrowSize : "-10000000px";
      positionStyles.top = targetRect.top + scrollTop - arrowSpacing;
      break;

     case "down":
     default:
      borderStyles.borderLeft = "".concat(props.arrowSize, "px solid transparent");
      borderStyles.borderRight = "".concat(props.arrowSize, "px solid transparent");
      if (props.background) borderStyles.borderBottom = "10px solid ".concat(props.background); else {
        borderStyles.borderBottomWidth = "".concat(props.arrowSize, "px");
        borderStyles.borderBottomStyle = "solid";
      }
      positionStyles.left = state.showTip && tip ? targetRect.left + scrollLeft + halfTargetWidth - props.arrowSize : "-10000000px";
      positionStyles.top = targetRect.bottom + scrollTop + arrowSpacing - props.arrowSize;
      break;
    }
    return {
      borderStyles,
      positionStyles
    };
  }
  function positions(direction, forceDirection, tip, target, state, props) {
    var alignMode = parseAlignMode(direction);
    var trimmedDirection = direction.split("-")[0];
    var realDirection = trimmedDirection;
    if (!forceDirection && tip) {
      var testArrowStyles = props.arrow && getArrowStyles(target, tip, trimmedDirection, state, props);
      realDirection = (0, _getDirection["default"])(trimmedDirection, tip, target, props, _functions.bodyPadding, testArrowStyles);
    }
    var maxWidth = getTipMaxWidth();
    var width;
    if (tip) {
      var spacer = tip.style.width ? 0 : 1;
      width = Math.min(tip.offsetWidth, maxWidth) + spacer;
    }
    var tipPosition = "up" === realDirection || "down" === realDirection ? getUpDownPosition(tip, target, state, realDirection, alignMode, props) : getLeftRightPosition(tip, target, state, realDirection, alignMode, props);
    return {
      tip: _objectSpread({}, tipPosition, {
        maxWidth,
        width
      }),
      arrow: getArrowStyles(target, tip, realDirection, state, props),
      realDirection
    };
  }
}, function(module, exports) {
  module.exports = isPromise;
  module.exports.default = isPromise;
  function isPromise(obj) {
    return !!obj && ("object" === typeof obj || "function" === typeof obj) && "function" === typeof obj.then;
  }
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = (string, options) => {
    options = Object.assign({
      preserveNewLines: false
    }, options);
    if ("string" !== typeof string) throw new TypeError(`Expected input to be of type \`string\`, got \`${typeof string}\``);
    if (!options.preserveNewlines) return string.split(/\r?\n/);
    const parts = string.split(/(\r?\n)/);
    const lines = [];
    for (let i = 0; i < parts.length; i += 2) lines.push(parts[i] + (parts[i + 1] || ""));
    return lines;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const stripAnsi = __webpack_require__(19);
  const isFullwidthCodePoint = __webpack_require__(21);
  const emojiRegex = __webpack_require__(22);
  const stringWidth = string => {
    if ("string" !== typeof string || 0 === string.length) return 0;
    string = stripAnsi(string);
    if (0 === string.length) return 0;
    string = string.replace(emojiRegex(), "  ");
    let width = 0;
    for (let i = 0; i < string.length; i++) {
      const code = string.codePointAt(i);
      if (code <= 31 || code >= 127 && code <= 159) continue;
      if (code >= 768 && code <= 879) continue;
      if (code > 65535) i++;
      width += isFullwidthCodePoint(code) ? 2 : 1;
    }
    return width;
  };
  module.exports = stringWidth;
  module.exports.default = stringWidth;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = void 0;
  var _react = _interopRequireDefault(__webpack_require__(2));
  var _propTypes = _interopRequireDefault(__webpack_require__(6));
  var _Portal = _interopRequireWildcard(__webpack_require__(25));
  var _position = _interopRequireDefault(__webpack_require__(7));
  var _functions = __webpack_require__(4);
  function _interopRequireWildcard(obj) {
    if (obj && obj.__esModule) return obj; else {
      var newObj = {};
      if (null != obj) for (var key in obj) if (Object.prototype.hasOwnProperty.call(obj, key)) {
        var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {};
        if (desc.get || desc.set) Object.defineProperty(newObj, key, desc); else newObj[key] = obj[key];
      }
      newObj["default"] = obj;
      return newObj;
    }
  }
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _typeof(obj) {
    if ("function" === typeof Symbol && "symbol" === typeof Symbol.iterator) _typeof = function(obj) {
      return typeof obj;
    }; else _typeof = function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    return _typeof(obj);
  }
  function _extends() {
    _extends = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) if (Object.prototype.hasOwnProperty.call(source, key)) target[key] = source[key];
      }
      return target;
    };
    return _extends.apply(this, arguments);
  }
  function _objectSpread(target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = null != arguments[i] ? arguments[i] : {};
      var ownKeys = Object.keys(source);
      if ("function" === typeof Object.getOwnPropertySymbols) ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter((function(sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      })));
      ownKeys.forEach((function(key) {
        _defineProperty(target, key, source[key]);
      }));
    }
    return target;
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
  }
  function _possibleConstructorReturn(self, call) {
    if (call && ("object" === _typeof(call) || "function" === typeof call)) return call;
    return _assertThisInitialized(self);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _assertThisInitialized(self) {
    if (void 0 === self) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _inherits(subClass, superClass) {
    if ("function" !== typeof superClass && null !== superClass) throw new TypeError("Super expression must either be null or a function");
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _defineProperty(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    }); else obj[key] = value;
    return obj;
  }
  var defaultColor = "#fff";
  var defaultBg = "#333";
  var resizeThrottle = 100;
  var resizeThreshold = 5;
  var stopProp = function(e) {
    return e.stopPropagation();
  };
  var Tooltip = function(_React$Component) {
    _inherits(Tooltip, _React$Component);
    _createClass(Tooltip, null, [ {
      key: "getDerivedStateFromProps",
      value: function(nextProps) {
        return _Portal.isBrowser && nextProps.isOpen ? {
          hasBeenShown: true
        } : null;
      }
    } ]);
    function Tooltip() {
      var _this;
      _classCallCheck(this, Tooltip);
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Tooltip).call(this));
      _defineProperty(_assertThisInitialized(_this), "debounceTimeout", false);
      _defineProperty(_assertThisInitialized(_this), "hoverTimeout", false);
      _this.state = {
        showTip: false,
        hasHover: false,
        ignoreShow: false,
        hasBeenShown: false
      };
      _this.showTip = _this.showTip.bind(_assertThisInitialized(_this));
      _this.hideTip = _this.hideTip.bind(_assertThisInitialized(_this));
      _this.checkHover = _this.checkHover.bind(_assertThisInitialized(_this));
      _this.toggleTip = _this.toggleTip.bind(_assertThisInitialized(_this));
      _this.startHover = _this.startHover.bind(_assertThisInitialized(_this));
      _this.endHover = _this.endHover.bind(_assertThisInitialized(_this));
      _this.listenResizeScroll = _this.listenResizeScroll.bind(_assertThisInitialized(_this));
      _this.handleResizeScroll = _this.handleResizeScroll.bind(_assertThisInitialized(_this));
      _this.bodyTouchStart = _this.bodyTouchStart.bind(_assertThisInitialized(_this));
      _this.bodyTouchEnd = _this.bodyTouchEnd.bind(_assertThisInitialized(_this));
      _this.targetTouchStart = _this.targetTouchStart.bind(_assertThisInitialized(_this));
      _this.targetTouchEnd = _this.targetTouchEnd.bind(_assertThisInitialized(_this));
      return _this;
    }
    _createClass(Tooltip, [ {
      key: "componentDidMount",
      value: function() {
        if (this.props.isOpen) this.setState({
          isOpen: true
        });
        this.scrollParent = (0, _functions.getScrollParent)(this.target);
        window.addEventListener("resize", this.listenResizeScroll);
        this.scrollParent.addEventListener("scroll", this.listenResizeScroll);
        window.addEventListener("touchstart", this.bodyTouchStart);
        window.addEventListener("touchEnd", this.bodyTouchEnd);
      }
    }, {
      key: "componentDidUpdate",
      value: function(_, prevState) {
        if (!this.state.hasBeenShown && this.props.isOpen) {
          this.setState({
            hasBeenShown: true
          });
          return setTimeout(this.showTip, 0);
        }
        if (!prevState.hasBeenShown && this.state.hasBeenShown) this.showTip();
      }
    }, {
      key: "componentWillUnmount",
      value: function() {
        window.removeEventListener("resize", this.listenResizeScroll);
        this.scrollParent.removeEventListener("scroll", this.listenResizeScroll);
        window.removeEventListener("touchstart", this.bodyTouchStart);
        window.removeEventListener("touchEnd", this.bodyTouchEnd);
        clearTimeout(this.debounceTimeout);
        clearTimeout(this.hoverTimeout);
      }
    }, {
      key: "listenResizeScroll",
      value: function() {
        clearTimeout(this.debounceTimeout);
        this.debounceTimeout = setTimeout(this.handleResizeScroll, resizeThrottle);
        if (this.state.targetTouch) this.setState({
          targetTouch: void 0
        });
      }
    }, {
      key: "handleResizeScroll",
      value: function() {
        if (this.state.showTip) {
          var clientWidth = Math.round(document.documentElement.clientWidth / resizeThreshold) * resizeThreshold;
          this.setState({
            clientWidth
          });
        }
      }
    }, {
      key: "targetTouchStart",
      value: function() {
        this.setState({
          targetTouch: true
        });
      }
    }, {
      key: "targetTouchEnd",
      value: function() {
        if (this.state.targetTouch) this.toggleTip();
      }
    }, {
      key: "bodyTouchEnd",
      value: function() {
        if (this.state.targetTouch) this.setState({
          targetTouch: void 0
        });
      }
    }, {
      key: "bodyTouchStart",
      value: function(e) {
        if (!(this.target && this.target.contains(e.target)) && !(this.tip && this.tip.contains(e.target)) && !this.props.isOpen) this.hideTip();
      }
    }, {
      key: "toggleTip",
      value: function() {
        this.state.showTip ? this.hideTip() : this.showTip();
      }
    }, {
      key: "showTip",
      value: function() {
        var _this2 = this;
        if (!this.state.hasBeenShown) return this.setState({
          hasBeenShown: true
        });
        if (!this.state.showTip) this.setState({
          showTip: true
        }, (function() {
          if ("function" === typeof _this2.props.onToggle) _this2.props.onToggle(_this2.state.showTip);
        }));
      }
    }, {
      key: "hideTip",
      value: function() {
        var _this3 = this;
        this.setState({
          hasHover: false
        });
        if (this.state.showTip) this.setState({
          showTip: false
        }, (function() {
          if ("function" === typeof _this3.props.onToggle) _this3.props.onToggle(_this3.state.showTip);
        }));
      }
    }, {
      key: "startHover",
      value: function() {
        if (!this.state.ignoreShow) {
          this.setState({
            hasHover: true
          });
          clearTimeout(this.hoverTimeout);
          this.hoverTimeout = setTimeout(this.checkHover, this.props.hoverDelay);
        }
      }
    }, {
      key: "endHover",
      value: function() {
        this.setState({
          hasHover: false
        });
        clearTimeout(this.hoverTimeout);
        this.hoverTimeout = setTimeout(this.checkHover, this.props.mouseOutDelay || this.props.hoverDelay);
      }
    }, {
      key: "checkHover",
      value: function() {
        this.state.hasHover ? this.showTip() : this.hideTip();
      }
    }, {
      key: "render",
      value: function() {
        var _this4 = this;
        var _this$props = this.props, arrow = _this$props.arrow, arrowSize = _this$props.arrowSize, background = _this$props.background, className = _this$props.className, children = _this$props.children, color = _this$props.color, content = _this$props.content, direction = _this$props.direction, distance = _this$props.distance, eventOff = _this$props.eventOff, eventOn = _this$props.eventOn, eventToggle = _this$props.eventToggle, forceDirection = _this$props.forceDirection, isOpen = _this$props.isOpen, mouseOutDelay = _this$props.mouseOutDelay, padding = _this$props.padding, styles = _this$props.styles, TagName = _this$props.tagName, tipContentHover = _this$props.tipContentHover, tipContentClassName = _this$props.tipContentClassName, useDefaultStyles = _this$props.useDefaultStyles, useHover = _this$props.useHover, arrowContent = _this$props.arrowContent;
        var isControlledByProps = "undefined" !== typeof isOpen && null !== isOpen;
        var showTip = isControlledByProps ? isOpen : this.state.showTip;
        var wrapperStyles = _objectSpread({
          position: "relative"
        }, styles);
        var props = {
          style: wrapperStyles,
          ref: function(target) {
            _this4.target = target;
          },
          className
        };
        var portalProps = {
          onClick: stopProp
        };
        if (eventOff) props[eventOff] = this.hideTip;
        if (eventOn) props[eventOn] = this.showTip;
        if (eventToggle) props[eventToggle] = this.toggleTip; else if (useHover && !isControlledByProps) {
          props.onMouseEnter = this.startHover;
          props.onMouseLeave = tipContentHover || mouseOutDelay ? this.endHover : this.hideTip;
          props.onTouchStart = this.targetTouchStart;
          props.onTouchEnd = this.targetTouchEnd;
          if (tipContentHover) {
            portalProps.onMouseEnter = this.startHover;
            portalProps.onMouseLeave = this.endHover;
            portalProps.onTouchStart = stopProp;
          }
        }
        var tipPortal;
        if (this.state.hasBeenShown) {
          var currentPositions = (0, _position["default"])(direction, forceDirection, this.tip, this.target, _objectSpread({}, this.state, {
            showTip
          }), {
            background: useDefaultStyles ? defaultBg : background,
            arrow,
            arrowSize,
            distance
          });
          var tipStyles = _objectSpread({}, currentPositions.tip, {
            background: useDefaultStyles ? defaultBg : background,
            color: useDefaultStyles ? defaultColor : color,
            padding,
            boxSizing: "border-box",
            zIndex: this.props.zIndex,
            position: "absolute",
            display: "inline-block"
          });
          var arrowStyles = _objectSpread({}, currentPositions.arrow.positionStyles, arrowContent ? {} : currentPositions.arrow.borderStyles, {
            position: "absolute",
            width: "0px",
            height: "0px",
            zIndex: this.props.zIndex + 1
          });
          tipPortal = _react["default"].createElement(_Portal["default"], null, _react["default"].createElement("div", _extends({}, portalProps, {
            className: "undefined" !== typeof tipContentClassName ? tipContentClassName : className
          }), _react["default"].createElement("span", {
            className: "react-tooltip-lite",
            style: tipStyles,
            ref: function(tip) {
              _this4.tip = tip;
            }
          }, content), _react["default"].createElement("span", {
            className: "react-tooltip-lite-arrow react-tooltip-lite-".concat(currentPositions.realDirection, "-arrow"),
            style: arrowStyles
          }, arrowContent)));
        }
        return _react["default"].createElement(TagName, props, children, tipPortal);
      }
    } ]);
    return Tooltip;
  }(_react["default"].Component);
  _defineProperty(Tooltip, "propTypes", {
    arrow: _propTypes["default"].bool,
    arrowSize: _propTypes["default"].number,
    background: _propTypes["default"].string,
    children: _propTypes["default"].node.isRequired,
    className: _propTypes["default"].string,
    color: _propTypes["default"].string,
    content: _propTypes["default"].node.isRequired,
    direction: _propTypes["default"].string,
    distance: _propTypes["default"].number,
    eventOff: _propTypes["default"].string,
    eventOn: _propTypes["default"].string,
    eventToggle: _propTypes["default"].string,
    forceDirection: _propTypes["default"].bool,
    hoverDelay: _propTypes["default"].number,
    isOpen: _propTypes["default"].bool,
    mouseOutDelay: _propTypes["default"].number,
    padding: _propTypes["default"].oneOfType([ _propTypes["default"].string, _propTypes["default"].number ]),
    styles: _propTypes["default"].object,
    tagName: _propTypes["default"].string,
    tipContentHover: _propTypes["default"].bool,
    tipContentClassName: _propTypes["default"].string,
    useDefaultStyles: _propTypes["default"].bool,
    useHover: _propTypes["default"].bool,
    zIndex: _propTypes["default"].number,
    onToggle: _propTypes["default"].func,
    arrowContent: _propTypes["default"].node
  });
  _defineProperty(Tooltip, "defaultProps", {
    arrow: true,
    arrowSize: 10,
    background: "",
    className: "",
    color: "",
    direction: "up",
    distance: void 0,
    eventOff: void 0,
    eventOn: void 0,
    eventToggle: void 0,
    forceDirection: false,
    hoverDelay: 200,
    isOpen: void 0,
    mouseOutDelay: void 0,
    padding: "10px",
    styles: {},
    tagName: "div",
    tipContentHover: false,
    tipContentClassName: void 0,
    useDefaultStyles: false,
    useHover: true,
    zIndex: 1e3,
    onToggle: void 0,
    arrowContent: null
  });
  var _default = Tooltip;
  exports["default"] = _default;
}, function(module, exports, __webpack_require__) {
  var map = {
    "./action-types.js": 13,
    "./assets.js": 14,
    "./custom-event-types.js": 15,
    "./extension-origin.js": 16,
    "./index.js": 1,
    "./message-types.js": 17,
    "./others.js": 18
  };
  function webpackContext(req) {
    var id = webpackContextResolve(req);
    return __webpack_require__(id);
  }
  function webpackContextResolve(req) {
    if (!__webpack_require__.o(map, req)) {
      var e = new Error("Cannot find module '" + req + "'");
      e.code = "MODULE_NOT_FOUND";
      throw e;
    }
    return map[req];
  }
  webpackContext.keys = function() {
    return Object.keys(map);
  };
  webpackContext.resolve = webpackContextResolve;
  module.exports = webpackContext;
  webpackContext.id = 12;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "STORAGE_READ", (function() {
    return STORAGE_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_WRITE", (function() {
    return STORAGE_WRITE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_DELETE", (function() {
    return STORAGE_DELETE;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_CHANGED", (function() {
    return STORAGE_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ", (function() {
    return SETTINGS_READ;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_READ_ALL", (function() {
    return SETTINGS_READ_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_WRITE_ALL", (function() {
    return SETTINGS_WRITE_ALL;
  }));
  __webpack_require__.d(__webpack_exports__, "SETTINGS_CHANGED", (function() {
    return SETTINGS_CHANGED;
  }));
  __webpack_require__.d(__webpack_exports__, "GET_OPTION_DEFS", (function() {
    return GET_OPTION_DEFS;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_FETCH_GET", (function() {
    return PROXIED_FETCH_GET;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_AUDIO", (function() {
    return PROXIED_AUDIO;
  }));
  __webpack_require__.d(__webpack_exports__, "PROXIED_CREATE_TAB", (function() {
    return PROXIED_CREATE_TAB;
  }));
  const STORAGE_READ = "STORAGE_READ";
  const STORAGE_WRITE = "STORAGE_WRITE";
  const STORAGE_DELETE = "STORAGE_DELETE";
  const STORAGE_CHANGED = "STORAGE_CHANGED";
  const SETTINGS_READ = "SETTINGS_READ";
  const SETTINGS_READ_ALL = "SETTINGS_READ_ALL";
  const SETTINGS_WRITE_ALL = "SETTINGS_WRITE_ALL";
  const SETTINGS_CHANGED = "SETTINGS_CHANGED";
  const GET_OPTION_DEFS = "GET_OPTION_DEFS";
  const PROXIED_FETCH_GET = "PROXIED_FETCH_GET";
  const PROXIED_AUDIO = "PROXIED_AUDIO";
  const PROXIED_CREATE_TAB = "PROXIED_CREATE_TAB";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "ASSET_CLASSNAME", (function() {
    return ASSET_CLASSNAME;
  }));
  const ASSET_CLASSNAME = "sf-asset";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BRIDGE_EVENT_TYPE", (function() {
    return BRIDGE_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "POST_STATUS_SUCCESS_EVENT_TYPE", (function() {
    return POST_STATUS_SUCCESS_EVENT_TYPE;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_UNLOADED_EVENT_TYPE", (function() {
    return EXTENSION_UNLOADED_EVENT_TYPE;
  }));
  const BRIDGE_EVENT_TYPE = "SpaceFanfouBridgeMessage";
  const POST_STATUS_SUCCESS_EVENT_TYPE = "SpaceFanfouPostStatusSuccess";
  const EXTENSION_UNLOADED_EVENT_TYPE = "SpaceFanfouUnloaded";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "EXTENSION_ORIGIN_PLACEHOLDER_RE", (function() {
    return EXTENSION_ORIGIN_PLACEHOLDER_RE;
  }));
  const EXTENSION_ORIGIN_PLACEHOLDER = "<EXTENSION_ORIGIN_PLACEHOLDER>";
  const EXTENSION_ORIGIN_PLACEHOLDER_RE = new RegExp(EXTENSION_ORIGIN_PLACEHOLDER, "g");
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "BROADCASTING_MESSAGE", (function() {
    return BROADCASTING_MESSAGE;
  }));
  __webpack_require__.d(__webpack_exports__, "CONVERSATIONAL_MESSAGE", (function() {
    return CONVERSATIONAL_MESSAGE;
  }));
  const BROADCASTING_MESSAGE = "BROADCASTING_MESSAGE";
  const CONVERSATIONAL_MESSAGE = "CONVERSATIONAL_MESSAGE";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  __webpack_require__.d(__webpack_exports__, "CONTROL_PLACEHOLDER", (function() {
    return CONTROL_PLACEHOLDER;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_KEY_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_KEY_IS_EXTENSION_UPGRADED;
  }));
  __webpack_require__.d(__webpack_exports__, "STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED", (function() {
    return STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED;
  }));
  const CONTROL_PLACEHOLDER = "<CONTROL_PLACEHOLDER>";
  const STORAGE_KEY_IS_EXTENSION_UPGRADED = "is-extension-upgraded";
  const STORAGE_AREA_NAME_IS_EXTENSION_UPGRADED = "session";
}, function(module, exports, __webpack_require__) {
  "use strict";
  const ansiRegex = __webpack_require__(20);
  module.exports = string => "string" === typeof string ? string.replace(ansiRegex(), "") : string;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = ({onlyFirst = false} = {}) => {
    const pattern = [ "[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)", "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-ntqry=><~]))" ].join("|");
    return new RegExp(pattern, onlyFirst ? void 0 : "g");
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  const isFullwidthCodePoint = codePoint => {
    if (Number.isNaN(codePoint)) return false;
    if (codePoint >= 4352 && (codePoint <= 4447 || 9001 === codePoint || 9002 === codePoint || 11904 <= codePoint && codePoint <= 12871 && 12351 !== codePoint || 12880 <= codePoint && codePoint <= 19903 || 19968 <= codePoint && codePoint <= 42182 || 43360 <= codePoint && codePoint <= 43388 || 44032 <= codePoint && codePoint <= 55203 || 63744 <= codePoint && codePoint <= 64255 || 65040 <= codePoint && codePoint <= 65049 || 65072 <= codePoint && codePoint <= 65131 || 65281 <= codePoint && codePoint <= 65376 || 65504 <= codePoint && codePoint <= 65510 || 110592 <= codePoint && codePoint <= 110593 || 127488 <= codePoint && codePoint <= 127569 || 131072 <= codePoint && codePoint <= 262141)) return true;
    return false;
  };
  module.exports = isFullwidthCodePoint;
  module.exports.default = isFullwidthCodePoint;
}, function(module, exports, __webpack_require__) {
  "use strict";
  module.exports = function() {
    return /\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F|\uD83D\uDC68(?:\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68\uD83C\uDFFB|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFE])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|[\u2695\u2696\u2708]\uFE0F|\uD83D[\uDC66\uDC67]|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|(?:\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708])\uFE0F|\uD83C\uDFFB\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C[\uDFFB-\uDFFF])|(?:\uD83E\uDDD1\uD83C\uDFFB\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)\uD83C\uDFFB|\uD83E\uDDD1(?:\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1)|(?:\uD83E\uDDD1\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDD1D\u200D(?:\uD83D[\uDC68\uDC69]))(?:\uD83C[\uDFFB-\uDFFE])|(?:\uD83E\uDDD1\uD83C\uDFFC\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB\uDFFC])|\uD83D\uDC69(?:\uD83C\uDFFE\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB-\uDFFD\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFC\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFD-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFB\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFC-\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFD\u200D(?:\uD83E\uDD1D\u200D\uD83D\uDC68(?:\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD])|\uD83C\uDFFF\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDAF-\uDDB3\uDDBC\uDDBD]))|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|(?:\uD83E\uDDD1\uD83C\uDFFD\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1|\uD83D\uDC69\uD83C\uDFFE\u200D\uD83E\uDD1D\u200D\uD83D\uDC69)(?:\uD83C[\uDFFB-\uDFFD])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C\uDFFF\u200D[\u2695\u2696\u2708]|\uD83C\uDFFE\u200D[\u2695\u2696\u2708]|\uD83C\uDFFC\u200D[\u2695\u2696\u2708]|\uD83C\uDFFB\u200D[\u2695\u2696\u2708]|\uD83C\uDFFD\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83C\uDFF4\u200D\u2620)\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC15\u200D\uD83E\uDDBA|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83C\uDDF6\uD83C\uDDE6|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83E\uDDD1(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD-\uDDCF\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDBB\uDDD2-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5\uDEEB\uDEEC\uDEF4-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])|(?:[#\*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDED5\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEFA\uDFE0-\uDFEB]|\uD83E[\uDD0D-\uDD3A\uDD3C-\uDD45\uDD47-\uDD71\uDD73-\uDD76\uDD7A-\uDDA2\uDDA5-\uDDAA\uDDAE-\uDDCA\uDDCD-\uDDFF\uDE70-\uDE73\uDE78-\uDE7A\uDE80-\uDE82\uDE90-\uDE95])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDC8F\uDC91\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD0F\uDD18-\uDD1F\uDD26\uDD30-\uDD39\uDD3C-\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDBB\uDDCD-\uDDCF\uDDD1-\uDDDD])/g;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var ReactPropTypesSecret = __webpack_require__(24);
  function emptyFunction() {}
  function emptyFunctionWithReset() {}
  emptyFunctionWithReset.resetWarningCache = emptyFunction;
  module.exports = function() {
    function shim(props, propName, componentName, location, propFullName, secret) {
      if (secret === ReactPropTypesSecret) return;
      var err = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
      err.name = "Invariant Violation";
      throw err;
    }
    shim.isRequired = shim;
    function getShim() {
      return shim;
    }
    var ReactPropTypes = {
      array: shim,
      bigint: shim,
      bool: shim,
      func: shim,
      number: shim,
      object: shim,
      string: shim,
      symbol: shim,
      any: shim,
      arrayOf: getShim,
      element: shim,
      elementType: shim,
      instanceOf: getShim,
      node: shim,
      objectOf: getShim,
      oneOf: getShim,
      oneOfType: getShim,
      shape: getShim,
      exact: getShim,
      checkPropTypes: emptyFunctionWithReset,
      resetWarningCache: emptyFunction
    };
    ReactPropTypes.PropTypes = ReactPropTypes;
    return ReactPropTypes;
  };
}, function(module, exports, __webpack_require__) {
  "use strict";
  var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  module.exports = ReactPropTypesSecret;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = exports.isBrowser = void 0;
  var _react = _interopRequireDefault(__webpack_require__(2));
  var _propTypes = _interopRequireDefault(__webpack_require__(6));
  var _reactDom = _interopRequireDefault(__webpack_require__(2));
  function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
      default: obj
    };
  }
  function _typeof(obj) {
    if ("function" === typeof Symbol && "symbol" === typeof Symbol.iterator) _typeof = function(obj) {
      return typeof obj;
    }; else _typeof = function(obj) {
      return obj && "function" === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
    return _typeof(obj);
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && ("object" === _typeof(call) || "function" === typeof call)) return call;
    return _assertThisInitialized(self);
  }
  function _assertThisInitialized(self) {
    if (void 0 === self) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return self;
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _inherits(subClass, superClass) {
    if ("function" !== typeof superClass && null !== superClass) throw new TypeError("Super expression must either be null or a function");
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  var useCreatePortal = "function" === typeof _reactDom["default"].createPortal;
  var isBrowser = "undefined" !== typeof window;
  exports.isBrowser = isBrowser;
  var Portal = function(_React$Component) {
    _inherits(Portal, _React$Component);
    function Portal(props) {
      var _this;
      _classCallCheck(this, Portal);
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Portal).call(this, props));
      if (isBrowser) {
        _this.container = document.createElement("div");
        document.body.appendChild(_this.container);
        _this.renderLayer();
      }
      return _this;
    }
    _createClass(Portal, [ {
      key: "componentDidUpdate",
      value: function() {
        this.renderLayer();
      }
    }, {
      key: "componentWillUnmount",
      value: function() {
        if (!useCreatePortal) _reactDom["default"].unmountComponentAtNode(this.container);
        document.body.removeChild(this.container);
      }
    }, {
      key: "renderLayer",
      value: function() {
        if (!useCreatePortal) _reactDom["default"].unstable_renderSubtreeIntoContainer(this, this.props.children, this.container);
      }
    }, {
      key: "render",
      value: function() {
        if (useCreatePortal) return _reactDom["default"].createPortal(this.props.children, this.container);
        return null;
      }
    } ]);
    return Portal;
  }(_react["default"].Component);
  Portal.propTypes = {
    children: _propTypes["default"].node.isRequired
  };
  var _default = Portal;
  exports["default"] = _default;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports["default"] = getDirection;
  var _functions = __webpack_require__(4);
  function checkLeftRightWidthSufficient(tip, target, distance, bodyPadding) {
    var targetRect = target.getBoundingClientRect();
    var deadSpace = Math.min(targetRect.left, document.documentElement.clientWidth - targetRect.right);
    return tip.offsetWidth + target.offsetWidth + distance + bodyPadding + deadSpace < document.documentElement.clientWidth;
  }
  function checkTargetSufficientlyVisible(target, tip, props) {
    var targetRect = target.getBoundingClientRect();
    var bottomOverhang = targetRect.bottom > window.innerHeight;
    var topOverhang = targetRect.top < 0;
    if (topOverhang && bottomOverhang) return true;
    if (target.offsetHeight > tip.offsetHeight) {
      var halfTargetHeight = target.offsetHeight / 2;
      var arrowClearance = props.arrowSize + _functions.minArrowPadding;
      var bottomOverhangAmount = targetRect.bottom - window.innerHeight;
      var topOverhangAmount = -targetRect.top;
      var targetCenterToBottomOfWindow = halfTargetHeight - bottomOverhangAmount;
      var targetCenterToTopOfWindow = halfTargetHeight - topOverhangAmount;
      return targetCenterToBottomOfWindow >= arrowClearance && targetCenterToTopOfWindow >= arrowClearance;
    }
    return !bottomOverhang && !topOverhang;
  }
  function checkForArrowOverhang(props, arrowStyles, bodyPadding) {
    var scrollLeft = (0, _functions.getScrollLeft)();
    var hasLeftClearance = arrowStyles.positionStyles.left - scrollLeft > bodyPadding;
    var hasRightClearance = arrowStyles.positionStyles.left + 2 * props.arrowSize < scrollLeft + document.documentElement.clientWidth - bodyPadding;
    return !hasLeftClearance || !hasRightClearance;
  }
  function getDirection(currentDirection, tip, target, props, bodyPadding, arrowStyles, recursive) {
    if (!target) return currentDirection;
    var targetRect = target.getBoundingClientRect();
    var arrowSpacing = (0, _functions.getArrowSpacing)(props);
    var heightOfTipWithArrow = tip.offsetHeight + arrowSpacing + bodyPadding;
    var spaceBelowTarget = window.innerHeight - targetRect.bottom;
    var spaceAboveTarget = targetRect.top;
    var hasSpaceBelow = spaceBelowTarget >= heightOfTipWithArrow;
    var hasSpaceAbove = spaceAboveTarget >= heightOfTipWithArrow;
    switch (currentDirection) {
     case "right":
      if (!checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding) || !checkTargetSufficientlyVisible(target, tip, props)) return getDirection("up", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (document.documentElement.clientWidth - targetRect.right < tip.offsetWidth + arrowSpacing + bodyPadding) return "left";
      return "right";

     case "left":
      if (!checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding) || !checkTargetSufficientlyVisible(target, tip, props)) return getDirection("up", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (targetRect.left < tip.offsetWidth + arrowSpacing + bodyPadding) return "right";
      return "left";

     case "up":
      if (!recursive && arrowStyles && checkForArrowOverhang(props, arrowStyles, bodyPadding)) return getDirection("left", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (!hasSpaceAbove) {
        if (hasSpaceBelow) return "down";
        if (!recursive && checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      }
      return "up";

     case "down":
     default:
      if (!recursive && arrowStyles && checkForArrowOverhang(props, arrowStyles, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      if (!hasSpaceBelow) {
        if (hasSpaceAbove) return "up";
        if (!recursive && checkLeftRightWidthSufficient(tip, target, arrowSpacing, bodyPadding)) return getDirection("right", tip, target, arrowSpacing, bodyPadding, arrowStyles, true);
      }
      return "down";
    }
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var preact_module = __webpack_require__(0);
  var is_promise = __webpack_require__(8);
  var is_promise_default = __webpack_require__.n(is_promise);
  var constants = __webpack_require__(1);
  var extensionUnloaded = {
    trigger() {
      const event = new CustomEvent(constants["EXTENSION_UNLOADED_EVENT_TYPE"]);
      window.dispatchEvent(event);
    },
    addListener(fn) {
      window.addEventListener(constants["EXTENSION_UNLOADED_EVENT_TYPE"], fn, {
        once: true
      });
    }
  };
  var noop = () => {};
  function toBooleanPromise(x) {
    return "boolean" === typeof x ? x : is_promise_default()(x) ? x.then(toBooleanPromise) : Promise.resolve(true);
  }
  var wrapper = module => {
    let promise;
    const {install = noop, uninstall = noop, ...rest} = module;
    extensionUnloaded.addListener(uninstall);
    return {
      ...rest,
      ready() {
        return promise || (promise = toBooleanPromise(install()));
      }
    };
  };
  class Deferred {
    constructor() {
      this.promise = new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
      Object.freeze(this);
    }
  }
  var defined = __webpack_require__(5);
  var defined_default = __webpack_require__.n(defined);
  let outputLevel = 1;
  if (true) outputLevel = 2;
  function log(level, logger, ...message) {
    if (level >= outputLevel) logger("[SpaceFanfou]", ...message);
  }
  var libs_log = {
    debug(...message) {
      log(0, console.log, ...message);
    },
    info(...message) {
      log(1, console.log, ...message);
    },
    error(...message) {
      log(2, console.error, ...message);
    }
  };
  function defaultExceptionHandler(error) {
    libs_log.error(error);
  }
  var safelyInvokeFn = opts => {
    let fn;
    if ("function" === typeof opts) {
      fn = opts;
      opts = {};
    } else fn = opts.fn;
    const exceptionHandler = defined_default()(opts.exceptionHandler, defaultExceptionHandler);
    const args = defined_default()(opts.args, []);
    try {
      fn(...args);
    } catch (error) {
      exceptionHandler(error);
    }
  };
  var safelyInvokeFns = opts => {
    if (Array.isArray(opts)) opts = {
      fns: opts
    };
    const {fns, ...restOpts} = opts;
    for (const fn of fns) safelyInvokeFn({
      fn,
      ...restOpts
    });
  };
  var arrayUniquePush = (array, element) => {
    if (!array.includes(element)) array.push(element);
  };
  var arrayRemove = (array, element) => {
    const index = array.indexOf(element);
    if (-1 !== index) array.splice(index, 1);
  };
  let port;
  let id = 0;
  const deferreds = {};
  const broadcastListeners = [];
  function onMessage({type, senderId, message}) {
    if (type === constants["BROADCASTING_MESSAGE"]) messaging.broadcast(message); else if (null != senderId) {
      const d = deferreds[senderId];
      d.resolve(message);
      delete deferreds[senderId];
    }
  }
  function onDisconnect() {
    extensionUnloaded.trigger();
  }
  const messaging = wrapper({
    install() {
      port = chrome.runtime.connect();
      port.onMessage.addListener(onMessage);
      port.onDisconnect.addListener(onDisconnect);
    },
    uninstall() {
      port = null;
      broadcastListeners.length = 0;
    },
    registerBroadcastListener(fn) {
      arrayUniquePush(broadcastListeners, fn);
    },
    unregisterBroadcastListener(fn) {
      arrayRemove(broadcastListeners, fn);
    },
    broadcast(message) {
      safelyInvokeFns({
        fns: broadcastListeners,
        args: [ message ]
      });
    },
    postMessage(message) {
      const senderId = id++;
      const d = deferreds[senderId] = new Deferred;
      port.postMessage({
        senderId,
        message
      });
      return d.promise;
    }
  });
  var environment_messaging = messaging;
  const settings = wrapper({
    async install() {
      await environment_messaging.ready();
    },
    readAll() {
      return environment_messaging.postMessage({
        action: constants["SETTINGS_READ_ALL"]
      });
    }
  });
  var environment_settings = settings;
  var classnames = __webpack_require__(3);
  var classnames_default = __webpack_require__.n(classnames);
  var index_esm_arrayRemove = remove;
  function remove(arr1, arr2) {
    if (!Array.isArray(arr1) || !Array.isArray(arr2)) throw new Error("expected both arguments to be arrays");
    var result = [];
    var len = arr1.length;
    for (var i = 0; i < len; i++) {
      var elem = arr1[i];
      if (-1 == arr2.indexOf(elem)) result.push(elem);
    }
    return result;
  }
  var split_lines = __webpack_require__(9);
  var split_lines_default = __webpack_require__.n(split_lines);
  var string_width = __webpack_require__(10);
  var string_width_default = __webpack_require__.n(string_width);
  const MAX_CONTINOUS_BLANK_LINE_NUMBER = 1;
  const MAX_SUMMARY_LENGTH = 120;
  var parseVersionHistory = rawVersionHistory => {
    const lines = split_lines_default()(rawVersionHistory);
    const parsed = [];
    let currentLine;
    let continousBlankLineNumber = 0;
    let currentVersionItem;
    while (lines.length) {
      currentLine = lines.shift().trim();
      if (!currentLine) if (++continousBlankLineNumber > MAX_CONTINOUS_BLANK_LINE_NUMBER) throw new Error(`连续空行不该超过 ${MAX_CONTINOUS_BLANK_LINE_NUMBER} 行`); else continue;
      continousBlankLineNumber = 0;
      if (currentLine.startsWith("#")) continue;
      if (currentLine.startsWith("v")) {
        const versionTag = currentLine.slice(1);
        currentVersionItem = {
          version: versionTag,
          releaseDate: "0000-00-00",
          summary: "",
          updateDetails: []
        };
        parsed.push(currentVersionItem);
        continue;
      }
      if (currentLine.startsWith("@")) {
        const releaseDate = currentLine.slice(1);
        currentVersionItem.releaseDate = releaseDate;
        continue;
      }
      if (currentLine.startsWith("~ ")) {
        const summary = currentLine.slice(2);
        if (string_width_default()(summary) > MAX_SUMMARY_LENGTH) throw new Error(`摘要不该长于 ${MAX_SUMMARY_LENGTH} 字`);
        currentVersionItem.summary = summary;
        continue;
      }
      if (currentLine.startsWith("- ")) {
        const updateDetail = currentLine.slice(2);
        currentVersionItem.updateDetails.push(updateDetail);
        continue;
      }
      throw new Error("无法识别：" + currentLine);
    }
    return parsed;
  };
  var versionHistory = "# 参见 /docs/publish.md\n\nv1.0.0\n@2019-09-12\n~ 这次版本更新完全重写了代码，带来了云同步功能，并且在功能、样式和用户体验方面作了大量改进。\n- 用户设置和其他扩展数据支持云同步\n- 发送消息彻底 AJAX 化，大幅优化了发送消息和上传图片的用户体验\n- 优化饭友关注关系检查速度\n- 右键菜单分享功能支持分享图片\n- 改进及增加更多快捷键支持（T 键全局支持返回页首；←/→ 键控制翻页；Enter 键使输入框聚焦；Esc 键使输入框失焦）\n- 多用户切换列表按照使用历史排序\n- 有爱饭友支持拖拽排序\n- 定时刷新时间戳显示\n- 更换了 Timeline 新未读消息提示音\n- 改进了对 HiDPI 显示器的支持\n- 发送或删除消息后，更新侧栏的统计数字\n- 改进了关闭用户自定义模板功能，现在可以应用到更多页面\n- 加快功能加载的速度\n- 大量功能、样式和用户体验方面的问题修正与改进\n\nv0.9.7.2\n@2017-08-19\n- 针对 HiDPI 显示器进行优化\n\nv0.9.6.2\n@2017-06-28\n- 修正对虾米音乐的支持，添加对网易云音乐的支持（暂时只支持 HTTP）\n\nv0.9.6.0\n@2017-06-26\n- 启用全新样式\n- 支持饭否 HTTPS 页面\n- 细节改进\n\nv0.9.3.5\n@2014-08-14\n- 修正对美团云图片的支持\n\nv0.9.2.6\n@2014-03-31\n- 新增批量管理好友关注请求功能\n\nv0.9.2.2\n@2014-03-11\n- 消息内容支持换行\n- 新增「背景图片自适应窗口大小」插件\n\nv0.9.1.8\n@2014-03-03\n- 改善页面滚动性能\n- 诸多细节改进和 bugs 修正\n\nv0.9.0.2\n@2014-01-30\n- 修正当未加锁删除互相关注的粉丝时出错的 bug\n\nv0.9.0.1\n@2014-01-25\n- 修正 is.gd 短链接展开的 bug\n\nv0.9.0.0\n@2014-01-23\n- 修正虾米播放器\n- 加入 Flickr 图片预览支持\n\nv0.8.9.6\n@2014-01-15\n- 允许自定义页面右上角的用户名\n\nv0.8.9.1\n@2014-01-14\n- 自动展开短链接、为图片链接添加预览图、为虾米链接添加封面和播放器\n- 从剪贴板读取和上传图片\n- 自动隐藏页面右上角自己的名字（默认关闭）\n- 将界面中自己的名字替换为「我」（默认关闭）\n- 样式更新和细节修正\n\nv0.8.7.0\n@2013-11-20\n- 修正「Emoji 表情选择器」插件\n- 修正「自动检查关注的话题」插件\n- 修正设置页\n\nv0.8.6.7\n@2013-11-17\n- 修正「Emoji 表情选择器」插件\n\nv0.8.6.4\n@2013-11-09\n- 修正「多用户切换」插件\n\nv0.8.6.3\n@2013-11-07\n- 启用全新设计的设置页和 logo\n\nv0.8.6.1\n@2013-11-04\n- 修正「经典饭否 logo」插件\n\nv0.8.5.7\n@2013-11-01\n- 允许彻底屏蔽随机应用推荐（不再需要手工屏蔽）\n\nv0.8.5.5\n@2013-11-01\n- 新增「自动检查关注的话题」插件\n\nv0.8.4.8\n@2013-09-28\n- 增加上传头像后自动备份的功能\n- 修正点击后退按钮后 Timeline 中 AJAX 加载的消息丢失的 bug\n- 细节更新\n\nv0.8.4.4\n@2013-09-09\n- 更新「展开转发和回复消息」插件\n- 修正图片放大功能\n- 细节更新\n\nv0.8.4.0\n@2013-08-29\n- 修正样式\n\nv0.8.3.8\n@2013-08-17\n- 修正「浮动输入框」插件样式 bug\n- 修正「转发自己消息」插件 bug\n\nv0.8.3.6\n@2013-08-06\n- 消息通知插件允许不同时检查新@消息数量和新私信数量（请参见设置页）\n\nv0.8.3.5\n@2013-08-01\n- 样式更新\n- 细节更新\n\nv0.8.3.0\n@2013-07-11\n- 修正「好友关系检查」插件\n\nv0.8.2.9\n@2013-07-10\n- 新增「好友关系检查」插件\n\nv0.8.2.8\n@2013-07-09\n- 修正「转发自己消息」插件\n- 更新「Emoji 表情选择器」插件\n\nv0.8.2.5\n@2013-07-09\n- 新增「Emoji 表情选择器」\n- 样式更新\n- 细节更新\n\nv0.8.1.6\n@2013-06-29\n- 新增太空饭否版@自动补全功能\n- 修正「Emoji 表情选择器」插件\n\nv0.8.1.4\n@2013-06-24\n- 修正「Emoji 表情选择器」插件\n\nv0.8.1.3\n@2013-06-23\n- 新增 Emoji 表情支持\n\nv0.8.1.0\n@2013-05-09\n- 新增「统计数字字体样式切换」插件\n- 修正页码撑大页面的 bug\n- 更新「侧栏详细统计信息」插件\n- 细节更新\n\nv0.7.5.2\n@2013-02-27\n- 更新「侧栏详细统计信息」插件: 解决偶尔加载失败的问题\n\nv0.7.5.0\n@2013-02-21\n- 更新和添加设置页截图\n\nv0.7.4.8\n@2013-02-17\n- 首次启动显示欢迎提示\n\nv0.7.4.7\n@2013-02-13\n- 新增「未读消息处理」插件（详见设置页）\n- 更新「浮动输入框」插件\n- 更新「批量消息处理」插件\n- 更新「自动翻页」插件\n- 新增「提醒用户评分」插件\n- 细节更新\n\nv0.7.4.0\n@2012-12-27\n- bug 修正\n\nv0.7.3.6\n@2012-12-23\n- 修正圣诞帽错位问题\n- 设置页添加关闭圣诞帽效果功能\n\nv0.7.3.4\n@2012-12-20\n- 2012 圣诞节彩蛋\n\nv0.7.3.1\n@2012-12-16\n- 修正侧栏模块无法折叠的问题\n\nv0.7.2.9\n@2012-11-15\n- bug 修正\n- 更新「自动翻页」插件\n\nv0.7.2.7\n@2012-11-15\n- 细节更新\n- 更新「浮动输入框」插件\n\nv0.7.1.6\n@2012-08-24\n- 更新「屏蔽随机应用推荐和饭否应用广告」插件\n- 更新设置页\n\nv0.7.1.4\n@2012-08-23\n- 细节更新\n- 更新「屏蔽随机应用推荐和饭否应用广告」插件\n\nv0.7.0.4\n@2012-07-29\n- 修正「展开转发和回复消息」插件\n\nv0.7.0.0\n@2012-07-21\n- 细节更新\n- 多处 bugs 修正\n- 性能优化\n\nv0.6.9.0\n@2012-07-01\n- 新增「有爱饭友列表」插件\n- 多处样式更新和 bugs 修正\n\nv0.6.8.2\n@2012-06-23\n- 修正「浮动输入框」插件拖拽图片上传功能\n- 细节更新\n\nv0.6.8.0\n@2012-06-21\n- 修正部分未读消息不显示的问题\n- 修正「浮动输入框」插件开启后不能传图的问题\n- 改进加载方式\n- 新增「消息批量管理」插件\n- 「侧栏详细统计信息」插件添加查看背景图片功能\n- 多处样式更新和 bugs 修正\n\nv0.6.7.0\n@2012-06-04\n- 更换插件加载原理，提升性能\n- 增加向上滚动滚轮后自动点击「显示新增 X 条新消息」功能\n- 修正「侧栏详细统计信息」插件\n- 修正更改设置项后不能及时生效的问题\n- 细节更新\n\nv0.6.6.3\n@2012-05-31\n- 优化「返回顶部」功能和页面滚动性能\n- 样式更新\n- 更新「侧栏统计信息」插件\n\nv0.6.6.0\n@2012-05-30\n- 新增通知插件（具体功能见设置页）\n- 更新设置页\n";
  var version_history = parseVersionHistory(versionHistory);
  class VersionHistory_VersionHistory extends preact_module["a"] {
    render() {
      return Object(preact_module["g"])("div", {
        id: "version-history"
      }, version_history.map(this.renderVersionUpdateDetails, this));
    }
    renderVersionUpdateDetails({version, releaseDate, updateDetails}) {
      return Object(preact_module["g"])("div", {
        key: "version-" + version
      }, this.renderVersionAndReleaseDate({
        version,
        releaseDate
      }), this.renderUpdateDetails(updateDetails));
    }
    renderVersionAndReleaseDate({version, releaseDate}) {
      return Object(preact_module["g"])("h3", null, "v", version, Object(preact_module["g"])("span", {
        className: "sub"
      }, "（", releaseDate, "）"));
    }
    renderUpdateDetails(updateDetails) {
      return Object(preact_module["g"])("ul", null, updateDetails.map(this.renderUpdateDetail, this));
    }
    renderUpdateDetail(updateDetail, index) {
      return Object(preact_module["g"])("li", {
        key: index
      }, updateDetail);
    }
  }
  class ExternalLink_ExternalLink extends preact_module["a"] {
    render() {
      const {url, text, className, children} = this.props;
      return Object(preact_module["g"])("a", {
        href: url,
        target: "_blank",
        className
      }, text || children);
    }
  }
  var getExtensionVersion = () => {
    const {version, version_name: name} = chrome.runtime.getManifest();
    return name || version;
  };
  const URL_OFFICIAL_FANFOU = "https://fanfou.com/spacefanfou";
  const URL_GITHUB = "https://github.com/fanfoujs/space-fanfou";
  const URL_HANDBOOK_FOR_BEGINNERS = "https://spacekid.me/spacefanfou/";
  const URL_ISSUES = "https://fanfou.com/home?status=%40%E9%94%90%E9%A3%8E%20%40%E5%A4%AA%E7%A9%BA%E5%B0%8F%E5%AD%A9%20%E6%88%91%E5%8F%91%E7%8E%B0%E4%BA%86%E5%A4%AA%E7%A9%BA%E9%A5%AD%E5%90%A6%E7%9A%84%E4%B8%80%E4%B8%AA%E9%97%AE%E9%A2%98%3A";
  const URL_SHARE = "https://fanfou.com/sharer?u=http%3A%2F%2Fis.gd%2Fsfanfou?t=%E5%A4%AA%E7%A9%BA%E9%A5%AD%E5%90%A6%20-%20Chrome%20%E7%BD%91%E4%B8%8A%E5%BA%94%E7%94%A8%E5%BA%97?d=%E5%90%91%E5%A4%A7%E5%AE%B6%E6%8E%A8%E8%8D%90%E5%A4%AA%E7%A9%BA%E9%A5%AD%E5%90%A6%EF%BC%8C%E8%B6%85%E5%BC%BA%E5%A4%A7%E7%9A%84%E9%A5%AD%E5%90%A6%20Chrome%20%E6%B5%8F%E8%A7%88%E5%99%A8%E6%89%A9%E5%B1%95%E7%A8%8B%E5%BA%8F%E3%80%82?s=bl";
  const ICON_SIZE = 48;
  const getFanfouUserProfileUrl = id => "https://fanfou.com/" + id;
  const authors = [ {
    id: "anegie",
    nickname: "太空小孩",
    avatar: "https://s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/3c/7j.jpg",
    desc: Object(preact_module["g"])("span", null, "太空饭否创始人。饭否全新页面外观的主要设计者。", Object(preact_module["g"])("br", null), "目前负责太空饭否少量开发和维护工作。")
  }, {
    id: "ruif",
    nickname: "锐风",
    avatar: "https://s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/34/d8.jpg",
    desc: Object(preact_module["g"])("span", null, "太空饭否主要开发者。饭否全新页面功能的主要创造者。", Object(preact_module["g"])("br", null), "目前负责太空饭否主要开发和维护工作。")
  }, {
    id: "lito",
    nickname: "饭小默",
    avatar: "https://s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/9f/1m.jpg",
    desc: Object(preact_module["g"])("span", null, "太空饭否开发者。饭否全新图标的主要设计者。", Object(preact_module["g"])("br", null), "目前负责太空饭否主要开发和维护工作。")
  }, {
    id: "xidorn",
    nickname: "Xidorn",
    avatar: "https://s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/vq/0q.jpg",
    desc: Object(preact_module["g"])("span", null, "太空饭否主要开发者。饭否全新页面功能的主要创造者。", Object(preact_module["g"])("br", null), "目前已经退出开发工作。")
  }, {
    id: "zhasm",
    nickname: ".rex",
    avatar: "https://s3.meituan.net/v1/mss_3d027b52ec5a4d589e68050845611e68/avatar/l0/00/57/sg.jpg",
    desc: Object(preact_module["g"])("span", null, "太空饭否协作开发者。", Object(preact_module["g"])("br", null), "目前负责太空饭否 Chrome 应用商店的疑难解答工作。")
  } ];
  const HelpAndSupport_sections = [ {
    title: "太空饭否",
    items: [ {
      icon: "icons/icon-256.png",
      url: URL_OFFICIAL_FANFOU,
      title: Object(preact_module["g"])("span", null, Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "官方饭否",
        url: URL_OFFICIAL_FANFOU
      }), " - ", Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "入门手册",
        url: URL_HANDBOOK_FOR_BEGINNERS
      }), " - ", Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "开源项目",
        url: URL_GITHUB
      }), " - ", Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "报告问题",
        url: URL_ISSUES
      })),
      desc: "版本 " + getExtensionVersion()
    } ]
  }, {
    title: "太空饭否开发组",
    items: authors.map(author => ({
      icon: author.avatar,
      url: getFanfouUserProfileUrl(author.id),
      title: Object(preact_module["g"])("span", null, Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: author.nickname,
        url: getFanfouUserProfileUrl(author.id)
      }), " (", author.id, ")"),
      desc: author.desc
    }))
  } ];
  class HelpAndSupport_HelpAndSupport extends preact_module["a"] {
    render() {
      return Object(preact_module["g"])("div", null, HelpAndSupport_sections.map(this.renderSection, this), this.renderFooter());
    }
    renderSection(section) {
      return Object(preact_module["g"])("div", {
        key: section.title
      }, Object(preact_module["g"])("h3", null, section.title), section.items.map(this.renderItem, this));
    }
    renderItem({icon, url, title, desc}) {
      return Object(preact_module["g"])("div", {
        key: url
      }, Object(preact_module["g"])("div", {
        className: "left"
      }, Object(preact_module["g"])(ExternalLink_ExternalLink, {
        url,
        className: "avatar"
      }, Object(preact_module["g"])("img", {
        src: icon,
        width: ICON_SIZE,
        height: ICON_SIZE
      }))), Object(preact_module["g"])("div", {
        className: "info left"
      }, Object(preact_module["g"])("h4", null, title), Object(preact_module["g"])("div", {
        className: "desc"
      }, desc)), Object(preact_module["g"])("div", {
        className: "clear"
      }));
    }
    renderFooter() {
      return Object(preact_module["g"])("footer", null, "版权所有 © 2011-", (new Date).getFullYear(), " ", Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "太空饭否开发组",
        url: URL_GITHUB
      }), "。保留所有权利。", Object(preact_module["g"])("br", null), "如果你喜欢太空饭否，可以", Object(preact_module["g"])(ExternalLink_ExternalLink, {
        text: "推荐太空饭否",
        url: URL_SHARE
      }), Object(preact_module["g"])("a", {
        href: "",
        target: "_blank"
      }), "给你的饭友。", Object(preact_module["g"])("br", null));
    }
  }
  const tabDefs = [ {
    title: "页面功能",
    sections: [ {
      title: "Timeline 时间线",
      options: [ "show-contextual-statuses", "enrich-statuses", "auto-pager", "process-unread-statuses" ]
    }, {
      title: "输入框",
      options: [ "floating-status-form" ]
    }, {
      title: "侧栏",
      options: [ "favorite-fanfouers", "check-saved-searches" ]
    }, {
      title: "批量管理",
      options: [ "batch-remove-statuses", "batch-remove-private-messages", "batch-manage-relationships" ]
    }, {
      title: "其他",
      options: [ "check-friendship" ]
    } ]
  }, {
    title: "页面外观",
    sections: [ {
      title: "功能",
      options: [ "remove-personalized-theme", "remove-app-recommendations" ]
    }, {
      title: "细节",
      options: [ "translucent-sidebar", "box-shadows", "remove-logo-beta" ]
    } ]
  }, {
    title: "工具",
    sections: [ {
      title: "桌面通知",
      options: [ "notifications" ]
    }, {
      title: "右键菜单",
      options: [ "share-to-fanfou" ]
    } ]
  }, {
    title: "更新历史",
    children: Object(preact_module["g"])(VersionHistory_VersionHistory, null)
  }, {
    title: "帮助与支持",
    children: Object(preact_module["g"])(HelpAndSupport_HelpAndSupport, null)
  } ];
  var getTabDefs = async () => {
    await environment_messaging.ready();
    const optionDefs = await environment_messaging.postMessage({
      action: constants["GET_OPTION_DEFS"]
    });
    const a = Object.keys(optionDefs);
    const b = [];
    for (const tabDef of tabDefs) {
      if (!tabDef.sections) continue;
      for (const section of tabDef.sections) {
        b.push(...section.options);
        section.options = section.options.map(featureName => optionDefs[featureName]);
      }
    }
    const x = index_esm_arrayRemove(a, b);
    const y = index_esm_arrayRemove(b, a);
    if (x.length) console.error("tabDefs 遗漏了部分 feature：", x); else if (y.length) console.error("tabDefs 包含了不存在的 feature：", y);
    return tabDefs;
  };
  var compat_module = __webpack_require__(2);
  var dist = __webpack_require__(11);
  var dist_default = __webpack_require__.n(dist);
  function _extends() {
    return _extends = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _extends.apply(null, arguments);
  }
  function patch() {
    const positionModule = __webpack_require__(7);
    const originalPositionFn = positionModule.default;
    positionModule.default = (...args) => {
      const result = originalPositionFn(...args);
      if ("undefined" === typeof result.tip.transform) result.tip.transform = null;
      return result;
    };
  }
  patch();
  const defaultProps = {
    arrowSize: 5,
    padding: "8px",
    distance: 10
  };
  function TooltipWithDefaultProps(props) {
    return Object(compat_module["createElement"])(dist_default.a, _extends({}, defaultProps, props));
  }
  const tooltipProps = {
    tagName: "span",
    content: "这个设置项不会被同步",
    distance: 10
  };
  class CloudSyncingDisabledTip_CloudSyncingDisabledTip extends preact_module["a"] {
    render() {
      return Object(preact_module["g"])("span", {
        className: "cloud-syncing-disabled"
      }, Object(preact_module["g"])(TooltipWithDefaultProps, tooltipProps, Object(preact_module["g"])("span", {
        className: "icon-cloud-syncing-disabled"
      })));
    }
  }
  function App_extends() {
    return App_extends = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, App_extends.apply(null, arguments);
  }
  const LAST_TAB_ID_STORAGE_KEY = "settings/lastTabId";
  let App_tabDefs;
  class App_App extends preact_module["a"] {
    constructor(...args) {
      super(...args);
      this.initBackground = () => new Promise(resolve => {
        chrome.runtime.getBackgroundPage(resolve);
      });
      this.saveSettings = async () => {
        const {optionValues} = this.state;
        await environment_messaging.postMessage({
          action: constants["SETTINGS_WRITE_ALL"],
          payload: {
            optionValues
          }
        });
      };
      this.readLastTabId = () => new Promise(resolve => {
        chrome.storage.sync.get(LAST_TAB_ID_STORAGE_KEY, values => {
          resolve(values[LAST_TAB_ID_STORAGE_KEY]);
        });
      });
      this.writeLastTabId = () => {
        this.background.chrome.storage.sync.set({
          [LAST_TAB_ID_STORAGE_KEY]: this.state.currentTabId
        });
      };
      this.renderNavagationItem = (tabDef, tabId) => {
        const {currentTabId} = this.state;
        const {title} = tabDef;
        const classNames = classnames_default()({
          current: currentTabId === tabId
        });
        const onClick = () => this.setState({
          currentTabId: tabId
        });
        return Object(preact_module["g"])("li", {
          key: tabId,
          className: classNames
        }, Object(preact_module["g"])("a", {
          onClick
        }, title));
      };
      this.renderTab = (tabDef, tabId) => {
        const {currentTabId} = this.state;
        const {title, children, sections} = tabDef;
        const classNames = classnames_default()("tab", {
          hide: tabId !== currentTabId
        });
        return Object(preact_module["g"])("div", {
          key: tabId,
          className: classNames
        }, Object(preact_module["g"])("header", null, Object(preact_module["g"])("h2", null, title)), children || sections.map(this.renderSection));
      };
      this.renderSection = (sectionDef, sectionId) => {
        const {title, options} = sectionDef;
        return Object(preact_module["g"])("section", {
          key: sectionId
        }, Object(preact_module["g"])("h3", null, title), options.map(this.renderOptionGroup));
      };
      this.renderOptionGroup = (optionDefs, optionGroupId) => Object(preact_module["g"])("ul", {
        key: optionGroupId
      }, optionDefs.map(this.renderOption));
      this.renderOption = optionDef => {
        const {key, isSubOption, parentKey, type} = optionDef;
        const classNames = classnames_default()("option", {
          "is-sub-option": isSubOption,
          hide: isSubOption && !this.getOptionValue(parentKey)
        });
        return Object(preact_module["g"])("li", {
          key,
          className: classNames
        }, "checkbox" === type && this.renderCheckbox(optionDef), "number" === type && this.renderNumberInput(optionDef), this.renderComment(optionDef), optionDef.disableCloudSyncing && Object(preact_module["g"])(CloudSyncingDisabledTip_CloudSyncingDisabledTip, null));
      };
      this.background = null;
      this.state = {
        isReady: false,
        currentTabId: 0,
        optionValues: {}
      };
      this.init();
    }
    async init() {
      const currentTabId = "#version-history" === window.location.hash ? 3 : await this.readLastTabId() || 0;
      App_tabDefs = await getTabDefs();
      this.background = await this.initBackground();
      this.setState({
        isReady: true,
        currentTabId,
        optionValues: await environment_settings.readAll()
      });
      window.addEventListener("unload", this.writeLastTabId);
    }
    render() {
      return this.state.isReady && Object(preact_module["g"])("div", {
        className: "wrapper"
      }, this.renderNavagation(), this.renderTabs());
    }
    renderNavagation() {
      return Object(preact_module["g"])("nav", null, Object(preact_module["g"])("h1", null, "太空饭否"), Object(preact_module["g"])("ul", null, App_tabDefs.map(this.renderNavagationItem)));
    }
    renderTabs() {
      return Object(preact_module["g"])("div", {
        id: "tabs"
      }, App_tabDefs.map(this.renderTab));
    }
    renderCheckbox(optionDef) {
      const {label} = optionDef;
      const controlOptions = this.getControlOptions(optionDef, "checked");
      const labelClassNames = classnames_default()({
        "is-disabled": optionDef.isSoldered
      });
      return Object(preact_module["g"])("span", {
        className: "checkbox"
      }, Object(preact_module["g"])("label", {
        className: labelClassNames
      }, Object(preact_module["g"])("input", App_extends({
        type: "checkbox"
      }, controlOptions)), Object(preact_module["g"])("span", null), label));
    }
    renderNumberInput(optionDef) {
      const [pre, post] = optionDef.label.split(constants["CONTROL_PLACEHOLDER"]);
      const controlOptions = this.getControlOptions(optionDef, "valueAsNumber");
      return Object(preact_module["g"])("label", null, pre, Object(preact_module["g"])("input", App_extends({
        type: "number"
      }, controlOptions)), post);
    }
    renderComment(optionDef) {
      const {comment} = optionDef;
      return comment && Object(preact_module["g"])("span", {
        className: "comment"
      }, comment);
    }
    getControlOptions(optionDef, valueKey) {
      const {key} = optionDef;
      const value = this.getOptionValue(key);
      const onChange = event => {
        this.setState(state => ({
          optionValues: {
            ...state.optionValues,
            [key]: event.target[valueKey]
          }
        }), this.saveSettings);
      };
      return {
        [valueKey]: value,
        disabled: optionDef.isSoldered,
        onChange,
        ...optionDef.controlOptions
      };
    }
    getOptionValue(key) {
      return this.state.optionValues[key];
    }
  }
  function renderApp() {
    Object(preact_module["j"])(Object(preact_module["g"])(App_App, null), document.getElementById("app"));
  }
  async function main() {
    await environment_settings.ready();
    renderApp();
  }
  main();
} ]);